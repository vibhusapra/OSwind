from pathlib import Path
import hashlib,json,re,math,subprocess

root=Path.cwd();base=root/'.artifacts/storage-setup-recovery-v1';run=base/'qualification-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());result=json.loads((run/'results.json').read_text())
assert len(inputs['inputFiles'])==700 and len(inputs['workingChanges'])==8
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert result['baseSource']==inputs['baseSource']=='b236b9d95af364114f0f8d455b6733f1ea5fde16'
assert result['inputManifestSHA256']==sha(run/'inputs.json') and result['runnerSHA256']==sha(base/'qualify-v1.py')
prior=json.loads((root/'benchmarks/sync-owner-response-inputs-v1.json').read_text())['inputFiles']
assert len(prior)==698 and len(set(inputs['inputFiles'])-set(prior))==2
assert sum(inputs['inputFiles'][p]==h for p,h in prior.items())==692
# XCTest output can directly follow a complete native JSON trace on the same
# line. Match exact event grammar anywhere, then require unique identities and
# the independent aggregate summary. Do not ignore missing/duplicate cases.
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def rows(text):
    found=[(a+'.'+b,c) for a,b,c in pattern.findall(text)]
    assert len(found)==len(set(a for a,b in found))
    return dict(found)
def inspect(text,expected):
    found=rows(text);assert found==expected
    counts={k:list(found.values()).count(k) for k in ['passed','failed','skipped']}
    assert counts['failed']==0 and counts['passed']>0
    summary=f"Executed {len(found)} tests, with {counts['skipped']} tests skipped and 0 failures"
    if counts['skipped']==1:summary=f'Executed {len(found)} tests, with 1 test skipped and 0 failures'
    if counts['skipped']==0:summary=f'Executed {len(found)} tests, with 0 failures'
    assert summary in text
    assert not any(s in text for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped')}
full=rows((run/'full-debug.log').read_text());assert len(full)==2743
assert list(full.values()).count('passed')==2581 and list(full.values()).count('skipped')==162
required=set()
for file in ['AtomicPrivateInboxTests.swift','VaultCredentialDiagnosticTests.swift']:
    source=(root/'Tests/OSwindCoreTests'/file).read_text()
    for className,body in re.findall(r'final class (\w+Tests):XCTestCase \{(.*?)(?=\nfinal class |\nprivate final class |\Z)',source,re.S):
        required|={'OSwindCoreTests.'+className+'.'+m for m in re.findall(r'func (test\w+)\(',body)}
assert len(required)==12
gated={'OSwindCoreTests.AtomicPrivateInboxTests.testOwnedProcessDeathBeforePublicationCleansAbandonedStageAndRetries','OSwindCoreTests.AtomicPrivateInboxTests.testOwnedAtomicInboxCrashWorker','OSwindCoreTests.NativeVaultCredentialDiagnosticTests.testActualFailedCreationRetainsNativeResultWithoutCredentialOutput'}
assert all(full[k]==('skipped' if k in gated else 'passed') for k in required)
focused='AtomicPrivateInbox|PersonalSync(Folder|Pairing|ApprovedResponse)|Backup|Vault'
owned='AtomicPrivateInboxTests|NativeVault|VaultSessionTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably'
def native_env(mode):
    parent=run/('native-'+mode)
    return {'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_ATOMIC_INBOX_CRASH':'1','OSWIND_TEST_VAULT_TRACE_DIR':str(parent/'traces'),'OSWIND_TEST_VAULT_QUERY_TRACE_DIR':str(parent/'queries'),'OSWIND_TEST_CREDENTIAL_DIAGNOSTIC_DIR':str(parent/'credential')}
expectedStages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('owned-native-tsan',['swift','test','--skip-build','--sanitize=thread','--filter',owned],native_env('tsan')),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('owned-native-optimized',['swift','test','-c','release','--skip-build','--filter',owned],native_env('optimized')),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(run/'OSwind.app')})]
assert [s['name'] for s in result['stages']]==[s[0] for s in expectedStages]
reports=[];selections={};nativeReceipts=[]
for stage,(name,command,environment) in zip(result['stages'],expectedStages):
    assert stage['command']==command and stage['environment']==environment and stage['exit']==0
    assert root/stage['log']==run/(name+'.log') and sha(root/stage['log'])==stage['sha256']
    assert math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ['debug-build-tests','release-build','package']:continue
    text=(root/stage['log']).read_text();expected=full if name=='full-debug' else {k:v for k,v in full.items() if re.search(focused if name.startswith('affected') else owned,k)}
    if name.startswith('owned'):
        observed=rows(text);assert set(observed)==set(expected)
        assert len(observed)==75 and observed=={k:('skipped' if k=='OSwindCoreTests.AtomicPrivateInboxTests.testOwnedAtomicInboxCrashWorker' else 'passed') for k in expected}
        changed={k:v for k,v in observed.items() if v!=expected[k]}
        assert all(v=='passed' and expected[k]=='skipped' for k,v in changed.items())
        methodNative={'OSwindAppTests.LibraryOpeningTests.testNativeVaultLockDuringPreparationClosesLateStoreAndDetaches','OSwindAppTests.PersonalSyncLifecycleTests.testNativeVaultLockJoinsActualSyncBeforeDetachingOwnedImage','OSwindAppTests.PersonalSyncLifecycleTests.testNativeVaultLockJoinsPendingSetupBeforeClosingItsLateSession','OSwindCoreTests.SnapshotAdmissionTests.testNativeVaultSnapshotAdmissionAndCancelledWorkPermitVerifiedDetach','OSwindCoreTests.SyncCredentialBindingTests.testOwnedNativeVaultCopyCannotReuseOriginalCredentialBinding'}
        allowed={k for k in expected if '.NativeVault' in k or k.endswith('.testOwnedProcessDeathBeforePublicationCleansAbandonedStageAndRetries') or k.endswith('.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably') or '.VaultSessionTests.' in k or k in methodNative}
        assert set(changed)<=allowed
        assert all(observed[k]=='passed' for k in methodNative)
        regressionRequired=set()
        for file,cls in [('NativeVaultCancellationTests.swift','NativeVaultCancellationTests'),('VaultDetachSettlementTests.swift','NativeVaultDetachSettlementTests')]:
            source=(root/'Tests/OSwindCoreTests'/file).read_text().split('final class '+cls+':XCTestCase')[1]
            regressionRequired|={'OSwindCoreTests.'+cls+'.'+m for m in re.findall(r'func (test\w+)\(',source)}
        assert len(regressionRequired)==7 and all(observed[k]=='passed' for k in regressionRequired)
        assert observed['OSwindCoreTests.PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably']=='passed'
        assert 'NATIVE_CANCEL_PHASE attach cycles=5 inputClosed=5 activeHelpers=5 historyChecks=5' in text
        assert 'NATIVE_CANCEL_PHASE create cycles=1 inputClosed=1 activeHelpers=1 resumed=1' in text
        assert all(observed[k]=='passed' for k in required&set(observed)-{'OSwindCoreTests.AtomicPrivateInboxTests.testOwnedAtomicInboxCrashWorker'})
        assert observed['OSwindCoreTests.AtomicPrivateInboxTests.testOwnedAtomicInboxCrashWorker']=='skipped'
        assert 'OWNED_ATOMIC_INBOX_CRASH signal=9 finalAbsentBeforeKill=true abandonedStageCleaned=true originalNamespaceRetry=true noCredentialAccountsCreated=true' in text
        assert 'OWNED_NATIVE_CREATE_DIAGNOSTIC realHelper=true status=1 nonzeroExitRecorded=true stdoutExcluded=true secretExcluded=true originalCanaryPreserved=true noImageCreated=true' in text
        mode='tsan' if name.endswith('tsan') else 'optimized';diagnostic=run/('native-'+mode)/'credential/native-create-result.json';d=json.loads(diagnostic.read_text())
        assert d['summary']['operation']=='imageCreate' and d['summary']['status']==1 and d['summary']['termination']=='exit'
        assert d.get('stdoutSuffix') is None and d['summary']['stdoutBytes']==0 and d['summary']['stderrBytes']==41
        assert d['stderrSuffix']=='hdiutil: create failed - Not a directory\n'
        assert hashlib.sha256(d['stderrSuffix'].encode()).hexdigest()==d['summary']['stderrSHA256']
        nativeReceipts.append({'mode':mode,'diagnosticSHA256':sha(diagnostic),'explicitNativeTransitions':sorted(changed),'scope':'Controlled unavailable-parent failure, not the cause of the earlier hosted failure.'})
        expected=observed
    reports.append({'mode':name,**inspect(text,expected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']});selections[name]=expected
assert selections['affected-tsan']==selections['affected-optimized']
assert all(selections[n][k]=='passed' for n in ['full-debug','affected-tsan','affected-optimized'] for k in required-gated)
text=(run/'affected-tsan.log').read_text();reference=selections['affected-tsan'];case=next(iter(required-gated));method=case.rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l);faults={}
for name,bad in {'drop-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'hidden-failure':text.replace(line,line.replace("' passed","' failed"),1),'missing-new-case':text.replace(method,'testWrongIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,reference)
    except (AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()}
assert {'Contents/MacOS/OSwind','Contents/MacOS/oswindctl','Contents/MacOS/oswind-preparation-guardian','Contents/Info.plist'}.issubset(files)
priorPackage=json.loads((root/'benchmarks/sync-owner-response-v1.json').read_text())['newPackage']['files']
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in priorPackage.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==priorPackage['Contents/Info.plist']
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
nativeFiles={str(p.relative_to(run)):sha(p) for p in run.glob('native-*/*/*.json')}
assert nativeFiles
review={'format':'OSwind atomic private inbox and credential diagnostics review v1','baseSource':inputs['baseSource'],'inputCount':700,'unchangedPriorInputs':692,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':result['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':reports,'newMethodIdentities':sorted(required),'newOrdinaryMethods':9,'newGatedMethods':sorted(gated),'alteredLogControls':faults,'nativeReceipts':nativeReceipts,'nativeEvidenceFiles':nativeFiles,'newPackage':{'path':str(package),'files':files,'strictAdHocSignatureExit':signature.returncode,'allPriorResourcesAndBundleInfoUnchanged':True},'scope':'Atomic initial private-inbox staging/publication and safe internal native create/attach observation. Existing files, changed parent, cancellation and owned process death preserve namespace/retry. Real credential helpers retain stdin-only secret, finish-on-cancellation ownership and no mutation retry. Hosted PR151 image-create cause remains unknown; controlled negative diagnostics do not explain it. No fullsync/physical twoMac/provider, GUI/TCC/keyboard, 24h/power, notarized distribution, completev0 or topthree acceptance.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'inputCount':700,'stages':[{k:r[k] for k in ['mode','defined','passed','failed','skipped']} for r in reports],'alteredControls':len(faults),'reviewSHA256':sha(out)}))
