from pathlib import Path
import hashlib,json,os,platform,subprocess,time

root=Path.cwd();base=root/'.artifacts/storage-setup-recovery-v1';out=base/'qualification-v1';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='b236b9d95af364114f0f8d455b6733f1ea5fde16'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines()
pins={p:sha(root/p) for p in sorted(set(paths)) if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved']) and (root/p).is_file()}
changes=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()))
assert len(pins)==700 and len(changes)==8 and all(p.startswith(('Sources/','Tests/')) for p in changes)
manifest={'format':'OSwind atomic local storage setup inputs v1','baseSource':head,'inputFiles':pins,'workingChanges':{p:sha(root/p) for p in changes},'scope':'Private encrypted inbox complete-marker staging/atomic publication, guarded cleanup/retry; native create/attach safe internal result observation with exact credential execution/lifetime/no-retry behavior preserved. Original PR151 image-create cause remains unknown; diagnostic fix does not explain it retroactively.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
focused='AtomicPrivateInbox|PersonalSync(Folder|Pairing|ApprovedResponse)|Backup|Vault'
owned='AtomicPrivateInboxTests|NativeVault|VaultSessionTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably'
def native_env(mode):
    parent=out/('native-'+mode)
    return {'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_ATOMIC_INBOX_CRASH':'1','OSWIND_TEST_VAULT_TRACE_DIR':str(parent/'traces'),'OSWIND_TEST_VAULT_QUERY_TRACE_DIR':str(parent/'queries'),'OSWIND_TEST_CREDENTIAL_DIAGNOSTIC_DIR':str(parent/'credential')}
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('owned-native-tsan',['swift','test','--skip-build','--sanitize=thread','--filter',owned],native_env('tsan')),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('owned-native-optimized',['swift','test','-c','release','--skip-build','--filter',owned],native_env('optimized')),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,command,extra in stages:
    assert all(sha(root/p)==h for p,h in pins.items());print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb') as f:rc=subprocess.run(command,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT).returncode
    results['stages'].append({'name':name,'command':command,'environment':extra,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)})
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in pins.items())
    if rc:raise SystemExit(rc)
print('QUALIFICATION_COMPLETE',flush=True)
