from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/storage-setup-recovery-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text())
assert review['reviewerSHA256']==sha(base/'review-v1.py') and review['inputManifestSHA256']==sha(run/'inputs.json')
assert len(review['alteredLogControls'])==5 and len(review['newMethodIdentities'])==12
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges'])
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputs['inputFiles'].items():
    p=root/path;b=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2]
        protected[path.decode()]=hashlib.sha256(b).hexdigest()
files={'qualification/inputs.json':run/'inputs.json','qualification/results.json':run/'results.json','qualification/review.json':reviewPath,'qualification/runner.py':base/'qualify-v1.py','qualification/reviewer.py':base/'review-v1.py','publisher.py':Path(__file__),'development/atomic-inbox.log':root/'.artifacts/atomic-private-inbox-v1/development-v1.log','development/credential-diagnostics-v1.log':root/'.artifacts/native-credential-diagnostics-v1/development-v1.log','development/credential-diagnostics-v2.log':root/'.artifacts/native-credential-diagnostics-v1/development-v2.log','development/native.log':root/'.artifacts/native-credential-diagnostics-v1/native-development-v1/native.log','development/native-create-result.json':root/'.artifacts/native-credential-diagnostics-v1/native-development-v1/native-create-result.json'}
for stage in json.loads((run/'results.json').read_text())['stages']:files['qualification/logs/'+stage['name']+'.log']=root/stage['log']
for path,h in review['nativeEvidenceFiles'].items():
    p=run/path;assert sha(p)==h;files['qualification/'+path]=p
for path in inputs['workingChanges']:files['source/'+path]=root/path
payload={name:path.read_bytes() for name,path in files.items()}
payload['README.txt']=(f'OSwind atomic private inbox / native credential diagnostics runtime {source}.700 committed runtime/test/dependency inputs;692 preceding inputs unchanged;8 changed files. See exact independently reviewed Debug/TSan/optimized and owned-native selections.12 new method identities:9ordinary plus explicit process-death parent/child and native-failure gates. Internal private-inbox creation stages a complete authenticated marker in an owned workspace and atomically publishes without replacing destinations; thrown preparation, cancellation, changed physical parent, race and actual SIGKILL preserve namespace/retry. Shared user-selected transport creation semantics unchanged. Native create/attach internal observation records safe exit/signal/duration/bytecounts/SHA and bounded stderr, omits stdout/args/stdin, preserves fixed hdiutil and stdin secret, finish-on-cancellation helper lifetime, no mutation retries. Real controlled create failure is Not a directory, status1, no image/mount and preserved canary; it does not diagnose the earlier hosted PR151 creation failure, whose cause remains unknown. New native held-reader and cancellation selections pass only as separately observed, not retroactive CI success. Fresh local production package strict ad-hoc verification, not production signing/notarization. No product GUI/TCC/keyboard, physical twoMac/provider/fullsync, uninterrupted24h, energy/battery, completev0 or topthree claim. All83 feature statuses and previous published bytes unchanged. Explicit source/log/receipt/native redacted diagnostic archive only: no executable, library DB, account inventory or private credentials. Frozen earlier reviewers/publishers/benchmarks and ongoing capture workers untouched.\n').encode()
archive=root/'benchmarks/storage-setup-recovery-raw-v1.zip';manifest=root/'benchmarks/storage-setup-recovery-inputs-v1.json';receipt=root/'benchmarks/storage-setup-recovery-v1.json'
assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in sorted(payload.items()):z.writestr(name,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and set(z.namelist())==set(payload) and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x') as f:json.dump({**inputs,'sourceCommit':source},f,indent=2);f.write('\n')
result={**review,'sourceCommit':source,'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'qualificationInputs':{'archiveMember':'qualification/inputs.json','sha256':sha(run/'inputs.json')},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload),'allArchivedBytesComparedToInputs':True,'files':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True}}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'sourceCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
