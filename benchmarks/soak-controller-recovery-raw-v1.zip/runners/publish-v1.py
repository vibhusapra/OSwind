from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/soak-controller-recovery-v1';OUT=BASE/'qualification-v2';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());review=json.loads((OUT/'reviewed-v1.json').read_text());assert review['passed']==17 and len(review['alteredLogControls'])==5
assert review['reviewerSHA256']==sha(BASE/'review-v1.py') and review['inputManifestSHA256']==sha(OUT/'inputs.json')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['inputFiles'])
for p,h in inputs['inputFiles'].items():
 assert sha(ROOT/p)==h
 assert subprocess.check_output(['git','show',source+':'+p])==(ROOT/p).read_bytes()
assert all(sha(Path(p))==h for p,h in inputs['protectedBenchmarks'].items()) and len(inputs['protectedBenchmarks'])==499
files={}
for name in ['inputs.json','results.json','reviewed-v1.json','python-syntax.log','owned-fault-contracts.log']:files['qualification/'+name]=OUT/name
for name in ['qualify-v1.py','qualify-v2.py','review-v1.py','publish-v1.py','qualification-controller-v1.log','qualification-controller-v2.log','retained-driver-v1.py','development-v1.log','development-v2.log']:files['runners/'+name]=BASE/name
for p in inputs['inputFiles']:files['source/'+p]=ROOT/p
assessmentPath=ROOT/'.artifacts/native-targeted-soak-v1/long-run-terminal-assessment-v1.json';assessment=json.loads(assessmentPath.read_text());files['retained-incomplete-long-run/terminal-assessment.json']=assessmentPath
for p,h in inputs['originalLongRunFiles'].items():
 file=ROOT/p;assert sha(file)==h;files['retained-incomplete-long-run/'+file.name]=file
runManifest=json.loads((ROOT/'.artifacts/native-targeted-soak-v1/long-run-v1/owned-soak-9BE5CDE3-DD96-49F5-9A85-8714B8D16608/run-manifest.json').read_text());assert runManifest['runnerSHA256']==inputs['originalControllerSHA256']
payload={name:path.read_bytes() for name,path in files.items()}
payload['README.txt']=(f'OSwind soak controller disk-failure source {source}.\n'
    'Only Python controller/helper/fault tests and CI selection change. All711 prior non-workflow runtime inputs remain unchanged. '
    'Seventeen contract tests use inert authored fixture/XCTest payloads, mocked native signing/host/ps calls and real directly owned Python child processes. '
    'Disk-full, output/handle/log/launch/final failures, ignored SIGTERM, interrupted waiting, graceful stop and unrelated sentinel contracts pass. '
    'Five altered unittest logs reject. This is source/hash/unittest review, not a separate external PID trace or native capture/24h acceptance. '
    'The first qualification wrapper failed before test execution on __file__ string handling; corrected v2 passes, original failure and both source wrappers retained.\n'
    'The original24h attempt stopped incomplete after ENOSPC in heartbeat/stop/fixture-exit writes. Its last stale running status reports27657.44 uptime seconds,1380attempts,3saved,1377lockdeferrals,0recordederrors. '
    'Original tool session8761 returned1; exact controller/worker/fixture PIDs were absent at assessment. Worker/fixture exit codes were not persisted. '
    'No original long-run restart or successful benchmark repetition. Partial resource/attempt records, trace and exact old runner are retained unchanged. '
    'The stale status and zero recorded errors do not prove24hcompletion, uninterrupted coverage, successful cleanup, automatic scheduling, power or product ranking. '
    'No databases, model weights, runtime executables, user history or keys are included. All499 preceding benchmark files remain unchanged.\n').encode()
archive=ROOT/'benchmarks/soak-controller-recovery-raw-v1.zip';manifest=ROOT/'benchmarks/soak-controller-recovery-inputs-v1.json';receipt=ROOT/'benchmarks/soak-controller-recovery-v1.json';assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and all(z.read(n)==b for n,b in payload.items())
publicInputs=inputs|{'sourceCommit':source,'protectedBenchmarks':{str(Path(p).relative_to(ROOT)):h for p,h in inputs['protectedBenchmarks'].items()}}
with manifest.open('x') as f:json.dump(publicInputs,f,indent=2);f.write('\n')
result=review|{'sourceCommit':source,'baseSource':inputs['baseSource'],'allFourCommittedInputBlobsMatch':True,'retainedIncompleteLongRun':assessment,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{name:hashlib.sha256(data).hexdigest() for name,data in payload.items()}},'reviewSHA256':sha(OUT/'reviewed-v1.json'),'publisherSHA256':sha(__file__)}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'source':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'members':len(payload),'priorBenchmarksUnchanged':499}))
