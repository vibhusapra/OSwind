from pathlib import Path
import ast,hashlib,json,math,re,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/soak-controller-recovery-v1';OUT=BASE/'qualification-v2';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (OUT/'reviewed-v1.json').exists()
inputs=json.loads((OUT/'inputs.json').read_text());results=json.loads((OUT/'results.json').read_text())
assert len(inputs['inputFiles'])==4 and all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
assert results['inputManifestSHA256']==sha(OUT/'inputs.json') and results['runnerSHA256']==sha(BASE/'qualify-v2.py')
prior=json.loads((ROOT/'.artifacts/native-keyword-profile-v1/qualification-v1/inputs.json').read_text())['inputFiles']
assert len(prior)==712 and sum(sha(ROOT/p)==h for p,h in prior.items())==711
assert len(inputs['protectedBenchmarks'])==499 and all(sha(Path(p))==h for p,h in inputs['protectedBenchmarks'].items())
assessment=ROOT/'.artifacts/native-targeted-soak-v1/long-run-terminal-assessment-v1.json'
assert sha(assessment)==inputs['originalLongRunAssessmentSHA256'] and all(sha(ROOT/p)==h for p,h in inputs['originalLongRunFiles'].items())
assert sha(BASE/'retained-driver-v1.py')==inputs['originalControllerSHA256']
assert (BASE/'retained-driver-v1.py').read_bytes()==subprocess.check_output(['git','show',inputs['baseSource']+':scripts/native-targeted-capture-soak.py'])
tree=ast.parse((ROOT/'scripts/test-soak-process-owner.py').read_text());expected={n.name+'.'+m.name for n in tree.body if isinstance(n,ast.ClassDef) for m in n.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_')};assert len(expected)==17
pattern=re.compile(r'^(test_\w+) \(__main__\.([^.]+)\.(test_\w+)\) \.\.\. (\w+)$',re.M)
def inspect(text):
 rows=pattern.findall(text);assert len(rows)==len({c+'.'+m for _,c,m,_ in rows})==17
 assert all(first==method and status=='ok' for first,cls,method,status in rows)
 assert {cls+'.'+method for _,cls,method,_ in rows}==expected
 assert re.search(r'\nRan 17 tests in [0-9.]+s\n\nOK\s*$',text)
 assert not any(s in text for s in ('Traceback (most recent call last)','FAILED (','ERROR:','FAIL:'))
 return sorted(expected)
assert [s['name'] for s in results['stages']]==['python-syntax','owned-fault-contracts']
for stage in results['stages']:
 assert stage['exit']==0 and sha(ROOT/stage['log'])==stage['sha256'] and math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
log=(OUT/'owned-fault-contracts.log').read_text();identities=inspect(log);line=next(l for l in log.splitlines() if ' ... ok' in l)
faults={}
for name,bad in {'missing-case':log.replace(line,'',1),'duplicate-case':line+'\n'+log,'wrong-identity':log.replace(line,line.replace('test_','test_forged_',1),1),'failed-case':log.replace(line,line.replace(' ... ok',' ... FAIL'),1),'hidden-traceback':log.replace('\nOK','\nTraceback (most recent call last):\nOK',1)}.items():
 try:inspect(bad)
 except AssertionError:faults[name]='rejected'
 else:raise AssertionError('Altered log accepted '+name)
workflow=(ROOT/'.github/workflows/ci.yml').read_text();assert workflow.count('python3 scripts/test-soak-process-owner.py')==1
original=subprocess.check_output(['git','show',inputs['baseSource']+':.github/workflows/ci.yml'],text=True)
addition='      - name: Verify soak cleanup survives unavailable diagnostics without native capture\n        run: python3 scripts/test-soak-process-owner.py\n';assert workflow.replace(addition,'',1)==original
result={'format':'OSwind soak-controller disk-failure review v1','state':'reviewed','inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(BASE/'qualify-v2.py'),'reviewerSHA256':sha(__file__),'methods':identities,'passed':17,'skipped':0,'alteredLogControls':faults,'priorRuntimeInputsUnchanged':711,'priorBenchmarkFilesUnchanged':499,'originalLongRunAssessmentSHA256':sha(assessment),'originalControllerSHA256':sha(BASE/'retained-driver-v1.py'),'stageLogs':{s['name']:s['sha256'] for s in results['stages']},'scope':inputs['scope'],'reviewScope':'Codex source/input/hash and exact unittest identity/outcome review. Real owned-child assertions are executed by the retained test code; no separate external PID trace or independent human audit. No successful original runtime/benchmark/soak repeated. The first wrapper fails before testing due __file__ string handling; retained separately, corrected v2 succeeds.'}
with (OUT/'reviewed-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'state':'reviewed','methods':17,'alteredLogs':len(faults),'runtimeInputsUnchanged':711,'oldBenchmarksUnchanged':499,'reviewSHA256':sha(OUT/'reviewed-v1.json')}))
