from pathlib import Path
import hashlib,json,os,re,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/soak-controller-recovery-v1';OUT=BASE/'qualification-v1';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['scripts/native-targeted-capture-soak.py','scripts/soak_process_owner.py','scripts/test-soak-process-owner.py','.github/workflows/ci.yml'];pins={p:sha(ROOT/p) for p in paths}
prior=json.loads((ROOT/'.artifacts/native-keyword-profile-v1/qualification-v1/inputs.json').read_text())['inputFiles'];assert len(prior)==712
assert all(sha(ROOT/p)==h for p,h in prior.items() if p!='.github/workflows/ci.yml')
old=BASE/'retained-driver-v1.py';blob=subprocess.check_output(['git','show','74f822a589a1ab97892a0fa286122a2ef7967b5e:scripts/native-targeted-capture-soak.py']);assert old.read_bytes()==blob
oldSoak=ROOT/'.artifacts/native-targeted-soak-v1/long-run-terminal-assessment-v1.json';assessment=json.loads(oldSoak.read_text());assert assessment['state']=='stopped-incomplete-enospc' and assessment['controllerTerminalExit']==1 and assessment['ownedPIDsNoLongerPresent'] is True
assert all(sha(ROOT/p)==h for p,h in assessment['sourceFilesSHA256'].items())
protected={str(p):sha(p) for p in (ROOT/'benchmarks').rglob('*') if p.is_file()};assert len(protected)==499
expected=set(re.findall(r'^    def (test_\w+)\(', (ROOT/'scripts/test-soak-process-owner.py').read_text(),re.M));assert len(expected)==17
manifest={'format':'OSwind owned soak-controller disk-failure inputs v1','baseSource':'74f822a589a1ab97892a0fa286122a2ef7967b5e','inputFiles':pins,'priorRuntimeInputsUnchanged':711,'original712InputManifestSHA256':sha(ROOT/'.artifacts/native-keyword-profile-v1/qualification-v1/inputs.json'),'originalControllerSHA256':sha(old),'originalLongRunAssessmentSHA256':sha(oldSoak),'originalLongRunFiles':assessment['sourceFilesSHA256'],'protectedBenchmarks':protected,'expectedMethods':sorted(expected),'scope':'Changed Python controller/helper/17-contract tests plus CI selection only; all711 preceding non-workflow runtime inputs unchanged. Inert authored fake fixture/XCTest payloads with real directly owned processes; mocked native codesign/host/ps commands. No native capture, TCC/history/models, filesystem actually filled, old long-run restart or product benchmark. Original observed ENOSPC long run remains incomplete; no24h/power/capture qualification.'}
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(__file__),'stages':[]}
for name,command in [('python-syntax',['python3','-m','py_compile',*paths[:3]]),('owned-fault-contracts',['python3','scripts/test-soak-process-owner.py'])]:
 assert all(sha(ROOT/p)==h for p,h in pins.items());log=OUT/(name+'.log');begin=time.monotonic()
 with log.open('xb') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 result['stages'].append({'name':name,'command':command,'exit':code,'wallSeconds':time.monotonic()-begin,'log':str(log.relative_to(ROOT)),'sha256':sha(log)});(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
 assert all(sha(ROOT/p)==h for p,h in pins.items()) and all(sha(Path(p))==h for p,h in protected.items())
 if code:raise SystemExit(code)
print(json.dumps({'state':'completed','stages':result['stages'],'expectedMethods':len(expected)}))
