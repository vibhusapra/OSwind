from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';NATIVE=Path('/Users/vibhusapra/.codex/worktrees/calendar-meeting-context/oswind/.artifacts/snapshot-source-fit-v1');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r1=BASE/'native-raster-unlocked-reviewed-v1.json';r2=BASE/'native-raster-pillow-reviewed-v1.json';review=json.loads(r1.read_text());pixels=json.loads(r2.read_text())
assert sha(r1)=='11e0db5dac98d5937ff09ec256124e662d7f7e8e4815cd14da651f751e43a0df' and sha(r2)=='65738104745cfc089e6bcc1b33422011c5749634a32d0693ee6e994dc776249f'
assert review['reviewerSHA256']==sha(BASE/'review-native-raster-unlocked-v1.py') and pixels['reviewerSHA256']==sha(BASE/'review-native-raster-pillow-v1.py')
assert pixels['priorReviewSHA256']==sha(r1) and len(pixels['cases'])==6 and len(pixels['incorrectRasterControls'])==3 and len(review['alteredRecordControls'])==5
assert all(sha(Path(p))==h for p,h in review['retainedArtifactFiles'].items())
inputs=json.loads((NATIVE/'qualification-v1/inputs.json').read_text());assert len(inputs['inputFiles'])==694
for p,h in inputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',review['candidateSource']+':'+p])).hexdigest()==h
attempts=json.loads((NATIVE/'unlocked-attempts-v1.json').read_text())
for row in attempts['drivers']:
    assert sha(NATIVE/row['original'])==row['originalSHA256'] and sha(NATIVE/row['new'])==row['newSHA256']
assert (NATIVE/'reproduce-v3-unlocked.py').read_text().replace('baseline-native-v3-unlocked','baseline-native-v2')==(NATIVE/'reproduce-v2.py').read_text()
assert (NATIVE/'verify-candidate-v2-unlocked.py').read_text().replace('candidate-native-v2-unlocked','candidate-native-v1')==(NATIVE/'verify-candidate-v1.py').read_text()
files={str(Path(p).relative_to(NATIVE)):Path(p) for p in review['retainedArtifactFiles']}
for name in ['unlocked-attempts-v1.json','reproduce-v2.py','reproduce-v3-unlocked.py','reproduce-v3-unlocked.log','verify-candidate-v1.py','verify-candidate-v2-unlocked.py','verify-candidate-v2-unlocked.log','CropBoundaryFixture.swift','ImageGeometryProbe.swift','SessionReadiness.swift','qualification-v1/inputs.json','qualification-v1/candidate-debug/provenance.json']:files['native-runners/'+name]=NATIVE/name
for name in ['current-session-readiness-v1.json','review-native-raster-unlocked-v1.py','native-raster-unlocked-reviewed-v1.json','review-native-raster-pillow-v1.py','native-raster-pillow-reviewed-v1.json','native-raster-pillow-review-v1.log','publish-native-raster-unlocked-v1.py']:files['review/'+name]=BASE/name
payload={n:p.read_bytes() for n,p in files.items()}
payload['README.txt']=(f'Fresh actual generated-window raster observations, candidate source {review["candidateSource"]}, baseline {review["baselineSource"]}.\n'
 'Both engines pass actual full/left/right capture at2x scale and have identical corresponding JPEG hashes. Three captures per engine, one attempt per case. '
 'Exact owned source bundle/window/PID, full1280x842/half640x842 rasters, appropriate OCR markers and opposite-side marker absence, both reaped owned fixture children. '
 'The color oracle inspects full width and middle half of height; it does not establish universal/all-pixel privacy. '
 'Independent Pillow/ImageCms decoding of the preserved JPEGs repeats that declared oracle, rejecting three incorrect raster substitutions. Five altered-record controls reject. '
 'The older engine also passes, so the original padding/1x issue is not reproduced and no causal fix/competitive speed/energy claim follows. '
 'Original failed attempts, locked waiters, successful runners, binaries and publications remain unchanged. No runtime or successful live benchmark repeated for metadata. '
 'This contains generated-window JSON/settings/JPEG/logs and source/receipt manifests only. No private database, keys, model, executable or user-window capture.\n').encode()
archive=ROOT/'benchmarks/native-raster-fit-unlocked-raw-v1.zip';manifest=ROOT/'benchmarks/native-raster-fit-unlocked-inputs-v1.json';receipt=ROOT/'benchmarks/native-raster-fit-unlocked-v1.json';assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and z.testzip() is None and all(z.read(n)==b for n,b in payload.items())
record={'format':'OSwind fresh native 2x raster inputs v1','candidateSource':review['candidateSource'],'baselineSource':review['baselineSource'],'candidateInputManifestSHA256':sha(NATIVE/'qualification-v1/inputs.json'),'candidate694InputFiles':inputs['inputFiles'],'attempts':json.loads((NATIVE/'unlocked-attempts-v1.json').read_text()),'retainedArtifactFiles':review['retainedArtifactFiles'],'reviewers':{n:sha(BASE/n) for n in ['review-native-raster-unlocked-v1.py','review-native-raster-pillow-v1.py']}}
manifest.open('x').write(json.dumps(record,indent=2)+'\n')
result=review|{'independentPixelDecoder':pixels,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(r1),'independentPixelReviewSHA256':sha(r2),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},'allArchivedBytesCompared':True}}
receipt.open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':6,'incorrectRasterControls':3,'alteredRecords':5,'archiveBytes':archive.stat().st_size,'archiveMembers':len(payload),'sha256':sha(receipt)}))
