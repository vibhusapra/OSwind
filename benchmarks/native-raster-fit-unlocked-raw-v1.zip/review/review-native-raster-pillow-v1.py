from pathlib import Path
import hashlib,json,sys
from PIL import Image,ImageCms,__version__
from io import BytesIO
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';NATIVE=Path('/Users/vibhusapra/.codex/worktrees/calendar-meeting-context/oswind/.artifacts/snapshot-source-fit-v1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=BASE/'native-raster-unlocked-reviewed-v1.json';review=json.loads(prior.read_text());assert sha(prior)=='11e0db5dac98d5937ff09ec256124e662d7f7e8e4815cd14da651f751e43a0df'
def decode(p):
    image=Image.open(p);image.load();icc=image.info.get('icc_profile');assert image.format=='JPEG'
    if icc:image=ImageCms.profileToProfile(image,ImageCms.ImageCmsProfile(BytesIO(icc)),ImageCms.createProfile('sRGB'),outputMode='RGB')
    else:image=image.convert('RGB')
    return image
def inspect(image,name):
    w,h=image.size;assert (w,h)==(1280 if name=='full' else 640,842)
    # Match the already declared oracle's middle half height. This independent
    # decoder does not widen that scope to all pixels or arbitrary app surfaces.
    central=image.crop((0,h//4,w,h*3//4));magenta=green=white=0
    for r,g,b in central.getdata():
        magenta+=r>g+60 and b>g+60;green+=g>r+60 and g>b+60;white+=min(r,g,b)>245
    assert white==0
    if name=='full':assert green>0 and magenta>0
    elif name=='left':assert green>0 and magenta==0
    else:assert magenta>0 and green==0
    return {'width':w,'height':h,'centralInspectedPixels':central.width*central.height,'strongMagentaPixels':magenta,'strongGreenPixels':green,'centralWhitePixels':white}
reports=[];decoded={}
for label,dirname in [('baseline','baseline-native-v3-unlocked'),('candidate','candidate-native-v2-unlocked')]:
    root=NATIVE/dirname;raw=json.loads((root/'report.json').read_text());assert sha(root/'report.json')==review['reports'][label]['reportSHA256']
    for case in raw['cases']:
        name=case['name'];p=root/(name+'-library')/case['source']['imagePath'];assert sha(p)==case['pixels']['sha256']
        image=decode(p);decoded[label,name]=image;reports.append({'engine':label,'case':name,'sha256':sha(p),**inspect(image,name)})
controls={}
for label,image,name in [('right-raster-as-left',decoded['candidate','right'],'left'),('left-raster-as-right',decoded['candidate','left'],'right'),('full-raster-as-left',decoded['candidate','full'],'left')]:
    try:inspect(image,name)
    except AssertionError:controls[label]='rejected'
    else:raise AssertionError('Accepted incorrect independently decoded raster '+label)
result={'format':'OSwind independent Pillow decode native raster review v1','priorReviewSHA256':sha(prior),'reviewerSHA256':sha(Path(__file__)),'python':sys.version,'pillow':__version__,'colorManagement':'Embedded ICC converted to sRGB through Pillow ImageCms when present','cases':reports,'incorrectRasterControls':controls,'scope':'Second decoder over the same six retained generated-window JPEGs, current2x display, declared full-width/middle-half-height color oracle. Opposite colors and central white remain absent in cropped cases. This is offline analysis of preserved actual captures, not a repeated live capture or whole-raster/universal privacy/performance/causal-fix acceptance. Earlier engine also passes.'}
(BASE/'native-raster-pillow-reviewed-v1.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':len(reports),'incorrectRasterControls':controls,'sha256':sha(BASE/'native-raster-pillow-reviewed-v1.json')}))
