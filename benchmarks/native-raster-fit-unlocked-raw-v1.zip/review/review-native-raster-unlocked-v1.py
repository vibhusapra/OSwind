from pathlib import Path
import copy,hashlib,json,subprocess
ROOT=Path.cwd();BASE=Path('/Users/vibhusapra/.codex/worktrees/calendar-meeting-context/oswind/.artifacts/snapshot-source-fit-v1');OUT=ROOT/'.artifacts/owner-app-integration-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
qual=json.loads((BASE/'qualification-v1/inputs.json').read_text());candidate=json.loads((BASE/'qualification-v1/candidate-debug/provenance.json').read_text())
published=json.loads((ROOT/'benchmarks/native-raster-fit-v1.json').read_text());runtime=published['sourceCommit'];assert runtime=='533b301913002f68a0eac8072435033ca984e43d'
assert candidate['inputManifestSHA256']==sha(BASE/'qualification-v1/inputs.json') and len(qual['inputFiles'])==694
for p,h in qual['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',runtime+':'+p])).hexdigest()==h
old=json.loads((ROOT/'benchmarks/capture-start-readiness-v1.json').read_text());baselineCLI=BASE.parent/'capture-start-readiness-v1/qualification-v2/OSwind.app/Contents/MacOS/oswindctl'
assert sha(baselineCLI)==old['newPackage']['files']['Contents/MacOS/oswindctl']
assert sha(BASE/'qualification-v1/candidate-debug/oswindctl')==candidate['binarySHA256']
reports={};artifacts={}
def inspect(report,exitRecord,root,expected):
    assert report['state']==expected and report['allSourcesExactOwnedBundle'] and report['cliUnchanged']
    assert report['ready']['pointPixelScale']==2 and report['ready']['backingScale']==2 and report['ready']['stableSCObservations']>=3
    assert report['bundle'].startswith('com.oswind.fixture.crop.') and report['ready']['bundle']==report['bundle']
    assert exitRecord['ownedSourceReaped'] is True and exitRecord['exit']==-15 and exitRecord['pid']==report['ready']['pid']
    assert [c['name'] for c in report['cases']]==['full','left','right']
    summaries=[]
    for case in report['cases']:
        name=case['name'];source=case['source'];pixels=case['pixels'];library=root/(name+'-library')
        assert source['bundleID']==report['bundle'] and source['kind']=='screen' and source['display'].startswith('window-'+str(report['ready']['windowID']))
        assert all(x['exit']==0 for x in case['attempts']) and 1<=len(case['attempts'])<=3
        path=source['imagePath'];assert path=='images/'+source['id']+'.jpg'
        assert sha(library/path)==pixels['sha256'] and pixels['height']==842 and pixels['width']==(1280 if name=='full' else 640)
        assert pixels['centralInspectedPixels']==pixels['width']*(pixels['height']*3//4-pixels['height']//4) and pixels['whitePixels']==0
        text=source['text'];left='INSIDE_LEFT_7429' in text;right='OUTSIDE_RIGHT_7429' in text
        if name=='full':assert pixels['strongGreenPixels']>0 and pixels['strongMagentaPixels']>0 and left and right
        if name=='left':assert pixels['strongGreenPixels']>0 and pixels['strongMagentaPixels']==0 and left and not right
        if name=='right':assert pixels['strongMagentaPixels']>0 and pixels['strongGreenPixels']==0 and right and not left
        summaries.append({'case':name,'width':pixels['width'],'height':pixels['height'],'centralInspectedPixels':pixels['centralInspectedPixels'],'strongGreenPixels':pixels['strongGreenPixels'],'strongMagentaPixels':pixels['strongMagentaPixels'],'centralWhitePixels':pixels['whitePixels'],'imageSHA256':pixels['sha256'],'oppositeOCRMarkerAbsent':name=='full' or (not right if name=='left' else not left),'attempts':len(case['attempts'])})
    return summaries
for label,dirname,state in [('baseline','baseline-native-v3-unlocked','not-reproduced'),('candidate','candidate-native-v2-unlocked','candidate-verified')]:
    root=BASE/dirname;report=json.loads((root/'report.json').read_text());exitRecord=json.loads((root/'fixture-exit.json').read_text())
    reports[label]={'runtime':old['runtimeCommit'] if label=='baseline' else runtime,'reportSHA256':sha(root/'report.json'),'fixtureExitSHA256':sha(root/'fixture-exit.json'),'caseSummary':inspect(report,exitRecord,root,state),'result':state}
    for p in root.rglob('*'):
        if p.is_file() and (p.name.endswith(('.json','.log','.jpg')) or p.name=='settings.json'):artifacts[str(p)]=sha(p)
root=BASE/'candidate-native-v2-unlocked';source=json.loads((root/'report.json').read_text());exitRecord=json.loads((root/'fixture-exit.json').read_text());controls={}
for label in ['opposite-pixel','wrong-bundle','bad-image-digest','opposite-ocr','unreaped-fixture']:
    bad=copy.deepcopy(source);badExit=copy.deepcopy(exitRecord)
    if label=='opposite-pixel':bad['cases'][1]['pixels']['strongMagentaPixels']=1
    if label=='wrong-bundle':bad['cases'][1]['source']['bundleID']='org.unrelated.application'
    if label=='bad-image-digest':bad['cases'][1]['pixels']['sha256']='0'*64
    if label=='opposite-ocr':bad['cases'][1]['source']['text']+='\nOUTSIDE_RIGHT_7429'
    if label=='unreaped-fixture':badExit['ownedSourceReaped']=False
    try:inspect(bad,badExit,root,'candidate-verified')
    except AssertionError:controls[label]='rejected'
    else:raise AssertionError('Accepted altered native raster record: '+label)
assert all(reports['baseline']['caseSummary'][i]['imageSHA256']==reports['candidate']['caseSummary'][i]['imageSHA256'] for i in range(3))
result={'format':'OSwind fresh unlocked 2x native raster review v1','candidateSource':runtime,'candidate694GitInputsMatch':True,'baselineSource':old['runtimeCommit'],'reports':reports,'alteredRecordControls':controls,'retainedArtifactFiles':artifacts,'reviewerSHA256':sha(__file__),'scope':'Six actual explicitly targeted generated-window captures, same 2x backing/ScreenCaptureKit scale. Full/left/right color content and OCR agree; all raster bytes match between engines. Pixel color inspection covers full width and middle half of height, with visual review of candidate rasters. Both fixture children reaped. Earlier engine also passes; original 1x/padding bug is not reproduced on this display. No causal fix, arbitrary surface privacy, automatic capture scheduling, audio, power,24h or GUI acceptance claim. Original failed runs/waiters unchanged.'}
(OUT/'native-raster-unlocked-reviewed-v1.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'candidateSource':runtime,'cases':6,'backingScale':2,'sameRasterBytes':True,'alteredRecordsRejected':len(controls),'reviewSHA256':sha(OUT/'native-raster-unlocked-reviewed-v1.json')}))
