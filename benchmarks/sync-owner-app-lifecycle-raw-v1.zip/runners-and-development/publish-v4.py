from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';OUT=BASE/'qualification-v5';CONT=BASE/'qualification-continuation-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());review=json.loads((CONT/'reviewed-wip-v3.json').read_text());source=inputs['source']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert review['sourceCommit']==source and review['reviewerSHA256']==sha(BASE/'review-wip-continuation-v3.py') and review['inputManifestSHA256']==sha(OUT/'inputs.json')
assert len(review['stages'])==4 and len(review['alteredLogControls'])==6 and len(review['alteredNativeControls'])==5
assert review['overallQualificationPassed'] is False
assert review['continuationInputSHA256']==sha(CONT/'inputs.json') and review['continuationResultsSHA256']==sha(CONT/'results.json')
assert all(sha(ROOT/p)==h for p,h in (inputs['inputFiles']|inputs['packageInputs']|inputs['protectedPriorFiles']).items())
protected=[p for p in inputs['protectedPriorFiles'] if p.startswith('benchmarks/')];assert len(protected)==505
assert all(subprocess.check_output(['git','show',inputs['baseSource']+':'+p])==(ROOT/p).read_bytes() for p in protected)
def archive(name,payload):
    path=ROOT/'benchmarks'/name;assert not path.exists()
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(payload.items()):z.writestr(n,b)
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(payload) and z.testzip() is None
        assert all(z.read(n)==b for n,b in payload.items())
    return {'file':name,'sha256':sha(path),'bytes':path.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},'allArchivedBytesCompared':True}
files={}
for p in OUT.iterdir():
    if p.is_file() and p.suffix in ('.log','.json'):files['qualification/'+p.name]=p
for p in CONT.iterdir():
    if p.is_file() and p.suffix in ('.log','.json'):files['distinct-continuation/'+p.name]=p
for dirname in ['ui-tsan','ui-optimized']:
    for p in (OUT/dirname).iterdir():
        if p.is_file():files['qualification/'+dirname+'/'+p.name]=p
# Retain actual failed full runs and development outputs; never include process
# samples, private databases, credential values, native vault payloads or binaries.
for name in ['qualify-v1.py','qualify-v2.py','qualify-v3.py','qualify-v4.py','qualify-v5.py','review-v3.py','review-v4.py','review-v5.py','publish-v1.py','publish-v2.py','publish-v3.py','publish-v4.py','continue-qualification-v1.py','review-wip-continuation-v1.py','review-wip-continuation-v2.py','review-wip-continuation-v3.py','qualification-controller-v4.log','qualification-controller-v5.log','qualification-continuation-controller-v1.log','review-pairing-phase-diagnostics-v1.py','pairing-phase-diagnostics-reviewed-v1.json','review-recovery-diagnostics-v1.py','recovery-diagnostics-reviewed-v1.json','full-debug-reviewed-checkpoint-v1.json','review-preflight-v1.json','expected-identities-v1.json','qualification-controller-v1.log','qualification-controller-v2.log','qualification-controller-v3.log','frozen-format2-inputs-v1.json','frozen-format2-manifest-v1.json','alias-cache-correction-v1.json','next-peer-membership-contract-v1.md','guardian-path-v12.log']:
    p=BASE/name
    if p.is_file():files['runners-and-development/'+name]=p
for dirname in ['qualification-v1','qualification-v2','qualification-v3','qualification-v4','pairing-phase-diagnostic-v1','pairing-phase-diagnostic-v2','pairing-trace-flag-control-v1','recovery-timeout-diagnostic-v1','recovery-timeout-diagnostic-v2','recovery-timeout-diagnostic-v3']:
    for p in (BASE/dirname).iterdir():
        if p.is_file() and p.name in ('inputs.json','results.json','result.json','test.log','launcher-v2.json','full-debug.log','debug-build.log','affected-tsan.log','debug-fixture-regression.log'):files['retained-attempts/'+dirname+'/'+p.name]=p
for p in BASE.glob('*.log'):
    if not p.name.startswith('qualification-controller') and 'sample' not in p.name:files.setdefault('runners-and-development/'+p.name,p)
for p in (BASE/'retained-native-ui-review-v1').iterdir():
    if p.is_file():files['retained-native-ui-review/'+p.name]=p
for p in inputs['changedInputs']:files['source/'+p]=ROOT/p
files['baseline/full-debug.log']=Path(inputs['parentFullDebug']['path'])
payload={n:p.read_bytes() for n,p in files.items()}
payload['README.txt']=(f'OSwind opt-in owner-addition app lifecycle source {source}.\n'
 '723 committed runtime/test/build inputs; 20 changed and 703 unchanged preceding inputs. '
 '41 new XCTest identities: 30 actual AppSession cases, four retained-owner busy-close cases, six exact-session transfer cases, one genuine frozen predecessor-format2 gate. '
 'Retained full Debug at136cf1e (2840 defined2670 passed170 skipped) plus the separately retained current5ef default-OFF Debugclass (28defined25passed3skipped), expanded affected TSAN/optimized and explicit native TSAN/optimized selections are inspected by exact identity/state, start/terminal balance, aggregate summary and diagnostics. The overall qualification is INCOMPLETE: actual current broad failure identities/exits are retained and not erased by distinct later modes or passing diagnostics. '
 'One existing wake callback case has a declared unlocked/thermal pass-or-skip variant; receipt reports the actual state. '
 'Native modes include real generated encrypted APFS images, original owned login-Keychain accounts and six offscreen request/review/response component rasters. '
 'Seven delivered-approval SIGKILL phases, frozen35/36 fences/backfill and new actual predecessor cached/fresh refusals remain selected. '
 'Six altered test logs and five altered native records must reject. Normal production package strict ad-hoc signature, executable modes and prior Info/resources are checked.\n'
 'Retained failed qualification v1 had aliased compiler module paths before tests. V2 reached2840 tests and failed three guardian process methods because test fixture hardcoded checkout.build/debug with an external build scratch. '
 'Corrected helper resolution is relative to the actual XCTest bundle in each selected configuration; ten actual process cases pass targeted before final qualification. '
 'V3 expandedTSAN retained one existing restricted-recovery timeout (1368pass131skip1fail); v4 normalDebugclass retained a different existing pairing-helper timeout (24pass3skip1fail). Both causes remain unexplained. Unchanged-binary isolated/class diagnostics and current default-OFF class pass do not erase or explain those failures. No production fix or deadline relaxation is claimed. '
 'Development failures and fixture corrections remain in logs. Native predecessor executable is immutable and omitted; its source fixture and hashes are included. '
 'No private account values, database, user history, weights, trace samples or executable are included.\n'
 'Both actual current failed methods remain open: PendingMediaSchedulerTests.testLibrarySwitchJoinsActualPendingMediaWorkerBeforeClosingStore has two assertion issues in broadTSAN; NativeVaultCancellationTests.testCancellationDuringMediaDrainStillClosesStoreAliasAndOwnedImage has one unexpected moved-image binding issue in native optimized. Causes remain unexplained. A later peer branch f24f3c6 contains a separately reproduced vault-observer close guard; this older5ef runtime lacks that guard and its packaged app is retained evidence, not a recommended preview build. '
 'Default two-Mac setup remains unchanged. New addition UI requires OSWIND_OWNER_ADDITION_PREVIEW=1. Existing peers still need catch-up and expanded-group connection. '
 'This is local software/generated native-account evidence, not physical two-Mac, interactive GUI, whole-product sync, uninterrupted24h/current automatic capture, power, production DP-Keychain, DeveloperID/notarization, complete v0 or ranking acceptance. '
 'All505 preceding benchmark publications and83 feature statuses remain unchanged.\n').encode()
raw=archive('sync-owner-app-lifecycle-raw-v1.zip',payload)
manifest=ROOT/'benchmarks/sync-owner-app-lifecycle-inputs-v1.json';receipt=ROOT/'benchmarks/sync-owner-app-lifecycle-v1.json';assert not manifest.exists() and not receipt.exists()
manifest.open('x').write(json.dumps(inputs,indent=2)+'\n')
result=review|{'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(CONT/'reviewed-wip-v3.json'),'publisherSHA256':sha(__file__),'qualificationLabel':'WIP; two retained failed methods and known older vault-observer guard gap; no current all-green qualification','knownLaterCorrection':{'commit':'f24f3c6fd3483ad96631891d275f8fec9cadc481','pullRequest':162,'scope':'loadVault refuses a fresh model while original membership close or finish is pending; independently reproduced on peer path','olderPackageRecommendation':'Retain only as evidence; do not recommend as a ready preview'},'rawEvidence':raw,'priorBenchmarkFilesUnchanged':505,'retainedFailedQualifications':{'v1':'Aliased compiler module paths, failed before tests.','v2':'Three guardian fixture methods failed after complete full suite; exact helper resolution fixed and targeted actual process tests pass.','v3':'One existing restricted-recovery timeout in expandedTSAN; cause remains unexplained.','v4':'One different existing15second pairing-helper timeout in normalDebugclass; cause remains unexplained.'}}
receipt.open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'rawSHA256':raw['sha256'],'rawBytes':raw['bytes'],'members':len(payload),'precedingPublicationsUnchanged':505}))
