from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';OUT=BASE/'qualification-v3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());review=json.loads((OUT/'reviewed-v3.json').read_text());source=inputs['source']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert review['sourceCommit']==source and review['reviewerSHA256']==sha(BASE/'review-v3.py') and review['inputManifestSHA256']==sha(OUT/'inputs.json')
assert len(review['stages'])==5 and len(review['alteredLogControls'])==6 and len(review['alteredNativeControls'])==5
assert all(sha(ROOT/p)==h for p,h in (inputs['inputFiles']|inputs['packageInputs']|inputs['protectedPriorFiles']).items())
protected=[p for p in inputs['protectedPriorFiles'] if p.startswith('benchmarks/')];assert len(protected)==505
assert all(subprocess.check_output(['git','show',inputs['baseSource']+':'+p])==(ROOT/p).read_bytes() for p in protected)
def archive(name,payload):
    path=ROOT/'benchmarks'/name;assert not path.exists()
    with zipfile.ZipFile(path,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(payload.items()):z.writestr(n,b)
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(payload) and z.testzip() is None
        assert all(z.read(n)==b for n,b in payload.items())
    return {'file':name,'sha256':sha(path),'bytes':path.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},'allArchivedBytesCompared':True}
files={}
for p in OUT.iterdir():
    if p.is_file() and p.suffix in ('.log','.json'):files['qualification/'+p.name]=p
for dirname in ['ui-tsan','ui-optimized']:
    for p in (OUT/dirname).iterdir():
        if p.is_file():files['qualification/'+dirname+'/'+p.name]=p
# Retain actual failed full runs and development outputs; never include process
# samples, private databases, credential values, native vault payloads or binaries.
for name in ['qualify-v1.py','qualify-v2.py','qualify-v3.py','review-v3.py','publish-v1.py','review-preflight-v1.json','expected-identities-v1.json','qualification-controller-v1.log','qualification-controller-v2.log','qualification-controller-v3.log','frozen-format2-inputs-v1.json','frozen-format2-manifest-v1.json','alias-cache-correction-v1.json','next-peer-membership-contract-v1.md','guardian-path-v12.log']:
    p=BASE/name
    if p.is_file():files['runners-and-development/'+name]=p
for dirname in ['qualification-v1','qualification-v2']:
    for p in (BASE/dirname).iterdir():
        if p.is_file() and p.suffix in ('.log','.json'):files['retained-failed/'+dirname+'/'+p.name]=p
for p in BASE.glob('*.log'):
    if not p.name.startswith('qualification-controller') and 'sample' not in p.name:files.setdefault('runners-and-development/'+p.name,p)
for p in inputs['changedInputs']:files['source/'+p]=ROOT/p
files['baseline/full-debug.log']=Path(inputs['parentFullDebug']['path'])
payload={n:p.read_bytes() for n,p in files.items()}
payload['README.txt']=(f'OSwind opt-in owner-addition app lifecycle source {source}.\n'
 '723 committed runtime/test/build inputs; 19 changed and 704 unchanged preceding inputs. '
 '41 new XCTest identities: 30 actual AppSession cases, four retained-owner busy-close cases, six exact-session transfer cases, one genuine frozen predecessor-format2 gate. '
 'Full Debug, expanded affected TSAN/optimized and explicit native TSAN/optimized selections are checked by exact identity/state, start/terminal balance, aggregate summary and absence of race diagnostics. '
 'One existing wake callback case has a declared unlocked/thermal pass-or-skip variant; receipt reports the actual state. '
 'Native modes include real generated encrypted APFS images, original owned login-Keychain accounts and six offscreen request/review/response component rasters. '
 'Seven delivered-approval SIGKILL phases, frozen35/36 fences/backfill and new actual predecessor cached/fresh refusals remain selected. '
 'Six altered test logs and five altered native records must reject. Normal production package strict ad-hoc signature, executable modes and prior Info/resources are checked.\n'
 'Retained failed qualification v1 had aliased compiler module paths before tests. V2 reached2840 tests and failed three guardian process methods because test fixture hardcoded checkout.build/debug with an external build scratch. '
 'Corrected helper resolution is relative to the actual XCTest bundle in each selected configuration; ten actual process cases pass targeted before final qualification. '
 'Development failures and fixture corrections remain in logs. Native predecessor executable is immutable and omitted; its source fixture and hashes are included. '
 'No private account values, database, user history, weights, trace samples or executable are included.\n'
 'Default two-Mac setup remains unchanged. New addition UI requires OSWIND_OWNER_ADDITION_PREVIEW=1. Existing peers still need catch-up and expanded-group connection. '
 'This is local software/generated native-account evidence, not physical two-Mac, interactive GUI, whole-product sync, uninterrupted24h/current automatic capture, power, production DP-Keychain, DeveloperID/notarization, complete v0 or ranking acceptance. '
 'All505 preceding benchmark publications and83 feature statuses remain unchanged.\n').encode()
raw=archive('sync-owner-app-lifecycle-raw-v1.zip',payload)
manifest=ROOT/'benchmarks/sync-owner-app-lifecycle-inputs-v1.json';receipt=ROOT/'benchmarks/sync-owner-app-lifecycle-v1.json';assert not manifest.exists() and not receipt.exists()
manifest.open('x').write(json.dumps(inputs,indent=2)+'\n')
result=review|{'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(OUT/'reviewed-v3.json'),'publisherSHA256':sha(__file__),'rawEvidence':raw,'priorBenchmarkFilesUnchanged':505,'retainedFailedQualifications':{'v1':'Aliased compiler module paths, failed before tests.','v2':'Three guardian fixture methods failed after complete full suite; exact helper resolution fixed and targeted actual process tests pass.'}}
receipt.open('x').write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':source,'rawSHA256':raw['sha256'],'rawBytes':raw['bytes'],'members':len(payload),'precedingPublicationsUnchanged':505}))
