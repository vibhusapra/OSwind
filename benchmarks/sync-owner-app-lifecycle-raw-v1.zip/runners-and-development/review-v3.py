from pathlib import Path
import hashlib,json,math,re,struct,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';OUT=BASE/'qualification-v3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());results=json.loads((OUT/'results.json').read_text())
assert len(inputs['inputFiles'])==723 and inputs['unchangedBaseInputs']==704 and len(inputs['changedInputs'])==19
assert results['source']==inputs['source']=='136cf1eb06348e4d080f8c97c67626343e7a7c11' # exact Git pin below is checked again
assert results['baseSource']==inputs['baseSource']=='2357d8addaf161815fe249da68c7ff567bfa3312'
assert results['inputManifestSHA256']==sha(OUT/'inputs.json') and results['runnerSHA256']==sha(BASE/'qualify-v3.py')
assert all(sha(ROOT/p)==h for p,h in (inputs['inputFiles']|inputs['packageInputs']|inputs['protectedPriorFiles']).items())
assert all(sha(p)==h for p,h in inputs['frozenFixtures'].items())
for p,h in inputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',inputs['source']+':'+p])).hexdigest()==h
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
started=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' started\.")
def cases(text):
    found=[(a+'.'+b,s) for a,b,s in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
expected=json.loads((BASE/'expected-identities-v1.json').read_text())
assert expected['source']=='3f4273dbc4d60fdd5ced34868a87fc66649567d1'
assert subprocess.check_output(['git','diff','--name-only',expected['source'],inputs['source']],text=True).splitlines()==['Tests/OSwindCoreTests/PreparationProcessTests.swift']
parent=inputs['parentFullDebug'];assert sha(parent['path'])==parent['sha256']==expected['oldFullSHA256']
old=cases(Path(parent['path']).read_text());assert len(old)==2799
new=expected['newMethodIdentities'];assert len(new)==41 and not set(new)&set(old)
assert expected['full']==old|new
for cls,count,module in [('SyncMembershipOwnerCloseTests',4,'OSwindCoreTests'),('SyncOwnerSessionTransferTests',6,'OSwindCoreTests'),('SyncCompletedResponseCompatibilityTests',1,'OSwindCoreTests'),('OwnerAdditionAppSessionTests',30,'OSwindAppTests')]:
    src=ROOT/'Tests'/module/(cls+'.swift');methods=re.findall(r'func (test\w+)\(',src.read_text());assert len(methods)==len(set(methods))==count
    assert set(module+'.'+cls+'.'+m for m in methods)=={k for k in new if k.startswith(module+'.'+cls+'.')}
full=expected['full'];broad={k:v for k,v in full.items() if re.search(inputs['selectors']['broad'],k)};native=expected['native']
assert len(full)==2840 and len(broad)==1500 and len(native)==313
assert set(native)=={k for k in full if re.search(inputs['selectors']['owned'],k)}
assert sum(v=='skipped' for v in native.values())==3
wake='OSwindAppTests.WorkspaceWakeLifecycleTests.testQuietPowerAndSessionCallbacksDoNotRequestVisualCatchup'
wakeReason='Visual admission requires an unlocked session and allowed thermal state; never changes device settings'
phases=['intent','decision','pairing','delivery','commit','clear','after-response']
compat='OWNED_PREDECESSOR_FORMAT2 admittedWrittenPrepared=true cachedAndFreshRefused=true exactCompletedResponse=true currentWriter=true recipientAccepted=true originalAccountsCleaned=5'
def inspect(text,plan):
    found=cases(text);wanted=plan.copy()
    # This one existing host-state test explicitly skips while locked/thermally
    # disallowed. Accept only its declared pass/skip variants, report the actual.
    if wake in wanted:
        assert found.get(wake) in ('passed','skipped')
        wanted[wake]=found[wake]
        if found[wake]=='skipped':assert wakeReason in text
    assert found==wanted
    beginnings=[a+'.'+b for a,b in started.findall(text)];assert len(beginnings)==len(set(beginnings)) and set(beginnings)==set(wanted)
    counts={s:list(found.values()).count(s) for s in ('passed','failed','skipped')};assert counts['failed']==0 and counts['passed']>0
    skip='' if not counts['skipped'] else f", with {counts['skipped']} "+('test' if counts['skipped']==1 else 'tests')+' skipped and'
    assert f"Executed {len(found)} tests{skip if skip else ', with'} 0 failures" in text
    assert not any(s in text for s in ('WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -[',"<unknown>:0: error:"))
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped'),'hostStateWakeCase':found.get(wake)}
def death(text):
    observed=re.findall(r'OWNED_DELIVERY_APPROVAL_DEATH phase=([a-z-]+) signal=9 exactResponse=true originalAccounts=3 cleaned=true',text);assert observed==phases
    assert text.count(compat)==1
    assert 'FROZEN36_FORMAT_FLOOR legacyAdmittedAndWritten=true cachedWriterFenced=true completedFormat2FreshRefused=true' in text
    assert 'FROZEN36_BACKFILL_FLOOR legacyAdmittedAndWritten=true rejectedCommitRecoveredExactToken=true' in text
    return observed
assert len(results['stages'])==len(inputs['stages'])==8
reports=[]
for stage,planned in zip(results['stages'],inputs['stages']):
    name=planned['name'];assert stage['name']==name and stage['command']==planned['command'] and stage['environment']==planned['environment'] and stage['exit']==0
    assert ROOT/stage['log']==OUT/(name+'.log') and sha(ROOT/stage['log'])==stage['sha256'] and math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ('debug-build-tests','release-build','package'):continue
    text=(ROOT/stage['log']).read_text();plan=full if name=='full-debug' else native if name.startswith('owned-') else broad
    report={'name':name,**inspect(text,plan),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']}
    if name.startswith('owned-'):report['deliveredApprovalDeathPhases']=death(text);report['predecessorFormat2Gate']=True
    reports.append(report)
text=(OUT/'affected-tsan.log').read_text();identity='OSwindAppTests.OwnerAdditionAppSessionTests.testApproveThirdMacClosesOriginalAndReopensFreshQuietWorkspace';method=identity.rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l);faults={}
for label,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'failed-case':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testUnexpectedIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race','missing-start':text.replace(next(l for l in text.splitlines() if method in l and "' started." in l),'',1)}.items():
    try:inspect(bad,broad)
    except (AssertionError,KeyError):faults[label]='rejected'
    else:raise AssertionError('Accepted altered log '+label)
nativeText=(OUT/'owned-native-tsan.log').read_text();deathFaults={}
for label,bad in {'missing-death-phase':nativeText.replace('phase=clear signal=9','phase=other signal=9',1),'duplicate-death-phase':nativeText+'\nOWNED_DELIVERY_APPROVAL_DEATH phase=clear signal=9 exactResponse=true originalAccounts=3 cleaned=true','unverified-cleanup':nativeText.replace('originalAccounts=3 cleaned=true','originalAccounts=3 cleaned=false',1),'missing-predecessor':nativeText.replace(compat,'',1),'wrong-predecessor-cleanup':nativeText.replace('originalAccountsCleaned=5','originalAccountsCleaned=4',1)}.items():
    try:death(bad)
    except AssertionError:deathFaults[label]='rejected'
    else:raise AssertionError('Accepted altered native evidence '+label)
ui={};names={n+'-'+a+'.png' for n in ('request','review','response') for a in ('light','dark')}
for dirname in ('ui-tsan','ui-optimized'):
    folder=OUT/dirname;assert {p.name for p in folder.iterdir() if p.is_file()}==names
    images={}
    for p in folder.iterdir():
        blob=p.read_bytes();assert blob[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack('>II',blob[16:24]);assert width>0 and height>0
        original=(BASE/'ui-v2'/p.name).read_bytes();assert blob[16:24]==original[16:24]
        images[p.name]={'sha256':sha(p),'width':width,'height':height}
    for name in ('request','review','response'):assert images[name+'-light.png']['sha256']!=images[name+'-dark.png']['sha256']
    ui[dirname]=images
package=OUT/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()};previous=json.loads((ROOT/'benchmarks/sync-delivered-response-v1.json').read_text())['package']['files']
assert len(files)==len(previous)==34
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:assert (package/'Contents/MacOS'/name).stat().st_mode&0o777==0o755
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
result={'format':'OSwind owner app lifecycle independent review v3','sourceCommit':inputs['source'],'baseSource':inputs['baseSource'],'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(BASE/'qualify-v3.py'),'reviewerSHA256':sha(__file__),'expectedIdentitiesSHA256':sha(BASE/'expected-identities-v1.json'),'inputCount':723,'unchangedBaseInputs':704,'changedInputs':inputs['changedInputs'],'newMethodIdentities':new,'stages':reports,'alteredLogControls':faults,'alteredNativeControls':deathFaults,'UIRasters':ui,'package':{'files':files,'strictAdHocSignatureExit':0,'allPriorResourcesAndInfoUnchanged':True,'executableModes0755':True},'scope':inputs['scope'],'limitations':'Actual app lifecycle tests include generated APFS and owned original login-Keychain accounts, all producer drains, stale review/session/root/database refusals, close retry, cancellation, late lock, quiet restore and vault recovery. Offscreen SwiftUI components only; no interactive GUI/physical two-Mac, full group sync, 24h/current automatic capture, power, production DP-Keychain/DeveloperID/notary/full-v0/top-three acceptance. One existing host-state wake case has an explicit pass/skip variant and actual identities are reported.'}
with (OUT/'reviewed-v3.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'inputs':723,'newMethods':41,'stages':[{k:v for k,v in r.items() if k!='skippedIdentities'} for r in reports],'alteredLogs':len(faults),'alteredNativeEvidence':len(deathFaults),'reviewSHA256':sha(OUT/'reviewed-v3.json')}))
