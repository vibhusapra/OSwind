from pathlib import Path
import hashlib,json,re
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
qualified=json.loads((BASE/'qualification-v3/inputs.json').read_text());assert all(sha(ROOT/p)==h for p,h in qualified['inputFiles'].items())
expected=json.loads((BASE/'expected-identities-v1.json').read_text())['full'];expectedClass={k:v for k,v in expected.items() if '.PersonalSyncPairingModelTests.' in k};assert len(expectedClass)==28
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
reports={}
first=BASE/'recovery-timeout-diagnostic-v1';failed=json.loads((first/'result.json').read_text());assert failed['exit']==-6 and 'Interceptors are not working' in (first/'test.log').read_text() and not pattern.findall((first/'test.log').read_text())
for number,count in [(2,1),(3,28)]:
    root=BASE/('recovery-timeout-diagnostic-v'+str(number));inputs=json.loads((root/'inputs.json').read_text());result=json.loads((root/'result.json').read_text());launcher=json.loads((root/'launcher-v2.json').read_text())
    assert inputs['source']==result['source']==qualified['source'] and result['exit']==0 and result['exactChildReaped']
    assert inputs['driverSHA256']==sha(BASE/('diagnose-recovery-timeout-v'+str(number)+'.py'))
    assert result['inputManifestSHA256']==sha(root/'inputs.json') and result['testLogSHA256']==sha(root/'test.log') and result['launcherSHA256']==sha(root/'launcher-v2.json')
    frozen=Path(inputs['bundle']);assert {str(p.relative_to(frozen)):sha(p) for p in frozen.rglob('*') if p.is_file()}==inputs['files']
    assert sha(launcher['tsanRuntime'])==launcher['sha256'] and launcher['environment']['DYLD_INSERT_LIBRARIES']==launcher['tsanRuntime']
    text=(root/'test.log').read_text();found=[(c+'.'+m,s)for c,m,s in pattern.findall(text)];assert len(found)==len(set(k for k,v in found))==count
    plan=expectedClass if count==28 else {k:v for k,v in expectedClass.items()if k.endswith('.testTerminationJoinsActualRestrictedRecoveryAfterCancellation')};assert dict(found)==plan
    assert 'sanitizer=true timeoutSeconds=120' in text and 'WARNING: ThreadSanitizer' not in text
    counts={s:sum(v==s for k,v in found)for s in ['passed','failed','skipped']};assert counts['failed']==0
    reports[str(number)]={'defined':count,**counts,'inputSHA256':sha(root/'inputs.json'),'testLogSHA256':sha(root/'test.log'),'resultSHA256':sha(root/'result.json'),'exactFrozenFiles':inputs['files'],'samples':len(result['samples']),'wallSeconds':result['wallSeconds']}
result={'format':'OSwind unchanged instrumented recovery diagnostics independent review v1','source':qualified['source'],'qualifiedInputManifestSHA256':sha(BASE/'qualification-v3/inputs.json'),'firstLauncherRefusedBeforeTests':True,'retainedBroadFailureLogSHA256':sha(BASE/'qualification-v3/affected-tsan.log'),'diagnostics':reports,'reviewerSHA256':sha(Path(__file__)),'scope':'Exact source/frozen binary/runtime preload, test identities/states and owned-child exits checked. One specifically failed method and its whole28methodclass pass without source/condition/deadline changes. The original1500methodselection still has one actual timeout; these passes neither explain its cause nor erase it. No native APFS/Keychain/render opt-ins, whole current qualification, production fix, performance or v0 acceptance claim.'}
(BASE/'recovery-diagnostics-reviewed-v1.json').open('x').write(json.dumps(result,indent=2)+'\n');print(json.dumps({'source':qualified['source'],'diagnostics':{k:{kk:vv for kk,vv in v.items() if kk!='exactFrozenFiles'} for k,v in reports.items()},'reviewSHA256':sha(BASE/'recovery-diagnostics-reviewed-v1.json')}))
