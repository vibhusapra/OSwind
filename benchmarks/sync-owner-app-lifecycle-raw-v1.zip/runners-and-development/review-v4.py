from pathlib import Path
import hashlib,json,math,re,struct,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';OUT=BASE/'qualification-v4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());results=json.loads((OUT/'results.json').read_text())
assert len(inputs['inputFiles'])==723 and inputs['unchangedBaseInputs']==703 and len(inputs['changedInputs'])==20
assert results['source']==inputs['source']=='857a03becf5829b779ed274b0e416f519ec1adc5' # exact Git pin below is checked again
assert results['baseSource']==inputs['baseSource']=='2357d8addaf161815fe249da68c7ff567bfa3312'
assert results['inputManifestSHA256']==sha(OUT/'inputs.json') and results['runnerSHA256']==sha(BASE/'qualify-v4.py')
assert all(sha(ROOT/p)==h for p,h in (inputs['inputFiles']|inputs['packageInputs']|inputs['protectedPriorFiles']).items())
assert all(sha(p)==h for p,h in (inputs['frozenFixtures']|inputs['retainedFiles']).items())
for p,h in inputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',inputs['source']+':'+p])).hexdigest()==h
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
started=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' started\.")
def cases(text):
    found=[(a+'.'+b,s) for a,b,s in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
expected=json.loads((BASE/'expected-identities-v1.json').read_text())
assert expected['source']=='3f4273dbc4d60fdd5ced34868a87fc66649567d1'
assert subprocess.check_output(['git','diff','--name-only',expected['source'],inputs['source']],text=True).splitlines()==['Tests/OSwindAppTests/PersonalSyncPairingModelTests.swift','Tests/OSwindCoreTests/PreparationProcessTests.swift']
parent=inputs['parentFullDebug'];assert sha(parent['path'])==parent['sha256']==expected['oldFullSHA256']
old=cases(Path(parent['path']).read_text());assert len(old)==2799
new=expected['newMethodIdentities'];assert len(new)==41 and not set(new)&set(old)
assert expected['full']==old|new
for cls,count,module in [('SyncMembershipOwnerCloseTests',4,'OSwindCoreTests'),('SyncOwnerSessionTransferTests',6,'OSwindCoreTests'),('SyncCompletedResponseCompatibilityTests',1,'OSwindCoreTests'),('OwnerAdditionAppSessionTests',30,'OSwindAppTests')]:
    src=ROOT/'Tests'/module/(cls+'.swift');methods=re.findall(r'func (test\w+)\(',src.read_text());assert len(methods)==len(set(methods))==count
    assert set(module+'.'+cls+'.'+m for m in methods)=={k for k in new if k.startswith(module+'.'+cls+'.')}
full=expected['full'];broad={k:v for k,v in full.items() if re.search(inputs['selectors']['broad'],k)};native=expected['native']
assert len(full)==2840 and len(broad)==1500 and len(native)==313
assert set(native)=={k for k in full if re.search(inputs['selectors']['owned'],k)}
assert sum(v=='skipped' for v in native.values())==3
wake='OSwindAppTests.WorkspaceWakeLifecycleTests.testQuietPowerAndSessionCallbacksDoNotRequestVisualCatchup'
wakeReason='Visual admission requires an unlocked session and allowed thermal state; never changes device settings'
phases=['intent','decision','pairing','delivery','commit','clear','after-response']
compat='OWNED_PREDECESSOR_FORMAT2 admittedWrittenPrepared=true cachedAndFreshRefused=true exactCompletedResponse=true currentWriter=true recipientAccepted=true originalAccountsCleaned=5'
def inspect(text,plan):
    found=cases(text);wanted=plan.copy()
    # This one existing host-state test explicitly skips while locked/thermally
    # disallowed. Accept only its declared pass/skip variants, report the actual.
    if wake in wanted:
        assert found.get(wake) in ('passed','skipped')
        wanted[wake]=found[wake]
        if found[wake]=='skipped':assert wakeReason in text
    assert found==wanted
    beginnings=[a+'.'+b for a,b in started.findall(text)];assert len(beginnings)==len(set(beginnings)) and set(beginnings)==set(wanted)
    counts={s:list(found.values()).count(s) for s in ('passed','failed','skipped')};assert counts['failed']==0 and counts['passed']>0
    skip='' if not counts['skipped'] else f", with {counts['skipped']} "+('test' if counts['skipped']==1 else 'tests')+' skipped and'
    assert f"Executed {len(found)} tests{skip if skip else ', with'} 0 failures" in text
    assert not any(s in text for s in ('WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -[',"<unknown>:0: error:"))
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped'),'hostStateWakeCase':found.get(wake)}
def death(text):
    observed=re.findall(r'OWNED_DELIVERY_APPROVAL_DEATH phase=([a-z-]+) signal=9 exactResponse=true originalAccounts=3 cleaned=true',text);assert observed==phases
    assert text.count(compat)==1
    assert 'FROZEN36_FORMAT_FLOOR legacyAdmittedAndWritten=true cachedWriterFenced=true completedFormat2FreshRefused=true' in text
    assert 'FROZEN36_BACKFILL_FLOOR legacyAdmittedAndWritten=true rejectedCommitRecoveredExactToken=true' in text
    return observed
fixture={k:v for k,v in full.items() if '.PersonalSyncPairingModelTests.' in k};assert len(fixture)==28
retained=inputs['retainedFullDebug'];retainedInputs=json.loads((BASE/'qualification-v3/inputs.json').read_text());retainedResults=json.loads((BASE/'qualification-v3/results.json').read_text())
assert retained['source']==retainedInputs['source']=='136cf1eb06348e4d080f8c97c67626343e7a7c11'
assert retained['inputManifestSHA256']==sha(BASE/'qualification-v3/inputs.json')
assert set(inputs['inputFiles'])==set(retainedInputs['inputFiles'])
delta=[p for p,h in inputs['inputFiles'].items() if retainedInputs['inputFiles'][p]!=h];assert delta==retained['changedTestOnlyInputs']==['Tests/OSwindAppTests/PersonalSyncPairingModelTests.swift']
assert retainedInputs['packageInputs']==inputs['packageInputs'] and retainedInputs['frozenFixtures']==inputs['frozenFixtures'] and retainedInputs['protectedPriorFiles']==inputs['protectedPriorFiles']
for p,h in retainedInputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',retainedInputs['source']+':'+p])).hexdigest()==h
oldFull=next(x for x in retainedResults['stages'] if x['name']=='full-debug');assert oldFull==retained['stage'] and oldFull['exit']==0 and oldFull['sha256']==sha(ROOT/oldFull['log'])
retainedFullReport={'source':retained['source'],**inspect((ROOT/oldFull['log']).read_text(),full),'logSHA256':oldFull['sha256'],'wallSeconds':oldFull['wallSeconds'],'currentTestOnlyChanges':delta,'allOther722InputsAndPackageIdentical':True,'scope':retained['scope']}
assert retainedFullReport['defined']==2840 and retainedFullReport['passed']==2670 and retainedFullReport['skipped']==170
oldBroad=next(x for x in retainedResults['stages'] if x['name']=='affected-tsan');assert oldBroad['exit']==1 and oldBroad['sha256']==sha(ROOT/oldBroad['log'])=='79f0f5dde350444648c95cce687819a3c0dcdcacdbb6fd9760ce165e85c3c254'
oldText=(ROOT/oldBroad['log']).read_text();oldExpected=broad.copy();oldExpected[wake]='passed';failedIdentity='OSwindAppTests.PersonalSyncPairingModelTests.testTerminationJoinsActualRestrictedRecoveryAfterCancellation';oldExpected[failedIdentity]='failed';assert cases(oldText)==oldExpected
assert 'Executed 1500 tests, with 131 tests skipped and 1 failure' in oldText and 'Owned root transition did not finish: ' in oldText and 'WARNING: ThreadSanitizer' not in oldText
retainedFailure={'source':retained['source'],'logSHA256':oldBroad['sha256'],'defined':1500,'passed':1368,'skipped':131,'failed':1,'identity':failedIdentity,'cause':'Unexplained; no source/deadline change in successful frozen diagnostics, new fixture adds only state/callsite diagnostics and a stronger existing admission assertion. Do not call this a production fix.'}
diag=BASE/'recovery-diagnostics-reviewed-v1.json';assert sha(diag)=='e900fa768bd545ba57e6145852d3b9bc6b2ed8ccd5f2536ab65221e8f73d37d2';diagnostics=json.loads(diag.read_text());assert diagnostics['reviewerSHA256']==sha(BASE/'review-recovery-diagnostics-v1.py')
for number,count in [('2',1),('3',28)]:
    root=BASE/('recovery-timeout-diagnostic-v'+number);record=json.loads((root/'result.json').read_text());pin=json.loads((root/'inputs.json').read_text());launcher=json.loads((root/'launcher-v2.json').read_text())
    assert record['source']==retained['source'] and record['exit']==0 and record['exactChildReaped']
    assert record['inputManifestSHA256']==sha(root/'inputs.json') and record['testLogSHA256']==sha(root/'test.log') and record['launcherSHA256']==sha(root/'launcher-v2.json')
    assert pin['driverSHA256']==sha(BASE/('diagnose-recovery-timeout-v'+number+'.py')) and sha(launcher['tsanRuntime'])==launcher['sha256']
    assert {str(p.relative_to(Path(pin['bundle']))):sha(p) for p in Path(pin['bundle']).rglob('*') if p.is_file()}==pin['files']
    wanted=fixture if number=='3' else {failedIdentity:'passed'};assert cases((root/'test.log').read_text())==wanted
assert len(results['stages'])==len(inputs['stages'])==7
reports=[]
for stage,planned in zip(results['stages'],inputs['stages']):
    name=planned['name'];assert stage['name']==name and stage['command']==planned['command'] and stage['environment']==planned['environment'] and stage['exit']==0
    assert ROOT/stage['log']==OUT/(name+'.log') and sha(ROOT/stage['log'])==stage['sha256'] and math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ('release-build','package'):continue
    text=(ROOT/stage['log']).read_text();plan=fixture if name=='debug-fixture-regression' else native if name.startswith('owned-') else broad
    report={'name':name,**inspect(text,plan),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']}
    if name.startswith('owned-'):report['deliveredApprovalDeathPhases']=death(text);report['predecessorFormat2Gate']=True
    reports.append(report)
text=(OUT/'affected-tsan.log').read_text();identity='OSwindAppTests.OwnerAdditionAppSessionTests.testApproveThirdMacClosesOriginalAndReopensFreshQuietWorkspace';method=identity.rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l);faults={}
for label,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'failed-case':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testUnexpectedIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race','missing-start':text.replace(next(l for l in text.splitlines() if method in l and "' started." in l),'',1)}.items():
    try:inspect(bad,broad)
    except (AssertionError,KeyError):faults[label]='rejected'
    else:raise AssertionError('Accepted altered log '+label)
nativeText=(OUT/'owned-native-tsan.log').read_text();deathFaults={}
for label,bad in {'missing-death-phase':nativeText.replace('phase=clear signal=9','phase=other signal=9',1),'duplicate-death-phase':nativeText+'\nOWNED_DELIVERY_APPROVAL_DEATH phase=clear signal=9 exactResponse=true originalAccounts=3 cleaned=true','unverified-cleanup':nativeText.replace('originalAccounts=3 cleaned=true','originalAccounts=3 cleaned=false',1),'missing-predecessor':nativeText.replace(compat,'',1),'wrong-predecessor-cleanup':nativeText.replace('originalAccountsCleaned=5','originalAccountsCleaned=4',1)}.items():
    try:death(bad)
    except AssertionError:deathFaults[label]='rejected'
    else:raise AssertionError('Accepted altered native evidence '+label)
ui={};names={n+'-'+a+'.png' for n in ('request','review','response') for a in ('light','dark')}
for dirname in ('ui-tsan','ui-optimized'):
    folder=OUT/dirname;assert {p.name for p in folder.iterdir() if p.is_file()}==names
    images={}
    for p in folder.iterdir():
        blob=p.read_bytes();assert blob[:8]==b'\x89PNG\r\n\x1a\n';width,height=struct.unpack('>II',blob[16:24]);assert width>0 and height>0
        original=(BASE/'ui-v2'/p.name).read_bytes();assert blob[16:24]==original[16:24]
        images[p.name]={'sha256':sha(p),'width':width,'height':height}
    for name in ('request','review','response'):assert images[name+'-light.png']['sha256']!=images[name+'-dark.png']['sha256']
    ui[dirname]=images
package=OUT/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()};previous=json.loads((ROOT/'benchmarks/sync-delivered-response-v1.json').read_text())['package']['files']
assert len(files)==len(previous)==34
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:assert (package/'Contents/MacOS'/name).stat().st_mode&0o777==0o755
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
result={'format':'OSwind owner app lifecycle independent review v4','sourceCommit':inputs['source'],'baseSource':inputs['baseSource'],'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(BASE/'qualify-v4.py'),'reviewerSHA256':sha(__file__),'expectedIdentitiesSHA256':sha(BASE/'expected-identities-v1.json'),'inputCount':723,'unchangedBaseInputs':703,'changedInputs':inputs['changedInputs'],'newMethodIdentities':new,'retainedFullDebug':retainedFullReport,'retainedBroadFailure':retainedFailure,'unchangedDiagnosticReviewSHA256':sha(diag),'stages':reports,'alteredLogControls':faults,'alteredNativeControls':deathFaults,'UIRasters':ui,'package':{'files':files,'strictAdHocSignatureExit':0,'allPriorResourcesAndInfoUnchanged':True,'executableModes0755':True},'scope':inputs['scope'],'limitations':'Actual app lifecycle tests include generated APFS and owned original login-Keychain accounts, all producer drains, stale review/session/root/database refusals, close retry, cancellation, late lock, quiet restore and vault recovery. Offscreen SwiftUI components only; no interactive GUI/physical two-Mac, full group sync, 24h/current automatic capture, power, production DP-Keychain/DeveloperID/notary/full-v0/top-three acceptance. One existing host-state wake case has an explicit pass/skip variant and actual identities are reported. Full Debug is the retained136source result plus a separately selected current28methodfixture regression; allother722inputs and allproduction/packageinputs are identical. Earlier broadTSANtimeout remains unexplained; currentdiagnostics do not change its30secondcondition/deadline or claim a production fix.'}
with (OUT/'reviewed-v4.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'inputs':723,'newMethods':41,'stages':[{k:v for k,v in r.items() if k!='skippedIdentities'} for r in reports],'alteredLogs':len(faults),'alteredNativeEvidence':len(deathFaults),'reviewSHA256':sha(OUT/'reviewed-v4.json')}))
