from pathlib import Path
import hashlib,json,re,subprocess
R=Path.cwd();B=R/'.artifacts/owner-app-integration-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();S='5efde85a5c84a877c787afe9f700276d4aef61d3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==S
D=B/'pairing-phase-diagnostic-v2';I=json.loads((D/'inputs.json').read_text());O=json.loads((D/'result.json').read_text())
assert I['source']==O['source']==S and not I['phaseTracingRequested'] and O['exit']==0
assert len(I['sourceInputs'])==723 and all(sha(R/p)==h for p,h in I['sourceInputs'].items())
assert O['inputManifestSHA256']==sha(D/'inputs.json') and O['logSHA256']==sha(D/'test.log') and I['driverSHA256']==sha(B/'diagnose-pairing-phases-v2.py')
pat=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def cases(t):
 x=[(a+'.'+b,s) for a,b,s in pat.findall(t)];assert len(x)==len(dict(x));return dict(x)
T=(D/'test.log').read_text();C=cases(T);E=json.loads((B/'expected-identities-v1.json').read_text())['full'];P={k:v for k,v in E.items() if '.PersonalSyncPairingModelTests.' in k}
assert C==P and len(C)==28 and list(C.values()).count('passed')==25 and list(C.values()).count('skipped')==3
assert 'OWNED_PAIRING_PHASE' not in T and 'Executed 28 tests, with 3 tests skipped and 0 failures' in T
K=B/'pairing-trace-flag-control-v1';KI=json.loads((K/'inputs.json').read_text());KO=json.loads((K/'result.json').read_text());KT=(K/'test.log').read_text()
assert KI['source']==KO['source']==S and KO['exit']==0 and KI['environment']=={'OSWIND_TEST_PAIRING_PHASE_TRACE':'1'}
assert KO['inputSHA256']==sha(K/'inputs.json') and KO['logSHA256']==sha(K/'test.log') and KI['driverSHA256']==sha(B/'check-pairing-trace-flag-v1.py')
assert KO['tracingOffFullClassLogSHA256']==sha(D/'test.log') and KI['priorDebugInputSHA256']==sha(D/'inputs.json')
assert cases(KT)=={'OSwindAppTests.PersonalSyncPairingModelTests.testDeniedOrClosedLibraryDoesNotCreateCredentials':'passed'}
for phase in ['setup-begin','setup-store-a','setup-store-b','setup-complete','teardown-begin','teardown-sessions','teardown-models','teardown-preferences','teardown-store-a','teardown-store-b','teardown-complete']:assert 'phase='+phase+' elapsedSeconds=' in KT
bundle=Path(KI['command'][-1]);assert {str(p.relative_to(bundle)):sha(p) for p in bundle.rglob('*') if p.is_file()}==KI['files']
old=json.loads((B/'qualification-v3/inputs.json').read_text());assert {p for p,h in I['sourceInputs'].items() if old['inputFiles'][p]!=h}=={'Tests/OSwindAppTests/PersonalSyncPairingModelTests.swift'}
pins={str(p):sha(p) for p in [D/'inputs.json',D/'result.json',D/'test.log',K/'inputs.json',K/'result.json',K/'test.log',B/'diagnose-pairing-phases-v2.py',B/'check-pairing-trace-flag-v1.py']}
O={'source':S,'reviewerSHA256':sha(__file__),'sourceInputCount':723,'defaultOff':{'defined':28,'passed':25,'skipped':3,'logSHA256':sha(D/'test.log')},'traceOn':{'defined':1,'passed':1,'logSHA256':sha(K/'test.log')},'retainedFiles':pins,'scope':'Current-source Debug class plus a separate trace-on branch check. Only one test file differs from retained successful full Debug136. Earlier broadTSAN and subsequent Debug timeouts remain unexplained. No production fix, deadline relaxation, full-current-suite or performance claim.'}
with (B/'pairing-phase-diagnostics-reviewed-v1.json').open('x') as f:json.dump(O,f,indent=2);f.write('\n')
print(json.dumps(O))
