from pathlib import Path
import hashlib,json,os,platform,subprocess,time
ROOT=Path.cwd();B=ROOT/'.artifacts/owner-app-integration-v1';PRIOR=B/'qualification-v5';OUT=B/'qualification-continuation-v1';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source='5efde85a5c84a877c787afe9f700276d4aef61d3'
I=json.loads((PRIOR/'inputs.json').read_text());inputHash=sha(PRIOR/'inputs.json');assert I['source']==source and len(I['stages'])==6
ownerPID=99043
ownerStart=subprocess.check_output(['ps','-p',str(ownerPID),'-o','lstart='],text=True).strip();assert ownerStart
ownerCommand=subprocess.check_output(['ps','-p',str(ownerPID),'-o','command='],text=True).strip();assert ownerCommand.endswith('.artifacts/owner-app-integration-v1/qualify-v5.py')
def unchanged():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source and sha(PRIOR/'inputs.json')==inputHash
 assert all(sha(ROOT/p)==h for p,h in (I['inputFiles']|I['packageInputs']|I['protectedPriorFiles']).items())
 assert all(sha(p)==h for p,h in (I['frozenFixtures']|I['retainedFiles']).items())
unchanged()
watch={'format':'OSwind distinct-stage qualification continuation v1','source':source,'priorInputSHA256':inputHash,'priorPID':ownerPID,'priorStart':ownerStart,'priorCommand':ownerCommand,'driverSHA256':sha(__file__),'scope':'Wait for exact current controller to terminate, then execute only its unexecuted stage plans. Never rerun a successful or failed selection to obtain a green result. Retain every prior and new exit/log. Any failure keeps overall qualification incomplete; no production fix or relaxed waits. No protected source/HEAD changes until terminal.'}
(OUT/'watch-inputs.json').write_text(json.dumps(watch,indent=2)+'\n');print('WAIT_EXACT_PRIOR',ownerPID,flush=True)
deadline=time.monotonic()+10800
while True:
 p=subprocess.run(['ps','-p',str(ownerPID),'-o','lstart=','-o','stat=','-o','command='],capture_output=True,text=True)
 if p.returncode or ownerStart not in p.stdout or ownerCommand not in p.stdout or ' Z ' in p.stdout:break
 if time.monotonic()>=deadline:raise SystemExit('Exact prior controller still running after observation boundary; do not restart it.')
 time.sleep(5)
unchanged();R=json.loads((PRIOR/'results.json').read_text());assert R['source']==source and R['inputManifestSHA256']==inputHash and R['runnerSHA256']==sha(B/'qualify-v5.py')
assert 1<=len(R['stages'])<=len(I['stages'])
for actual,plan in zip(R['stages'],I['stages']):
 assert actual['name']==plan['name'] and actual['command']==plan['command'] and actual['environment']==plan['environment'] and sha(ROOT/actual['log'])==actual['sha256']
remaining=I['stages'][len(R['stages']):]
assert not remaining or R['stages'][-1]['exit']!=0
retained={str(PRIOR/'inputs.json'):inputHash,str(PRIOR/'results.json'):sha(PRIOR/'results.json'),**{str(ROOT/s['log']):s['sha256'] for s in R['stages']}}
manifest=watch|{'priorResults':R,'retainedFiles':retained,'stages':remaining,'watchInputSHA256':sha(OUT/'watch-inputs.json')}
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'source':source,'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(__file__),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'priorStagesNotRepeated':len(R['stages']),'stages':[],'overallQualificationComplete':False}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_') and k not in ['OSWIND_OWNER_ADDITION_PREVIEW','OSWIND_OWNER_UI_QA_DIR']}
for planned in remaining:
 unchanged();assert all(sha(p)==h for p,h in retained.items());assert os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize>=16*1024**3
 name=planned['name'];print('START_DISTINCT_REMAINING',name,flush=True);start=time.monotonic();log=OUT/(name+'.log')
 with log.open('xb') as f:code=subprocess.run(planned['command'],env=env|planned['environment'],stdout=f,stderr=subprocess.STDOUT).returncode
 result['stages'].append(planned|{'exit':code,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(ROOT)),'sha256':sha(log)})
 (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH_DISTINCT_REMAINING',name,code,flush=True);unchanged()
# This deliberately keeps a failed earlier run failed, even when every other
# selected mode succeeds. Final review must report the actual failures.
result['allDistinctPlansExecuted']=len(R['stages'])+len(result['stages'])==len(I['stages'])
result['overallQualificationComplete']=all(s['exit']==0 for s in R['stages']+result['stages'])
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('ALL_DISTINCT_STAGES_COMPLETE overallPass='+str(result['overallQualificationComplete']),flush=True)
raise SystemExit(0 if result['overallQualificationComplete'] else 1)
