from pathlib import Path
import hashlib,json,os,platform,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/owner-app-integration-v1';OUT=BASE/'qualification-v2';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='3f4273dbc4d60fdd5ced34868a87fc66649567d1'
base='2357d8addaf161815fe249da68c7ff567bfa3312'
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines()
extra=['scripts/build-app.sh','scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(ROOT/p) for p in paths if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved',*extra]) and (ROOT/p).is_file()};assert len(pins)==723
changes=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines();assert len(changes)==18 and all(p in pins for p in changes)
unchangedBase={p:h for p,h in pins.items() if p not in changes};assert len(unchangedBase)==705
assert all(hashlib.sha256(subprocess.check_output(['git','show',base+':'+p])).hexdigest()==h for p,h in unchangedBase.items())
packageInputs={p:sha(ROOT/p) for p in paths if p.startswith(('ThirdParty/','assets/','models/')) and (ROOT/p).is_file()}
packageInputs|={p:sha(ROOT/p) for p in ['scripts/build-app.sh','scripts/convert-visual-model.py','scripts/convert-visual-model.py.lock']}
protected={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'benchmarks').rglob('*') if p.is_file()}
assert len(protected)==505
for p in ['docs/features.json','docs/landscape.md','docs/landscape.html']:
    if (ROOT/p).is_file():protected[p]=sha(ROOT/p)
frozen35=Path('/Users/vibhusapra/.codex/worktrees/sync-enrollment/oswind/.artifacts/keyword-startup-v1/package-v1/OSwind.app/Contents/MacOS/oswindctl');assert sha(frozen35)=='c958f555cf55c962b721f2835c5e9675d922a096bb4a4c0948f59016ec50887d'
oldbase=Path('/Users/vibhusapra/.codex/worktrees/calendar-meeting-context/oswind/.artifacts')
f36path=oldbase/'sync-membership-floor-v1/frozen36-manifest-v2.json';f36=json.loads(f36path.read_text());f36root=Path(f36['bundle'])
assert f36['executableSHA256']=='80a09cbd70547dc61b1834bd6ef2f20a5867852a9b73ab38030391d0ac7959de'
f2path=BASE/'frozen-format2-manifest-v1.json';f2=json.loads(f2path.read_text());f2root=Path(f2['bundle'])
assert f2['executableSHA256']=='eda659940af877a7fff5d11e32585c64e9077a29b61d9ca269507a86b0be8561'
frozen={str(frozen35):sha(frozen35),str(f36path):sha(f36path),str(f2path):sha(f2path),**{str(f36root/p):h for p,h in f36['files'].items()},**{str(f2root/p):h for p,h in f2['files'].items()}}
parentFull=oldbase/'delivery-owner-response-v1/qualification-v1/full-debug.log'
assert parentFull.is_file()
def unchanged():
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
    assert all(sha(ROOT/p)==h for p,h in (pins|packageInputs|protected).items()) and all(sha(p)==h for p,h in frozen.items())
unchanged()
broad='OSwindAppTests|Sync|PersonalSync|LibraryWipe|LibraryRecovery|LibraryOpening|Vault'
owned='Vault|OwnerAdditionAppSessionTests|SyncCompletedResponseCompatibilityTests|SyncMembershipOwnerCloseTests|SyncOwnerSessionTransferTests|SyncDeliveryOwnerResponseCrashTests|SyncOwnerApproval|PersonalSyncApprovedResponseTests|SyncMembership(Preparation|Floor|Backfill)|SyncDeliveryAnchorTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably'
native={'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE35_CLI':str(frozen35),'OSWIND_TEST_NATIVE36_BUNDLE':str(f36root),'OSWIND_TEST_PREDECESSOR_FORMAT2_MANIFEST':str(f2path)}
stages=[('debug-build-tests',['swift','build','--build-tests','-j','2'],{}),('full-debug',['swift','test','--skip-build','-j','2'],{}),('affected-tsan',['swift','test','--sanitize=thread','-j','2','--filter',broad],{}),('owned-native-tsan',['swift','test','--sanitize=thread','--skip-build','-j','2','--filter',owned],native|{'OSWIND_OWNER_UI_QA_DIR':str(OUT/'ui-tsan')}),('affected-optimized',['swift','test','-c','release','-j','2','--filter',broad],{}),('owned-native-optimized',['swift','test','-c','release','--skip-build','-j','2','--filter',owned],native|{'OSWIND_OWNER_UI_QA_DIR':str(OUT/'ui-optimized')}),('release-build',['swift','build','-c','release','-j','2'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(OUT/'OSwind.app')})]
scratch=Path('/Users/vibhusapra/.codex/worktrees/calendar-meeting-context/oswind/.build')
stages=[(n,c[:2]+['--scratch-path',str(scratch)]+c[2:] if c[0]=='swift' else c,e|({'OSWIND_BUILD_ROOT':str(scratch)} if n=='package' else {})) for n,c,e in stages]
manifest={'format':'OSwind owner app lifecycle qualification inputs v2','source':source,'baseSource':base,'inputFiles':pins,'changedInputs':changes,'unchangedBaseInputs':len(unchangedBase),'packageInputs':packageInputs,'protectedPriorFiles':protected,'frozenFixtures':frozen,'parentFullDebug':{'path':str(parentFull),'sha256':sha(parentFull)},'selectors':{'broad':broad,'owned':owned},'stages':[{'name':n,'command':c,'environment':e} for n,c,e in stages],'scope':'Opt-in owner-addition app preview: exact review, joined actual producer drain/session stop, retained original owner through intent/close failure, same-directory/account/generation quiet reopening, response return and saved recovery including encrypted vault detach/unlock. Default two-Mac setup unchanged. Peer membership catch-up and fullsync not enabled.'}
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'source':source,'baseSource':base,'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(__file__),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_') and k not in ['OSWIND_OWNER_ADDITION_PREVIEW','OSWIND_OWNER_UI_QA_DIR']}
for name,command,environment in stages:
    unchanged();print('START',name,flush=True);begin=time.monotonic();log=OUT/(name+'.log')
    with log.open('xb') as f:code=subprocess.run(command,env=env|environment,stdout=f,stderr=subprocess.STDOUT).returncode
    result['stages'].append({'name':name,'command':command,'environment':environment,'exit':code,'wallSeconds':time.monotonic()-begin,'log':str(log.relative_to(ROOT)),'sha256':sha(log)})
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH',name,code,flush=True);unchanged()
    if code:raise SystemExit(code)
print('QUALIFICATION_COMPLETE',flush=True)
