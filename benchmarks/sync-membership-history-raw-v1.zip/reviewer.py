from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();base=root/'.artifacts/sync-membership-history-v1/development-v3';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((base/'inputs.json').read_text());results=json.loads((base/'results.json').read_text())
assert inputs['source']==results['source']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert sha(base/'inputs.json')==results['inputManifestSHA256']
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items()) and len(inputs['inputFiles'])>650
assert set(inputs['workingChanges'])=={'Sources/OSwindCore/PersonalSyncPairing.swift','Sources/OSwindCore/SyncMembershipHistory.swift','Tests/OSwindCoreTests/SyncMembershipHistoryTests.swift'}
assert set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())=={'Sources/OSwindCore/PersonalSyncPairing.swift','docs/SYNC-MEMBERSHIP-REFRESH-WIP.md'}
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())=={'Sources/OSwindCore/SyncMembershipHistory.swift','Tests/OSwindCoreTests/SyncMembershipHistoryTests.swift'}
expected=set(re.findall(r'func (test\w+)\(', (root/'Tests/OSwindCoreTests/SyncMembershipHistoryTests.swift').read_text()));assert len(expected)==10
native_new='testOwnedNativeKeychainFourLibrariesRetainExactOfflineHistoryAcrossNativeReopen';native_selector=results['stages'][-1]['command'][-1]
assert [s['name'] for s in results['stages']]==['debug','tsan','optimized','owned-keychain']
review=[];first=None
for stage in results['stages']:
 log=root/stage['log'];assert stage['exit']==0 and sha(log)==stage['sha256'];text=log.read_text()
 raw=re.findall(r"Test Case '-\[(\w+\.\w+) (test\w+)\]' (passed|skipped|failed)",text)
 states={(a,b):c for a,b,c in raw};assert len(states)==len(raw) and states
 summary=re.findall(r'Executed (\d+) tests?, with (?:(\d+) tests? skipped and )?(\d+) failures?',text)[-1]
 assert int(summary[0])==len(states) and int(summary[1] or 0)==sum(v=='skipped' for v in states.values()) and int(summary[2])==0
 assert all(v in ['passed','skipped'] for v in states.values()) and 'WARNING: ThreadSanitizer:' not in text
 new={b:c for (a,b),c in states.items() if a=='OSwindCoreTests.SyncMembershipHistoryTests'};assert set(new)==expected
 if stage['name']=='owned-keychain':
  assert all(v=='passed' for v in states.values()),'Owned stage may not hide a native skip'
  assert set(states)=={(a,b) for a,b in first if re.search(native_selector,a+'/'+b)}
 else:
  assert new[native_new]=='skipped' and all(new[b]=='passed' for b in expected-{native_new})
  if first is None:first=set(states)
  else:assert set(states)==first
 review.append({'mode':stage['name'],'defined':len(states),'passed':sum(v=='passed' for v in states.values()),'skipped':[a+'/'+b for (a,b),v in states.items() if v=='skipped'],'failed':0,'newHistoryMethods':new,'logSHA256':sha(log),'wallSeconds':stage['wallSeconds']})
out=base/'reviewed-v1.json';assert not out.exists()
result={'format':'OSwind persistent membership history selected development review v1','baseSource':inputs['source'],'inputCount':len(inputs['inputFiles']),'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(base/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':review,'scope':'Actual pre-delivery pairing public certificate retention, exact private-head export and portable-recovery exclusion; selected native/lifecycle regression and four owned login-Keychain libraries on one Mac. No active delivery membership mutation, native36/recovery, revocation/rotation, physical devices, provider or production signing acceptance.'}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'review':str(out.relative_to(root)),'sha256':sha(out),'stages':[{'mode':s['mode'],'defined':s['defined'],'passed':s['passed'],'skipped':len(s['skipped'])} for s in review]}))
