from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();base=root/'.artifacts/sync-membership-history-v1';out=base/'development-v3';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
files=sorted(p for p in subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines() if p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved'])
pins={p:sha(root/p) for p in files if (root/p).is_file()};assert len(pins)>650
changed=['Sources/OSwindCore/PersonalSyncPairing.swift','Sources/OSwindCore/SyncMembershipHistory.swift','Tests/OSwindCoreTests/SyncMembershipHistoryTests.swift']
manifest={'source':source,'inputFiles':pins,'workingChanges':{p:pins[p] for p in changed},'scope':'Persistent public history in actual pre-delivery pairing; selected native writer/lifecycle regression and owned Keychain. Not native membership transition.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
prior=root/'.artifacts';frozen={
 'OSWIND_TEST_PUBLICATION_OLD32_CLI':(prior/'sync-unavailable-scopes-v1/qualification-v3/OSwind.app/Contents/MacOS/oswindctl','ce600b7d4c74eaaba65db61050b9b369a05352a9fe80c145e7a438448e01e6e2'),
 'OSWIND_TEST_COLLECTION_PRIOR33_CLI':(prior/'search-index-lifecycle-v1/qualification-v1/OSwind.app/Contents/MacOS/oswindctl','6580f0db8534063df2fbf04115eb4142af9eb33ef2e2df098d177f6988013c92'),
 'OSWIND_TEST_NATIVE34_CLI':(prior/'sync-native-admission-v1/qualification-v1/frozen-prior34/oswindctl','be363108102b5308a7325375e8aa6a4f6597cfd2d92091a195b995ed1484e644')}
assert all(sha(p)==h for p,h in frozen.values())
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')};env.update({k:str(p) for k,(p,h) in frozen.items()})
selector='SyncMembership|SyncPairingTests|SyncNativeWriterAdmissionTests|SyncDeliveryAnchorTests|PersonalSyncLifecycleTests|PersonalSyncPairingModelTests'
stages=[('debug',['swift','test','--filter',selector],{}),('tsan',['swift','test','--sanitize=thread','--filter',selector],{}),('optimized',['swift','test','-c','release','--filter',selector],{}),('owned-keychain',['swift','test','--filter','SyncMembershipHistory|PersonalSyncPairingTests|SyncNativeWriterAdmissionTests|SyncDeliveryAnchorTests'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'})]
results={'source':source,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'frozenControls':{k:h for k,(p,h) in frozen.items()},'stages':[]}
for name,cmd,extras in stages:
 assert all(sha(root/p)==h for p,h in pins.items());print('START',name,flush=True);log=out/(name+'.log');started=time.monotonic()
 stageenv={**env,**extras,'OSWIND_TEST_SYNC_ANCHORED_FIXTURE_ROOT':str(out/(name+'-fixtures'))}
 with log.open('xb') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=stageenv).returncode
 results['stages'].append({'name':name,'command':cmd,'environment':extras,'exit':code,'wallSeconds':time.monotonic()-started,'log':str(log.relative_to(root)),'sha256':sha(log)})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,code,flush=True)
 assert all(sha(root/p)==h for p,h in pins.items());assert all(sha(p)==h for p,h in frozen.values())
 if code:raise SystemExit(code)
print('ALL_STAGES_TERMINAL',flush=True)
