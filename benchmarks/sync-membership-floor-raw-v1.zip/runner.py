from pathlib import Path
import hashlib,json,os,platform,subprocess,time
root=Path.cwd();base=root/'.artifacts/sync-membership-floor-v1';out=base/'qualification-v1';out.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='652bf4476af01620d7896631f65633df134b4f27'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();files=sorted(set(p for p in paths if p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved']));pins={p:sha(root/p) for p in files if (root/p).is_file()};assert len(pins)==682
changes=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()));code=[p for p in changes if p.startswith(('Sources/','Tests/'))];assert len(code)==6
manifest={'format':'OSwind native membership format-floor qualification inputs v1','baseSource':source,'inputFiles':pins,'workingChanges':{p:pins[p] for p in code},'scope':'Format2 for new completed handovers; actual frozen d665a30 positive admission, cached-writer fencing and fresh format refusal, cancellation/retirement floor preservation, legacy pending recovery. Already-cleared format1 previews can finish replay but still need a separate durable backfill fence before public integration. F059 incomplete.'};(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
frozen={
'OSWIND_TEST_PUBLICATION_OLD32_CLI':(root/'.artifacts/sync-unavailable-scopes-v1/qualification-v3/OSwind.app/Contents/MacOS/oswindctl','ce600b7d4c74eaaba65db61050b9b369a05352a9fe80c145e7a438448e01e6e2'),
'OSWIND_TEST_COLLECTION_PRIOR33_CLI':(root/'.artifacts/search-index-lifecycle-v1/qualification-v1/OSwind.app/Contents/MacOS/oswindctl','6580f0db8534063df2fbf04115eb4142af9eb33ef2e2df098d177f6988013c92'),
'OSWIND_TEST_NATIVE34_CLI':(root/'.artifacts/sync-native-admission-v1/qualification-v1/frozen-prior34/oswindctl','be363108102b5308a7325375e8aa6a4f6597cfd2d92091a195b995ed1484e644'),
'OSWIND_TEST_NATIVE35_CLI':(Path('/Users/vibhusapra/.codex/worktrees/sync-enrollment/oswind/.artifacts/keyword-startup-v1/package-v1/OSwind.app/Contents/MacOS/oswindctl'),'c958f555cf55c962b721f2835c5e9675d922a096bb4a4c0948f59016ec50887d')}
# Fixed frozen inputs are never rebuilt, resigned or overwritten.
frozen36_manifest=base/'frozen36-manifest-v2.json';frozen36=json.loads(frozen36_manifest.read_text());frozen36_root=Path(frozen36['bundle']);frozen36_manifest_sha=sha(frozen36_manifest)
assert frozen36['originalRuntime']=='d665a30196b1609a2248cc1550fe3f817b3f8277' and frozen36['originalInputCount']==679 and frozen36['executableSHA256']=='80a09cbd70547dc61b1834bd6ef2f20a5867852a9b73ab38030391d0ac7959de'
def require_old36():
 assert sha(frozen36_manifest)==frozen36_manifest_sha and all(sha(frozen36_root/p)==h for p,h in frozen36['files'].items())
require_old36()
original=json.loads((base/'frozen36-original-inputs-v1.json').read_text());assert len(original['inputFiles'])==679
assert all(sha(base/'frozen36-build-v1'/p)==h for p,h in original['inputFiles'].items())
assert sha(base/'frozen36-build-v1/Tests/OSwindCoreTests/SyncNative36FrozenWorkerTests.swift')==frozen36['workerSHA256']
assert all(sha(p)==h for p,h in frozen.values())
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')};env.update({k:str(p) for k,(p,h) in frozen.items()});env['OSWIND_TEST_NATIVE36_BUNDLE']=str(frozen36_root)
selector='Sync|LibraryRecovery|PersonalSync'
native='SyncMembership|SyncCredentialMaterial|SyncPairingTests|SyncNativeWriterAdmission|SyncNativeReceivedRetirement|SyncDeliveryAnchor|LibraryRecovery'
stages=[('full-debug',['swift','test'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',selector],{}),('affected-optimized',['swift','test','-c','release','--filter',selector],{}),('owned-native',['swift','test','--filter',native],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_NATIVE_VAULT':'1'}),('owned-membership-tsan',['swift','test','--sanitize=thread','--filter','SyncMembership'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),('owned-membership-optimized',['swift','test','-c','release','--filter','SyncMembership'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'})]
results={'baseSource':source,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'host':{'macOS':subprocess.check_output(['sw_vers','-productVersion'],text=True).strip(),'architecture':platform.machine()},'frozenControls':{k:h for k,(p,h) in frozen.items()},'frozen36Engine':{k:frozen36[k] for k in ['originalRuntime','originalInputCount','workerSHA256','executableSHA256','files']},'frozen36ManifestSHA256':frozen36_manifest_sha,'stages':[]}
for name,cmd,extras in stages:
 require_old36();assert all(sha(root/p)==h for p,h in pins.items());assert all(sha(p)==h for p,h in frozen.values());log=out/(name+'.log');print('START',name,flush=True);started=time.monotonic();stageenv={**env,**extras,'OSWIND_TEST_SYNC_ANCHORED_FIXTURE_ROOT':str(out/(name+'-fixtures'))}
 with log.open('xb') as f:code=subprocess.run(cmd,env=stageenv,stdout=f,stderr=subprocess.STDOUT).returncode
 results['stages'].append({'name':name,'command':cmd,'environment':extras,'exit':code,'wallSeconds':time.monotonic()-started,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,code,flush=True)
 require_old36();assert all(sha(root/p)==h for p,h in pins.items());assert all(sha(p)==h for p,h in frozen.values())
 if code:raise SystemExit(code)

with (out/'discovered-tests.txt').open('x') as listing:
 subprocess.run(['swift','test','list'],stdout=listing,stderr=subprocess.STDOUT,check=True)
assert all(sha(root/p)==h for p,h in pins.items())
print('ALL_QUALIFICATION_STAGES_TERMINAL',flush=True)
