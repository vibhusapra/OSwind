from pathlib import Path
import hashlib,json,subprocess,time,os
ROOT=Path.cwd();BASE=ROOT/'.artifacts/peer-membership-update-v1';OUT=BASE/'qualification-v1';OUT.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
prior=json.loads((BASE/'development-inputs-v15/inputs.json').read_text());pins={p:sha(ROOT/p) for p in prior['inputFiles']};assert len(pins)==726
assert {p for p,h in prior['inputFiles'].items() if pins[p]!=h}=={'.github/workflows/ci.yml'}
parent=json.loads(Path('/Users/vibhusapra/.codex/worktrees/sync-owner-app-lifecycle/oswind/.artifacts/owner-app-integration-v1/qualification-v5/inputs.json').read_text());packagePins={p:sha(ROOT/p) for p in parent['packageInputs']};assert packagePins==parent['packageInputs']
protected={p:sha(ROOT/p) for p in subprocess.check_output(['git','ls-files','benchmarks'],text=True).splitlines()};assert len(protected)==517
frozen35=json.loads((BASE/'checkout-reuse-v1.json').read_text())['frozen35PackageFiles'];assert all(sha(ROOT/p)==h for p,h in frozen35.items())
build=ROOT/'.build';assert build.is_dir() and not build.is_symlink()
# Preserve the successful normal/native v15 test engine before sanitizer changes
# the mutable build root. Clone, do not rebuild, resign or rerun that evidence.
frozen=BASE/'frozen-current-native-debug-v15';frozen.mkdir();bundle=frozen/'OSwindPackageTests.xctest';subprocess.run(['cp','-cR',str(build/'arm64-apple-macosx/debug/OSwindPackageTests.xctest'),str(bundle)],check=True);engine={str(p.relative_to(bundle)):sha(p) for p in bundle.rglob('*') if p.is_file()};assert len(engine)==4
(frozen/'manifest.json').write_text(json.dumps({'bundle':str(bundle),'files':engine,'nativeDebugReceiptSHA256':sha(ROOT/'benchmarks/sync-peer-membership-v1.json')},indent=2)+'\n');print(json.dumps({'event':'preserved-v15-engine','files':4,'source':source}),flush=True)
selection='PersonalSyncMembershipUpdateTests|PeerMembershipAppSessionTests|OwnerAdditionAppSessionTests|PersonalSyncPairingModelTests|SyncOwnerSessionTransferTests';native={'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_NATIVE_VAULT':'1'}
stages=[{'name':'affected-native-tsan','command':['swift','test','--sanitize=thread','--filter',selection],'environment':native},{'name':'affected-native-optimized','command':['swift','test','-c','release','--filter',selection],'environment':native},{'name':'release-build','command':['swift','build','-c','release'],'environment':{}},{'name':'package','command':['bash','scripts/build-app.sh','release'],'environment':{'OSWIND_BUILD_ROOT':str(build),'OSWIND_APP_OUTPUT':str(OUT/'OSwind.app')}}]
inputs={'format':'OSwind peer qualification distinct selections v1','source':source,'nativeDebugSource':json.loads((ROOT/'benchmarks/sync-peer-membership-v1.json').read_text())['sourceCommit'],'inputFiles':pins,'packageInputs':packagePins,'protectedPublications':protected,'frozen35Files':frozen35,'frozenV15Engine':engine,'buildRoot':str(build),'stages':stages,'scope':'95method owner/peer/pairing/exact-transfer classes, real generated native flags. Rendering env intentionally absent: ordinary UI-render methods retain declared skips; actual12currentimages were already inspected in v15. No local test retries. Distinct modes/build/package run even if a test selection fails; all exits remain recorded.'};(OUT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
def check():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
 assert all(sha(ROOT/p)==h for p,h in (pins|packagePins|protected|frozen35).items())
 assert all(sha(bundle/p)==h for p,h in engine.items())
results=[]
for stage in stages:
 check();log=OUT/(stage['name']+'.log');start=time.monotonic();print(json.dumps({'event':'stage-start','name':stage['name']}),flush=True)
 with log.open('x') as handle:r=subprocess.run(stage['command'],env=os.environ|stage['environment'],stdout=handle,stderr=subprocess.STDOUT)
 check();row=stage|{'exit':r.returncode,'elapsedSeconds':time.monotonic()-start,'logSHA256':sha(log)};results.append(row);(OUT/'results.json').write_text(json.dumps({'source':source,'stages':results,'allPlannedStagesFinished':len(results)==len(stages),'allStageExitsZero':all(x['exit']==0 for x in results)},indent=2)+'\n');print(json.dumps({'event':'stage-complete',**{k:row[k] for k in ['name','exit','elapsedSeconds','logSHA256']}}),flush=True)
raise SystemExit(0 if all(x['exit']==0 for x in results) else 1)
