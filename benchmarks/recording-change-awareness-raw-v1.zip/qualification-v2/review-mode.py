from pathlib import Path
import sys,re,json,hashlib
out=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['optimized','tsan']
record=json.loads((out/(mode+'.json')).read_text());log=(out/(mode+'.log')).read_text()
assert record['exitCode']==0
assert hashlib.sha256((out/(mode+'.log')).read_bytes()).hexdigest()==record['logSHA256']
cases=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",log)
counts={s:sum(status==s for _,status,_ in cases) for s in ['passed','skipped','failed']}
assert len(cases)==628 and len({name for name,_,_ in cases})==628 and counts=={'passed':607,'skipped':21,'failed':0},counts
assert 'Executed 628 tests, with 21 tests skipped and 0 failures (0 unexpected)' in log
diagnostics=re.findall(r'(?m)^.*(?:WARNING: ThreadSanitizer|SUMMARY: ThreadSanitizer|ThreadSanitizer: (?:data race|reported)).*$',log)
assert not diagnostics,diagnostics
skipLines=[line for line in log.splitlines() if ' : Test skipped - ' in line];assert len(skipLines)==21
review={'source':record['source'],'defined':len(cases),**counts,'uniqueMethods':len(cases),'raceDiagnostics':diagnostics,'logSHA256':record['logSHA256'],'skipEvidence':skipLines,'methods':[{'method':name,'status':status,'seconds':float(seconds)} for name,status,seconds in cases],'scope':'Selected current runtime qualification, not whole suite, hosted CI, physical GUI/audio, automatic24h, energy, distribution or ranking acceptance.'}
with (out/(mode+'-methods-review.json')).open('x') as f:json.dump(review,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in review.items() if k not in ['methods','skipEvidence']}))
