from pathlib import Path
import json
base=Path(__file__).resolve().parent;r=base.parents[1];receipt=json.loads((r/'benchmarks/recording-change-awareness-v1.json').read_text())
assert receipt['runtimeSource']=='ec02cdd68f99d05270ba3e1101944e67503a44a4'
comparisons=receipt['comparisons'];pages=comparisons['pages']['summary']['corpora'];windows=comparisons['windows']['summary']['corpora']
def med(group,engine,metric):return group[engine][metric]['medianMs']
table=[]
for name,label in [('live20k','20,000 authored clips'),('imports256','256 large authored imports')]:
 for mode,group,metrics in [('Archive paging',pages[name],['publication','completion']),('Loaded-history refresh',windows[name],['windowRead','publication','completion'])]:
  for metric in metrics:table.append(f'| {label}: {mode.lower()}, {metric} | {med(group,"baseline",metric):.3f} | {med(group,"candidate",metric):.3f} |')
section='''## Recording changes refresh the loaded history

Source `ec02cdd` adds foreground, visible, unlocked/admitted recording-change checks (3 seconds normally, 10 in Low Power Mode) and the same check after local recording saves. SQL reads and grouping remain owned by the app work registry; departure cancels the monitor and joins actual work before close. The public two-peer AppModel fixture observes an incoming recording and its deletion without a local recording-saved signal. That fixture injects a 50 ms cadence; it is not a measurement of default scheduling or physical two-Mac behavior.

An opaque local nonce advances on committed recording-metadata insert/update/delete, including compatible prior writers and incoming projection. Unrelated note, screen and vector-only changes leave it alone. Rollback, missing/malformed nonce and trigger repair are covered. The canonical source-cache version remains 2; no transported kind, source identity rewrite or historical transcript scan is added on ready open. An actual retained signed 195b CLI imports authored audio, advances the nonce and leaves the new triggers installed.

An older page can only merge into the same audio revision. A refresh rereads the already loaded page budget in one consistent snapshot, re-reads retained selection from current thin rows, and preserves the cursor through more than 512 new arrivals. Deleted/regrouped sources and changed titles are replaced coherently. Quiet audio refresh keeps the last selection/detail visible with actions disabled; privacy changes clear previews before replacement. If the newest page is entirely excluded, **Load older recordings** remains reachable in the empty view.

Prepared-page publication tries the SQL and settings locks without waiting and uses a read-only snapshot, preserving existing SQLite authorizers and configuration. A matching cached native proof needs no external credential access on the main actor; changed authority refuses until a normal owned background read refreshes admission. Freshness is checked as of that snapshot; an external commit after it is later state. The established media → SQL → snapshot mutex → settings-file lock order is retained.

Current selected optimized and Thread Sanitizer runs each have **628 defined / 607 passed / 21 explicit skips / zero failures**, with no race diagnostic. Skips are retained child entry helpers and explicit scale/prior-binary/render/performance opt-ins; exact reasons are in the receipt. Selected real encrypted APFS, original-Keychain/all-13-kind sync, Metal retrieval, privacy/erasure, backup/restore, incoming/outgoing scope and actual app departure controls pass. This is not a whole-suite result. A separate current 101-method Debug selection has 99 passes/two prior-native-binary skips, and all **16 actual light/dark component rasters** were manually inspected.

Original five desired-contract probes against unchanged prior production have one pass/four failed methods/eight issues: already-obsolete pages publish after an external audio insert/delete/regroup, and a blocked model republishes a deleted source. Manual idle refresh was the old explicit design, not a claimed broken automatic observer. The unrelated-note control passes. These failed artifacts remain retained. The first hidden-head render fixture then failed after its hosting window deliberately deactivated the model; explicit reactivation corrects the fixture, followed by the passing full focused run. That original failed attempt is also retained.

Two distinct counterbalanced comparisons each use eight process pairs per authored corpus: **64 separate processes total**, with **656 page observations** in the archive comparison. Archive paging compares actual retained 195b against ec02cdd using the unchanged earlier benchmark definition. Full loaded-history refresh compares actual pre-ID-cache and current engines implementing the same refresh behavior, with an identical new benchmark definition. It measures the genuine immutable-source-ID/hex-conversion change; it is not compared with the old head-only manual refresh. Every process has a new copied library. Original corpora, source inputs and actual frozen engines stay unchanged; complete source IDs and canonical row invariants are checked. In the refresh trial, only one original title/payload.title changes and one authored audio source is added. Warmup/initial traversal/mutations are separate; timed reads deny all SQL writes and canonical transcript-payload reads.

| Authored corpus / measured stage | Baseline median ms | Candidate median ms |
|---|---:|---:|
'''+ '\n'.join(table)+'''

Archive publication medians increased slightly in this comparison: 0.808 → 0.860 ms for 20k clips and 0.255 → 0.263 ms for large imports. These small publication costs remain in the results alongside the lower completion times.

Pooled pages are dependent observations. The receipt retains all eight paired process medians/reductions, raw values, linear-interpolated p95s, maxima, warmups, initial traversals and outliers. Publication ends at loaded-status emission and excludes deferred cleanup/rendering; completion includes worker scheduling and a 1 ms polling observer. Store construction is outside the clocks. One shared Mac and the older manual-cadence soak remain uncontrolled background context. These timings do not establish frames/vsync/input latency, OS-cold launch, capture overhead, speech, battery/thermal behavior or competitor rank.

A fresh normal release development app passes strict deep ad-hoc signature verification, the empty-library smoke, actual packaged-CLI scope control and exact all-file/mode/signature ZIP round trip. Its Core compiler command excludes `-enable-testing`; test engines remain separately preserved. The package is a local development artifact, with native activation, production signing/notarization and release acceptance still open.

[Current source/input/test/performance/package receipt](../benchmarks/recording-change-awareness-v1.json) · [All original logs, observations, source snapshots and rasters](../benchmarks/recording-change-awareness-raw-v1.zip).

![Quiet recording refresh](../assets/recorded-meetings-v6-updating-dark.png)
![Older recordings remain reachable](../assets/recorded-meetings-v6-hidden-head-light.png)

Named sessions/reviewed calendar-occurrence links, native wrapper/keyboard/VoiceOver/record/import/open/playback, physical speech/device quality, controlled energy and current automatic-app 24h acceptance remain open. Quiet-restored grouped peer re-enrollment still needs original session bindings. Separate owner/peer failed broad gates are not erased by these passes. The 83-feature ledger, dated 20-offering report and all preceding published evidence remain unchanged; F042, full v0 parity and top-three placement remain unfinished.

'''
wip=r/'docs/RECORDED-MEETINGS-WIP.md';text=wip.read_text();assert '## Recording changes refresh the loaded history' not in text
text=text.replace('- [ ] Incoming-change UI invalidation and actual list-publication/frame-cost audit.','- [x] Incoming-change UI invalidation, coherent loaded history and model/SQL/publication cost comparisons.\n- [ ] Actual native frame/vsync/input cost and controlled capture/energy acceptance.')
text=text.replace('- [x] Current normal release/ad-hoc development package at 7ab704b, packaged CLI scope control and exact ZIP/signature round trip. Native interaction and release acceptance remain open.','- [x] Current normal release/ad-hoc development package at ec02cdd, packaged CLI scope control and exact ZIP/signature round trip. Native interaction and release acceptance remain open.')
text=text.replace('## Initial workspace evidence',section+'## Initial workspace evidence',1);wip.write_text(text)
progress=r/'docs/PROGRESS.md';text=progress.read_text();heading='## 2026-11-03 — recording changes refresh coherent loaded history';assert heading not in text
entry=f'''{heading}

Source `ec02cdd` observes local/compatible-old-writer/incoming audio changes while Recordings is foreground and active, refreshes the loaded window coherently, preserves quiet selection, clears previews for privacy changes and keeps older history reachable behind an excluded head. Prepared publication uses nonwaiting read-only admission with no external credential refresh on the main actor. Current selected optimized and Thread Sanitizer runs each have **628 defined / 607 passed / 21 expected skips / zero failures**, without a race diagnostic. A separate current 99-pass/two-skip focused run supplies 16 manually reviewed light/dark components, including quiet update and hidden-head states. Real APFS/original-Keychain/all-13-kind, actual old CLI, public peer/app-departure, scope/backup/privacy and Metal checks pass.

Two new comparisons retain **64 separate processes / 656 archive-page observations**, all IDs/canonical invariants and unchanged originals/actual frozen engines. For 20k authored clips, archive page completion median is **{med(pages['live20k'],'baseline','completion'):.3f} → {med(pages['live20k'],'candidate','completion'):.3f} ms** against retained 195b. Full-history refresh completion is **{med(windows['live20k'],'baseline','completion'):.3f} → {med(windows['live20k'],'candidate','completion'):.3f} ms** across the actual before/after ID-cache engines. All warmups, maxima and paired process values remain visible. A fresh normal ad-hoc development package, packaged-CLI control and exact ZIP/signature round trip pass. Original negative and failed development attempts remain retained. Names/calendar links, native/physical/accessibility, energy/current automatic24h, separate failed owner/peer gates, distribution, full v0 and ranking remain open. [Details/TODOs](RECORDED-MEETINGS-WIP.md#recording-changes-refresh-the-loaded-history) · [Receipt](../benchmarks/recording-change-awareness-v1.json) · [Raw evidence](../benchmarks/recording-change-awareness-raw-v1.zip).

'''
text=text.replace('# OSwind delivery ledger\n\n','# OSwind delivery ledger\n\n'+entry,1);progress.write_text(text)
print('Updated two living documents; historical sections retained.')
