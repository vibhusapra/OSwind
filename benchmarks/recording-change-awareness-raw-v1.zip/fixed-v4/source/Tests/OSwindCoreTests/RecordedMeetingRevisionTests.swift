import XCTest
import CSQLite
@testable import OSwindCore

private final class RecordingDatabaseGate:@unchecked Sendable {
    let entered=XCTestExpectation(description:"Owned database gate")
    private let released=DispatchSemaphore(value:0)
    func pause() {entered.fulfill();released.wait()}
    func release() {released.signal()}
}
final class RecordedMeetingRevisionTests:XCTestCase {
    private var root:URL!,store:MemoryStore!
    override func setUpWithError()throws {root=FileManager.default.temporaryDirectory.appendingPathComponent("owned-recording-revision-"+UUID().uuidString);store=try MemoryStore(root:root)}
    override func tearDownWithError()throws {try store.close();try FileManager.default.removeItem(at:root)}
    private func audio(_ index:Int,in library:MemoryStore?=nil)throws {
        var memory=Memory(id:"clip-\(index)",timestamp:Date(timeIntervalSince1970:Double(index)),kind:.audio,app:"Owned audio",title:"Clip \(index)",text:"Authored source \(index)")
        memory.audioSessionID="session-\(index)";memory.transcript = .init(text:memory.text,duration:30,segments:[.init(start:0,end:30,text:memory.text)],model:"Authored fixture");try (library ?? store).insert(memory)
    }
    func testAudioRevisionTracksCommitsButNotUnrelatedWritesOrRollback()throws {
        let initial=try store.recordedMeetingRevision();try audio(0);let added=try store.recordedMeetingRevision();XCTAssertNotEqual(initial,added)
        try store.insert(Memory(id:"note",kind:.note,app:"Owned note",text:"Authored note"));XCTAssertEqual(try store.recordedMeetingRevision(),added)
        try store.withRoutineDatabase {db in
            try db.execute("BEGIN IMMEDIATE");do {try db.execute("DELETE FROM memories WHERE id='clip-0'");XCTAssertNotEqual(try store.recordedMeetingRevision(),added);try db.execute("ROLLBACK")}catch {try? db.execute("ROLLBACK");throw error}
        }
        XCTAssertEqual(try store.recordedMeetingRevision(),added);try store.delete("clip-0");XCTAssertNotEqual(try store.recordedMeetingRevision(),added)
    }
    func testReadyPageRevisionAndPublicationReadThroughAnotherWALWriterReservation()throws {
        try audio(0);let page=try store.recordedMeetingPage(),other=try MemoryStore(root:root);defer {try? other.withRoutineDatabase {try $0.execute("ROLLBACK")};try? other.close()}
        try other.withRoutineDatabase {try $0.execute("BEGIN IMMEDIATE")}
        XCTAssertEqual(try store.recordedMeetingRevision(),page.revision)
        XCTAssertEqual(try store.recordedMeetingPage().sources,page.sources)
        var published=false;try store.withCurrentRecordedMeetingPage(page) {published=true};XCTAssertTrue(published)
    }
    func testPublicationRefusesBusySameConnectionWithoutWaitingForItsWorker()async throws {
        try audio(0);let page=try store.recordedMeetingPage(),gate=RecordingDatabaseGate(),library=store!
        let worker=Task.detached {try library.withRoutineDatabase {_ in gate.pause()}}
        await fulfillment(of:[gate.entered],timeout:5)
        // A fuse lets a broken blocking implementation fail instead of hanging
        // the test process. Passing must return while the gate is still held.
        DispatchQueue.global().asyncAfter(deadline:.now()+2) {gate.release()}
        let start=ContinuousClock.now
        XCTAssertThrowsError(try store.withCurrentRecordedMeetingPage(page) {}) {XCTAssertTrue($0 is RecordedMeetingRefreshError)}
        XCTAssertLessThan(start.duration(to:.now),.milliseconds(500))
        gate.release();try await worker.value
    }
    func testPublicationForbidsWritesAndRestoresConnectionConfigurationOnFailure()throws {
        try audio(0);let page=try store.recordedMeetingPage()
        try store.withRoutineDatabase {try $0.execute("PRAGMA busy_timeout=1234")}
        XCTAssertThrowsError(try store.withCurrentRecordedMeetingPage(page) {try store.withRoutineDatabase {try $0.execute("UPDATE memories SET title='Wrong' WHERE id='clip-0'")}})
        try store.withRoutineDatabase {db in XCTAssertEqual(try db.eraseCount("PRAGMA busy_timeout"),1234);XCTAssertEqual(try db.eraseCount("PRAGMA query_only"),0)}
        XCTAssertEqual(try store.get("clip-0")?.title,"Clip 0");try audio(1)
    }
    func testWindowRetainsSelectedOlderSourceWithoutSkippingNewHeadGap()throws {
        for index in 0..<600 {try audio(index)}
        let first=try store.recordedMeetingPage(),second=try store.recordedMeetingPage(before:first.next),selected=try XCTUnwrap(second.sources.first {$0.memoryID=="clip-0"})
        let other=try MemoryStore(root:root);defer {try? other.close()};for index in 600..<1300 {try audio(index,in:other)}
        let window=try store.recordedMeetingWindow(pages:2,retaining:[selected]);XCTAssertEqual(window.pages.count,2);XCTAssertEqual(window.pages.flatMap(\.sources).count,1024)
        XCTAssertEqual(window.retained.map(\.memoryID),["clip-0"]);XCTAssertTrue(window.pages.allSatisfy {$0.revision==window.pages[0].revision})
        var ids=Set((window.pages.flatMap(\.sources)+window.retained).map(\.memoryID)),cursor=window.pages.last?.next
        while let next=cursor {let page=try store.recordedMeetingPage(before:next);ids.formUnion(page.sources.map(\.memoryID));cursor=page.next}
        XCTAssertEqual(ids,Set((0..<1300).map {"clip-\($0)"}))
        try other.delete("clip-0");let changed=try store.recordedMeetingWindow(pages:2,retaining:[selected]);XCTAssertTrue(changed.retained.isEmpty)
    }
    func testRepairingNonceTriggersInvalidatesClockWithoutRebuildingReadyRows()throws {
        try audio(0);let page=try store.recordedMeetingPage(),value=page.revision.value,rowRevision=try XCTUnwrap(page.sources.first?.revision)
        try store.withRoutineDatabase {try $0.execute("DROP TRIGGER recorded_meeting_revision_insert")};try store.close();store=try MemoryStore(root:root)
        let current=try store.recordedMeetingPage();XCTAssertNotEqual(current.revision.value,value);XCTAssertEqual(current.sources.first?.revision,rowRevision)
    }
    func testReadyWindowAndRevisionNeverReadPayloadOrWrite()throws {
        try audio(0);let selected=try XCTUnwrap(store.recordedMeetingPage().sources.first)
        try store.withRoutineDatabase {db in
            XCTAssertEqual(sqlite3_set_authorizer(db.handle,{_,action,table,column,_,_ in
                if [SQLITE_INSERT,SQLITE_UPDATE,SQLITE_DELETE].contains(action) {return SQLITE_DENY}
                if action==SQLITE_READ,let table,let column,String(cString:table)=="memories",String(cString:column)=="payload" {return SQLITE_DENY}
                return SQLITE_OK
            },nil),SQLITE_OK)
        }
        defer {try? store.withRoutineDatabase {sqlite3_set_authorizer($0.handle,nil,nil)}}
        let window=try store.recordedMeetingWindow(pages:2,retaining:[selected]);XCTAssertEqual(window.pages.count,1);XCTAssertEqual(window.retained,[selected])
        XCTAssertEqual(try store.recordedMeetingRevision(),window.pages[0].revision);try store.withCurrentRecordedMeetingPage(window.pages[0]) {}
    }
    func testWindowUsesOneReadSnapshotWhenAnotherWriterCommitsDuringItsTraversal()throws {
        try audio(0);let selected=try XCTUnwrap(store.recordedMeetingPage().sources.first),other=try MemoryStore(root:root);defer {try? other.close()}
        let mutation=RecordingTraceMutation {try self.audio(1,in:other)}
        try store.withRoutineDatabase {db in
            sqlite3_trace_v2(db.handle,UInt32(SQLITE_TRACE_STMT),{_,context,_,sql in
                guard let context,let sql,String(cString:sql.assumingMemoryBound(to:CChar.self)).contains("FROM recorded_meeting_sources") else {return 0}
                Unmanaged<RecordingTraceMutation>.fromOpaque(context).takeUnretainedValue().run();return 0
            },Unmanaged.passUnretained(mutation).toOpaque())
        }
        defer {try? store.withRoutineDatabase {sqlite3_trace_v2($0.handle,0,nil,nil)}}
        let window=try store.recordedMeetingWindow(pages:2,retaining:[selected]);XCTAssertTrue(mutation.called);XCTAssertNil(mutation.error)
        XCTAssertEqual(window.pages.flatMap(\.sources).map(\.memoryID),["clip-0"]);XCTAssertEqual(window.retained,[selected])
        XCTAssertThrowsError(try store.withCurrentRecordedMeetingPage(window.pages[0]) {})
    }
    func testMalformedOrMissingNonceRepairsOnReopenWithoutReplacingSourceRows()throws {
        try audio(0);let original=try XCTUnwrap(store.recordedMeetingPage().sources.first?.revision)
        for damage in ["UPDATE store_metadata SET value='invalid' WHERE key='recorded_meeting_revision_v1'","DELETE FROM store_metadata WHERE key='recorded_meeting_revision_v1'"] {
            try store.withRoutineDatabase {try $0.execute(damage)};XCTAssertThrowsError(try store.recordedMeetingRevision());try store.close();store=try MemoryStore(root:root)
            let page=try store.recordedMeetingPage();XCTAssertEqual(page.sources.first?.revision,original);try store.withCurrentRecordedMeetingPage(page) {}
        }
    }
    func testForeignAndClosedWindowReferencesRefuse()throws {
        try audio(0);let ref=try XCTUnwrap(store.recordedMeetingPage().sources.first),other=try MemoryStore(root:root.appendingPathComponent("other"));defer {try? other.close()}
        XCTAssertThrowsError(try other.recordedMeetingWindow(pages:1,retaining:[ref]));XCTAssertThrowsError(try store.recordedMeetingWindow(pages:0,retaining:[]))
        try store.close();XCTAssertThrowsError(try store.recordedMeetingRevision())
    }
}

private final class RecordingTraceMutation {
    private let action:()throws->Void
    private(set) var called=false,error:Error?
    init(_ action:@escaping ()throws->Void) {self.action=action}
    func run() {guard !called else {return};called=true;do {try action()}catch {self.error=error}}
}
