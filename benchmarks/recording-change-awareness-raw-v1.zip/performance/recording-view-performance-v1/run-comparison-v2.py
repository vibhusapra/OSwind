from pathlib import Path
import os,sys,subprocess,json,hashlib,shutil,time,importlib.util
root=Path(__file__).resolve().parent;r=root.parents[3];base=root.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('canonical_check',root/'canonical-check.py');checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(checks)
mode=sys.argv[1];assert mode in ['pages','windows']
protocol=json.loads((root/('protocol-v2.json' if mode=='pages' else 'window-protocol-v1.json')).read_text())
pins=json.loads((root/'execution-inputs-v3.json').read_text());old=json.loads((r/'.artifacts/recording-view-performance-v1/comparison-inputs-v1.json').read_text())
originals=old['originalCorpora'];out=root/(mode+'-comparison-v2')
engine_paths={name:r/value['bundle'] for name,value in pins['engines'][mode].items()}
activeDirectories=[(r/value['bundle']).parent for value in pins['engines'][mode].values()]
def check(allHistorical=False):
 for value in pins['engines'][mode].values():assert sha(r/value['manifest'])==value['manifestSHA256']
 protected=pins['protectedFiles'] if allHistorical else [item for item in pins['protectedFiles'] if '/frozen-' not in item['path'] or any(Path(item['path']).is_relative_to(directory) for directory in activeDirectories)]
 for item in pins['inputs']+protected:
  p=Path(item['path']);p=p if p.is_absolute() else r/p
  assert sha(p)==item['sha256'],str(p)
 for corpus in originals.values():
  for item in corpus['files']:assert sha(r/item['path'])==item['sha256'],item['path']
check(allHistorical=True);out.mkdir()
for name,corpus in originals.items():assert checks.canonical(r/corpus['directory']/'memory.sqlite')==corpus['canonical']
observations=[];journal=(out/'observations.jsonl').open('x')
try:
 for corpus in protocol['corpora']:
  name=corpus['name'];original=originals[name];expected=corpus.get('rows',corpus.get('originalRows'))
  for pair in range(protocol['pairsPerCorpus']):
   order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
   for engine in order:
    check();trial=f'{mode}-{name}-pair{pair:02d}-{engine}';target=root/'trials'/trial/'library';target.parent.mkdir(parents=True)
    assert shutil.disk_usage(r).free>16*1024**3+2*sum(x['bytes'] for x in original['files'])
    shutil.copytree(r/original['directory'],target)
    env=os.environ.copy();env.pop('DYLD_INSERT_LIBRARIES',None);env.update({'OSWIND_RECORDING_VIEW_ROOT':str(root),'OSWIND_RECORDING_VIEW_CORPUS':name,'OSWIND_RECORDING_VIEW_TRIAL':trial})
    command=['xcrun','xctest','-XCTest',protocol['testMethod'],str(engine_paths[engine])]
    log=out/(trial+'.log');started=time.monotonic()
    with log.open('xb') as output:
     process=subprocess.Popen(command,cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT)
     with (out/(trial+'.started.json')).open('x') as f:json.dump({'pid':process.pid,'controllerPID':os.getpid(),'command':command,'source':pins['candidateSource']},f)
     code=process.wait()
    result=root/'trials'/trial/('result.json' if mode=='pages' else 'window-result.json')
    entry={'corpus':name,'pair':pair,'order':order,'engine':engine,'trial':trial,'command':command,'exitCode':code,'commandSeconds':time.monotonic()-started,'logSHA256':sha(log),'result':str(result.relative_to(root)) if result.exists() else None}
    if result.exists():entry['resultSHA256']=sha(result)
    observations.append(entry);journal.write(json.dumps(entry)+'\n');journal.flush()
    assert code==0 and result.exists(),entry
    data=json.loads(result.read_text())
    if mode=='pages':
     assert data['expected']==data['uniqueSources']==expected and len(data['pages'])==corpus['pages']
     assert len(data['publicationSeconds'])==len(data['allGroupMetricSweepSeconds'])==len(data['completionWallSeconds'])==corpus['pages']
     proof=checks.canonical(target/'memory.sqlite');assert proof==original['canonical']
    else:
     assert data['originalSources']==expected and data['afterSources']==expected+1 and data['allIDsVerified'] and data['selectionPreserved'] and data['changedTitleUpdated']
     assert len(data['windowReadSeconds'])==len(data['publicationSeconds'])==1
     proof=checks.window_delta(r/original['directory']/'memory.sqlite',target/'memory.sqlite',expected)
    with (out/(trial+'.canonical.json')).open('x') as f:json.dump(proof,f,indent=2)
    check();print(json.dumps({'trial':trial,'exitCode':code,'seconds':entry['commandSeconds'],'canonicalVerified':True}),flush=True)
finally:journal.close()
assert len(observations)==protocol['observations']
if mode=='pages':
 for name in originals:
  for pair in range(protocol['pairsPerCorpus']):
   rows=[x for x in observations if x['corpus']==name and x['pair']==pair];assert len(rows)==2
   a,b=[json.loads((root/x['result']).read_text()) for x in rows]
   assert a['loadedSources']==b['loadedSources'] and a['metricChecksums']==b['metricChecksums'],(name,pair)
check(allHistorical=True);result={'candidateSource':pins['candidateSource'],'observations':len(observations),'allOriginalsInputsAndFrozenEnginesUnchanged':True,'allCanonicalRowsAndResultChecksVerified':True,'journalSHA256':sha(out/'observations.jsonl'),'scope':protocol['controls']}
if mode=='pages':
 result['pageObservations']=sum(len(json.loads((root/x['result']).read_text())['pages']) for x in observations);assert result['pageObservations']==protocol['pageObservations']
with (out/'result.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps(result),flush=True)
