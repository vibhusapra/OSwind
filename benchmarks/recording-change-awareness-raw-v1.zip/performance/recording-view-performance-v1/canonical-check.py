from pathlib import Path
import sqlite3,urllib.parse,hashlib,struct,itertools,json
COLUMNS='id,timestamp,kind,app,title,url,text,favorite,payload,embedding,embedding_model'
def connection(path):
 path=Path(path)
 assert not Path(str(path)+'-wal').exists() or Path(str(path)+'-wal').stat().st_size==0,'Uncheckpointed trial WAL'
 return sqlite3.connect('file:'+urllib.parse.quote(str(path),safe='/')+'?mode=ro&immutable=1',uri=True)
def canonical(path):
 digest=hashlib.sha256();count=0
 with connection(path) as db:
  for row in db.execute('SELECT '+COLUMNS+' FROM memories ORDER BY id COLLATE BINARY'):
   count+=1
   for value in row:
    if value is None:kind,data=b'N',b''
    elif isinstance(value,bytes):kind,data=b'B',value
    elif isinstance(value,str):kind,data=b'S',value.encode()
    elif isinstance(value,int):kind,data=b'I',struct.pack('>q',value)
    else:kind,data=b'F',struct.pack('>d',value)
    digest.update(kind+struct.pack('>Q',len(data))+data)
 return {'count':count,'sha256':digest.hexdigest()}
def window_delta(original,trial,expected):
 identical=0;changed=0
 with connection(original) as old,connection(trial) as new:
  before=old.execute('SELECT '+COLUMNS+' FROM memories ORDER BY id COLLATE BINARY')
  after=new.execute('SELECT '+COLUMNS+" FROM memories WHERE id!='freshness-added' ORDER BY id COLLATE BINARY")
  for a,b in itertools.zip_longest(before,after):
   assert a is not None and b is not None and a[0]==b[0],'Original row missing/extra'
   if a[0]!='authored-00000000':assert a==b,'Unrelated canonical row changed';identical+=1;continue
   changed+=1
   for index in range(11):
    if index not in [4,8]:assert a[index]==b[index],('Unexpected column',index)
   assert a[4]!=b[4] and b[4]=='Owned refreshed recording source'
   ap,bp=json.loads(a[8]),json.loads(b[8]);assert ap.pop('title')!=bp.pop('title') and ap==bp,'Unexpected payload mutation'
  added=new.execute("SELECT kind,payload FROM memories WHERE id='freshness-added'").fetchall()
  assert len(added)==1 and added[0][0]=='audio'
  assert new.execute('SELECT count(*) FROM memories').fetchone()[0]==expected+1
 assert changed==1 and identical==expected-1
 return {'unchangedOriginalRows':identical,'changedOriginalRows':changed,'allowedChanges':['authored-00000000.title','authored-00000000.payload.title'],'addedAudioRows':1,'allOtherOriginalColumnsAndPayloadFieldsExact':True,'canonicalAfter':canonical(trial)}
