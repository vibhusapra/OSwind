from pathlib import Path
import json,statistics,sys,hashlib
root=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['pages','windows'];out=root/(mode+'-comparison-v2')
entries=[json.loads(line) for line in (out/'observations.jsonl').read_text().splitlines()];assert len(entries)==32
assert json.loads((out/'result.json').read_text())['allCanonicalRowsAndResultChecksVerified']
data={entry['trial']:json.loads((root/entry['result']).read_text()) for entry in entries}
def quantile(values,q):
 values=sorted(values);position=(len(values)-1)*q;lo=int(position);hi=min(lo+1,len(values)-1)
 return values[lo]+(values[hi]-values[lo])*(position-lo)
def describe(values):
 assert values and all(v>=0 for v in values)
 return {'n':len(values),'minMs':min(values)*1000,'medianMs':statistics.median(values)*1000,'p95Ms':quantile(values,.95)*1000,'maxMs':max(values)*1000,'valuesMs':[x*1000 for x in values]}
metrics={'publication':'publicationSeconds','completion':'completionWallSeconds','groupMetrics':'allGroupMetricSweepSeconds','sqlRead':'pages'} if mode=='pages' else {'publication':'publicationSeconds','completion':'refreshCompletionWallSeconds','windowRead':'windowReadSeconds','initialTraversal':'initialTraversalSeconds'}
def samples(result,field):
 value=result[field]
 if field=='pages':return [v['seconds'] for v in value]
 return value if isinstance(value,list) else [value]
summary={'mode':mode,'quantile':'Linear interpolation at (n-1)*q. Pooled page observations are dependent, not independent replicates.','scope':'Descriptive same-host counterbalanced process pairs. All measurements/warmups/outliers retained; no confidence interval, frame/input latency, energy or ranking inference.','corpora':{}}
for corpus in ['live20k','imports256']:
 group={}
 for engine in ['baseline','candidate']:
  rows=[x for x in entries if x['corpus']==corpus and x['engine']==engine]
  group[engine]={name:describe([sample for row in rows for sample in samples(data[row['trial']],field)]) for name,field in metrics.items()}
  group[engine]['warmup']=describe([data[row['trial']]['warmSeconds'] for row in rows])
 reductions={}
 for name,field in metrics.items():
  values=[];pairs=[]
  for pair in range(8):
   matches=[x for x in entries if x['corpus']==corpus and x['pair']==pair]
   a=next(data[x['trial']] for x in matches if x['engine']=='baseline');b=next(data[x['trial']] for x in matches if x['engine']=='candidate')
   av=statistics.median(samples(a,field));bv=statistics.median(samples(b,field));delta=100*(1-bv/av)
   pairs.append({'pair':pair,'baselineMedianMs':av*1000,'candidateMedianMs':bv*1000,'reductionPercent':delta});values.append(delta)
  reductions[name]={'medianReductionPercent':statistics.median(values),'minReductionPercent':min(values),'maxReductionPercent':max(values),'pairs':pairs}
 group['pairedProcessMedians']=reductions;summary['corpora'][corpus]=group
with (out/'summary-v2.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({'mode':mode,'corpora':{c:{'medianMs':{e:{m:summary['corpora'][c][e][m]['medianMs'] for m in metrics} for e in ['baseline','candidate']},'medianPairedReductionPercent':{m:v['medianReductionPercent'] for m,v in summary['corpora'][c]['pairedProcessMedians'].items()}} for c in summary['corpora']}},indent=2))
