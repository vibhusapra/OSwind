from pathlib import Path
import os,subprocess,time,json,hashlib,shutil,re
out=Path(__file__).resolve().parent;base=out.parent;r=base.parents[1];pins=json.loads((out/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
 for item in pins['protectedFrozen']:assert sha(Path(item['path']))==item['sha256']
check();command=['swift','test','--jobs','4','--filter','RecordedMeetingTests.testPageCannotPublishAfterOtherConnection|RecordedMeetingTests.testPageRemainsPublishableAfterOtherConnectionChangesOnlyNotes|RecordedMeetingsModelTests.testDeletedRecordingDuringGroupingCannotReappearFromPreparedPage'];started=time.monotonic()
with (out/'test.log').open('xb') as log:result=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT)
check();text=(out/'test.log').read_text();record={'source':pins['source'],'productionIdenticalTo':pins['productionIdenticalTo'],'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-started,'inputsAndHistoricalEnginesUnchanged':True,'logSHA256':sha(out/'test.log'),'scope':pins['scope']}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
cases=re.findall(r"Test Case '([^']+)' (passed|skipped|failed) \(([0-9.]+) seconds\)\.",text)
if cases:
 frozen=base/'frozen-negative-v1';frozen.mkdir();products=r/'.build/arm64-apple-macosx/debug';shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest');manifest=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()];(base/'frozen-negative-v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(record));print(text[-5000:]);raise SystemExit(result.returncode)
