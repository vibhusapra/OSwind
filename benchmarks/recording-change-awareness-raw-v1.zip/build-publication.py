from pathlib import Path
import json,hashlib,datetime,shutil,zipfile,re
base=Path(__file__).resolve().parent;r=base.parents[1];performance=base/'performance/recording-view-performance-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
pins=read(base/'qualification-v2/inputs.json');assert pins['source']=='ec02cdd68f99d05270ba3e1101944e67503a44a4'
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256'],item['path']
historical=read(base/'publication-protected-v1.json')
for item in historical:assert sha(r/item['path'])==item['sha256'],item['path']
qualification={}
for mode in ['optimized','tsan']:
 result=read(base/f'qualification-v2/{mode}.json');review=read(base/f'qualification-v2/{mode}-methods-review.json')
 assert result['exitCode']==0 and review['defined']==628 and review['passed']==607 and review['skipped']==21 and not review['raceDiagnostics']
 qualification[mode]={'result':result,'review':{k:v for k,v in review.items() if k!='methods'}}
comparisons={}
for mode in ['pages','windows']:
 out=performance/(mode+'-comparison-v2');result=read(out/'result.json');summary=read(out/'summary-v2.json')
 assert result['observations']==32 and result['allCanonicalRowsAndResultChecksVerified'] and result['allOriginalsInputsAndFrozenEnginesUnchanged']
 comparisons[mode]={'result':result,'summary':summary,'independentReview':read(out/'independent-review-v1.json')}
package=read(base/'package-v1/package.json');assert package['source']==pins['source'] and package['exitCode']==package['signature']['exitCode']==package['smoke']['exitCode']==package['packagedScopeControl']['exitCode']==0
assert package['developmentArchive']['allExtractedFilesAndModesMatch'] and package['developmentArchive']['signatureAfterRoundTripExitCode']==0
assert all(not x['enableTesting'] for x in package['normalCoreCommands'])
frozen=[]
for manifest in sorted(base.glob('frozen-*.json')):
 for item in read(manifest):assert sha(base/item['path'])==item['sha256'],item['path']
 frozen.append({'path':manifest.name,'sha256':sha(manifest)})
review=read(base/'fixed-v8/visual-review-v1.json');assert review['passed'] and len(review['scenes'])==16
assets=[]
for item in review['scenes']:
 source=base/'fixed-v8'/item['path'];assert sha(source)==item['sha256']
 target=r/'assets'/('recorded-meetings-v6-'+source.name);assert not target.exists();shutil.copy2(source,target)
 assets.append({'path':str(target.relative_to(r)),'sha256':sha(target)})
development=[]
for name in ['negative-v1']+[f'fixed-v{x}' for x in range(1,9)]+['window-development-v1','window-development-v2']:
 directory=base/name;record=read(directory/'result.json') if (directory/'result.json').exists() else None
 log=directory/'test.log'
 if not log.exists():log=directory/'negative.log'
 statuses=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",log.read_text()) if log.exists() else []
 development.append({'name':name,'result':record,'methods':len(statuses),'counts':{s:sum(status==s for _,status,_ in statuses) for s in ['passed','skipped','failed']},'note':'Preserved original attempt; negative contract probes and fixed-v6 fixture-lifecycle failure are not erased by subsequent successful runs.'})
files=[]
for p in sorted(base.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(base)
 if any(part.startswith('frozen-') or part in ['library','OSwind.app','archive-check','__pycache__'] for part in rel.parts[:-1]):continue
 if p.suffix not in ['.json','.jsonl','.py','.swift','.txt','.log','.png','.stdout','.stderr']:continue
 assert not p.is_symlink();files.append(p)
manifest=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
archive=r/'benchmarks/recording-change-awareness-raw-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(base)))
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.infolist())==len(files)+1
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
receipt={'schema':1,'runtimeSource':pins['source'],'initialImplementationSource':'fc92b45211835c07eda0db90e0dbdf81404c4e96','negativeSource':'3cf79a81d9b51a45c5ff5a2bb70121dfa06ff629','negativeProductionIdenticalTo':'5d1107297c9d023a8ed76bb2980671ace784bd1e','inputCount':len(pins['inputs']),'qualification':qualification,'comparisons':comparisons,'development':development,'priorOptimizedQualification':read(base/'qualification-v1/optimized.json'),'componentReview':review,'assets':assets,'frozenManifests':frozen,'package':package,'raw':{'path':str(archive.relative_to(r)),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(files)+1,'scope':'Terminal logs, hashes, protocols, source snapshots, authored raster components and all measurement results. Actual compiled engines, original corpora, trial libraries and the normal app/archive remain retained locally; binaries/databases are not embedded in this raw-evidence ZIP.'},'historicalFilesProtected':len(historical),'ci':{'staticSelection':read(base/'ci-static-v1.json'),'parentPR164Native':read(base/'parent-pr164-native-terminal-v1.json'),'currentRuntime':'Not yet published; no hosted result claimed.'},'remaining':['Named recording sessions and durable reviewed calendar-occurrence links','Actual recorded/upcoming wrapper, keyboard and VoiceOver interaction','Physical microphone/system audio, permission/device switching, ASR quality and playback','Current automatic-app 24-hour capture and controlled power/thermal/resource acceptance','Quiet-restored grouped peer audio needs original session bindings before new enrollment','Separate owner/peer WIP qualification failures and full enlarged-group sync lifecycle remain open','Production signing/notarization/distribution and physical two-Mac/provider acceptance','Whole v0 feature parity and top-three ranking remain unqualified'],'scope':'Authored single-Mac development fixtures and descriptive counterbalanced component/process measurements. Freshness is checked as of the prepared read snapshot; a later external commit is later state. Cached native publication admission performs no external credential refresh; normal owned background reads still verify current native authority. Canonical source-cache schema remains version2; no new transported kind or source ID rewriting. Established lock order remains media, SQL, snapshot mutex, settings-file lock. No full-suite, physical GUI/audio, speech, energy, uninterrupted automatic24h, release-readiness or competitive-ranking claim.','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
target=r/'benchmarks/recording-change-awareness-v1.json'
with target.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
for item in historical:assert sha(r/item['path'])==item['sha256']
print(json.dumps({'receipt':str(target),'raw':receipt['raw'],'assets':len(assets),'historicalFilesProtected':len(historical)},indent=2))
