import Foundation
import Vision
let request=VNRecognizeTextRequest();request.recognitionLevel = .accurate;request.usesLanguageCorrection=false
try VNImageRequestHandler(url:URL(fileURLWithPath:CommandLine.arguments[1]),options:[:]).perform([request])
print((request.results ?? []).compactMap {$0.topCandidates(1).first?.string}.joined(separator:"\n"))
