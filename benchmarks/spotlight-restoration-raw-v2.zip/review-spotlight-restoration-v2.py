from pathlib import Path
import datetime,hashlib,json,re,zipfile
base=Path.cwd()/'.artifacts/keyword-startup-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['13','14','15','16','17','18','19','20','21','22'];reads={n:json.loads((base/('spotlight-read-'+n+'.json')).read_text()) for n in names};floor='4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945'
assert all(r['unrelatedSHA256']==floor for r in reads.values())
assert [reads[n]['matchingOwnedCount'] for n in ['13','16','17','18','20','22']]==[4,3,2,2,1,0]
assert reads['22']['state']=='observed' and not reads['22']['matchingOwnedPaths']
initial=Path('/Users/vibhusapra/Documents/ChatGPT/oswind/.artifacts/competitor-screenpipe-v1/spotlight-owned-read-v2.json');verified=set(json.loads(initial.read_text())['matchingOwnedPaths']);assert set(reads['13']['matchingOwnedPaths']).issubset(verified)
for r in reads.values():assert set(r['matchingOwnedPaths']).issubset(verified)
for request,before,after in [('14','13','16'),('19','18','20'),('21','20','22')]:
 assert reads[request]['state']=='removal-requested'
 assert set(reads[before]['matchingOwnedPaths'])-set(reads[after]['matchingOwnedPaths'])=={reads[request]['requestedOwnedPath']}
removed=[]
for before,after in [('13','16'),('16','17'),('18','20'),('20','22')]:
 delta=set(reads[before]['matchingOwnedPaths'])-set(reads[after]['matchingOwnedPaths']);assert len(delta)==1 and set(reads[after]['matchingOwnedPaths']).issubset(reads[before]['matchingOwnedPaths']);removed.extend(delta)
assert set(removed)==set(reads['13']['matchingOwnedPaths']) and len(removed)==4
image=base/'spotlight-empty-2026-11-02.jpg';assert image.read_bytes()[:3]==b'\xff\xd8\xff'
ocr=base/'spotlight-empty-2026-11-02.ocr.txt';assert 'no locations added' in ocr.read_text().lower()
empty=base/'spotlight-empty-ui-ax.txt';assert 'No Locations Added' in empty.read_text() and 'table Excluded locations' in empty.read_text() and not re.search(r'row \((?:selected|selectable)\)',empty.read_text())
general=base/'spotlight-restored-general-ax.txt';assert re.search(r'row \(selected\) General',general.read_text())
selected=base/'spotlight-restored-general-selected.txt';assert not selected.exists();selected.write_text('\n'.join(line for line in general.read_text().splitlines() if 'row (selected) General' in line)+'\n')
files=[image,ocr,empty,selected,base/'spotlight-proof-ocr-v1.swift',base/'spotlight-proof-ocr-v1.stderr',base/'restore-owned-spotlight-v1.py',base/'spotlight-restoration-v1.json',base/'spotlight-restoration-runner-v1.log',Path(__file__)]
for n in names:files.extend([base/('spotlight-read-'+n+'.json'),base/('spotlight-read-'+n+'.log')])
archive=base/'spotlight-restoration-raw-v2.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.writestr(p.name,p.read_bytes())
result={'format':'OSwind targeted Spotlight restoration v2','state':'restoration-verified','completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initialOwnedCount':4,'finalOwnedCount':0,'onlyInitialVerifiedTaskCreatedPathsTargeted':True,'initialVerifiedPathsReceiptSHA256':sha(initial),'unrelatedSHA256BeforeAndAfter':floor,'independentObservedCounts':[4,3,2,2,1,0],'UIObservedCounts':[3,2,2,1,0],'finalUISignal':'No Locations Added','doneSucceeded':True,'originalGeneralPaneRestored':True,'globalServicesReset':False,'forceQuitOrSudo':False,'otherSettingsChanged':False,'screenshot':{'file':image.name,'sha256':sha(image),'bytes':image.stat().st_size,'ocrSHA256':sha(ocr)},'finalUIAXSHA256':sha(empty),'restoredGeneralSelectionSHA256':sha(selected),'rawArchive':{'file':archive.name,'sha256':sha(archive),'entries':len(files)},'reviewerSHA256':sha(Path(__file__)),'rawReads':{n:{'file':'spotlight-read-'+n+'.json','sha256':sha(base/('spotlight-read-'+n+'.json')),'state':r['state'],'matchingOwnedCount':r['matchingOwnedCount'],'removalStatus':r.get('removalStatus')} for n,r in reads.items()},'retainedFailures':[{'stage':'Automatic per-call verifier','file':'spotlight-restoration-runner-v1.log','sha256':sha(base/'spotlight-restoration-runner-v1.log'),'reason':'Immediate API read15 returned zero after the first removal, contradicted by healthy UI and read16 showing3. Controller stopped without further mutations. Zero rejected as final verification.'},{'stage':'System Settings removal','reason':'Group removal reported Privacy List Error but one owned path was independently removed. Subsequent UI removal also reported errors and left the remaining2 unchanged. Exact-path API requests then removed one at a time; UI and independent reads confirmed1 and0.'},{'stage':'First final receipt preflight','reason':'Screenshot was JPEG despite initial .png filename; header validation failed before any final receipt was written. Renamed without changing image bytes, then verified JPEG header and native OCR.'}],'scope':'Completes targeted restoration of the four remaining original benchmark-created Spotlight exclusions. Final healthy native UI, screenshot/OCR and fresh post-Done API read agree on zero, with unrelated-list hash unchanged. Old frozen comparison/review results stay unchanged. No live capture, power, quality, distribution or ranking acceptance follows.'}
out=base/'spotlight-restoration-v2.json';assert not out.exists()
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ['state','initialOwnedCount','finalOwnedCount','finalUISignal','originalGeneralPaneRestored']},indent=2))
