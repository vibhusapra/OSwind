import datetime,hashlib,json,pathlib,subprocess
base=pathlib.Path.cwd()/'.artifacts/keyword-startup-v1';original=pathlib.Path('/Users/vibhusapra/Documents/ChatGPT/oswind');helper=original/'.artifacts/competitor-screenpipe-v1/spotlight-owned-single-v1.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((base/'spotlight-read-13.json').read_text());assert prior['state']=='observed' and prior['matchingOwnedCount']==4;unrelated=prior['unrelatedSHA256'];paths=set(prior['matchingOwnedPaths']);result={'format':'OSwind targeted Spotlight cleanup continuation v1','initialRead':{'file':'spotlight-read-13.json','sha256':sha(base/'spotlight-read-13.json'),'ownedCount':4},'helperSHA256':sha(helper),'runnerSHA256':sha(pathlib.Path(__file__)),'unrelatedSHA256':unrelated,'onlyInitialVerifiedTaskCreatedPathsTargeted':True,'operations':[],'state':'restoration-in-progress'}
receipt=base/'spotlight-restoration-v1.json';assert not receipt.exists()
def save():receipt.write_text(json.dumps(result,indent=2)+'\n')
def call(index,remove):
 target=base/f'spotlight-read-{index}.json';log=base/f'spotlight-read-{index}.log';assert not target.exists() and not log.exists()
 with log.open('xb') as f:subprocess.run(['python3',str(helper),str(target),*(['--remove-one'] if remove else [])],cwd=original,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=35)
 value=json.loads(target.read_text());assert value['unrelatedSHA256']==unrelated
 return value,{'file':target.name,'sha256':sha(target),'logSHA256':sha(log)}
save()
for remaining in [4,3,2,1]:
 before,requestEvidence=call(14+(4-remaining)*2,True)
 assert before['state']=='removal-requested' and before['matchingOwnedCount']==remaining and set(before['matchingOwnedPaths'])==paths
 target=before['requestedOwnedPath'];assert target in paths
 after,readEvidence=call(15+(4-remaining)*2,False)
 assert after['state']=='observed' and after['matchingOwnedCount']==remaining-1 and set(after['matchingOwnedPaths'])==paths-{target}
 result['operations'].append({'request':requestEvidence,'requestStatus':before['removalStatus'],'removedOwnedPath':target,'independentRead':readEvidence,'independentOwnedCount':remaining-1});paths=set(after['matchingOwnedPaths']);save();print('VERIFIED_OWNED_COUNT',remaining-1,flush=True)
repeat,evidence=call(22,False);assert repeat['state']=='observed' and repeat['matchingOwnedCount']==0 and not repeat['matchingOwnedPaths']
result.update(state='targeted-restoration-independently-observed',finalOwnedCount=0,repeatRead=evidence,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Four exact original task-created exclusions removed with fresh per-call independent reads and unchanged unrelated-list hash. No resets, sudo, force quit, permission or credential change. UI confirmation remains separate. No old frozen benchmark/reviewer was rerun.');save();print('TARGETED_RESTORATION_TERMINAL',flush=True)
