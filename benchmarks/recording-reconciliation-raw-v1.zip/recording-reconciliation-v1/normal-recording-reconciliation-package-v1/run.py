from pathlib import Path
import json,hashlib,subprocess,time,os,struct,plistlib,shutil,zipfile
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=b/'recording-original-reconciliation-qualification-v1'
followup=b/'recording-reconciliation-bounded-scale-v1'
assert json.loads((followup/'driver-exit-v1.json').read_text())['exitCode']==0
extra=json.loads((followup/'result.json').read_text());assert extra['exitCode']==0 and extra['counts']=={'passed':2,'skipped':0,'failed':0}
assert json.loads((prior/'driver-exit-v1.json').read_text())['exitCode']==0
for mode in ['optimized','thread-sanitizer']:
 gate=json.loads((prior/mode/'result.json').read_text());assert gate['exitCode']==0 and gate['counts']['failed']==0 and gate['inputsAndPriorActualFilesUnchanged']
sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=r,text=True).strip(),'Commit concrete runtime/CI before packaging; document artifacts follow packaging.'
originalQualification=json.loads((prior/'execution-inputs.json').read_text())
for row in originalQualification['inputs']:
 if row['path'].startswith(('Sources/','ThirdParty/','Vendor/','models/','scripts/')) or row['path'] in ['Package.swift','Package.resolved']:assert sha(r/row['path'])==row['sha256'],row['path']
qualified=json.loads((followup/'execution-inputs.json').read_text())
for row in qualified['inputs']:
 if row['path'].startswith(('Sources/','Tests/')):assert sha(r/row['path'])==row['sha256'],row['path']
protected=qualified['protectedFrozen'][:]
corpora=qualified['protectedCurrentFocusedCorpora'][:]
for name in ['outgoing-cases','incoming-cases','measurement']:
 for p in sorted((followup/name).rglob('*')):
  if p.is_file():corpora.append({'path':str(p),'sha256':sha(p)})
files=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=r,text=True).splitlines()))
pins={'baseSource':sourceCommit,'qualifiedInputBase':qualified['baseSource'],'inputs':[{'path':p,'sha256':sha(r/p)} for p in files if (r/p).is_file()],'protectedFrozen':protected,'protectedCurrentFocusedCorpora':corpora,'productionFilesEqual846MethodQualification':True,'runtimeAndTestFilesEqualNewTwoControlSnapshot':True}
(out/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']+pins['protectedCurrentFocusedCorpora']:assert sha(Path(x['path']))==x['sha256'],x['path']
def code(p):
 data=p.read_bytes();assert struct.unpack_from('<I',data)[0]==0xfeedfacf
 n=struct.unpack_from('<I',data,16)[0];offset=32
 for _ in range(n):
  cmd,size=struct.unpack_from('<II',data,offset)
  if cmd==0x19:
   sections=struct.unpack_from('<I',data,offset+64)[0]
   for i in range(sections):
    pos=offset+72+i*80;name=data[pos:pos+16].split(b'\0')[0];segment=data[pos+16:pos+32].split(b'\0')[0]
    if name==b'__text' and segment==b'__TEXT':
     length=struct.unpack_from('<Q',data,pos+40)[0];start=struct.unpack_from('<I',data,pos+48)[0];return {'bytes':length,'sha256':hashlib.sha256(data[start:start+length]).hexdigest()}
  offset+=size
 raise AssertionError('No executable text section')
check();assert shutil.disk_usage(out).free>=16*1024**3;app=out/'OSwind.app';assert not app.exists();allowed=['PATH','HOME','TMPDIR','SHELL','LANG','LC_ALL','LC_CTYPE','SDKROOT','DEVELOPER_DIR','CPATH','LIBRARY_PATH','MACOSX_DEPLOYMENT_TARGET','__CF_USER_TEXT_ENCODING'];env={k:os.environ[k] for k in allowed if k in os.environ};env.update({'OSWIND_APP_OUTPUT':str(app),'OSWIND_BUILD_ROOT':str(out/'canonical-build')});started=time.monotonic()
with (out/'build.log').open('xb') as log:p=subprocess.run(['bash','scripts/build-app.sh','release'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
(out/'process-result.json').write_text(json.dumps({'exitCode':p.returncode,'command':['bash','scripts/build-app.sh','release'],'elapsedSeconds':time.monotonic()-started},indent=2)+'\n')
check();record={'source':sourceCommit,'testInputBaseSource':qualified['baseSource'],'testInputManifestSHA256':sha(followup/'execution-inputs.json'),'broaderProductionQualificationManifestSHA256':sha(prior/'execution-inputs.json'),'scope':'Fresh normal release app packaging with strict ad-hoc signing; not notarized distribution or physical/interactive acceptance. This normal build has a packaging purpose, not a provenance rebuild of earlier tests.','command':['bash','scripts/build-app.sh','release'],'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started,'inputsAndAllPriorActualEnginesUnchanged':True,'buildLogSHA256':sha(out/'build.log'),'app':str(app)}
if p.returncode:
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(p.returncode)
products=out/'actual-canonical-products';products.mkdir();manifest=[]
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 original=out/'canonical-build/release'/name;shutil.copy2(original,products/name)
 manifest.append({'path':str((products/name).relative_to(out)),'bytes':(products/name).stat().st_size,'sha256':sha(products/name),'mode':oct((products/name).stat().st_mode&0o777)})
(out/'actual-canonical-products.json').write_text(json.dumps(manifest,indent=2)+'\n')
files={}
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 packaged=app/'Contents/MacOS'/name;original=products/name;assert code(packaged)==code(original)
 files[name]={'packagedSHA256':sha(packaged),'unsignedActualCanonicalBuildProductSHA256':sha(original),'textSection':code(packaged),'packagedBytes':packaged.stat().st_size,'matchesOwnActualCanonicalBuild':True}
record['executables']=files
with (out/'signature-verify.log').open('xb') as log:subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,stdout=log,stderr=subprocess.STDOUT)
info=plistlib.loads((app/'Contents/Info.plist').read_bytes());assert info['CFBundleIdentifier']=='com.oswind.desktop'
for key in ['NSCalendarsFullAccessUsageDescription','NSMicrophoneUsageDescription','NSScreenCaptureUsageDescription','NSAppleEventsUsageDescription']:assert info.get(key)
for name in ['NOTICES.txt','Apache-2.0.txt']:assert (app/'Contents/Resources/ThirdParty'/name).is_file()
cli=app/'Contents/MacOS/oswindctl';owned=out/'owned-cli-smoke';assert not owned.exists()
def invoke(label,args):
 start=time.monotonic();p=subprocess.run([str(cli),'--data',str(owned),*args],cwd=r,env=env,capture_output=True)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);(out/(label+'.result.json')).write_text(json.dumps({'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n');assert p.returncode==0,(label,p.returncode)
 return {'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()},p.stdout
record['smoke']={}
record['smoke']['emptyStats'],_=invoke('empty-stats',['stats'])
record['smoke']['authoredNote'],_=invoke('authored-note',['note','Authored signedpackagedsentinel for an owned package smoke test. No captured data.'])
record['smoke']['literalKeyword'],data=invoke('literal-keyword',['search','--mode','keyword','--literal','signedpackagedsentinel','--json'])
values=json.loads(data);assert isinstance(values,list) and len(values)==1 and values[0]['match']=='keyword' and 'signedpackagedsentinel' in values[0]['memory']['text'] and values[0]['memory']['id']==(out/'authored-note.stdout').read_text().strip();record['smoke']['sourceCount']=len(values);record['smoke']['exactAuthoredIDMatchesKeywordResult']=True
record['resources']=[{'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((app/'Contents/Resources').rglob('*')) if p.is_file()]
archive=out/'OSwind-recording-reconciliation-development.zip';subprocess.run(['ditto','-c','-k','--sequesterRsrc','--keepParent',str(app),str(archive)],check=True,cwd=r)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
roundtrip=out/'round-trip';roundtrip.mkdir();subprocess.run(['ditto','-x','-k',str(archive),str(roundtrip)],check=True,cwd=r)
with (out/'round-trip-signature.log').open('xb') as log:subprocess.run(['codesign','--verify','--deep','--strict',str(roundtrip/'OSwind.app')],check=True,stdout=log,stderr=subprocess.STDOUT)
for p in sorted(app.rglob('*')):
 if p.is_file():assert sha(p)==sha(roundtrip/'OSwind.app'/p.relative_to(app)),str(p)
record['developmentArchive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'roundTripAllFileHashesAndStrictSignature':True}
durable=Path('/Users/vibhusapra/Documents/OSwind-builds')/('2026-11-04-recording-reconciliation-'+sourceCommit[:7]);durable.mkdir()
shutil.copy2(archive,durable/archive.name);assert sha(durable/archive.name)==sha(archive)
record['durableDelivery']={'directory':str(durable),'archive':str(durable/archive.name),'sha256':sha(archive)}
check();(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(durable/'build-info.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['resources','executables']}))
