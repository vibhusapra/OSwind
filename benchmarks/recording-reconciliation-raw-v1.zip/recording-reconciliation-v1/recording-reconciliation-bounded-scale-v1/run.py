from pathlib import Path
import json,hashlib,subprocess,time,re,os,shutil
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];pins=json.loads((out/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']+pins['protectedCurrentFocusedCorpora']:assert sha(Path(x['path']))==x['sha256'],x['path']
check();assert shutil.disk_usage(out).free>=16*1024**3
allowed=['PATH','HOME','TMPDIR','SHELL','LANG','LC_ALL','LC_CTYPE','SDKROOT','DEVELOPER_DIR','CPATH','LIBRARY_PATH','MACOSX_DEPLOYMENT_TARGET','__CF_USER_TEXT_ENCODING'];env={k:os.environ[k] for k in allowed if k in os.environ}
command=['swift','test','-c','release','--jobs','2','list'];start=time.monotonic()
with (out/'build.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
process={'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start,'testExecution':False};(out/'build-process-result.json').write_text(json.dumps(process,indent=2)+'\n');check()
if p.returncode:raise SystemExit(p.returncode)
products=r/'.build/arm64-apple-macosx/release';frozen=out/'actual-engine';frozen.mkdir();shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
manifest=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()];(out/'actual-engine.json').write_text(json.dumps(manifest,indent=2)+'\n')
for x in manifest:pins['protectedFrozen'].append({'path':str(out/x['path']),'sha256':x['sha256']})
(out/'execution-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');check()
methods=['OSwindCoreTests.SyncIncomingSourceTests/testRecordingOriginalRecoveryOversizedMetadataRefusesNativeWriteWithoutBlockingErasure','OSwindCoreTests.SyncIncomingSourceTests/testRecordingOriginalRecoveryNoEditBoundedCanonicalScanAtAuthoredScale'];env.update({'OSWIND_RECORDING_ORIGINAL_QA_DIR':str(out/'outgoing-cases'),'OSWIND_TEST_INCOMING_SOURCE_ROOT':str(out/'incoming-cases'),'OSWIND_RECORDING_RECONCILIATION_BENCH_DIR':str(out/'measurement')});command=['xcrun','xctest','-XCTest',','.join(methods),str(frozen/'OSwindPackageTests.xctest')];start=time.monotonic()
with (out/'test.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
process={'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start,'testExecution':True};(out/'process-result.json').write_text(json.dumps(process,indent=2)+'\n');check();s=(out/'test.log').read_text();m=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",s)
result={**process,'build':json.loads((out/'build-process-result.json').read_text()),'sourceAndPriorActualEnginesAndCorporaAndFrozenCurrentEngineUnchanged':True,'defined':len(m),'counts':{v:sum(y==v for _,y,_ in m) for v in ['passed','skipped','failed']},'logSHA256':sha(out/'test.log'),'diagnostics':[x for x in s.splitlines() if ' error: ' in x or 'failed -' in x],'scope':'Actual optimized two new controls only: native32KiB refusal/atomicity/continued erasure and authored2001label64candidate bounded reconciliation measurement. ProductionSources unchanged from completed846-method Debug/optimized/TSAN snapshot; no replay of unchanged broader native suites merely for provenance. Not power/physical/provider/competitor/fullv0 acceptance.','childEnvironment':'Minimal explicit system/build allowlist, no inherited provider credentials.'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['command','build','diagnostics']}));print(s[-1100:]);assert len(m)==2,'Unexpected XCTest selection count';raise SystemExit(p.returncode)
