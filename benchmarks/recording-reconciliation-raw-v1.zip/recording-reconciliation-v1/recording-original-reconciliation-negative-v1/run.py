from pathlib import Path
import json,hashlib,subprocess,time,re,shutil,os
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];pins=json.loads((out/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 for row in pins['inputs']:assert sha(r/row['path'])==row['sha256'],row['path']
 for row in pins['protectedFrozen']+pins['protectedCurrentFocusedCorpora']:assert sha(Path(row['path']))==row['sha256'],row['path']
check();env=os.environ.copy();env.pop('DYLD_INSERT_LIBRARIES',None);env['OSWIND_TEST_INCOMING_SOURCE_ROOT']=str(out/'incoming-cases');command=['swift','test','--jobs','4','--filter','SyncIncomingSourceTests.testRecordingOriginalRecoveryOriginalOnlyErasureReconcilesHeadWithoutCaptionEdit'];start=time.monotonic()
with (out/'test.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
process={'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start};(out/'process-result.json').write_text(json.dumps(process,indent=2)+'\n');check();s=(out/'test.log').read_text();m=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",s);result={**process,'counts':{v:sum(y==v for _,y,_ in m) for v in ['passed','skipped','failed']},'defined':len(m),'logSHA256':sha(out/'test.log'),'sourceAndPriorActualFilesAndCorporaUnchanged':True,'scope':'Desired no-edit derived metadata-head reconciliation after original-only erasure. Published9805 Core unchanged; one new authored 2-local-endpoint/PCM test. Not complete transport/outbox or real-device/provider acceptance.'}
if 'Build complete!' in s and m:
 frozen=out/'actual-engine';frozen.mkdir();products=r/'.build/arm64-apple-macosx/debug';shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest');manifest=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()];(out/'actual-engine.json').write_text(json.dumps(manifest,indent=2)+'\n');result['actualEngineFrozen']=True
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print(s[-1800:]);raise SystemExit(p.returncode)
