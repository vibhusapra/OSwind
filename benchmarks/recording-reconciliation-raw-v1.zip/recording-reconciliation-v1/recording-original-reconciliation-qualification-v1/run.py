from pathlib import Path
import os,json,hashlib,subprocess,time,re,shutil
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];pins=json.loads((out/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((b/'recording-original-reconciliation-broad-debug-v1/result.json').read_text())['exitCode']==0
release=b/'recording-original-reconciliation-release-build-v1';assert json.loads((release/'result.json').read_text())['exitCode']==0
for x in json.loads((release/'actual-engine.json').read_text()):pins['protectedFrozen'].append({'path':str(release/x['path']),'sha256':x['sha256']})
(out/'execution-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
classes=json.loads((out/'classes.json').read_text())
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']+pins['protectedCurrentFocusedCorpora']:assert sha(Path(x['path']))==x['sha256'],x['path']
check()
for mode in ['optimized','thread-sanitizer']:
 d=out/mode;d.mkdir();env=os.environ.copy();env.pop('DYLD_INSERT_LIBRARIES',None)
 env.update({'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_RECORDING_NAMES_UI_QA_DIR':str(d/'name-components'),'OSWIND_RECORDING_SCOPE_UI_DIR':str(d/'scope-components'),'OSWIND_RECORDED_MEETING_UI_QA_DIR':str(d/'recording-components'),'OSWIND_RECORDING_CALENDAR_UI_QA_DIR':str(d/'calendar-components'),'OSWIND_OWNER_VAULT_TRACE_DIR':str(d/'owner-traces'),'OSWIND_TEST_VAULT_TRACE_DIR':str(d/'native-traces'),'OSWIND_RECORDING_PRIOR_WRITER_CLI':str(r/'.artifacts/recording-view-performance-v1/frozen-normal-release-v1/oswindctl'),'OSWIND_RECORDING_WRITER_QA_DIR':str(d/'older-cli'),'OSWIND_RECORDING_ORIGINAL_QA_DIR':str(d/'outgoing-cases'),'OSWIND_TEST_INCOMING_SOURCE_ROOT':str(d/'incoming-cases')})
 selection=classes[:]
 if mode=='optimized':
  env.update({'OSWIND_SESSION_NAME_BENCH_DIR':str(d/'lookup-benchmark'),'OSWIND_RECORDING_OLD_CLI':str(r/'.artifacts/recorded-meeting-identifiers-v1/frozen-optimized-v1/oswindctl'),'OSWIND_RECORDING_CURRENT_CLI':str(release/'actual-engine/oswindctl'),'OSWIND_RECORDING_UNSCOPED_CLI':str(r/'.artifacts/recording-scope-v1/frozen-development-v10/oswindctl'),'OSWIND_RECORDING_CLI_QA_DIR':str(d/'cli')})
  command=['xcrun','xctest','-XCTest',','.join(selection),str(release/'actual-engine/OSwindPackageTests.xctest')]
 else:
  command=['swift','test','--sanitize','thread','--scratch-path',str(b/'calendar-integration-v1/tsan-build'),'--jobs','4','--filter','|'.join(selection)]
 start=time.monotonic()
 with (d/'test.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 process={'mode':mode,'sourceBase':pins['baseSource'],'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start,'testExecution':True};(d/'process-result.json').write_text(json.dumps(process,indent=2)+'\n')
 check();s=(d/'test.log').read_text();methods=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",s)
 result={**process,'inputsAndPriorActualFilesUnchanged':True,'defined':len(methods),'counts':{v:sum(y==v for _,y,_ in methods) for v in ['passed','skipped','failed']},'logSHA256':sha(d/'test.log'),'skips':[x for x in s.splitlines() if 'Test skipped -' in x],'diagnostics':[x for x in s.splitlines() if ' error: ' in x or 'WARNING: ThreadSanitizer' in x or 'SUMMARY: ThreadSanitizer' in x or 'failed -' in x],'actualEngine':'../recording-original-reconciliation-release-build-v1/actual-engine' if mode=='optimized' else None,'scope':'Current no-edit erasure reconciliation and incoming required-graph audit source snapshot. 34 Core/App classes; optimized enables 2 actual CLI controls. TSan includes native vault/Keychain. No physical/provider/full-v0/ranking acceptance.'}
 if mode=='thread-sanitizer' and 'Build complete!' in s and methods:
  products=b/'calendar-integration-v1/tsan-build/arm64-apple-macosx/debug';frozen=d/'actual-engine';frozen.mkdir();shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
  manifest=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()];(d/'actual-engine.json').write_text(json.dumps(manifest,indent=2)+'\n');result['actualEngineFrozen']=True
  for x in manifest:pins['protectedFrozen'].append({'path':str(out/x['path']),'sha256':x['sha256']})
 (d/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['command','skips','diagnostics']}),flush=True)
 if p.returncode:print(s[-1400:],flush=True);raise SystemExit(p.returncode)
check()
