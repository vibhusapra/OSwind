from pathlib import Path
import copy,hashlib,json,re,subprocess
root=Path.cwd();base=root/'.artifacts/capture-start-readiness-v1';run=base/'qualification-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());results=json.loads((run/'results.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==inputs['baseSource']==results['baseSource']=='2789996b7db347307107f26d689781f206d19298'
assert len(inputs['inputFiles'])==690 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
previous=inputs['previousQualification'];assert previous['inputsSHA256']==sha(base/'qualification-v1/inputs.json') and previous['resultsSHA256']==sha(base/'qualification-v1/results.json') and previous['nativeObservationSHA256']==sha(base/'native-qa-v1.json');assert json.loads((base/'native-qa-v1.json').read_text())['repairObserved']['footerIncorrectlyStale'] is True
assert set(inputs['workingChanges'])=={'Sources/OSwindCore/Capture.swift','Tests/OSwindCoreTests/CaptureStartReadinessTests.swift'}
prior=json.loads((root/'benchmarks/capture-request-admission-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==689
assert set(inputs['inputFiles'])-set(prior)=={'Tests/OSwindCoreTests/CaptureStartReadinessTests.swift'}
assert [p for p in prior if prior[p]!=inputs['inputFiles'][p]]==['Sources/OSwindCore/Capture.swift']
assert sha(base/'qualify-v2.py')==results['runnerSHA256'] and sha(run/'inputs.json')==results['inputManifestSHA256']
pattern=re.compile(r"^Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)",re.M)
def rows(text):
 r=[(a+'.'+b,c) for a,b,c in pattern.findall(text)];assert len(r)==len(set(a for a,b in r));return dict(r)
debug=(run/'affected-debug.log').read_text();reference=rows(debug)
expectedSkip='OSwindCoreTests.SnapshotAdmissionTests.testNativeVaultSnapshotAdmissionAndCancelledWorkPermitVerifiedDetach'
assert len(reference)==99 and reference[expectedSkip]=='skipped' and list(reference.values()).count('passed')==98
required={'OSwindCoreTests.CaptureStartReadinessTests.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests/OSwindCoreTests/CaptureStartReadinessTests.swift').read_text())};assert len(required)==6 and all(reference[x]=='passed' for x in required)
def inspect(text):
 r=rows(text);assert r==reference
 assert 'Executed 99 tests, with 1 test skipped and 0 failures' in text
 assert not any(t in text for t in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
 return {'defined':len(r),'passed':98,'skipped':[expectedSkip],'failed':0,'newMethodsPassed':sorted(required)}
reports=[]
assert [s['name'] for s in results['stages']]==['affected-debug','affected-tsan','affected-optimized','package']
selector='CaptureStartReadinessTests|SnapshotAdmissionTests|SnapshotRegionTests|AccessibilityTextCaptureTests|TextObservationCaptureTests|AccessibilityCaptureSetupTests|WorkspaceWakeLifecycleTests'
for stage in results['stages']:
 assert stage['exit']==0 and sha(root/stage['log'])==stage['sha256']
 if stage['name']!='package':
  expected=['swift','test']+(['--sanitize=thread'] if stage['name']=='affected-tsan' else ['-c','release'] if stage['name']=='affected-optimized' else [])+['--filter',selector]
  assert stage['command']==expected and stage['environment']=={}
  reports.append({'mode':stage['name'],**inspect((root/stage['log']).read_text()),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']})
 else:assert stage['command']==['bash','scripts/build-app.sh','release'] and stage['environment']=={'OSWIND_APP_OUTPUT':str(run/'OSwind.app')}
red=(base/'red-v1.log').read_text();assert sha(base/'red-v1.log')==inputs['redLogSHA256'];redrows=rows(red);assert set(redrows)==required and list(redrows.values()).count('failed')==5 and redrows['OSwindCoreTests.CaptureStartReadinessTests.testValidScopeStillRequiresOnlyItsOwnPermission']=='passed' and 'Executed 6 tests, with 13 failures' in red
faults={}
identity=next(iter(required));line=next(line for line in debug.splitlines() if identity.rsplit('.',1)[1] in line and "' passed" in line)
for name,bad in {'dropped-result':debug.replace(line,'',1),'duplicate-result':debug+'\n'+line,'hidden-failure':debug.replace(line,line.replace("' passed","' failed"),1),'missing-new-method':debug.replace(identity.rsplit('.',1)[1],'testWrongMethodIdentity'),'wrong-skip':debug.replace("testNativeVaultSnapshotAdmissionAndCancelledWorkPermitVerifiedDetach]' skipped","testNativeVaultSnapshotAdmissionAndCancelledWorkPermitVerifiedDetach]' passed")}.items():
 try:inspect(bad)
 except AssertionError:faults[name]='rejected'
 else:raise AssertionError('Accepted altered '+name)
assert len(faults)==5
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()};assert files and 'Contents/MacOS/OSwind' in files
native=json.loads((base/'native-qa-v1.json').read_text());assert native['blockedResumeHeader']=='OSwind PAUSED / Balanced' and native['blockedResumeButton']=='Resume capture' and native['blockedResumeFooter']=='Invalid capture area · choose a new area in Settings' and native['screenSources']==0 and native['qaStoppedVerified'] is True
preflight=json.loads((base/'native-qa-v2-preflight.json').read_text());assert preflight['state']=='blocked' and preflight['doctor']['screenLocked'] is True and preflight['candidateProcessObserved'] is False and preflight['workingChanges']==inputs['workingChanges'] and preflight['baseSource']==inputs['baseSource']

result={'format':'OSwind capture start readiness review v4','baseSource':inputs['baseSource'],'inputCount':690,'unchangedPriorInputs':688,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':reports,'retainedRedControl':{'failedMethods':5,'passedPermissionControl':1,'assertionFailures':13,'logSHA256':sha(base/'red-v1.log')},'rejectedAlteredLogControls':faults,'newPackage':{'path':str(package),'files':files,'scope':'Fresh local ad-hoc package; build script strict verification. No production signing/notary/DP-Keychain claim.'},'nativeQAObservation':{'priorBlockedStart':{'file':str((base/'native-qa-v1.json').relative_to(root)),'sha256':sha(base/'native-qa-v1.json'),'scope':'Actual first candidate GUI confirms blocked-start header/button/footer and zero screen sources; repair then exposes stale footer. Normalized manual observation, not automated UI assertions.'},'finalRepairCheck':{'file':str((base/'native-qa-v2-preflight.json').relative_to(root)),'sha256':sha(base/'native-qa-v2-preflight.json'),'state':'blocked','reason':'Mac locked before final v2 GUI launch. Repaired footer passes software tests only; final native observation remains pending.'}},'scope':'Capture scope readiness and cancellation only. Selected99 methods, not a full-suite rerun. Native-vault conditional remains skipped in these selections. All83feature statuses/landscape unchanged. Final repaired-footer GUI blocked by locked Mac. No new automatic24h, energy, complete sync, production signing or competitor ranking acceptance.'}
out=run/'reviewed-v4.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'inputCount':690,'stages':[{k:r[k] for k in ['mode','passed','skipped','failed']} for r in reports],'alteredControls':len(faults),'reviewSHA256':sha(out)}))
