from pathlib import Path
import hashlib,json,os,platform,subprocess,time
root=Path.cwd();base=root/'.artifacts/capture-start-readiness-v1';out=base/'qualification-v2';out.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='2789996b7db347307107f26d689781f206d19298'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();pins={p:sha(root/p) for p in sorted(set(paths)) if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved']) and (root/p).is_file()};assert len(pins)==690
changes={'Sources/OSwindCore/Capture.swift','Tests/OSwindCoreTests/CaptureStartReadinessTests.swift'}
manifest={'format':'OSwind capture start readiness inputs v2','baseSource':head,'inputFiles':pins,'workingChanges':{p:pins[p] for p in sorted(changes)},'redLogSHA256':sha(base/'red-v1.log'),'previousQualification':{'inputsSHA256':sha(base/'qualification-v1/inputs.json'),'resultsSHA256':sha(base/'qualification-v1/results.json'),'nativeObservationSHA256':sha(base/'native-qa-v1.json'),'reason':'First qualification passed selected software checks and blocked-start GUI. Actual repair then exposed stale footer, requiring this source/test update; earlier results/package stay frozen.'}};(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
selector='CaptureStartReadinessTests|SnapshotAdmissionTests|SnapshotRegionTests|AccessibilityTextCaptureTests|TextObservationCaptureTests|AccessibilityCaptureSetupTests|WorkspaceWakeLifecycleTests'
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]};env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
stages=[('affected-debug',['swift','test','--filter',selector],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',selector],{}),('affected-optimized',['swift','test','-c','release','--filter',selector],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]
for name,cmd,extra in stages:
 assert all(sha(root/p)==h for p,h in pins.items());print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
 with log.open('xb') as f:rc=subprocess.run(cmd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT).returncode
 results['stages'].append({'name':name,'command':cmd,'environment':extra,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
 assert all(sha(root/p)==h for p,h in pins.items())
 if rc:raise SystemExit(rc)
print('QUALIFICATION_STAGES_COMPLETE',flush=True)
