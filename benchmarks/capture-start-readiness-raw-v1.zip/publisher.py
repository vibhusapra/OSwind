from pathlib import Path
import hashlib,json,os,subprocess,zipfile
root=Path.cwd();base=root/'.artifacts/capture-start-readiness-v1';run=base/'qualification-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();reviewPath=run/'reviewed-v4.json'
assert sha(reviewPath)=='3a880abaf7aceaa05d50344afa12c15c183a9450d838c198f93e9c48f1a02fc3'
review=json.loads(reviewPath.read_text());inputs=json.loads((run/'inputs.json').read_text());results=json.loads((run/'results.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']==review['baseSource']=='2789996b7db347307107f26d689781f206d19298'
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges']) and len(inputs['workingChanges'])==2
assert len(inputs['inputFiles'])==690 and inputs['workingChanges']==review['workingChanges'] and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert review['reviewerSHA256']==sha(base/'review-v4.py') and review['runnerSHA256']==sha(base/'qualify-v2.py') and review['inputManifestSHA256']==sha(run/'inputs.json')
assert len(review['stages'])==3 and all(s['passed']==98 and s['failed']==0 and len(s['skipped'])==1 and len(s['newMethodsPassed'])==6 for s in review['stages']) and len(review['rejectedAlteredLogControls'])==5
assert len(results['stages'])==4 and all(s['exit']==0 for s in results['stages']) and review['nativeQAObservation']['finalRepairCheck']['state']=='blocked'
assert subprocess.check_output(['git','rev-parse','--show-object-format'],text=True).strip()=='sha1';tree={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
 if entry:
  h,p=entry.split(b'\t',1);tree[p.decode()]=h.decode().split()[2]
for path,h in inputs['inputFiles'].items():
 p=root/path;b=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
 if entry:
  h,p=entry.split(b'\t',1);b=(root/p.decode()).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==h.decode().split()[2];protected[p.decode()]=hashlib.sha256(b).hexdigest()
files={'runner-v2.py':base/'qualify-v2.py','reviewer-v4.py':base/'review-v4.py','publisher.py':Path(__file__),'inputs.json':run/'inputs.json','results.json':run/'results.json','reviewed-v4.json':reviewPath,'controller-v2.log':base/'controller-v2.log','review-controller-v4.log':run/'review-controller-v4.log','red-v1.log':base/'red-v1.log','prior/debug-v1.log':base/'debug-v1.log','prior/runner-v1.py':base/'qualify-v1.py','prior/controller-v1.log':base/'controller-v1.log','prior/inputs.json':base/'qualification-v1/inputs.json','prior/results.json':base/'qualification-v1/results.json','native/native-candidate-v1.json':base/'native-candidate-v1.json','native/native-candidate-v2.json':base/'native-candidate-v2.json','native/qa-v1.json':base/'native-qa-v1.json','native/qa-v2-preflight.json':base/'native-qa-v2-preflight.json','retained-checker-failure/reviewer-v3.py':base/'review-v3.py','retained-checker-failure/controller-v3.log':run/'review-controller-v3.log'}
for stage in results['stages']:
 p=root/stage['log'];assert sha(p)==stage['sha256'];files['logs/'+stage['name']+'.log']=p
previous=json.loads((base/'qualification-v1/results.json').read_text())
for stage in previous['stages']:
 p=root/stage['log'];assert sha(p)==stage['sha256'];files['prior/logs/'+stage['name']+'.log']=p
for path in inputs['workingChanges']:files['source/'+path]=root/path
payloads={n:p.read_bytes() for n,p in files.items()}
# Recover exact earlier source bytes from the final delta and validate against its frozen input pins.
oldpins=json.loads((base/'qualification-v1/inputs.json').read_text())['inputFiles']
old=(root/'Sources/OSwindCore/Capture.swift').read_text().replace('''            else if let previousIssue=captureScopeIssue(for:oldValue),status==previousIssue {
                status=captureScopeIssue ?? "Paused"
            }
''','',1).replace('''    private var captureScopeIssue:String? {captureScopeIssue(for:settings)}
    private func captureScopeIssue(for settings:AppSettings)->String? {''','''    private var captureScopeIssue:String? {''',1).replace('guard !(settings.allDisplays && settings.snapshotRegions.selectedDisplays?.isEmpty==true) else {return "No displays selected · choose a display in Settings"}','guard !noDisplaysSelected else {return "No displays selected · choose a display in Settings"}',1).encode()
assert hashlib.sha256(old).hexdigest()==oldpins['Sources/OSwindCore/Capture.swift'];payloads['prior/source/Capture.swift']=old
oldtest=(root/'Tests/OSwindCoreTests/CaptureStartReadinessTests.swift').read_text().replace('c.settings.snapshotRegions=SnapshotRegionSettings();await Task.yield();XCTAssertFalse(c.running);XCTAssertEqual(c.status,"Paused")','c.settings.snapshotRegions=SnapshotRegionSettings();await Task.yield();XCTAssertFalse(c.running)',1).encode();assert hashlib.sha256(oldtest).hexdigest()==oldpins['Tests/OSwindCoreTests/CaptureStartReadinessTests.swift'];payloads['prior/source/CaptureStartReadinessTests.swift']=oldtest
payloads['red-baseline-source/Capture.swift']=subprocess.check_output(['git','show',inputs['baseSource']+':Sources/OSwindCore/Capture.swift'])
payloads['README.txt']=(f'OSwind capture scope readiness runtime {source}, exact690 committed runtime/test/dependency blobs and2 changed files. Debug/TSan/optimized each98pass1native-vault skip0fail; all6new methods pass. Original red baseline5failed methods/13assertions plus1permission control. Five altered-log controls reject. First native candidate confirms PAUSED header on invalid resume, then exposes stale repair footer. Final footer repair passes software tests; final new GUI candidate is blocked before launch by locked Mac (CLI doctor confirms lock; no permission/unlock changes). Never call that native check passed. Earlier qualification stays frozen. Prior working-source versions are reconstructed from the final delta and match frozen source SHA256 pins exactly; original red Core is from committed parent. Failed checker-v3 referenced the old runner filename; corrected v4 passed without rerunning tests. Explicit source/log/receipt/manifests only, no DB/credential backend/account inventory/key/executable. No actual capture24h, energy, complete sync, production signing/notary/DP-Keychain, full parity or ranking claim. All83feature records/landscape unchanged.\n').encode()
receipt=root/'benchmarks/capture-start-readiness-v1.json';manifest=root/'benchmarks/capture-start-readiness-inputs-v1.json';archive=root/'benchmarks/capture-start-readiness-raw-v1.zip';assert all(not p.exists() for p in [receipt,manifest,archive])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(payloads.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payloads) and set(z.namelist())==set(payloads) and all(z.read(n)==b for n,b in payloads.items())
with manifest.open('x') as f:json.dump({'format':'OSwind capture start readiness inputs v1','runtimeCommit':source,'developmentBase':inputs['baseSource'],'inputFiles':inputs['inputFiles'],'workingChanges':inputs['workingChanges'],'developmentManifestSHA256':sha(run/'inputs.json')},f,indent=2);f.write('\n')
result={**review,'runtimeCommit':source,'allCommittedInputBlobsMatch':True,'inputManifest':manifest.name,'inputManifestSHA256':sha(manifest),'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'host':results['host'],'toolchain':results['toolchain'],'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payloads),'allArchivedBytesComparedToReviewedInputs':True,'files':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(payloads.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True,'manifestSHA256':hashlib.sha256(json.dumps(protected,sort_keys=True,separators=(',',':')).encode()).hexdigest()},'retainedCheckerFailure':'First executed checker-v3 referenced old runner path; v4 corrects it without rerunning product tests. The failed checker script/log is retained.','finalNativeRepairAcceptance':'Pending manual unlock; no final GUI pass claimed.'}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'runtimeCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payloads),'protectedBaseFiles':len(protected)}))
