import pathlib,sqlite3,json,hashlib,struct
root=pathlib.Path(__file__).resolve().parent;owned=root/'oswind-1000'
assert (owned/'owned-fixture').read_text()=='OSwind authored capture scale fixture v1'
receipt=json.loads((owned/'report.json').read_text());assert receipt['state']=='completed' and receipt['rows']==1000
source=sqlite3.connect('file:'+str(owned/'library/memory.sqlite')+'?mode=ro',uri=True)
rows=source.execute('SELECT id,timestamp,app,title,url,text FROM memories ORDER BY id COLLATE BINARY').fetchall();source.close();assert len(rows)==1000
h=hashlib.sha256()
for identifier,stamp,app,title,url,text in rows:
 assert identifier.startswith('scale-') and text=='Owned source '+identifier[6:]
 for s in [identifier,text]:b=s.encode();h.update(struct.pack('<Q',len(b)));h.update(b)
assert h.hexdigest()==receipt['originalIDTextSHA256After']
db=sqlite3.connect(root/'data/db.sqlite');assert db.execute('SELECT COUNT(*) FROM frames').fetchone()==(0,)
with db:
 db.execute('PRAGMA foreign_keys=ON')
 db.execute('INSERT INTO video_chunks(id,file_path,device_name) VALUES(1,?,?)',(str(root/'authored-no-media.mp4'),'Authored benchmark only'))
 for identifier,stamp,app,title,url,text in rows:
  db.execute("INSERT INTO frames(id,video_chunk_id,offset_index,timestamp,name,app_name,window_name,focused,browser_url,device_name,full_text,text_source) VALUES(?,1,0,strftime('%Y-%m-%dT%H:%M:%fZ',?,'unixepoch'),?,?,?,1,?,?,?,'ocr')",(int(identifier[6:]),stamp,identifier,app,title,url,'Authored benchmark only',text))
assert db.execute('SELECT COUNT(*) FROM frames_fts').fetchone()==(1000,)
actual=db.execute('SELECT name,full_text FROM frames ORDER BY name COLLATE BINARY').fetchall();assert actual==[(r[0],r[5]) for r in rows]
assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and not db.execute('PRAGMA foreign_key_check').fetchall()
db.execute('PRAGMA wal_checkpoint(TRUNCATE)');db.close()
result={'rows':1000,'identicalIDTextSHA256':h.hexdigest(),'schemaInitialization':'Unmodified published Screenpipe search command initialized its normal empty database and migrations.','screenpipeIngestion':'Authored SQL rows with its installed frame/FTS triggers; not capture or API ingestion.','oswindIngestion':'Existing owned scale fixture via current MemoryStore with ordinary source/index triggers; not capture or measured ingestion.','media':'No captured or supplied images/video/audio. Both source corpora are authored text.','sourceCommit':'7c0292bac86543b4c8c58eae2a7f109b9a3ba0c3','screenpipePackage':'@screenpipe/cli-darwin-arm64@0.4.54','scope':'Offline CLI keyword-query pilot only. No service/recorder, model/semantic quality, capture, energy or product ranking claim.'}
with (root/'corpus-1000.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
