# Next public owner operation — design constraints after source 9f47c46

This is a proposal for the next implementation, not a completion receipt. Current source remains frozen during qualification. F059 remains TODO.

## Current public behavior confirmed

- PersonalSyncModel.performPairing requires session == nil before every pairing action, including explicit last-response recovery (Sources/OSwind/PersonalSyncModel.swift:160). The new original delivery lease in lastApprovedResponse does not create a new live-session UI path.
- Public PersonalSyncPairing.reviewRequest/approve still reject delivery-prepared owners. New reviewDeliveredRequest/openOwnerApprovalPreparation and SyncMembershipPreparationOwner.prepareApproval are internal only.
- PersonalSyncSession.stop is idempotent and retains a detached stopping task. It joins retirement/review/scheduler before inbox/transport/pairing close. A new review/approval task must participate in the same ownership barrier and avoid waiting for itself.
- AppModel.store is immutable. prepareForLibrarySwitch retires the model and all UI actions; cancelExternalWorkAndWait joins actual import/audio/answer/index/model/clipboard/workflow/tool/library/media work. A retired model must never be reactivated around a replaced store.
- AppSession.preparedModel currently catches initialization failure with try? store.close. That is not sufficient ownership for a failed membership store close. Existing sync-erasure reopen flow does not retain a separate operation owner and cannot be copied as-is.

## Proposed operation ownership

1. Exact live-session review carries opaque request bytes/fingerprint, owner envelope hash, group root/head, current library identity and unpredictable session generation. Expiry uses a live clock. Display only names, root/request fingerprints and expiry; no keys/protocol authority.
2. On explicit approval, reserve AppSession operation before yielding; retire the exact current AppModel, gate new work, drain actual producers. Stop/join the exact reviewed PersonalSyncSession. A review from another library/session or changed root/head refuses even if request text is identical. Normal delivery ticks/bookmark changes should not invalidate an otherwise same-session pairing-head review.
3. After stop, reacquire original pairing/delivery accounts and validate review/expiry again at intent. No new credential identity or provider access is needed. Core prepareApproval retains one exact encrypted plan; before intent cancellation remains no admission; after durable choice recovery uses the saved operation.
4. Keep the operation owner, old store and original credential ownership retained through close failure. Close must be uncancelled cleanup, observable and retryable. AppSession.pendingLock/termination/watcher/departure must join this same owner; no fresh routine store or vault detach until actual close succeeds. Tests must block/throw actual store close and assert no premature replacement/detach or lost owner.
5. On final clear, retain typed response for explicit display/copy after fresh quiet AppModel is installed. Fresh open must recover latest exact response without provider. Missing/corrupt latest refuses rather than falling back to initial. Do not automatically renew expired response or reissue already-admitted membership.
6. Reopen with startServices:false and preserve saved manual reconnect/network pause. Do not silently resume capture, processing or provider access. If cancellation/lock wins after apply, ciphertext remains durable and UI can explicitly recover later.
7. Opening an unfinished membership operation needs a distinct restricted recovery presentation, not an erase cleanup label. Recovery must not offer ordinary recording or discard the pending original-account owner. Provider absence is separately actionable after membership recovery.

## Required tests before public enablement

- Review belongs to exact session/library/root/head; same-head delivery ticks permitted; different replacement session and root/head/request swaps rejected.
- Actual held capture/import/answer/embedding/model/readers ignore cancellation until released; approval remains busy and no private intent before every owned producer/session joins.
- Actual store close failure retains owner and refuses new routine store/vault detach; explicit retry, lock, termination, move and user departure all settle the same operation.
- Existing seven Core SIGKILL phases are not UI return acceptance. Add fresh-process/app-boundary final response/reopen death checks under original accounts; keep successful Core evidence unchanged.
- Provider absent/changed, network paused/manual reconnect and late cancelled UI results leave preferences/recording quiet; explicit copy only.
- All-kind incoming/outgoing replay, no echo, stale writers and older capability handling remain required. Removal, epoch rotation, pressure/provider retention and physical two-Mac acceptance are additional F059 work.

## Additional compatibility check to add before public enablement

The optional completedApproval field is absent on legacy envelopes; older strict canonical decoders should reject an envelope that contains it. Final qualification preserves existing actual frozen native35/36 fences, but those fixtures exercise pure-proof membership handover/backfill. Before enabling the app path, add the immediately preceding format2 package as an actual fresh/cached writer against a completed-response library. Keep that executable frozen and retain both refusal/no-mutation and pending-producer evidence; do not infer this new specific acceptance from existing floor tests alone.
