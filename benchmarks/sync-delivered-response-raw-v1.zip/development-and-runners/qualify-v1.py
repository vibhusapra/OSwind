from pathlib import Path
import hashlib,json,os,platform,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/delivery-owner-response-v1';OUT=BASE/'qualification-v1';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source.startswith('9f47c46')
base='ad32c6cd938b77edf2017bb206c07d24cdd3a855'
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines();extra=['scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(ROOT/p) for p in paths if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved',*extra]) and (ROOT/p).is_file()};assert len(pins)==715
changes=subprocess.check_output(['git','diff','--name-only',base,source],text=True).splitlines();assert len(changes)==7 and all(p in pins for p in changes)
oldpins={p:hashlib.sha256(subprocess.check_output(['git','show',base+':'+p])).hexdigest() for p in pins if p not in changes};assert len(oldpins)==708 and all(pins[p]==h for p,h in oldpins.items())
# Retain the exact existing old-engine fixtures, never build or alter them.
frozen35=Path('/Users/vibhusapra/.codex/worktrees/sync-enrollment/oswind/.artifacts/keyword-startup-v1/package-v1/OSwind.app/Contents/MacOS/oswindctl');assert sha(frozen35)=='c958f555cf55c962b721f2835c5e9675d922a096bb4a4c0948f59016ec50887d'
f36path=ROOT/'.artifacts/sync-membership-floor-v1/frozen36-manifest-v2.json';f36=json.loads(f36path.read_text());f36root=Path(f36['bundle']);assert f36['executableSHA256']=='80a09cbd70547dc61b1834bd6ef2f20a5867852a9b73ab38030391d0ac7959de'
frozen={str(frozen35):sha(frozen35),str(f36path):sha(f36path),**{str(f36root/p):h for p,h in f36['files'].items()}}
def unchanged():
    assert all(sha(ROOT/p)==h for p,h in pins.items()) and all(sha(p)==h for p,h in frozen.items())
unchanged()
broad='Sync|PersonalSync|LibraryWipe|LibraryRecovery|LibraryOpening'
owned='SyncDeliveryOwnerResponseCrashTests|SyncOwnerApproval|PersonalSyncApprovedResponseTests|SyncMembership(Preparation|Floor|Backfill)|SyncDeliveryAnchorTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably'
native={'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_NATIVE35_CLI':str(frozen35),'OSWIND_TEST_NATIVE36_BUNDLE':str(f36root)}
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',broad],{}),('owned-native-tsan',['swift','test','--sanitize=thread','--skip-build','--filter',owned],native),('affected-optimized',['swift','test','-c','release','--filter',broad],{}),('owned-native-optimized',['swift','test','-c','release','--skip-build','--filter',owned],native),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(OUT/'OSwind.app')})]
manifest={'format':'OSwind durable delivered-owner response inputs v1','source':source,'baseSource':base,'inputFiles':pins,'changedInputs':changes,'unchangedBaseInputs':708,'controllerInputs':{p:sha(ROOT/p) for p in ['scripts/native-targeted-capture-soak.py','scripts/soak_process_owner.py','scripts/test-soak-process-owner.py']},'frozenFixtures':frozen,'selectors':{'broad':broad,'owned':owned},'stages':[{'name':n,'command':c,'environment':e} for n,c,e in stages],'scope':'Internal original-account approval with separately addressed encrypted response plan, final-CAS promotion and exact explicit recovery. Public enrolled-owner guard remains. No app drain/close/reopen or fullsync completion.'}
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'source':source,'baseSource':base,'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(__file__),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,command,environment in stages:
    unchanged();print('START',name,flush=True);begin=time.monotonic();log=OUT/(name+'.log')
    with log.open('xb') as f:code=subprocess.run(command,env=env|environment,stdout=f,stderr=subprocess.STDOUT).returncode
    result['stages'].append({'name':name,'command':command,'environment':environment,'exit':code,'wallSeconds':time.monotonic()-begin,'log':str(log.relative_to(ROOT)),'sha256':sha(log)})
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH',name,code,flush=True);unchanged()
    if code:raise SystemExit(code)
print('QUALIFICATION_COMPLETE',flush=True)
