from pathlib import Path
import hashlib,json,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/delivery-owner-response-v1';PACKAGE=BASE/'qualification-v1/OSwind.app';reviewPath=BASE/'qualification-v1/reviewed-v1.json';review=json.loads(reviewPath.read_text());expected=review['package']['files'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=review['sourceCommit']
archive=BASE/('OSwind-'+source[:7]+'-local-preview.zip');receipt=BASE/'preview-archive-v1.json';assert not archive.exists() and not receipt.exists()
actual={str(p.relative_to(PACKAGE)):sha(p) for p in PACKAGE.rglob('*') if p.is_file()};assert actual==expected and len(actual)==34 and not any(p.is_symlink() for p in PACKAGE.rglob('*'))
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in sorted(actual):z.write(PACKAGE/name,'OSwind.app/'+name)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(actual) and set(z.namelist())=={'OSwind.app/'+n for n in actual}
 for name,h in actual.items():assert hashlib.sha256(z.read('OSwind.app/'+name)).hexdigest()==h
 modes={name:(z.getinfo('OSwind.app/Contents/MacOS/'+name).external_attr>>16)&0o777 for name in ['OSwind','oswindctl','oswind-preparation-guardian']};assert set(modes.values())=={0o755}
result={'sourceCommit':source,'archive':str(archive),'archiveSHA256':sha(archive),'bytes':archive.stat().st_size,'exactPackageFilesVerified':len(actual),'executableModes':modes,'qualificationReviewSHA256':sha(reviewPath),'scope':'Archive of the newly qualified strict ad-hoc package; exact bytes/modes verified without launching or rerunning app/benchmarks. Public enrolled-owner approval remains disabled pending app lifecycle integration. GUI/TCC, physical sync, distribution and complete-v0 acceptance remain open.'}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'source':source,'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'verifiedFiles':len(actual)}))
