from pathlib import Path
import hashlib,json,math,re,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/delivery-owner-response-v1';OUT=BASE/'qualification-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());results=json.loads((OUT/'results.json').read_text())
assert len(inputs['inputFiles'])==715 and inputs['unchangedBaseInputs']==708 and len(inputs['changedInputs'])==7
assert results['source']==inputs['source'] and results['baseSource']==inputs['baseSource']=='ad32c6cd938b77edf2017bb206c07d24cdd3a855'
assert results['inputManifestSHA256']==sha(OUT/'inputs.json') and results['runnerSHA256']==sha(BASE/'qualify-v1.py')
assert all(sha(ROOT/p)==h for p,h in (inputs['inputFiles']|inputs['controllerInputs']).items()) and all(sha(p)==h for p,h in inputs['frozenFixtures'].items())
for p,h in inputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',inputs['source']+':'+p])).hexdigest()==h
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def cases(text):
    found=[(a+'.'+b,s) for a,b,s in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
old=cases((ROOT/'.artifacts/native-keyword-profile-v1/qualification-v1/full-debug.log').read_text());assert len(old)==2783 and list(old.values()).count('passed')==2619 and list(old.values()).count('skipped')==164
new={}
for cls,count in [('SyncDeliveryOwnerResponseTests',14),('SyncDeliveryOwnerResponseCrashTests',2)]:
    source=(ROOT/'Tests/OSwindCoreTests'/(cls+'.swift')).read_text();methods=re.findall(r'func (test\w+)\(',source)
    assert len(methods)==len(set(methods))==count
    new|={'OSwindCoreTests.'+cls+'.'+m:('skipped' if cls.endswith('CrashTests') else 'passed') for m in methods}
assert len(new)==16 and not set(new)&set(old);full=old|new
assert len(full)==2799 and list(full.values()).count('passed')==2633 and list(full.values()).count('skipped')==166
broad=inputs['selectors']['broad'];owned=inputs['selectors']['owned'];selected={k:v for k,v in full.items() if re.search(broad,k)};native={k:v for k,v in full.items() if re.search(owned,k)}
assert len(selected)==830 and list(selected.values()).count('skipped')==58 and len(native)==81
children={'OSwindCoreTests.SyncMembershipBackfillCrashTests.testOwnedMembershipBackfillCrashWorker','OSwindCoreTests.SyncOwnerApprovalCrashTests.testOwnedApprovalCrashWorker','OSwindCoreTests.SyncDeliveryOwnerResponseCrashTests.testOwnedDeliveredApprovalCrashWorker'}
native={k:('skipped' if k in children else 'passed') for k in native};assert len(set(native)&children)==3
phases=['intent','decision','pairing','delivery','commit','clear','after-response']
def inspect(text,expected):
    found=cases(text);assert found==expected
    counts={s:list(found.values()).count(s) for s in ('passed','failed','skipped')};assert counts['failed']==0 and counts['passed']>0
    skip='' if not counts['skipped'] else f", with {counts['skipped']} "+('test' if counts['skipped']==1 else 'tests')+' skipped and'
    summary=f"Executed {len(found)} tests{skip if skip else ', with'} 0 failures";assert summary in text
    assert not any(s in text for s in ('WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['))
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped')}
def death(text):
    observed=re.findall(r'OWNED_DELIVERY_APPROVAL_DEATH phase=([a-z-]+) signal=9 exactResponse=true originalAccounts=3 cleaned=true',text);assert observed==phases
    assert 'FROZEN36_FORMAT_FLOOR legacyAdmittedAndWritten=true cachedWriterFenced=true completedFormat2FreshRefused=true' in text
    assert 'FROZEN36_BACKFILL_FLOOR legacyAdmittedAndWritten=true rejectedCommitRecoveredExactToken=true' in text
    return observed
assert len(results['stages'])==len(inputs['stages'])==8
reports=[]
for stage,planned in zip(results['stages'],inputs['stages']):
    name=planned['name'];assert stage['name']==name and stage['command']==planned['command'] and stage['environment']==planned['environment'] and stage['exit']==0
    assert ROOT/stage['log']==OUT/(name+'.log') and sha(ROOT/stage['log'])==stage['sha256'] and math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ('debug-build-tests','release-build','package'):continue
    text=(ROOT/stage['log']).read_text();expected=full if name=='full-debug' else native if name.startswith('owned-') else selected
    report={'name':name,**inspect(text,expected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']}
    if name.startswith('owned-'):report['deliveredApprovalDeathPhases']=death(text)
    reports.append(report)
text=(OUT/'affected-tsan.log').read_text();method=next(k for k,v in new.items() if v=='passed').rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l);faults={}
for label,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'failed-case':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testUnexpectedIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,selected)
    except (AssertionError,KeyError):faults[label]='rejected'
    else:raise AssertionError('Accepted altered log '+label)
nativeText=(OUT/'owned-native-tsan.log').read_text();deathFaults={}
for label,bad in {'missing-death-phase':nativeText.replace('phase=clear signal=9','phase=other signal=9',1),'duplicate-death-phase':nativeText+'\nOWNED_DELIVERY_APPROVAL_DEATH phase=clear signal=9 exactResponse=true originalAccounts=3 cleaned=true','unverified-cleanup':nativeText.replace('originalAccounts=3 cleaned=true','originalAccounts=3 cleaned=false',1)}.items():
    try:death(bad)
    except AssertionError:deathFaults[label]='rejected'
    else:raise AssertionError('Accepted altered death evidence '+label)
package=OUT/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()};previous=json.loads((ROOT/'benchmarks/keyword-empty-constraints-v1.json').read_text())['qualification']['package']['files']
assert len(files)==len(previous)==34
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:assert (package/'Contents/MacOS'/name).stat().st_mode&0o777==0o755
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
result={'format':'OSwind durable delivered-owner response review v1','sourceCommit':inputs['source'],'baseSource':inputs['baseSource'],'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(BASE/'qualify-v1.py'),'reviewerSHA256':sha(__file__),'inputCount':715,'unchangedBaseInputs':708,'changedInputs':inputs['changedInputs'],'newMethodIdentities':new,'stages':reports,'alteredLogControls':faults,'alteredDeathControls':deathFaults,'package':{'files':files,'strictAdHocSignatureExit':0,'allPriorResourcesAndInfoUnchanged':True,'executableModes0755':True},'scope':inputs['scope'],'limitations':'Local software and generated original login-Keychain accounts only. Seven delivered-response Core boundaries, prior initial-response/backfill death gates and actual frozen-engine fences are independently selected; no app UI return/drain/close-retry, physical twoMac, uninterrupted24h, energy, production DP-Keychain/DeveloperID/notary/full-v0/top-three acceptance.'}
with (OUT/'reviewed-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'inputs':715,'newMethods':16,'stages':[{k:v for k,v in r.items() if k!='skippedIdentities'} for r in reports],'alteredLogs':len(faults),'alteredDeathEvidence':len(deathFaults),'reviewSHA256':sha(OUT/'reviewed-v1.json')}))
