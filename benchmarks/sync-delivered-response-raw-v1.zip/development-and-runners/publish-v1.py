from pathlib import Path
import hashlib,json,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/delivery-owner-response-v1';OUT=BASE/'qualification-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());review=json.loads((OUT/'reviewed-v1.json').read_text());source=inputs['source']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert len(review['stages'])==5 and review['reviewerSHA256']==sha(BASE/'review-v1.py') and review['inputManifestSHA256']==sha(OUT/'inputs.json')
assert len(review['alteredLogControls'])==5 and len(review['alteredDeathControls'])==3
assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
protected=subprocess.check_output(['git','ls-tree','-r','--name-only',inputs['baseSource'],'--','benchmarks'],text=True).splitlines();assert len(protected)==502
assert all(subprocess.check_output(['git','show',inputs['baseSource']+':'+p])==(ROOT/p).read_bytes() for p in protected)
files={}
for name in ['inputs.json','results.json','reviewed-v1.json','debug-build-tests.log','full-debug.log','affected-tsan.log','owned-native-tsan.log','affected-optimized.log','owned-native-optimized.log','release-build.log','package.log']:files['qualification/'+name]=OUT/name
for name in ['qualify-v1.py','review-v1.py','publish-v1.py','qualification-controller-v1.log','development-v1.log','development-v2.log','development-v3.log','development-v4.log','development-v5-native.log','development-v5-inputs-retained.json','development-v6.log','development-v7.log','next-public-owner-operation-v1.md','preceding-publications-v1.json','write-docs-v1.py','archive-preview-v1.py']:files['development-and-runners/'+name]=BASE/name
for p in inputs['changedInputs']:files['source/'+p]=ROOT/p
files['environment/host-resource-observation-v1.json']=BASE/'host-resource-observation-v1.json'
files['environment/inactive-cache-reclamation-public-v1.json']=BASE/'inactive-cache-reclamation-public-v1.json'
files['baseline/full-debug.log']=ROOT/'.artifacts/native-keyword-profile-v1/qualification-v1/full-debug.log'
files['baseline/keyword-empty-constraints-v1.json']=ROOT/'benchmarks/keyword-empty-constraints-v1.json'
v5=json.loads((BASE/'development-v5-inputs-retained.json').read_text());matches={p:sha(ROOT/p)==h for p,h in v5.items()};assert sum(matches.values())==6 and not matches['Tests/OSwindCoreTests/SyncDeliveryOwnerResponseTests.swift']
payload={n:p.read_bytes() for n,p in files.items()}
payload['README.txt']=(f'OSwind durable enrolled-owner response Core foundation source {source}.\n'
 '715 committed inputs; seven changed source/test files. Fourteen ordinary methods and two gated process methods. '
 'Final Debug full and broad TSAN/optimized suites are selected independently, plus original login-Keychain response/backfill/frozen35/36 regression gates. '
 'New actual delivered-response SIGKILL phases: intent, decision, pairing, delivery, commit, clear, after-response. Final native TSAN and optimized require all seven, exact ciphertext and original-three-account cleanup. '
 'Five altered XCTest logs and three altered death records reject. Normal production build/strict ad-hoc package verified, same bundled resources and Info.\n'
 'Development v1 failed two existing response methods due wrong database scope; v2 corrected scope passes. v3 test compile failed on private review bytes; fixture retains original request instead. v4 twelve tests pass. '
 'v5-native seven real Keychain death phases pass; its post-run source-hash record matches final five Core files and crash file, while ordinary test file later added two cases. That record is not a predeclared final-binary manifest. '
 'v6 two lifecycle checks had one fixture error: absent folder bookmark. Its apparent provider-unavailable pass was insufficient. v7 corrects both using actual public session/bookmark creation and both pass. No production guards relaxed. '
 'All failed output retained; no rerun of successful Debug-native work for metadata.\n'
 'Core API after-response is not app UI return. Public post-delivery owner review/approval stays disabled pending session-bound review, real producer drain, failed-close ownership/retry, fresh quiet AppSession reopen and UI integration. '
 'No new credential identities for response recovery, no provider required, no fallback to older initial response after latest missing/corrupt. Ciphertext expiry is unchanged. '
 'Existing Keychain threat model does not prove resistance to selective malicious private-envelope rollback. '
 'Full sync including removal/rotation/capabilities/pressure/physical twoMac, uninterrupted24h, energy, production DP-Keychain, DeveloperID/notary, fullv0 and topthree remain open. '
 'One host observation during functional qualification records roughly60GB swap and low disk headroom; it does not identify a cause or support performance inference. Only inactive generated compiler module caches and a debug index were reclaimed, with715 source/frozen fixture hashes unchanged; no model/runtime/benchmark asset was removed. Unrelated local process inventory is omitted. '
 'No database, model, credential inventory, private keys, executable or user history is included. All502 preceding benchmark publications unchanged.\n').encode()
archive=ROOT/'benchmarks/sync-delivered-response-raw-v1.zip';manifest=ROOT/'benchmarks/sync-delivered-response-inputs-v1.json';receipt=ROOT/'benchmarks/sync-delivered-response-v1.json';assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x') as f:json.dump(inputs,f,indent=2);f.write('\n')
result=review|{'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(OUT/'reviewed-v1.json'),'publisherSHA256':sha(__file__),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest() for n,b in payload.items()},'allArchivedBytesCompared':True},'developmentNativeSourceMatches':matches,'priorBenchmarkFilesUnchanged':502}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'source':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'members':len(payload),'precedingPublicationsUnchanged':502}))
