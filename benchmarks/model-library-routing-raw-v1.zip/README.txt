OSwind endpoint-aware model library runtime 312860874b2b84a357bf41e3df0e2a585eed947a.
706 committed inputs; 701 of 703 preceding inputs unchanged; five changed/new source/test files; ten new methods. Exact full Debug / affected TSan / optimized method identities and states reviewed; five altered-log controls.

Explicit answer/search endpoints with two owned loopback HTTP servers, inert tags/ps/pull responses and existing-server detection. No model weights or inference. Task cancellation retains ownership until exit and participates in app retirement/drain. Existing LocalModelServer child-process settlement is not newly qualified.

The development compile failure (missing try in a new test) is retained. The passing development HTTP source precedes a small helper weak-capture/bounds adjustment. Development logs also precede the final early app-drain cancellation wiring. The final source is qualified by the formal stages, not substituted by development counts. Fresh production package passes strict ad-hoc verification; prior resources and bundle information remain unchanged.

No executables, user history or keys included. Earlier frozen quality/performance publications remain untouched. GUI/TCC and older-Mac acceptance, complete sync, physical 24-hour capture and power, signed/notarized distribution, full v0 completion and top-three acceptance remain open. All 83 feature statuses are unchanged.
