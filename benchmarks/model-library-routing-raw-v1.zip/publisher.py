from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/model-library-routing-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text())
assert review['reviewerSHA256']==sha(base/'review-v1.py')and review['inputManifestSHA256']==sha(run/'inputs.json')
assert len(review['alteredLogControls'])==5 and len(review['newMethodIdentities'])==10
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges'])
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputs['inputFiles'].items():
    p=root/path;b=os.readlink(p).encode()if p.is_symlink()else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2];protected[path.decode()]=hashlib.sha256(b).hexdigest()
files={'qualification/inputs.json':run/'inputs.json','qualification/results.json':run/'results.json','qualification/review.json':reviewPath,'qualification/runner.py':base/'qualify-v1.py','qualification/reviewer.py':base/'review-v1.py','publisher.py':Path(__file__),'development/compile-failure-v1.log':base/'development-v1.log','development/controlled-tests-v2.log':base/'development-v2.log','development/http-tests-v1.log':base/'http-development-v1.log','development/http-tests-source-v1.swift':base/'http-development-source-v1.swift'}
for stage in json.loads((run/'results.json').read_text())['stages']:
    p=root/stage['log'];assert stage['exit']==0 and sha(p)==stage['sha256'];files['qualification/logs/'+stage['name']+'.log']=p
for path in inputs['workingChanges']:files['source/'+path]=root/path
payload={n:p.read_bytes()for n,p in files.items()}
payload['README.txt']=(
    f'OSwind endpoint-aware model library runtime {source}.\n'
    '706 committed inputs; 701 of 703 preceding inputs unchanged; five changed/new source/test files; ten new methods. '
    'Exact full Debug / affected TSan / optimized method identities and states reviewed; five altered-log controls.\n\n'
    'Explicit answer/search endpoints with two owned loopback HTTP servers, inert tags/ps/pull responses and existing-server detection. '
    'No model weights or inference. Task cancellation retains ownership until exit and participates in app retirement/drain. '
    'Existing LocalModelServer child-process settlement is not newly qualified.\n\n'
    'The development compile failure (missing try in a new test) is retained. The passing development HTTP source precedes '
    'a small helper weak-capture/bounds adjustment. Development logs also precede the final early app-drain cancellation wiring. '
    'The final source is qualified by the formal stages, not substituted by development counts. '
    'Fresh production package passes strict ad-hoc verification; prior resources and bundle information remain unchanged.\n\n'
    'No executables, user history or keys included. Earlier frozen quality/performance publications remain untouched. '
    'GUI/TCC and older-Mac acceptance, complete sync, physical 24-hour capture and power, signed/notarized distribution, '
    'full v0 completion and top-three acceptance remain open. All 83 feature statuses are unchanged.\n'
).encode()
archive=root/'benchmarks/model-library-routing-raw-v1.zip';manifest=root/'benchmarks/model-library-routing-inputs-v1.json';receipt=root/'benchmarks/model-library-routing-v1.json';assert all(not p.exists()for p in[archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive)as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload)and set(z.namelist())==set(payload)and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x')as f:json.dump({**inputs,'sourceCommit':source},f,indent=2);f.write('\n')
result={**review,'sourceCommit':source,'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())}},'priorProtectedFiles':protected}
with receipt.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'sourceCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
