from pathlib import Path
import hashlib,json,os,platform,re,subprocess,time

root=Path.cwd();base=root/'.artifacts/model-library-routing-v1';out=base/'qualification-v1';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='56326dc30ad4b4c6fa867fd69b1746cf175ddc5d'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();extra=['scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(root/p)for p in sorted(set(paths+extra))if(p.startswith(('Sources/','Tests/','Vendor/','vendor/'))or p in ['Package.swift','Package.resolved',*extra])and(root/p).is_file()}
prior=json.loads((root/'benchmarks/local-model-presets-inputs-v1.json').read_text())['inputFiles'];assert len(pins)==706 and len(prior)==703 and sum(pins[p]==h for p,h in prior.items())==701
changed=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())&set(pins));assert len(changed)==5
methods=[]
for name in ['LocalModelLibraryTests','LocalModelLibraryHTTPTests']:
    methods += ['OSwindAppTests.'+name+'.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests/OSwindAppTests'/(name+'.swift')).read_text())]
assert len(methods)==len(set(methods))==10
manifest={'format':'OSwind endpoint-aware model library qualification inputs v1','baseSource':head,'inputFiles':pins,'unchangedPriorInputs':701,'workingChanges':{p:pins[p]for p in changed},'newMethodIdentities':sorted(methods),'scope':'Explicit answer/search destination for discovery/start/pull; endpoint-specific installed lists, configuration/operation fenced inspection success/error, telemetry failure retains list, admitted pull name/endpoint immutable, cancellation owns task until exit, retirement and external-work drain. No settings format/model defaults/prompts/embedding/capture/crypto changes. Actual two-owned-loopback-server test uses inert tags/ps/pull responses and existing-server startup check, no model weights or inference. App task joining is not new proof of LocalModelServer child-process settlement. Frozen earlier comparisons/packages untouched.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
focused='LocalModelLibraryTests|LocalModelLibraryHTTPTests|SemanticIndexTests|PrivacyAndIntegrationTests|LibraryOpeningTests|LibraryRecoveryTransferTests|RetiredLibraryActionTests|VaultSessionTests|SourceWorkSessionTests|LibraryWipeModelTests|WorkspaceWakeLifecycleTests|SearchIndexLifecycleTests'
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items()if not k.startswith('OSWIND_TEST_')}
for name,command,environment in stages:
    assert all(sha(root/p)==h for p,h in pins.items());print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb')as f:rc=subprocess.run(command,env={**env,**environment},stdout=f,stderr=subprocess.STDOUT).returncode
    results['stages'].append({'name':name,'command':command,'environment':environment,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in pins.items())
    if rc:raise SystemExit(rc)
print('QUALIFICATION_COMPLETE',flush=True)
