from pathlib import Path
import hashlib,json,math,re,subprocess

root=Path.cwd();base=root/'.artifacts/model-library-routing-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());result=json.loads((run/'results.json').read_text())
assert inputs['baseSource']==result['baseSource']=='56326dc30ad4b4c6fa867fd69b1746cf175ddc5d'
assert len(inputs['inputFiles'])==706 and len(inputs['workingChanges'])==5 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
prior=json.loads((root/'benchmarks/local-model-presets-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==703 and sum(inputs['inputFiles'][p]==h for p,h in prior.items())==701
assert result['inputManifestSHA256']==sha(run/'inputs.json')and result['runnerSHA256']==sha(base/'qualify-v1.py')
new=[]
for name in ['LocalModelLibraryTests','LocalModelLibraryHTTPTests']:
    new += ['OSwindAppTests.'+name+'.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests/OSwindAppTests'/(name+'.swift')).read_text())]
assert len(new)==len(set(new))==10 and sorted(new)==inputs['newMethodIdentities']
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def rows(text):
    found=[(a+'.'+b,c)for a,b,c in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
def inspect(text,expected):
    found=rows(text);assert found==expected;counts={k:list(found.values()).count(k)for k in ['passed','failed','skipped']};assert counts['failed']==0 and counts['passed']>0
    summary=f"Executed {len(found)} tests, with {counts['skipped']} tests skipped and 0 failures"
    if counts['skipped']==1:summary=f'Executed {len(found)} tests, with 1 test skipped and 0 failures'
    if counts['skipped']==0:summary=f'Executed {len(found)} tests, with 0 failures'
    assert summary in text and not any(s in text for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items()if v=='skipped')}
old=rows((root/'.artifacts/local-model-presets-v1/qualification-v1/full-debug.log').read_text());assert len(old)==2743 and not(set(old)&set(new))
full={**old,**{k:'passed'for k in new}};assert len(full)==2753 and list(full.values()).count('passed')==2591 and list(full.values()).count('skipped')==162
focused='LocalModelLibraryTests|LocalModelLibraryHTTPTests|SemanticIndexTests|PrivacyAndIntegrationTests|LibraryOpeningTests|LibraryRecoveryTransferTests|RetiredLibraryActionTests|VaultSessionTests|SourceWorkSessionTests|LibraryWipeModelTests|WorkspaceWakeLifecycleTests|SearchIndexLifecycleTests'
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(run/'OSwind.app')})]
assert len(result['stages'])==len(stages)
reports=[];selected={k:v for k,v in full.items()if re.search(focused,k)};assert set(new)<=set(selected)
for stage,(name,command,environment)in zip(result['stages'],stages):
    assert stage['name']==name and stage['command']==command and stage['environment']==environment and stage['exit']==0
    assert root/stage['log']==run/(name+'.log')and sha(root/stage['log'])==stage['sha256']and math.isfinite(stage['wallSeconds'])and stage['wallSeconds']>=0
    if name in ['full-debug','affected-tsan','affected-optimized']:
        reports.append({'mode':name,**inspect((root/stage['log']).read_text(),full if name=='full-debug'else selected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']})
text=(run/'affected-tsan.log').read_text();identity=new[0];method=identity.rsplit('.',1)[1];line=next(l for l in text.splitlines()if method in l and "' passed"in l);faults={}
for name,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'hidden-failure':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testWrongIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,selected)
    except(AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p)for p in package.rglob('*')if p.is_file()}
previous=json.loads((root/'benchmarks/local-model-presets-v1.json').read_text())['newPackage']['files']
assert{p:h for p,h in files.items()if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items()if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
review={'format':'OSwind endpoint-aware local model library qualification review v1','baseSource':inputs['baseSource'],'inputCount':706,'unchangedPriorInputs':701,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':result['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'newMethodIdentities':sorted(new),'stages':reports,'alteredLogControls':faults,'newPackage':{'path':str(package),'files':files,'strictAdHocSignatureExit':signature.returncode,'allPriorResourcesAndBundleInfoUnchanged':True},'scope':inputs['scope'],'limitations':'Controlled operations and two inert actual loopback HTTP servers, no weights downloaded or inference. Existing-server detection does not prove new process startup/exit settlement. GUI clicks/TCC/olderMac remain unqualified. No repeat of earlier frozen quality/performance runs. Full sync, physical24h/power, signed/notarized distribution, fullv0 and topthree acceptance remain open; all83 feature statuses unchanged.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'inputCount':706,'stages':[{k:r[k]for k in ['mode','defined','passed','failed','skipped']}for r in reports],'newMethods':10,'alteredControls':len(faults),'reviewSHA256':sha(out)}))
