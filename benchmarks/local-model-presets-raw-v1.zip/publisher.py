from pathlib import Path
import hashlib
import json
import os
import subprocess
import zipfile

root = Path.cwd()
base = root / '.artifacts/local-model-presets-v1'
run = base / 'qualification-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = json.loads((run / 'inputs.json').read_text())
review_path = run / 'reviewed-v1.json'
review = json.loads(review_path.read_text())
assert review['reviewerSHA256'] == sha(base / 'review-v1.py')
assert review['inputManifestSHA256'] == sha(run / 'inputs.json')
assert len(review['alteredLogControls']) == 5
assert len(review['newPythonMethodIdentities']) == 3
assert review['packagedDefaultProbe']['joined']
assert len(inputs['inputFiles']) == 703
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^'], text=True).strip() == inputs['baseSource']
changed = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD'], text=True).splitlines()
assert set(changed) == set(inputs['workingChanges']) and len(changed) == 5
tree = {}
for item in subprocess.check_output(['git', 'ls-tree', '-r', '-z', source]).split(b'\0'):
    if item:
        header, path = item.split(b'\t', 1)
        tree[path.decode()] = header.decode().split()[2]
for path, expected in inputs['inputFiles'].items():
    p = root / path
    data = os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected
    assert tree[path] == hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
protected = {}
for item in subprocess.check_output(['git', 'ls-tree', '-r', '-z', inputs['baseSource'], '--', 'benchmarks', 'docs/features.json', 'docs/landscape.html']).split(b'\0'):
    if item:
        header, path = item.split(b'\t', 1)
        data = (root / path.decode()).read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == header.decode().split()[2]
        protected[path.decode()] = hashlib.sha256(data).hexdigest()
comparison_names = ['local-model-comparison-v1.json', 'local-model-comparison-inputs-v1.json', 'local-model-comparison-raw-v1.zip', 'fixtures/answer-model-extension-v1.json']
comparison_files = {str(Path('benchmarks') / name): sha(root / 'benchmarks' / name) for name in comparison_names}
comparison = json.loads((root / 'benchmarks/local-model-comparison-v1.json').read_text())
assert comparison['rawEvidence']['sha256'] == comparison_files['benchmarks/local-model-comparison-raw-v1.zip']
assert comparison['reviewSHA256'] == '568a7505c3b95e6ab2da2847f95ffa33389709064760540945d4d8f2cf018554'
files = {
    'qualification/inputs.json': run / 'inputs.json',
    'qualification/results.json': run / 'results.json',
    'qualification/review.json': review_path,
    'qualification/runner.py': base / 'qualify-v1.py',
    'qualification/reviewer.py': base / 'review-v1.py',
    'qualification/probe.py': base / 'probe-packaged-default-v1.py',
    'publisher.py': Path(__file__),
    'offline/setup-controls.log': base / 'setup-controls-v1.log',
    'offline/old-setup-controls.log': base / 'old-setup-controls-v1.log',
    'offline/old-setup-models.sh': base / 'old-setup-models.sh',
}
for stage in json.loads((run / 'results.json').read_text())['stages']:
    p = root / stage['log']
    assert stage['exit'] == 0 and sha(p) == stage['sha256']
    files['qualification/logs/' + stage['name'] + '.log'] = p
probe_root = run / 'packaged-default-v1'
assert sha(probe_root / 'report.json') == review['packagedDefaultProbe']['reportSHA256']
files['packaged-default/report.json'] = probe_root / 'report.json'
probe = json.loads((probe_root / 'report.json').read_text())
for command in probe['commands']:
    for kind in ['stdout', 'stderr']:
        p = probe_root / command[kind]
        assert p.parent == probe_root and sha(p) == command[kind + 'SHA256']
        files['packaged-default/' + p.name] = p
for path in inputs['workingChanges']:
    files['source/' + path] = root / path
payload = {name: path.read_bytes() for name, path in files.items()}
payload['README.txt'] = (
    f'OSwind local chat preset wiring runtime {source}.703 committed source/test/dependency/setup/CI inputs;698 of700 prior runtime inputs unchanged. '
    'Five source/setup/CI files changed. FullDebug and focused TSan/optimized exact identities reviewed;3 offline setup controls pass and all3 fail against original script under an inert remote-host fixture. '
    'Two actual fresh packaged CLI local requests verify omitted-model default Qwen3.5 and retained explicit old Qwen setting, exact fictional source identity, unchanged settings bytes, absent Authorization, owned loopback proxy joined. '
    'No new Swift tests or prompt/generation/embedding/schema changes; no GUI click/TCC/olderMac acceptance. '
    'Separate96-attempt earlier-runtime model comparison is frozen and referenced by hash; it was not rerun for this patch. '
    'No model weights, executable, user history or credentials included. Full sync, physical capture/power, production distribution, fullv0 and topthree acceptance remain open. All83 feature statuses unchanged.\n'
).encode()
archive = root / 'benchmarks/local-model-presets-raw-v1.zip'
manifest = root / 'benchmarks/local-model-presets-inputs-v1.json'
receipt = root / 'benchmarks/local-model-presets-v1.json'
assert all(not p.exists() for p in [archive, manifest, receipt])
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payload.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(payload)
    assert set(z.namelist()) == set(payload)
    assert all(z.read(name) == data for name, data in payload.items())
with manifest.open('x') as f:
    json.dump({**inputs, 'sourceCommit': source}, f, indent=2)
    f.write('\n')
result = {
    **review, 'sourceCommit': source, 'allCommittedInputBlobsMatch': True,
    'publishedInputs': {'file': manifest.name, 'sha256': sha(manifest)},
    'reviewSHA256': sha(review_path), 'publisherSHA256': sha(Path(__file__)),
    'rawEvidence': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(payload.items())}},
    'separateFrozenModelComparison': comparison_files, 'priorProtectedFiles': protected,
}
with receipt.open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps({'sourceCommit': source, 'rawSHA256': sha(archive), 'rawBytes': archive.stat().st_size, 'rawMembers': len(payload), 'protectedBaseFiles': len(protected)}))
