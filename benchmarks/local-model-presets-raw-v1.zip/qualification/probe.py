from pathlib import Path
import argparse,hashlib,http.client,http.server,json,os,sqlite3,subprocess,threading,time

parser=argparse.ArgumentParser();parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
binary=args.binary.resolve();out=args.output.resolve();out.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binarySHA=sha(binary)
lock=threading.Lock();finished=threading.Condition(lock);wire=[];phase={'case':None};expected={'fresh':'qwen3.5:4b','legacy':'qwen3:4b-instruct-2507-q4_K_M'}
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):self.forward()
    def do_POST(self):self.forward()
    def forward(self):
        with lock:case=phase['case']
        if(self.command,self.path)not in[('GET','/api/tags'),('POST','/api/chat')]:self.send_error(404);return
        size=int(self.headers.get('Content-Length','0'));assert 0<=size<=1_000_000 and self.headers.get('Authorization')is None
        data=self.rfile.read(size);record={'case':case,'method':self.command,'path':self.path,'authorizationAbsent':True,'requestBytes':len(data)}
        if self.command=='POST':
            payload=json.loads(data);record['model']=payload['model'];record['requestBodySHA256']=hashlib.sha256(data).hexdigest();assert payload['model']==expected[case]
        connection=http.client.HTTPConnection('127.0.0.1',11434,timeout=150)
        try:
            connection.request(self.command,self.path,body=data if size else None,headers={'Content-Type':'application/json'});response=connection.getresponse();body=response.read()
            record.update(status=response.status,responseBytes=len(body),responseSHA256=hashlib.sha256(body).hexdigest());self.send_response(response.status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
        finally:
            connection.close()
            with finished:wire.append(record);finished.notify_all()
class Server(http.server.ThreadingHTTPServer):daemon_threads=False
server=Server(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start();endpoint='http://127.0.0.1:'+str(server.server_port)
env={k:v for k,v in os.environ.items()if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))};report={'state':'running','binary':str(binary),'binarySHA256':binarySHA,'scope':'Two actual packaged CLI local-model requests through an owned loopback recorder forwarding only tags/chat to existing127.0.0.1:11434. Fresh configuration selectsnewcompactdefault; persistedexplicitoldmodelpreserved. Fictional one-note libraries only. No paidprovider/keychain/cloud calls, weights download or oldbenchmark repeat.','cases':[]}
def save():
    p=out/'report.json';p.write_text(json.dumps(report,indent=2)+'\n');p.chmod(0o600)
def command(name,library,arguments):
    assert sha(binary)==binarySHA;stdout=out/(name+'.stdout');stderr=out/(name+'.stderr');start=time.monotonic()
    with stdout.open('xb')as o,stderr.open('xb')as e:r=subprocess.run([str(binary),'--data',str(library),*arguments],env=env,stdout=o,stderr=e,timeout=240)
    row={'name':name,'exit':r.returncode,'stdout':stdout.name,'stderr':stderr.name,'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr),'wallSeconds':time.monotonic()-start};report.setdefault('commands',[]).append(row);save();assert r.returncode==0,stderr.read_text()
    return stdout.read_text()
try:
    for case in ['fresh','legacy']:
        library=out/(case+'-library');library.mkdir(mode=0o700)
        settings={'captureOnLaunch':False,'automaticMaintenance':False,'apiEnabled':False,'routinesEnabled':False,'search':{'provider':'apple','indexPolicy':'exact'}}
        if case=='legacy':settings['ai']={'provider':'ollama','endpoint':'http://127.0.0.1:11434','model':expected[case],'allowRemote':False}
        settingsPath=library/'settings.json';settingsPath.write_text(json.dumps(settings)+'\n');settingsPath.chmod(0o600);settingsSHA=sha(settingsPath)
        text='Owned default-routing fixture: Nelia owns Vega export. This fictional note contains no actual user history.'
        identifier=command(case+'-seed',library,['note',text]).strip()
        with lock:phase['case']=case
        answer=json.loads(command(case+'-ask',library,['ask','--literal','--provider','ollama','--endpoint',endpoint,'Who owns Vega export?']))
        assert answer['provider']=='ollama'and answer['text'].strip()and len(answer['sources'])==1
        memory=answer['sources'][0]['memory'];assert memory['id']==identifier and memory['text']==text
        db=sqlite3.connect('file:'+str(library/'memory.sqlite')+'?mode=ro',uri=True)
        try:rows=db.execute('SELECT id,payload FROM memories').fetchall();assert len(rows)==1 and rows[0][0]==identifier and json.loads(rows[0][1])['text']==text
        finally:db.close()
        assert sha(settingsPath)==settingsSHA
        with finished:
            assert finished.wait_for(lambda:any(r['case']==case and r['method']=='POST'for r in wire),timeout=5)
            posts=[r for r in wire if r['case']==case and r['method']=='POST']
        assert len(posts)==1 and posts[0]['model']==expected[case]and posts[0]['status']==200 and posts[0]['authorizationAbsent']
        report['cases'].append({'case':case,'observedModel':posts[0]['model'],'responseProvider':answer['provider'],'responseText':answer['text'],'sourceIdentityAndStoredTextMatch':True,'settingsBytesUnchanged':True,'authorizationAbsent':True});save();print('PACKAGED_DEFAULT '+case+' model='+posts[0]['model']+' response=true source=true settingsUnchanged=true',flush=True)
    assert sha(binary)==binarySHA
    report['state']='completed';report['wire']=wire;save()
except BaseException as error:
    report.update(state='failed',error=str(error),wire=wire);save();raise
finally:
    server.shutdown();server.server_close();thread.join();print('OWNED_PROXY_JOINED',flush=True)
