from pathlib import Path
import hashlib,json,os,platform,re,subprocess,time

root=Path.cwd();base=root/'.artifacts/local-model-presets-v1';out=base/'qualification-v1';out.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='f9f12bcbf5287fc5f9e0bfce26f061988eaedec4'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();extra=['scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(root/p)for p in sorted(set(paths+extra))if(p.startswith(('Sources/','Tests/','Vendor/','vendor/'))or p in ['Package.swift','Package.resolved',*extra])and(root/p).is_file()}
assert len(pins)==703
changed=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())&set(pins));assert len(changed)==5
prior=json.loads((root/'benchmarks/local-model-comparison-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==700 and sum(pins[p]==h for p,h in prior.items())==698
offline=base/'setup-controls-v1.log';old=base/'old-setup-controls-v1.log'
assert 'Ran 3 tests' in offline.read_text()and offline.read_text().rstrip().endswith('OK')
assert 'Ran 3 tests' in old.read_text()and old.read_text().rstrip().endswith('FAILED (failures=3)')
adopted={'scope':'Three offline setup controls were completed at these unchanged setup/test source bytes before the formal build runner; no successful controls are rerun just for metadata. Earlier source control fails3/3 under the same inert tools/remote-host fixture; both logs retained. No installer/network/inference ran in these controls.','sourceSHA256':{p:pins[p]for p in extra[:2]},'passingLogSHA256':sha(offline),'oldFailingLogSHA256':sha(old),'oldSetupSHA256':sha(base/'old-setup-models.sh'),'passing':3,'oldFailures':3}
probe=base/'probe-packaged-default-v1.py'
manifest={'format':'OSwind local model preset qualification inputs v1','baseSource':head,'inputFiles':pins,'workingChanges':{p:pins[p]for p in changed},'additionalSetupInputs':extra,'adoptedOfflineControls':adopted,'probeSHA256':sha(probe),'scope':'CompactQwen3.5/newlargerGemma preset names and setup loopback/default wiring only. Model/answer96-request comparison predates changes at runtime49f and is separately frozen. Existing saved model preserved; prompts/answer schema/embedding models unchanged.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
focused='PrivacyAndIntegrationTests|ConversationTests|ChatAdmissionTests|RecapTests|RecapModelTests|RoutineTests|RoutinesModelTests|QueryScopeIntegrationTests|MeetingRequestTests|MeetingEvidencePolicyTests|EvidenceTextTests|SpeakerEvidenceTests|SearchPreviewTests|LocalRuntimeLiveTests'
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')}),('packaged-default',['python3',str(probe),'--binary',str(out/'OSwind.app/Contents/MacOS/oswindctl'),'--output',str(out/'packaged-default-v1')],{})]
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items()if not k.startswith('OSWIND_TEST_')}
for name,command,environment in stages:
    assert all(sha(root/p)==h for p,h in pins.items())and sha(probe)==manifest['probeSHA256'];print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb')as f:rc=subprocess.run(command,env={**env,**environment},stdout=f,stderr=subprocess.STDOUT).returncode
    results['stages'].append({'name':name,'command':command,'environment':environment,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in pins.items())and sha(probe)==manifest['probeSHA256']
    if rc:raise SystemExit(rc)
print('QUALIFICATION_COMPLETE',flush=True)
