from pathlib import Path
import hashlib,json,math,re,subprocess

root=Path.cwd();base=root/'.artifacts/local-model-presets-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());result=json.loads((run/'results.json').read_text())
assert len(inputs['inputFiles'])==703 and len(inputs['workingChanges'])==5 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert inputs['baseSource']==result['baseSource']=='f9f12bcbf5287fc5f9e0bfce26f061988eaedec4'
assert result['inputManifestSHA256']==sha(run/'inputs.json')and result['runnerSHA256']==sha(base/'qualify-v1.py')and inputs['probeSHA256']==sha(base/'probe-packaged-default-v1.py')
prior=json.loads((root/'benchmarks/local-model-comparison-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==700 and sum(inputs['inputFiles'][p]==h for p,h in prior.items())==698
offline=inputs['adoptedOfflineControls'];assert offline['passing']==offline['oldFailures']==3
assert all(sha(root/p)==h for p,h in offline['sourceSHA256'].items())
assert sha(base/'setup-controls-v1.log')==offline['passingLogSHA256']and sha(base/'old-setup-controls-v1.log')==offline['oldFailingLogSHA256']and sha(base/'old-setup-models.sh')==offline['oldSetupSHA256']
assert hashlib.sha256(subprocess.check_output(['git','show',inputs['baseSource']+':scripts/setup-models.sh'])).hexdigest()==offline['oldSetupSHA256']
methods=re.findall(r'def (test\w+)\(', (root/'scripts/test-setup-models.py').read_text());assert len(methods)==3
text=(base/'setup-controls-v1.log').read_text();assert all(re.search(r'^'+m+r' .* \.\.\. ok$',text,re.M)for m in methods)and text.rstrip().endswith('OK')
assert(base/'old-setup-controls-v1.log').read_text().rstrip().endswith('FAILED (failures=3)')
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def rows(text):
    found=[(a+'.'+b,c)for a,b,c in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
def inspect(text,expected):
    found=rows(text);assert found==expected;counts={k:list(found.values()).count(k)for k in ['passed','failed','skipped']};assert counts['failed']==0 and counts['passed']>0
    summary=f"Executed {len(found)} tests, with {counts['skipped']} tests skipped and 0 failures"
    if counts['skipped']==1:summary=f'Executed {len(found)} tests, with 1 test skipped and 0 failures'
    if counts['skipped']==0:summary=f'Executed {len(found)} tests, with 0 failures'
    assert summary in text and not any(s in text for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items()if v=='skipped')}
full=rows((run/'full-debug.log').read_text());oldFull=rows((root/'.artifacts/storage-setup-recovery-v1/qualification-v1/full-debug.log').read_text())
assert full==oldFull and len(full)==2743 and list(full.values()).count('passed')==2581 and list(full.values()).count('skipped')==162
focused='PrivacyAndIntegrationTests|ConversationTests|ChatAdmissionTests|RecapTests|RecapModelTests|RoutineTests|RoutinesModelTests|QueryScopeIntegrationTests|MeetingRequestTests|MeetingEvidencePolicyTests|EvidenceTextTests|SpeakerEvidenceTests|SearchPreviewTests|LocalRuntimeLiveTests'
expectedStages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(run/'OSwind.app')}),('packaged-default',['python3',str(base/'probe-packaged-default-v1.py'),'--binary',str(run/'OSwind.app/Contents/MacOS/oswindctl'),'--output',str(run/'packaged-default-v1')],{})]
assert[s['name']for s in result['stages']]==[s[0]for s in expectedStages]
reports=[];selections={}
for stage,(name,command,environment)in zip(result['stages'],expectedStages):
    assert stage['command']==command and stage['environment']==environment and stage['exit']==0 and root/stage['log']==run/(name+'.log')and sha(root/stage['log'])==stage['sha256']
    assert math.isfinite(stage['wallSeconds'])and stage['wallSeconds']>=0
    if name not in ['full-debug','affected-tsan','affected-optimized']:continue
    expected=full if name=='full-debug'else{k:v for k,v in full.items()if re.search(focused,k)}
    reports.append({'mode':name,**inspect((root/stage['log']).read_text(),expected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']});selections[name]=expected
assert selections['affected-tsan']==selections['affected-optimized']
text=(run/'affected-tsan.log').read_text();reference=selections['affected-tsan'];identity=next(k for k,v in reference.items()if v=='passed');method=identity.rsplit('.',1)[1];line=next(l for l in text.splitlines()if method in l and "' passed"in l);faults={}
for name,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'hidden-failure':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testWrongIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,reference)
    except(AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p)for p in package.rglob('*')if p.is_file()}
priorPackage=json.loads((root/'benchmarks/storage-setup-recovery-v1.json').read_text())['newPackage']['files']
assert{p:h for p,h in files.items()if p.startswith('Contents/Resources/')}=={p:h for p,h in priorPackage.items()if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==priorPackage['Contents/Info.plist']
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
probeRoot=run/'packaged-default-v1';probe=json.loads((probeRoot/'report.json').read_text());assert probe['state']=='completed'and probe['binarySHA256']==files['Contents/MacOS/oswindctl']
assert len(probe['cases'])==2 and[(c['case'],c['observedModel'])for c in probe['cases']]==[('fresh','qwen3.5:4b'),('legacy','qwen3:4b-instruct-2507-q4_K_M')]
assert all(c['sourceIdentityAndStoredTextMatch']and c['settingsBytesUnchanged']and c['authorizationAbsent']and c['responseProvider']=='ollama'for c in probe['cases'])
assert len(probe['commands'])==4 and all(c['exit']==0 for c in probe['commands'])
for c in probe['commands']:
    for kind in ['stdout','stderr']:assert sha(probeRoot/c[kind])==c[kind+'SHA256']
posts=[r for r in probe['wire']if r['method']=='POST'];assert len(posts)==2 and all(r['path']=='/api/chat'and r['status']==200 and r['authorizationAbsent']for r in posts)
assert all(r['path']in ['/api/tags','/api/chat']and r['status']==200 and r['authorizationAbsent']for r in probe['wire'])
assert 'OWNED_PROXY_JOINED'in(run/'packaged-default.log').read_text()
review={'format':'OSwind local chat preset wiring qualification review v1','baseSource':inputs['baseSource'],'inputCount':703,'unchangedPriorRuntimeInputs':698,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':result['runnerSHA256'],'probeSHA256':inputs['probeSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':reports,'adoptedOfflineSetupControls':offline,'newPythonMethodIdentities':methods,'alteredLogControls':faults,'packagedDefaultProbe':{'reportSHA256':sha(probeRoot/'report.json'),'cases':probe['cases'],'wire':probe['wire'],'joined':True},'newPackage':{'path':str(package),'files':files,'strictAdHocSignatureExit':signature.returncode,'allPriorResourcesAndBundleInfoUnchanged':True},'scope':'NewsetupcompactQwen3.5/largerGemma presetwiring; existingserializedmodelchoicespreserved; shellserve/pullforcedloopbackdespiteambientremotehost. FullDebug plusaffectedTSan/optimized,3adoptedofflinecontrols and2actualpackagedCLIrequests throughownedloopbackforwarder,source/settings/header/modelrouteidentity. No prompt/generation/embedding/schema change. Separate96attempt comparison uses earlierunchanged49f runtime and remainsfrozen; no fullnewmodelqualityrerun implied. No GUIclick/TCC/olderMac, physical24h/power/fullsync, notarizeddistribution, completev0 or topthreeclaim. All83statusesunchanged.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'inputCount':703,'stages':[{k:r[k]for k in ['mode','defined','passed','failed','skipped']}for r in reports],'offlineControls':3,'packagedCases':2,'alteredControls':len(faults),'reviewSHA256':sha(out)}))
