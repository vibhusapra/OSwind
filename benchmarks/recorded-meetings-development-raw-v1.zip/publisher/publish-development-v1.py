from pathlib import Path
import hashlib,json,re,subprocess,zipfile,shutil
ROOT=Path.cwd();BASE=ROOT/'.artifacts/meeting-sessions-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review3=json.loads((BASE/'ui-development-review-v3.json').read_text());review4=json.loads((BASE/'ui-development-review-v4.json').read_text());assert review3['UIQualificationPassed'] and review4['allEightExactImagesVisuallyReviewed']
v3=json.loads((BASE/'development-v3/result.json').read_text());v4=json.loads((BASE/'development-v4/result.json').read_text());assert v3['exit']==v4['exit']==0
for result,name in [(v3,'native-core-app-and-ui-v3.log'),(v4,'setup-refusal-ui-v4.log')]:assert result['logSHA256']==sha(BASE/name)
text=(BASE/'native-core-app-and-ui-v3.log').read_text();assert len(re.findall(r'Executed 17 tests, with 0 failures \(0 unexpected\)',text))==2 and 'OWNED_NATIVE_PUBLIC_THREE_DEVICE originalAccountIDsPreserved=true originalPrivateFieldsPreserved=true' in text
for version,commit in [('v3','c1086996976d8d5c43a382c6be7987aae13736a5'),('v4',subprocess.check_output(['git','rev-parse','c2726e2'],text=True).strip())]:
 inputs=json.loads((BASE/('development-'+version)/'inputs.json').read_text())
 for p,h in inputs['inputFiles'].items():assert hashlib.sha256(subprocess.check_output(['git','show',commit+':'+p])).hexdigest()==h
current=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();expected=json.loads((BASE/'development-v4/inputs.json').read_text());different=[p for p,h in expected['inputFiles'].items() if sha(ROOT/p)!=h];assert different==['Tests/OSwindAppTests/OwnerAdditionAppSessionTests.swift']
files={}
for p in BASE.iterdir():
 if p.is_file() and p.suffix in ('.log','.json') and p.name!='checkout-reuse-v1.json':files['development/'+p.name]=p
for d in BASE.glob('development-v*'):
 for p in d.rglob('*'):
  if p.is_file():files['development/'+str(p.relative_to(BASE))]=p
for d in BASE.glob('ui-development-v*'):
 if d.is_dir():
  for p in d.glob('*.png'):files['renders/'+d.name+'/'+p.name]=p
files['publisher/publish-development-v1.py']=Path(__file__)
changed=subprocess.check_output(['git','diff','--name-only','codex/peer-membership-update',current],text=True).splitlines();assert len(changed)==11
for p in changed:files['source/'+p]=ROOT/p
payload={n:p.read_bytes() for n,p in files.items()};payload['README.txt']=b'OSwind recorded meeting workspace development.17selected native Debug methods passed at c108699, including16new methods and1existing real-Keychain all13-kind three-library regression. Actual encrypted APFS detach with retained page values passed. Six corrected v3light/dark/compact/empty rasters reviewed. A later UI-only setup-refusal caption change and one eight-raster case passed; all six prior scenes byte-identical and both new refusal scenes reviewed. No microphone, system capture, playback or paid/API request. Prior v2behavioural tests passed but three intended populated renders were wrong; retained as failed visual QA, not promoted. Source snapshots and logs retained. No databases, media recordings, credentials, model weights or executable included. Full source qualification, sanitizer/optimized, physical audio, calendar linking, session-scoped Ask, performance and interactive accessibility remain open.\n'
archive=ROOT/'benchmarks/recorded-meetings-development-raw-v1.zip';receipt=ROOT/'benchmarks/recorded-meetings-development-v1.json';assert not archive.exists() and not receipt.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,data in sorted(payload.items()):z.writestr(n,data)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len(z.namelist())==len(payload) and all(z.read(n)==data for n,data in payload.items())
record={'format':'OSwind recorded meeting workspace development evidence v1','sourceAfterUpstreamTestMetadataMerge':current,'native17Source':'c1086996976d8d5c43a382c6be7987aae13736a5','native17InputSHA256':sha(BASE/'development-v3/inputs.json'),'native17LogSHA256':v3['logSHA256'],'native17Defined':17,'native17Passed':17,'native17Skipped':0,'newMethodsInNative17':16,'UIOnlyCorrectionSource':subprocess.check_output(['git','rev-parse','c2726e2'],text=True).strip(),'UIOnlyCasePassed':1,'UIOnlyInputSHA256':sha(BASE/'development-v4/inputs.json'),'UIOnlyLogSHA256':v4['logSHA256'],'uiV3Review':review3,'uiV4Review':review4,'onlyDeclaredInputChangedByLaterUpstreamMerge':different,'qualificationsComplete':False,'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(data).hexdigest() for n,data in payload.items()},'allArchivedBytesCompared':True},'scope':'Bounded metadata pages without transcript reads; explicit recording IDs, gap-aware observed-time union, import-date distinction, row-nonce and current open-store refs, current-settings UI publication, joined actualAppSession departure, foreign-page refusal, older-view departure token, ordinary-source SQL cache updates/rebuild, encrypted-page no-FD-detach, native13-kind sync regression. Core full schemas remain33/35/36; index is additive derived metadata.','remaining':['Session-specific Ask/recap and durable calendar occurrence linking/title editing','Cache migration/performance and portable/backup/current privacy corpus','Current source sanitizer/optimized and broader regression; release package','Wrapper tab interaction, keyboard/VoiceOver and physical audio/ASR/device/permission acceptance'],'limitations':'Generated fixtures and offscreen components on one Mac. No current whole suite or post-merge whole17run, no physical mic/system/voice quality, no provider request, no completeF042/v0/ranking claim.'};receipt.open('x').write(json.dumps(record,indent=2)+'\n')
for p in (BASE/'ui-development-v4').glob('*.png'):
 target=ROOT/'assets'/('recorded-meetings-'+p.name);assert not target.exists();shutil.copyfile(p,target)
print(json.dumps({'source':current,'nativeDebugPassed':17,'additionalUIcasePassed':1,'images':8,'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'qualificationComplete':False}))
