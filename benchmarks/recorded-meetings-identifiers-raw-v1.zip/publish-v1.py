from pathlib import Path
import json,subprocess,hashlib,zipfile
out=Path(__file__).resolve().parent;r=out.parents[1];review=json.loads((out/'reviewed-v1.json').read_text());assert review['currentSelectedQualificationPassed'];source=review['source']
sha=lambda value:hashlib.sha256(value).hexdigest()
public=r/'benchmarks/recorded-meetings-identifiers-v1.json';raw=r/'benchmarks/recorded-meetings-identifiers-raw-v1.zip';ci=r/'benchmarks/recorded-meetings-ci-selection-v3.json'
for path in [public,raw,ci]:assert not path.exists()
protected={}
for path in ['docs/features.json','docs/desktop-memory-landscape-2026-11-03.html','benchmarks/recorded-meetings-startup-v1.json','benchmarks/recorded-meetings-startup-raw-v1.zip','benchmarks/recorded-meetings-ci-selection-v2.json']:
 original=subprocess.check_output(['git','show','07c70a5:'+path],cwd=r);assert (r/path).read_bytes()==original;protected[path]=sha(original)
for path in subprocess.check_output(['git','diff','--name-only','07c70a5',source,'--','Sources','Tests','.github/workflows/ci.yml'],text=True,cwd=r).splitlines():
 data=subprocess.check_output(['git','show',source+':'+path],cwd=r);p=out/'source-current-v1'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
items=[]
for p in sorted(out.rglob('*')):
 relative=p.relative_to(out)
 if not p.is_file() or any(v.startswith('frozen-') or v=='__pycache__' for v in relative.parts[:-1]):continue
 if p.suffix.lower() in {'.json','.log','.swift','.py','.yml'}:items.append((str(relative),p.read_bytes()))
manifest={'source':source,'scope':'Authored identifier controls, source snapshots, all attempts, exact input/engine manifests and selected test logs. Actual frozen engines stay local; no user recordings, weights or credentials are included.','entries':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in items]}
with zipfile.ZipFile(raw,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for path,data in items:archive.writestr(path,data)
 archive.writestr('raw-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(raw) as archive:
 assert archive.testzip() is None and len(archive.namelist())==len(items)+1
 for item in manifest['entries']:assert sha(archive.read(item['path']))==item['sha256']
receipt={'format':'Recorded meeting canonical-identifier qualification v1','source':source,'review':review,'protectedHistoricalArtifacts':protected,'rawArchive':{'path':str(raw.relative_to(r)),'bytes':raw.stat().st_size,'members':len(items)+1,'sha256':sha(raw.read_bytes())},'scope':'Canonical identifier correctness and selected native/software regression only. Earlier performance and normal package belong to ac5bf82 and remain unchanged; no new current-source performance/package/whole-suite/physical claim.'}
public.write_text(json.dumps(receipt,indent=2)+'\n');ciData=json.loads((out/'ci-static-v1.json').read_text());ciData['localSelections']={name:{'defined':review['records'][name]['defined'],'statuses':review['records'][name]['statuses']} for name in ['optimized','tsan']};ci.write_text(json.dumps(ciData,indent=2)+'\n')
p=r/'docs/RECORDED-MEETINGS-WIP.md';text=p.read_text();old='- [ ] Controlled session-ID length/NUL edge cases, incoming-change UI invalidation and actual list-publication/frame-cost audit.';assert old in text;text=text.replace(old,'- [x] Controlled grapheme/NUL/byte-distinct session IDs, admission limits and prior-cache repair.\n- [ ] Incoming-change UI invalidation and actual list-publication/frame-cost audit.\n- [ ] Current normal-release package after the identifier change; earlier package evidence is pinned to ac5bf82.')
old='- [x] Selected current source optimized/sanitizer regression and strict ad-hoc development packaging; whole-current-suite and hosted qualification remain open.';assert old in text;text=text.replace(old,'- [x] Selected optimized/sanitizer regression; ac5bf82 also has strict ad-hoc development packaging. Current identifier checks are scoped below; whole-current-suite and hosted qualification remain open.')
anchor='## Deferred archive indexing and current selected checks\n';assert anchor in text;text=text.replace(anchor,anchor+'\nThis section records **ac5bf82**. Later identifier changes have separate qualification below; these timings, broader test selections and normal package are not relabeled as current-source results.\n')
text+='''
## Canonical recording identifiers

Source `29bd6c3` fixes accepted IDs being misclassified by the derived index. Swift admission counts graphemes; SQLite text length counts codepoints and stops at a NUL. Two authored controls on the unchanged prior production code exposed separate sessions and refused source opening for a valid 200-grapheme combining-mark ID and a leading-NUL ID. The three-method control run has two failed methods, 13 assertion issues (two unexpected), and one passing empty/over-limit admission check; its original source/log/engine are retained.

The index now checks nonempty UTF-8 bytes without trimming or normalization. Canonical source admission still rejects empty or over-200-grapheme IDs. Cache version 2 refuses prior grouping semantics until reopening repairs the derived rows; a generated old-cache fixture checks that behavior. Exact NUL suffixes and byte-distinct Unicode remain separate through reopening, and their original sources stay openable.

The focused normal Debug selection passed **30 methods with one optional render skip**. Current committed-source optimized and Thread Sanitizer selections each have the same **31 defined / 30 passed / 1 render skip / 0 failures**, with no race report. They include privacy, pagination, cancellation/rollback, backup/restore, actual encrypted APFS retained-page detach, real-Keychain three-library/all-13-kind replay and incoming origin separation/deletion.

The first fixed selection also exposed an adjacent app-fixture admission failure. A diagnostic reproduction showed `locked=true` as its only denied gate; the original run did not record that state. The fixture now supplies an explicit unlocked input, and another actual-AppModel unit tests locked → unlocked → locked admission. The production default still reads the real session lock. These are controlled tests, not physical OS-lock interaction or live GUI acceptance. All failed attempts are retained.

[Identifier source/input/test receipt](../benchmarks/recorded-meetings-identifiers-v1.json) · [Original controls, diagnostics and raw evidence](../benchmarks/recorded-meetings-identifiers-raw-v1.zip) · [CI selection review](../benchmarks/recorded-meetings-ci-selection-v3.json).

The broader 319-method runs, 290 performance observations and normal development package above remain pinned to ac5bf82. No new timings, normal package, whole-current-suite, physical/power/automatic 24-hour acceptance or ranking is claimed for this change. Feature statuses remain unchanged. Named sessions, durable calendar links and exact session Ask/recaps remain next product work.
''';p.write_text(text)
p=r/'docs/PROGRESS.md';old=p.read_text();entry='''## 2026-11-03 — canonical recording IDs and controlled lock admission

Source `29bd6c3` preserves accepted session IDs byte for byte across metadata grouping and source opening. Combining-mark and leading-NUL controls failed against the prior production code; cache version 2 and UTF-8 emptiness repair the mismatch without weakening source admission. Current optimized/Thread Sanitizer selections each have 31 defined / 30 passed / one optional render skip / zero failures. An adjacent lock-denied fixture and its diagnostic reproduction are retained; controlled locked/unlocked inputs exercise the actual app while the production default remains the real lock state. Earlier ac5bf82 broader tests, performance and package are historical, not current-source promotion. [Scope/TODOs](RECORDED-MEETINGS-WIP.md#canonical-recording-identifiers) · [Receipt](../benchmarks/recorded-meetings-identifiers-v1.json) · [Raw evidence](../benchmarks/recorded-meetings-identifiers-raw-v1.zip).

''';split=old.index('\n')+1;p.write_text(old[:split]+'\n'+entry+old[split:].lstrip('\n'))
for path,digest in protected.items():assert sha((r/path).read_bytes())==digest
result={'source':source,'receipt':str(public.relative_to(r)),'rawArchive':receipt['rawArchive'],'ci':str(ci.relative_to(r)),'protectedHistoricalArtifacts':protected};(out/'publication-v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
