from pathlib import Path
import subprocess,time,json,hashlib,os,shutil
out=Path(__file__).resolve().parent;r=out.parents[2];base=out.parent;pins=json.loads((out/'inputs.json').read_text());env=os.environ.copy();env.update({'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'})
selection='RecordedMeetingTests|RecordedMeetingIdentifierTests|RecordedMeetingPortabilityTests|RecordedMeetingsModelTests|NativeRecordedMeetingTests|SyncIncomingSourceTests.testIncomingRecordingProjectionKeepsOriginSessionSeparateAndDeletionRemovesMetadata|PersonalSyncMembershipUpdateTests.testOwnedNativeThreePublicSessionsPreserveThirteenKindsAndOriginalAccounts'
command=['swift','test','--sanitize','thread','--jobs','4','--filter',selection];start=time.monotonic()
with (out/'tsan.log').open('xb') as log:result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
for item in pins['inputs']:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
record={'source':pins['source'],'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'inputsUnchanged':True,'logSHA256':hashlib.sha256((out/'tsan.log').read_bytes()).hexdigest()};(out/'tsan.json').write_text(json.dumps(record,indent=2)+'\n')
products=r/'.build/arm64-apple-macosx/debug';frozen=base/'frozen-tsan-v1';frozen.mkdir();shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
items=[]
for p in sorted(frozen.rglob('*')):
 if p.is_file():items.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
(base/'frozen-tsan-v1.json').write_text(json.dumps(items,indent=2)+'\n');print(json.dumps(record));print((out/'tsan.log').read_text()[-4800:]);raise SystemExit(result.returncode)
