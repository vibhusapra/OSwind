from pathlib import Path
import json,re,hashlib,collections,subprocess,datetime
out=Path(__file__).resolve().parent;r=out.parents[1];q=out/'qualification-v1'
sha=lambda value:hashlib.sha256(value).hexdigest()
def parse(path):
 s=path.read_text();rows=[{'class':a,'method':b,'status':c,'seconds':float(d)} for a,b,c,d in re.findall(r"^Test Case '-\[(\S+) (\S+)\]' (passed|failed|skipped) \(([0-9.]+) seconds\)\.$",s,re.M)]
 tail=s[s.rindex("Test Suite 'Selected tests'"):]
 m=re.search(r'Executed\s+(\d+)\s+tests?,\s+with(?:\s+(\d+)\s+tests?\s+skipped\s+and)?\s+(\d+)\s+failures\s+\((\d+)\s+unexpected\)',tail);assert m,tail
 n,skips,issues,unexpected=[int(v or '0') for v in m.groups()];assert len(rows)==n and len({(v['class'],v['method']) for v in rows})==n
 statuses=dict(collections.Counter(v['status'] for v in rows));assert statuses.get('skipped',0)==skips
 return {'defined':n,'statuses':statuses,'assertionIssues':issues,'unexpectedIssues':unexpected,'methods':rows,'skipReasons':re.findall(r'Test skipped - (.*)',s),'logSHA256':sha(path.read_bytes()),'raceReport':bool(re.search(r'WARNING: ThreadSanitizer|SUMMARY: ThreadSanitizer',s))}
records={}
for name,log,result in [('negative','negative-v1.log','negative-v1.json'),('fixed-v2','fixed-v2/test.log','fixed-v2/result.json'),('diagnostic-v3','admission-diagnostic-v3/test.log','admission-diagnostic-v3/result.json'),('fixed-admission-v4','fixed-admission-v4/test.log','fixed-admission-v4/result.json'),('optimized','qualification-v1/optimized.log','qualification-v1/optimized.json'),('tsan','qualification-v1/tsan.log','qualification-v1/tsan.json')]:
 record=parse(out/log);record['result']=json.loads((out/result).read_text());assert record['logSHA256']==record['result']['logSHA256'];records[name]=record
assert records['negative']['defined']==3 and records['negative']['statuses']=={'failed':2,'passed':1} and records['negative']['assertionIssues']==13 and records['negative']['unexpectedIssues']==2
assert records['fixed-v2']['statuses']=={'passed':28,'failed':1,'skipped':1} and records['fixed-v2']['assertionIssues']==2
assert records['diagnostic-v3']['statuses']=={'failed':1} and records['diagnostic-v3']['assertionIssues']==2
assert 'OWNED_RECORDINGS_ADMISSION allowed=false locked=true libraryAvailable=true onboarding=false wipeBusy=false transferBusy=false' in (out/'admission-diagnostic-v3/test.log').read_text()
for name in ['fixed-admission-v4','optimized','tsan']:
 record=records[name];assert record['defined']==31 and record['statuses']=={'passed':30,'skipped':1} and record['assertionIssues']==record['unexpectedIssues']==0 and not record['raceReport']
 assert record['result']['exitCode']==0
pins=json.loads((q/'inputs.json').read_text());source=pins['source'];requests=''.join(source+':'+v['path']+'\n' for v in pins['inputs']).encode();blobs=subprocess.run(['git','cat-file','--batch'],input=requests,capture_output=True,check=True,cwd=r).stdout;position=0
for item in pins['inputs']:
 end=blobs.index(b'\n',position);header=blobs[position:end].decode().split();assert header[1]=='blob';length=int(header[2]);position=end+1;blob=blobs[position:position+length];position+=length+1
 assert sha(blob)==item['sha256']==sha((r/item['path']).read_bytes())
assert position==len(blobs)
for name in ['frozen-negative-v1.json','frozen-fixed-v2.json','frozen-optimized-v1.json','frozen-tsan-v1.json']:
 for item in json.loads((out/name).read_text()):assert sha((out/item['path']).read_bytes())==item['sha256']
review={'source':source,'pinnedInputs':len(pins['inputs']),'allGitBlobsAndWorkingInputsVerified':True,'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'currentSelectedQualificationPassed':True,'fullCurrentSuiteQualified':False,'currentNormalReleasePackaged':False,'hostedCIObserved':False,'physicalLockUIAudioPowerAutomatic24hQualified':False,'featureStatusPromoted':False,'notes':['Negative production matched ac5bf82; three newly authored methods yielded two failed methods,13 assertion issues and2unexpected, with admission-limit rejection passing. All original logs/inputs and actual negative engine retained.','The fixed-v2 normal31-predecessor selection had30defined/28pass/1skip/1failed method(2issues). A subsequent diagnostic reproduction observed real SessionState.locked=true as the sole denied recorded-view gate. The original run did not capture that state, so its precise cause is not claimed.','AppModel recordingsLocked defaults to real SessionState.locked. Owned deletion fixture now injects false; an added actual-AppModel unit tests locked/unlocked/locked admission. These do not qualify a real OS-lock interaction.','The normal Debug v4 source precedes a test-only cleanup extracting evidence before XCTAssertEqual; current optimized/TSAN pins match the committed source exactly. No assertion or production guard was weakened.','Cache version2 preserves canonical nonempty IDs verbatim, keeps the source grapheme cap, refuses older cache semantics until reopening repairs them, and does not infer unrelated sessions from titles/times.','Earlier ac5bf82 broad319 selections,290performance observations and normal release package remain historical and unchanged. No new timings, whole-current suite, package, GUI/physical acceptance or competitor rank is claimed.']}
(out/'reviewed-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ['records','notes']}));print([(k,v['defined'],v['statuses'],v['assertionIssues'],v['unexpectedIssues']) for k,v in records.items()])
