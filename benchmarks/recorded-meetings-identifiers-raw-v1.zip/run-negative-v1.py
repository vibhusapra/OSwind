from pathlib import Path
import subprocess,time,json,hashlib
out=Path(__file__).resolve().parent;r=out.parents[1];pins=json.loads((out/'negative-inputs-v1.json').read_text());command=['swift','test','--jobs','4','--filter','RecordedMeetingIdentifierTests'];start=time.monotonic()
with (out/'negative-v1.log').open('xb') as log:result=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT)
for item in pins['inputs']:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'sourcesUnchanged':True,'logSHA256':hashlib.sha256((out/'negative-v1.log').read_bytes()).hexdigest()};(out/'negative-v1.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/'negative-v1.log').read_text()[-7000:]);raise SystemExit(result.returncode)
