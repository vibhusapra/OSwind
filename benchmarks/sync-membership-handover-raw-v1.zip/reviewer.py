from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();base=root/'.artifacts/sync-membership-handover-v1';out=base/'qualification-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();target=out/'reviewed-v2.json';assert not target.exists()
inputs=json.loads((out/'inputs.json').read_text());results=json.loads((out/'results.json').read_text());expected_base='85b045bd9bdc03aa6b8337a298fa31e73d6a9795'
assert inputs['baseSource']==results['baseSource']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected_base
assert len(inputs['inputFiles'])==681 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert sha(out/'inputs.json')==results['inputManifestSHA256'] and results['runnerSHA256']==sha(base/'qualify-v2.py') and len(inputs['workingChanges'])==12
listing=out/'discovered-tests.txt';discovery={line.replace('/','.') for line in listing.read_text().splitlines() if re.fullmatch(r'OSwind(?:Core|App)Tests\.\w+/test\w+',line)};assert len(discovery)==2673
classes=['SyncMembershipPreparationTests','SyncMembershipCrashTests'];expected=set()
for cls in classes:
 for method in re.findall(r'func (test\w+)\(', (root/('Tests/OSwindCoreTests/'+cls+'.swift')).read_text()):expected.add('OSwindCoreTests.'+cls+'.'+method)
assert len(expected)==25
old_source=subprocess.check_output(['git','show',expected_base+':Tests/OSwindCoreTests/SyncMembershipPreparationTests.swift'],text=True)
old={'OSwindCoreTests.SyncMembershipPreparationTests.'+method for method in re.findall(r'func (test\w+)\(',old_source)};assert len(old)==13 and old<=expected
new=expected-old;assert len(new)==12
worker='OSwindCoreTests.SyncMembershipCrashTests.testOwnedMembershipCrashWorker';parent='OSwindCoreTests.SyncMembershipCrashTests.testOwnedProcessDeathAtFiveHandoverBoundariesRecoversExactForwardChoice'
keychains={'OSwindCoreTests.SyncMembershipPreparationTests.'+m for m in ['testOwnedNativeKeychainPreparationReopensAndCancelsOriginalAccounts','testOwnedNativeKeychainHandoverReopensNewMembershipWithOriginalAccounts']}
assert [s['name'] for s in results['stages']]==['full-debug','affected-tsan','affected-optimized','owned-native','owned-membership-tsan','owned-membership-optimized']
phases=['decision','pairing','delivery','commit','clear']
def validate(stage,text):
 assert 'WARNING: ThreadSanitizer:' not in text
 if 'tsan' not in stage['name']:assert 'OWNED_SYNC_APP_READY sanitizer=true' not in text
 raw=re.findall(r"Test Case '-\[(\w+\.\w+) (test\w+)\]' (passed|skipped|failed)",text);states={a+'.'+b:v for a,b,v in raw};assert len(states)==len(raw)
 summaries=re.findall(r'Executed (\d+) tests?, with (?:(\d+) tests? skipped and )?(\d+) failures?',text);assert summaries
 count=summaries[-1];assert int(count[0])==len(states) and int(count[1] or 0)==sum(v=='skipped' for v in states.values()) and int(count[2])==0 and all(v in ['passed','skipped'] for v in states.values())
 selected=discovery if stage['name']=='full-debug' else {name for name in discovery if re.search(stage['command'][-1],name)};assert set(states)==selected
 assert expected<=set(states)
 owned=stage['name'].startswith('owned-')
 assert all(states[m]=='passed' for m in expected-(keychains|{worker,parent}))
 assert states[worker]=='skipped' and states[parent]==('passed' if owned else 'skipped')
 assert all(states[m]==('passed' if owned else 'skipped') for m in keychains)
 assert text.count('NATIVE36_FROZEN35_FENCE positive33=true waitingBeforeEnrollmentRefused=true fresh36Refused=true originalBinaryUnchanged=true')==1
 for phase in phases:assert text.count('OWNED_MEMBERSHIP_PROCESS_DEATH phase='+phase+' signal=9 forwardRecovered=true originalAccounts=4 cleaned=true')==(1 if owned else 0)
 if owned:assert {n for n,v in states.items() if v=='skipped'}=={worker},'Inspect any unexpected owned skip explicitly'
 return states
review=[];texts={}
for stage in results['stages']:
 log=root/stage['log'];assert stage['exit']==0 and sha(log)==stage['sha256'];text=log.read_text();states=validate(stage,text);texts[stage['name']]=text
 review.append({'mode':stage['name'],'defined':len(states),'passed':sum(v=='passed' for v in states.values()),'skipped':[name for name,v in states.items() if v=='skipped'],'failed':0,'newHandoverMethods':{n:states[n] for n in sorted(new)},'allFocusedMembershipMethods':{n:states[n] for n in sorted(expected)},'logSHA256':sha(log),'wallSeconds':stage['wallSeconds']})
# Mutated in-memory logs must be rejected; never rerun successful product tests.
regular=results['stages'][0];native=results['stages'][3];text=texts[regular['name']];case=re.search(r"Test Case '-\[\w+\.\w+ test\w+\]' passed[^\n]*",text).group(0)
faults={'duplicate-outcome':(regular,text+'\n'+case),'dropped-outcome':(regular,text.replace(case,'',1)),'hidden-skip':(regular,text.replace(case,case.replace(' passed',' skipped'),1)),'race-warning':(regular,text+'\nWARNING: ThreadSanitizer: injected invalid log'),'wrong-summary':(regular,re.sub(r'Executed 2673 tests,','Executed 2672 tests,',text)),'missing-owned-kill-gate':(native,texts[native['name']].replace('OWNED_MEMBERSHIP_PROCESS_DEATH phase=commit signal=9 forwardRecovered=true originalAccounts=4 cleaned=true','MISSING_GATE'))}
for label,(stage,changed) in faults.items():
 try:validate(stage,changed)
 except AssertionError:pass
 else:raise AssertionError('Fault control accepted '+label)
readiness=re.findall(r'OWNED_SYNC_APP_READY sanitizer=true timeoutSeconds=120 elapsedSeconds=([0-9.eE+-]+) phase=(\w+)',texts['affected-tsan']);assert readiness
result={'instrumentedAppReadiness':{'observations':len(readiness),'overOriginal20Seconds':sum(float(seconds)>20 for seconds,phase in readiness),'maxSeconds':max(float(seconds) for seconds,phase in readiness),'normalBudgetSeconds':20,'instrumentedBudgetSeconds':120},'format':'OSwind native membership handover qualification review v2','baseSource':inputs['baseSource'],'inputCount':681,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'discoverySHA256':sha(listing),'stages':review,'rejectedInMemoryLogFaults':list(faults),'retainedEarlierFailure':'Same production runtime with original20s app readiness helper: fullDebug2530pass143skip0fail, broaderTSan698pass42skip3readinessFailures0raceWarnings. Original logs/source retained; the helper change is functional test instrumentation, not a product performance fix or proof of the original slowdown cause.','scope':'Internal addition handover, exact recovery through original accounts/native checkpoints, bounded later-peer replay and all13-kind transfer. Five actual owned SIGKILL boundaries and core worker cancellation/uncanceled close are tested. Public owner-add response durability, actual app session/UI producer drain, revocation/rotation, acknowledged compaction/large media/queue/provider retention, physical two Macs/provider, energy and production-signing acceptance remain open. Real login-Keychain is not production data-protection-Keychain acceptance. Frozen35 collector waits before pairing/enrollment, not an old already-admitted native35 Keychain client. Source review identified a potential preparation-only native36 developer runtime compatibility gap: that older runtime predates replay. No frozen36 control or permanent state-format floor is implemented yet; those remain required before full public integration.'}
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'review':str(target.relative_to(root)),'sha256':sha(target),'faultControls':list(faults),'stages':[{'mode':s['mode'],'defined':s['defined'],'passed':s['passed'],'skipped':len(s['skipped'])} for s in review]}))
