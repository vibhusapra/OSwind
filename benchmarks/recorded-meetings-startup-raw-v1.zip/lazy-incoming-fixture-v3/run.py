from pathlib import Path
import os,subprocess,json,time,hashlib
out=Path(__file__).resolve().parent;r=out.parents[2]
inputs=json.loads((out/'inputs.json').read_text());env=os.environ.copy();env.update({'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'})
command=['swift','test','--jobs','4','--filter','SyncIncomingSourceTests.testIncomingRecordingProjectionKeepsOriginSessionSeparateAndDeletionRemovesMetadata']
start=time.monotonic()
with (out/'test.log').open('xb') as log:result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
for item in inputs: assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256'],'Sources changed'
record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'sourcesUnchanged':True,'logSHA256':hashlib.sha256((out/'test.log').read_bytes()).hexdigest()}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/'test.log').read_text()[-4000:]);raise SystemExit(result.returncode)
