from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
r=Path(__file__).resolve().parents[2];out=Path(__file__).resolve().parent
before=json.loads((out/'owned-benchmark.json').read_text())
env=os.environ.copy();env['OSWIND_RECORDED_BENCH_ROOT']=str(out);env['OSWIND_RECORDED_BENCH_MODE']='seed'
command=['swift','test','-c','release','--jobs','4','--filter','RecordedMeetingBenchmarkTests']
start=time.monotonic()
with (out/'build-and-seed-v1.log').open('xb') as log: result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
after=[]
for item in before['inputs']:
 p=r/item['path'];after.append({'path':item['path'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
assert after==before['inputs'],'Pinned sources changed'
record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'sourcesUnchanged':True,'logSHA256':hashlib.sha256((out/'build-and-seed-v1.log').read_bytes()).hexdigest()}
(out/'build-and-seed-v1.json').write_text(json.dumps(record,indent=2)+'\n')
if result.returncode: raise SystemExit(result.returncode)
products=r/'.build/arm64-apple-macosx/release';frozen=out/'frozen-eager-v1';frozen.mkdir()
shutil.copy2(products/'oswindctl',frozen/'oswindctl')
shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
manifest=[]
for p in sorted(frozen.rglob('*')):
 if p.is_file(): manifest.append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
(out/'frozen-eager-v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(record));print((out/'seed.json').read_text())
