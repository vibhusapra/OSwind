from pathlib import Path
import os,sys,subprocess,time,json,hashlib,sqlite3,statistics,re,shutil,datetime
out=Path(__file__).resolve().parent;r=out.parents[1]
assert (out/'build-and-seed-v1.json').exists()
assert json.loads((out/'build-and-seed-v1.json').read_text())['exitCode']==0
assert not (out/'trials').exists(),'Preserve prior trials'
(out/'trials').mkdir()
baselineOriginal=Path('/Users/vibhusapra/.codex/worktrees/sync-enrollment/oswind/.artifacts/peer-membership-update-v1/qualification-v1/OSwind.app/Contents/MacOS/oswindctl')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(baselineOriginal)=='9ddbb052dffe290e5287b441a8d7a2030c09b2b1b2c43ec875c8dde3d5b311be'
baseline=out/'frozen-baseline-oswindctl';shutil.copy2(baselineOriginal,baseline)
candidate=out/'frozen-eager-v1/oswindctl'
manifest=json.loads((out/'frozen-eager-v1.json').read_text())
for item in manifest: assert sha(out/item['path'])==item['sha256']
records=[];corpora=[]
def canonical(directory):
 con=sqlite3.connect('file:'+str(directory/'memory.sqlite')+'?mode=ro',uri=True)
 h=hashlib.sha256();n=0
 for ident,payload in con.execute('select id,payload from memories order by id collate binary'):
  for data in (ident.encode(),payload):h.update(len(data).to_bytes(8,'big'));h.update(data)
  n+=1
 con.close();return {'sourceCount':n,'canonicalSourceSHA256':h.hexdigest()}
def sqlState(directory):
 con=sqlite3.connect('file:'+str(directory/'memory.sqlite')+'?mode=ro',uri=True)
 state={key:con.execute('pragma '+key).fetchone()[0] for key in ['page_count','freelist_count','page_size','user_version']}
 state['hasRecordingIndex']=bool(con.execute("select 1 from sqlite_master where name='recorded_meeting_sources'").fetchone())
 if state['hasRecordingIndex']:state['recordingRows']=con.execute('select count(*) from recorded_meeting_sources').fetchone()[0]
 con.close();state['databaseBytes']=(directory/'memory.sqlite').stat().st_size;state['allocatedDatabaseBytes']=(directory/'memory.sqlite').stat().st_blocks*512
 return state
def run(command,prefix,environment=None):
 timeFile=out/(prefix+'.time.txt');stdout=out/(prefix+'.stdout');stderr=out/(prefix+'.stderr')
 full=['/usr/bin/time','-l','-o',str(timeFile),*map(str,command)];start=time.perf_counter()
 with stdout.open('xb') as output,stderr.open('xb') as error: completed=subprocess.run(full,cwd=r,env=environment,stdout=output,stderr=error)
 elapsed=time.perf_counter()-start;timing=timeFile.read_text();rss=re.search(r'(\d+)\s+maximum resident set size',timing)
 observation={'command':list(map(str,command)),'exitCode':completed.returncode,'wallSeconds':elapsed,'maxRSSBytes':int(rss.group(1)) if rss else None,'stdout':stdout.name,'stderr':stderr.name,'time':timeFile.name}
 records.append(observation);(out/'observations-eager-v1.json').write_text(json.dumps(records,indent=2)+'\n')
 assert completed.returncode==0,observation
 return observation,json.loads(stdout.read_text()) if command[1]=='stats' else None
for corpus,count in [('live20k',20000),('imports256',256)]:
 pristine=out/'corpora'/corpus;expected=canonical(pristine);assert expected['sourceCount']==count
 info={'name':corpus,'inputDatabaseSHA256':sha(pristine/'memory.sqlite'),'canonical':expected,'before':sqlState(pristine),'trials':[]}
 for pair in range(8):
  for product in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   assert shutil.disk_usage(out).free>8*2**30
   name=f'{corpus}-p{pair:02d}-{product}';trial=out/'trials'/name
   subprocess.run(['/bin/cp','-cR',str(pristine),str(trial)],check=True)
   assert sha(trial/'memory.sqlite')==info['inputDatabaseSHA256']
   cli=baseline if product=='baseline' else candidate
   row={'name':name,'product':product,'pair':pair,'opens':[]}
   for opening in range(4):
    observation,stats=run([cli,'stats','--data',trial],name+f'-open{opening}')
    assert stats['count']==count and stats['audioSegments']==count
    observation.update({'corpus':corpus,'product':product,'pair':pair,'opening':opening,'state':'unindexed-first-process-open' if opening==0 else 'index-ready-followup-process-open' if product=='candidate' else 'predecessor-followup-process-open','verifiedSources':stats['count']})
    row['opens'].append(observation)
   assert canonical(trial)==expected,'Canonical sources changed'
   row['after']=sqlState(trial);assert row['after']['hasRecordingIndex']==(product=='candidate')
   if product=='candidate':assert row['after']['recordingRows']==count
   info['trials'].append(row)
  print(corpus,'pair',pair,'retained',flush=True)
 corpora.append(info)
 trialName=corpus+'-p00-candidate';env=os.environ.copy();env.update({'OSWIND_RECORDED_BENCH_ROOT':str(out),'OSWIND_RECORDED_BENCH_MODE':'page','OSWIND_RECORDED_BENCH_TRIAL':trialName,'OSWIND_RECORDED_BENCH_COUNT':str(count)})
 run(['/usr/bin/xcrun','xctest','-XCTest','OSwindCoreTests.RecordedMeetingBenchmarkTests/testAuthoredArchiveStartupAndPaging',out/'frozen-eager-v1/OSwindPackageTests.xctest'],'paging-'+corpus,env)
 assert json.loads((out/('page-'+trialName+'.json')).read_text())['uniqueSources']==count
# Persist observations again after their verification labels have been added.
(out/'observations-eager-v1.json').write_text(json.dumps(records,indent=2)+'\n')
for item in manifest:assert sha(out/item['path'])==item['sha256']
assert sha(baselineOriginal)==sha(baseline)=='9ddbb052dffe290e5287b441a8d7a2030c09b2b1b2c43ec875c8dde3d5b311be'
summary={'scope':'Authored archives, filesystem caches not flushed. First process opens omit the new cache; followup processes use the same trial. Both optimized CLIs, same canonical inputs, eight counterbalanced pairs per corpus, three followups per trial. OSwind component regression only; no energy or competitor ranking.','source':json.loads((out/'owned-benchmark.json').read_text())['source'],'baselineSHA256':sha(baseline),'candidateSHA256':sha(candidate),'corpora':corpora,'records':records,'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'eager-reviewed-inputs-v1.json').write_text(json.dumps(summary,indent=2)+'\n')
for corpus in corpora:
 for product in ['baseline','candidate']:
  for initial in [True,False]:
   rows=[v for v in records if v.get('corpus')==corpus['name'] and v.get('product')==product and (v['opening']==0)==initial]
   values=sorted(v['wallSeconds'] for v in rows)
   print(corpus['name'],product,'initial' if initial else 'followup','n',len(rows),'medianMs',round(statistics.median(values)*1000,3),'maxMs',round(max(values)*1000,3),'maxRSSMiB',round(max(v['maxRSSBytes'] for v in rows)/2**20,3),flush=True)
print('DONE',len(records),'observations',flush=True)
