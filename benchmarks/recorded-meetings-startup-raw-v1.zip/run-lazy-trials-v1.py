from pathlib import Path
import os,subprocess,time,json,hashlib,sqlite3,statistics,re,shutil,datetime
out=Path(__file__).resolve().parent;r=out.parents[1]
assert json.loads((out/'qualification-lazy-v1/optimized.json').read_text())['exitCode']==0
assert len(json.loads((out/'eager-reviewed-inputs-v1.json').read_text())['records'])==130
marker=out/'lazy-trials-started-v1.json';marker.open('x').write(json.dumps({'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
engines={'eager':out/'frozen-eager-v1','lazy':out/'frozen-lazy-v1'}
manifest=[*json.loads((out/'frozen-eager-v1.json').read_text()),*json.loads((out/'frozen-lazy-v1.json').read_text())]
for item in manifest:assert sha(out/item['path'])==item['sha256']
records=[];corpora=[]
def canonical(directory):
 con=sqlite3.connect('file:'+str(directory/'memory.sqlite')+'?mode=ro',uri=True);h=hashlib.sha256();count=0
 for ident,payload in con.execute('select id,payload from memories order by id collate binary'):
  for data in (ident.encode(),payload):h.update(len(data).to_bytes(8,'big'));h.update(data)
  count+=1
 con.close();return {'sourceCount':count,'canonicalSourceSHA256':h.hexdigest()}
def state(directory):
 con=sqlite3.connect('file:'+str(directory/'memory.sqlite')+'?mode=ro',uri=True)
 value={key:con.execute('pragma '+key).fetchone()[0] for key in ['page_count','freelist_count','page_size']}
 value['recordingRows']=con.execute('select count(*) from recorded_meeting_sources').fetchone()[0]
 value['marker']=con.execute("select value from store_metadata where key='recorded_meeting_index_version'").fetchone()[0]
 con.close();value['databaseBytes']=(directory/'memory.sqlite').stat().st_size;return value
def run(command,prefix,env=None):
 timeFile=out/(prefix+'.time.txt');stdout=out/(prefix+'.stdout');stderr=out/(prefix+'.stderr')
 start=time.perf_counter()
 with stdout.open('xb') as output,stderr.open('xb') as error:completed=subprocess.run(['/usr/bin/time','-l','-o',str(timeFile),*map(str,command)],cwd=r,env=env,stdout=output,stderr=error)
 elapsed=time.perf_counter()-start;timing=timeFile.read_text();rss=re.search(r'(\d+)\s+maximum resident set size',timing)
 value={'command':list(map(str,command)),'exitCode':completed.returncode,'wallSeconds':elapsed,'maxRSSBytes':int(rss.group(1)) if rss else None,'stdout':stdout.name,'stderr':stderr.name,'time':timeFile.name}
 records.append(value);(out/'observations-lazy-v1.json').write_text(json.dumps(records,indent=2)+'\n')
 assert completed.returncode==0,value
 return value
for corpus,count in [('live20k',20000),('imports256',256)]:
 pristine=out/'corpora'/corpus;expected=canonical(pristine);assert expected['sourceCount']==count
 info={'name':corpus,'inputDatabaseSHA256':sha(pristine/'memory.sqlite'),'canonical':expected,'trials':[]}
 for pair in range(8):
  for product in (['eager','lazy'] if pair%2==0 else ['lazy','eager']):
   assert shutil.disk_usage(out).free>8*2**30
   name=f'lazy-{corpus}-p{pair:02d}-{product}';trial=out/'trials'/name
   assert not trial.exists();subprocess.run(['/bin/cp','-cR',str(pristine),str(trial)],check=True);assert sha(trial/'memory.sqlite')==info['inputDatabaseSHA256']
   row={'name':name,'product':product,'pair':pair,'opens':[]}
   for opening in range(4):
    observation=run([engines[product]/'oswindctl','stats','--data',trial],name+f'-open{opening}');stats=json.loads((out/observation['stdout']).read_text())
    assert stats['count']==count and stats['audioSegments']==count
    observation.update({'stage':'cli','corpus':corpus,'product':product,'pair':pair,'opening':opening,'verifiedSources':count});row['opens'].append(observation)
   row['beforePage']=state(trial);assert row['beforePage']['recordingRows']==(count if product=='eager' else 0);assert row['beforePage']['marker']==('1' if product=='eager' else 'pending:1')
   env=os.environ.copy();env.update({'OSWIND_RECORDED_BENCH_ROOT':str(out),'OSWIND_RECORDED_BENCH_MODE':'page','OSWIND_RECORDED_BENCH_TRIAL':name,'OSWIND_RECORDED_BENCH_COUNT':str(count)})
   observation=run(['/usr/bin/xcrun','xctest','-XCTest','OSwindCoreTests.RecordedMeetingBenchmarkTests/testAuthoredArchiveStartupAndPaging',engines[product]/'OSwindPackageTests.xctest'],name+'-page',env)
   page=json.loads((out/('page-'+name+'.json')).read_text());assert page['uniqueSources']==count
   observation.update({'stage':'paging','corpus':corpus,'product':product,'pair':pair,'verifiedSources':count,'firstPageSeconds':page['traversalPageSeconds'][0],'pageReport':'page-'+name+'.json'});row['page']=observation
   row['afterPage']=state(trial);assert row['afterPage']['marker']=='1' and row['afterPage']['recordingRows']==count
   assert canonical(trial)==expected,'Canonical sources changed';info['trials'].append(row)
  print(corpus,'pair',pair,'retained',flush=True)
 corpora.append(info)
(out/'observations-lazy-v1.json').write_text(json.dumps(records,indent=2)+'\n')
for item in manifest:assert sha(out/item['path'])==item['sha256']
summary={'scope':'Optimized frozen eager versus deferred recording index. Eight counterbalanced pairs per corpus, three followup CLI opens per trial, then first use and complete source traversal in each trial. Lazy CLI opens must leave the cache pending with zero projected rows; first use must produce all exact source IDs and mark ready. Filesystem caches not flushed, single Mac with an older manual capture soak active; no energy, physical ASR or competitor ranking claim.','source':json.loads((out/'qualification-lazy-v1/inputs.json').read_text())['source'],'engineSHA256':{key:sha(path/'oswindctl') for key,path in engines.items()},'corpora':corpora,'records':records,'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'lazy-reviewed-inputs-v1.json').write_text(json.dumps(summary,indent=2)+'\n')
for corpus in corpora:
 for product in ['eager','lazy']:
  for initial in [True,False]:
   values=[v for v in records if v.get('stage')=='cli' and v['corpus']==corpus['name'] and v['product']==product and (v['opening']==0)==initial]
   print(corpus['name'],product,'initial' if initial else 'followup','n',len(values),'medianMs',round(statistics.median(v['wallSeconds'] for v in values)*1000,3),'maxMs',round(max(v['wallSeconds'] for v in values)*1000,3),'maxRSSMiB',round(max(v['maxRSSBytes'] for v in values)/2**20,3),flush=True)
  pages=[v['firstPageSeconds'] for v in records if v.get('stage')=='paging' and v['corpus']==corpus['name'] and v['product']==product]
  print(corpus['name'],product,'firstpage n',len(pages),'medianMs',round(statistics.median(pages)*1000,3),'maxMs',round(max(pages)*1000,3),flush=True)
print('DONE',len(records),'observations',flush=True)
