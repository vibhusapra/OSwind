from pathlib import Path
import os,subprocess,json,hashlib,time
out=Path(__file__).resolve().parent;r=out.parents[2];base=out.parent
pins=json.loads((out/'inputs.json').read_text())['inputs']+json.loads((out/'package-inputs-v1.json').read_text())
for item in pins:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
cli=r/'.build/arm64-apple-macosx/release/oswindctl';before=hashlib.sha256(cli.read_bytes()).hexdigest();assert before==hashlib.sha256((base/'frozen-lazy-v1/oswindctl').read_bytes()).hexdigest()
app=out/'OSwind.app';assert not app.exists();env=os.environ.copy();env['OSWIND_APP_OUTPUT']=str(app);command=['bash','scripts/build-app.sh','release'];start=time.monotonic()
with (out/'package.log').open('xb') as log:result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
verify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],capture_output=True)
for item in pins:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
assert hashlib.sha256(cli.read_bytes()).hexdigest()==before,'Build product changed'
manifest=[]
for p in sorted(app.rglob('*')):
 if p.is_file():manifest.append({'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)})
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:assert (app/'Contents/MacOS'/name).stat().st_mode&0o777==0o755
record={'source':json.loads((out/'inputs.json').read_text())['source'],'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'verifyCommand':['codesign','--verify','--deep','--strict','OSwind.app'],'verifyExitCode':verify.returncode,'verifyOutput':verify.stdout.decode()+verify.stderr.decode(),'sourcesAndPackageInputsUnchanged':True,'frozenComparatorUnchanged':True,'logSHA256':hashlib.sha256((out/'package.log').read_bytes()).hexdigest(),'files':manifest,'scope':'Local ad-hoc signed development package; no notarization, GUI/physical acceptance or release readiness implied.'}
(out/'package.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'}));print('packageFiles',len(manifest));assert verify.returncode==0
