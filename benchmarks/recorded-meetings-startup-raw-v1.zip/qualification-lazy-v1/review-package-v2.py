from pathlib import Path
import os,subprocess,json,hashlib,re,shutil,datetime
out=Path(__file__).resolve().parent;r=out.parents[2];base=out.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
app=out/'OSwind.app';log=out/'package.log';assert log.read_text().rstrip().endswith(str(app)), 'Build script did not reach its successful verified-app output'
assert not (out/'package-review-v2.json').exists()
pins=json.loads((out/'inputs.json').read_text());packagePins=json.loads((out/'package-inputs-v1.json').read_text())
for item in pins['inputs']+packagePins:assert sha(r/item['path'])==item['sha256']
verify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],capture_output=True);assert verify.returncode==0
products=r/'.build/arm64-apple-macosx/release';frozen=base/'frozen-normal-release-v1';assert not frozen.exists();frozen.mkdir()
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 assert (app/'Contents/MacOS'/name).stat().st_mode&0o777==0o755
 shutil.copy2(products/name,frozen/name)
normal=[]
for p in sorted(frozen.iterdir()):normal.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)})
(base/'frozen-normal-release-v1.json').write_text(json.dumps(normal,indent=2)+'\n')
for manifest in ['frozen-eager-v1.json','frozen-lazy-v1.json','frozen-lazy-tsan-v1.json']:
 for item in json.loads((base/manifest).read_text()):assert sha(base/item['path'])==item['sha256']
smokeRoot=out/'owned-package-smoke';assert not smokeRoot.exists()
smokeCommand=[str(app/'Contents/MacOS/oswindctl'),'stats','--data',str(smokeRoot)]
smoke=subprocess.run(smokeCommand,capture_output=True);(out/'package-smoke.stdout').write_bytes(smoke.stdout);(out/'package-smoke.stderr').write_bytes(smoke.stderr)
assert smoke.returncode==0;stats=json.loads(smoke.stdout);assert stats['count']==stats['audioSegments']==0
files=[]
for p in sorted(app.rglob('*')):
 if p.is_file():files.append({'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)})
buildSeconds=float(re.findall(r'Build complete! \(([0-9.]+)s\)',log.read_text())[-1])
changed=sha(products/'oswindctl')!=sha(base/'frozen-lazy-v1/oswindctl')
record={'source':pins['source'],'command':['bash','scripts/build-app.sh','release'],'exitCode':0,'normalBuildSeconds':buildSeconds,'originalWrapperExitCode':int(os.environ['OSWIND_PACKAGE_WRAPPER_EXIT']),'originalPostbuildAssumptionFailed':changed,'originalWrapperNote':'The initial wrapper required mutable .build/release to stay byte-identical to the optimized-test product. Normal release recompiles without -enable-testing (observed actual frontend flags). This was a metadata-review assumption; build/signing completed. v2 inspects the retained package without rebuilding or resigning.','verifyCommand':['codesign','--verify','--deep','--strict','OSwind.app'],'verifyExitCode':verify.returncode,'verifyOutput':(verify.stdout+verify.stderr).decode(),'sourcesAndPackageInputsUnchanged':True,'frozenComparatorUnchanged':True,'optimizedTestCLIHash':sha(base/'frozen-lazy-v1/oswindctl'),'normalReleaseCLIHash':sha(products/'oswindctl'),'logSHA256':sha(log),'files':files,'smoke':{'command':smokeCommand,'exitCode':smoke.returncode,'sources':stats['count'],'audio':stats['audioSegments'],'stdoutSHA256':sha(out/'package-smoke.stdout'),'stderrSHA256':sha(out/'package-smoke.stderr')},'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Normal release/ad-hoc development package plus owned empty-library CLI smoke. Optimized test and performance engines are separate frozen products of the same pinned source. No notarization, live GUI/audio/physical acceptance or release readiness implied.'}
(out/'package-review-v2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='files'}));print('packageFiles',len(files))
