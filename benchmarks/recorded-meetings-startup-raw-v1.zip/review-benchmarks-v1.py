from pathlib import Path
import json,math,re,hashlib,statistics,subprocess,datetime
out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reports={};allNames=[]
for kind,total in [('eager',130),('lazy',160)]:
 source=json.loads((out/(kind+'-reviewed-inputs-v1.json')).read_text());records=source['records'];assert len(records)==total
 for value in records:
  assert value['exitCode']==0 and math.isfinite(value['wallSeconds']) and value['wallSeconds']>0
  for key in ['stdout','stderr','time']:assert (out/value[key]).is_file();allNames.append(value[key])
  timing=(out/value['time']).read_text();rss=int(re.search(r'(\d+)\s+maximum resident set size',timing).group(1));assert rss==value['maxRSSBytes'] and rss>0
  if len(value['command'])>1 and value['command'][1]=='stats':
   body=json.loads((out/value['stdout']).read_text());count=20000 if value['corpus']=='live20k' else 256;assert body['count']==body['audioSegments']==count
  else:
   text=(out/value['stdout']).read_text()+(out/value['stderr']).read_text();assert 'Executed 1 test, with 0 failures' in text and 'failed (' not in text
   if 'pageReport' in value:
    page=json.loads((out/value['pageReport']).read_text());assert page['uniqueSources']==value['verifiedSources'];assert sum(page['traversalExamined'])==page['uniqueSources'];assert len(page['repeatedFirstPageSeconds'])==11
    assert page['traversalPageSeconds'][0]==value['firstPageSeconds']
 cells=[]
 for corpus in ['live20k','imports256']:
  products=['baseline','candidate'] if kind=='eager' else ['eager','lazy']
  for product in products:
   for initial in [True,False]:
    rows=[v for v in records if v.get('corpus')==corpus and v.get('product')==product and 'opening' in v and (v['opening']==0)==initial]
    values=sorted(v['wallSeconds']*1000 for v in rows);assert len(rows)==(8 if initial else 24)
    cells.append({'corpus':corpus,'product':product,'operation':'first-open' if initial else 'followup-open','n':len(rows),'medianMs':statistics.median(values),'p95Ms':values[math.ceil(.95*len(values))-1],'maxMs':max(values),'maximumRSSBytes':max(v['maxRSSBytes'] for v in rows),'allMs':values})
   if kind=='lazy':
    rows=[v for v in records if v.get('stage')=='paging' and v['corpus']==corpus and v['product']==product];values=sorted(v['firstPageSeconds']*1000 for v in rows);assert len(values)==8
    cells.append({'corpus':corpus,'product':product,'operation':'first-recordings-page-including-backfill-if-pending','n':8,'medianMs':statistics.median(values),'p95Ms':max(values),'maxMs':max(values),'allMs':values})
 for corpus in source['corpora']:
  path=out/'corpora'/corpus['name']/'memory.sqlite';assert sha(path)==corpus['inputDatabaseSHA256']
 reports[kind]={'report':kind+'-reviewed-inputs-v1.json','reportSHA256':sha(out/(kind+'-reviewed-inputs-v1.json')),'observationCount':total,'cells':cells}
assert len(allNames)==len(set(allNames)), 'Raw observation names overlap'
engines=[]
for manifest in ['frozen-eager-v1.json','frozen-lazy-v1.json']:
 for item in json.loads((out/manifest).read_text()):assert sha(out/item['path'])==item['sha256']
for relative in ['frozen-baseline-oswindctl','frozen-eager-v1/oswindctl','frozen-lazy-v1/oswindctl']:
 path=out/relative;verify=subprocess.run(['/usr/bin/codesign','--verify','--strict',str(path)],capture_output=True)
 engines.append({'path':relative,'sha256':sha(path),'strictCodeSignatureExit':verify.returncode,'signatureOutput':(verify.stdout+verify.stderr).decode()})
record={'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allObservationsRetained':True,'observations':290,'wholeCLIObservations':256,'pageWorkerObservations':34,'rawObservationFiles':len(allNames),'reports':reports,'engines':engines,'scope':'Measured authored-corpus component results on one Mac; first process open is not an OS-cold filesystem cache. Work is deferred to first Recordings use, not removed. No actual speech media, GUI frame timing, energy, continuous automatic24h acceptance or competitor ranking. First-lazy-open outlier remains in maximum and p95; its cause is unproved.'}
(out/'benchmarks-reviewed-v1.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['reports','engines']}));print('strict signatures',[(v['path'],v['strictCodeSignatureExit']) for v in engines])
