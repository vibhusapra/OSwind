from pathlib import Path
import json,re,hashlib,collections,subprocess,datetime
out=Path(__file__).resolve().parent;r=out.parents[1];q=out/'qualification-lazy-v1'
sha=lambda data:hashlib.sha256(data).hexdigest()
pattern=re.compile(r"^Test Case '-\[(\S+) (\S+)\]' (passed|failed|skipped) \(([0-9.]+) seconds\)\.$",re.M)
def parse(log):
 text=log.read_text();rows=[{'class':a,'method':b,'status':c,'seconds':float(d)} for a,b,c,d in pattern.findall(text)]
 assert len({(v['class'],v['method']) for v in rows})==len(rows),'Duplicate method output'
 tail=text[text.rindex("Test Suite 'Selected tests'"):]
 count=int(re.search(r'Executed (\d+) test',tail).group(1));assert len(rows)==count
 status=dict(collections.Counter(v['status'] for v in rows));reasons=re.findall(r"-\[(\S+) (\S+)\] : Test skipped - (.*)",text)
 skipped=[{'class':a,'method':b,'reason':c} for a,b,c in reasons];assert len(skipped)==status.get('skipped',0)
 return {'methods':rows,'defined':count,'statuses':status,'skips':skipped,'logSHA256':sha(log.read_bytes()),'raceReport':bool(re.search(r'WARNING: ThreadSanitizer|SUMMARY: ThreadSanitizer',text))}
workflow=(r/'.github/workflows/ci.yml').read_text();selection=re.search(r"OSWIND_RECORDED_MEETING_UI_QA_DIR=.*--filter '([^']+)'",workflow).group(1)
stages={}
for name in ['optimized','tsan']:
 result=json.loads((q/(name+'.json')).read_text());stage=parse(q/(name+'.log'));assert stage['logSHA256']==result['logSHA256'];assert stage['defined']==319
 stage['result']=result;critical=[v for v in stage['methods'] if re.search(selection,v['class']+'.'+v['method'])];assert len(critical)==26
 stage['recordedCISelection']={'defined':26,'statuses':dict(collections.Counter(v['status'] for v in critical))}
 stage['skipCategories']={'childEntryHelpers':sum('Only run as' in v['reason'] for v in stage['skips']),'optInScaleProbes':sum('output required' in v['reason'] for v in stage['skips']),'qualifiedPrior32ExecutableRequired':sum('qualified prior32' in v['reason'] for v in stage['skips']),'componentRender':sum('workspace components' in v['reason'] for v in stage['skips'])}
 assert sum(stage['skipCategories'].values())==15
 stages[name]=stage
pins=json.loads((q/'inputs.json').read_text());assert pins['source']=='ac5bf825ba7b70149f47287ccb9399c0e55d525b'
requests=''.join(pins['source']+':'+v['path']+'\n' for v in pins['inputs']).encode();result=subprocess.run(['git','cat-file','--batch'],input=requests,capture_output=True,check=True,cwd=r)
pos=0;data=result.stdout
for item in pins['inputs']:
 end=data.index(b'\n',pos);header=data[pos:end].decode().split();assert header[1]=='blob';size=int(header[2]);pos=end+1;blob=data[pos:pos+size];pos+=size+1
 assert sha(blob)==item['sha256']==sha((r/item['path']).read_bytes()),item['path']
assert pos==len(data)
package=json.loads((q/'package-review-v2.json').read_text());assert package['exitCode']==package['verifyExitCode']==0
for item in package['files']:
 path=q/'OSwind.app'/item['path'];assert sha(path.read_bytes())==item['sha256']
for manifest in ['frozen-eager-v1.json','frozen-lazy-v1.json','frozen-lazy-tsan-v1.json']:
 for item in json.loads((out/manifest).read_text()):assert sha((out/item['path']).read_bytes())==item['sha256']
development={}
for name in ['lazy-development-v1','lazy-development-v2','lazy-incoming-fixture-v3']:
 stage=parse(out/name/'test.log');stage['result']=json.loads((out/name/'result.json').read_text());assert stage['logSHA256']==stage['result']['logSHA256'];development[name]=stage
assert development['lazy-development-v1']['statuses']=={'passed':20,'skipped':1}
assert development['lazy-development-v2']['statuses']=={'passed':22,'skipped':1,'failed':1}
assert development['lazy-incoming-fixture-v3']['statuses']=={'passed':1}
review={'source':pins['source'],'sourcePinnedInputs':len(pins['inputs']),'allGitBlobsAndWorkingInputsVerified':True,'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':stages,'development':development,'package':package,'benchmarkReview':'benchmarks-reviewed-v1.json','benchmarkReviewSHA256':sha((out/'benchmarks-reviewed-v1.json').read_bytes()),'selectedQualificationPassed':all(v['result']['exitCode']==0 and v['statuses'].get('failed',0)==0 and not v['raceReport'] for v in stages.values()),'fullCurrentSuiteQualified':False,'physicalGUIAudioPowerAndAutomatic24hQualified':False,'hostedCIObserved':False,'featureLedgerPromoted':False,'priorUpstreamWIPFailuresSuperseded':False,'notes':['Actual skip categories were audited per method:9 child-entry helpers,3 opt-in scale probes,2 exact-prior32 executable probes,1 component render. Earlier14-child-only commentary was explicitly corrected.','Failed development24-method run is retained. Its incoming fixture lacked a receiver local-write drain; adding that test sequence alone passed the isolated method. No production sync fix or original upstream failure cause is claimed.','Normal Debug21-method first-use variant passed before subsequent empty-library and erasure-preview changes; source snapshots reproduce its original input hashes. Current optimized and TSAN are separately pinned ac5bf82.','Original and new290performance observations remain separate, all outliers retained. Deferred first-use cost is reported rather than hidden.','Earlier owner/peer broad WIP failures are outside this selected scope and remain tracked.']}
(out/'qualification-reviewed-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items() if k not in ['stages','development','package','notes']}));print('stages',[(k,v['defined'],v['statuses'],v['skipCategories']) for k,v in stages.items()])
