from pathlib import Path
import json,hashlib,subprocess,zipfile
out=Path(__file__).resolve().parent;r=out.parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
qualification=json.loads((out/'qualification-reviewed-v1.json').read_text());bench=json.loads((out/'benchmarks-reviewed-v1.json').read_text());assert qualification['selectedQualificationPassed']
source=qualification['source'];public=r/'benchmarks/recorded-meetings-startup-v1.json';raw=r/'benchmarks/recorded-meetings-startup-raw-v1.zip';ci=r/'benchmarks/recorded-meetings-ci-selection-v2.json'
for p in [public,raw,ci]:assert not p.exists(),p
protected={}
for path in ['docs/features.json','docs/desktop-memory-landscape-2026-11-03.html']:
 prior=subprocess.check_output(['git','show','2a6034d:'+path],cwd=r);assert (r/path).read_bytes()==prior;protected[path]=sha(prior)
changed=subprocess.check_output(['git','diff','--name-only','2a6034d',source,'--','Sources','Tests','.github/workflows/ci.yml'],text=True,cwd=r).splitlines()
for path in changed:
 blob=subprocess.check_output(['git','show',source+':'+path],cwd=r);destination=out/'source-ac5bf82'/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(blob)
files=[];skip={'corpora','trials','frozen-eager-v1','frozen-lazy-v1','frozen-lazy-tsan-v1','OSwind.app','frozen-normal-release-v1','owned-package-smoke','__pycache__'}
for p in sorted(out.rglob('*')):
 if not p.is_file():continue
 relative=p.relative_to(out)
 if any(part in skip for part in relative.parts[:-1]):continue
 if p.suffix.lower() not in {'.json','.log','.txt','.py','.swift','.yml','.stdout','.stderr'}:continue
 files.append((str(relative),p.read_bytes()))
manifest={'source':source,'scope':'Generated observations and source/log/input/package receipts. Large generated databases, model caches and frozen executables stay local; hashes and generator are included.','entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in files]}
with zipfile.ZipFile(raw,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
 for name,data in files:archive.writestr(name,data)
 archive.writestr('raw-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(raw) as archive:
 assert archive.testzip() is None and len(archive.namelist())==len(files)+1
 for item in manifest['entries']:assert sha(archive.read(item['path']))==item['sha256']
receipt={'format':'Recorded meeting deferred-index component qualification v1','source':source,'date':'2026-11-03 America/Los_Angeles','selectedQualificationPassed':True,'fullCurrentSuiteQualified':False,'v0FeatureComplete':False,'hostedCIObserved':False,'scope':bench['scope'],'qualification':qualification,'benchmark':bench,'protectedExistingArtifacts':protected,'rawArchive':{'path':str(raw.relative_to(r)),'bytes':raw.stat().st_size,'members':len(files)+1,'sha256':sha(raw.read_bytes())}}
public.write_text(json.dumps(receipt,indent=2)+'\n')
ciData=json.loads((out/'deferred-ci-static-review-v1.json').read_text());ciData['localSourceSelection']={name:stage['recordedCISelection'] for name,stage in qualification['stages'].items()};ci.write_text(json.dumps(ciData,indent=2)+'\n')
def cell(corpus,product,operation):return next(v for v in bench['reports']['lazy']['cells'] if v['corpus']==corpus and v['product']==product and v['operation']==operation)
rows=[]
for corpus,label in [('live20k','20,000 short clips'),('imports256','256 long saved transcripts')]:
 a=cell(corpus,'eager','first-open');b=cell(corpus,'lazy','first-open');pa=cell(corpus,'eager','first-recordings-page-including-backfill-if-pending');pb=cell(corpus,'lazy','first-recordings-page-including-backfill-if-pending')
 rows.append(f"| {label} | {a['medianMs']:.3f} → {b['medianMs']:.3f} | {pa['medianMs']:.3f} → {pb['medianMs']:.3f} | {a['maxMs']:.3f} → {b['maxMs']:.3f} |")
summary=(out/'publish-template-v2.txt').read_text().replace('@@ROWS@@','\n'.join(rows))
doc=r/'docs/RECORDED-MEETINGS-WIP.md';text=doc.read_text();old='Initial installation/repair still scans audio payloads to build this index; its large-archive cost has not yet been benchmarked.';assert text.count(old)==1
text=text.replace(old,'Opening/repair installs the cache and write-through triggers without a historical transcript scan. The first Recordings load builds historical metadata in its cancellable worker; measured first-use and steady-state costs are reported below.')
replacements={
'- [ ] Initial cache installation/repair, large-archive metadata-page time and memory measurements; evaluate lazy first-use backfill if opening cost is material.':'- [x] Measure first-open/first-use metadata costs and move historical backfill into the cancellable Recordings load; retain all process latency/RSS observations.',
'- [ ] Portable backup/restore and wider incoming/erase/privacy regression for the derived index.':'- [x] Generated portable backup/restore, incoming-origin projection/deletion and current privacy/erasure regression for the derived index.',
'- [ ] Current source sanitizer, optimized, broader app/source-lifecycle regression and release packaging.':'- [x] Selected current source optimized/sanitizer regression and strict ad-hoc development packaging; whole-current-suite and hosted qualification remain open.\n- [ ] Controlled session-ID length/NUL edge cases, incoming-change UI invalidation and actual list-publication/frame-cost audit.'}
for old,new in replacements.items():assert text.count(old)==1;text=text.replace(old,new)
doc.write_text(text+summary)
progress=r/'docs/PROGRESS.md';before=progress.read_text();entry=(out/'progress-template-v2.txt').read_text()
if before.startswith('# '):split=before.index('\n')+1;progress.write_text(before[:split]+'\n'+entry+before[split:].lstrip('\n'))
else:progress.write_text(entry+before)
for path,digest in protected.items():assert sha((r/path).read_bytes())==digest
record={'source':source,'receipt':str(public.relative_to(r)),'raw':receipt['rawArchive'],'ci':str(ci.relative_to(r)),'protectedExistingArtifacts':protected,'docUpdated':str(doc.relative_to(r)),'progressUpdated':str(progress.relative_to(r))}
(out/'publish-review-v2.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
