from pathlib import Path
import json,hashlib,subprocess,struct,plistlib
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];old=b/'normal-names-package-v1';app=old/'OSwind.app';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins=json.loads((b/'retained-names-current-optimized-regression-v1/inputs.json').read_text())
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']

def code(p):
 data=p.read_bytes();assert struct.unpack_from('<I',data)[0]==0xfeedfacf
 n=struct.unpack_from('<I',data,16)[0];offset=32
 for _ in range(n):
  cmd,size=struct.unpack_from('<II',data,offset)
  if cmd==0x19:
   sections=struct.unpack_from('<I',data,offset+64)[0]
   for i in range(sections):
    pos=offset+72+i*80;name=data[pos:pos+16].split(b'\0')[0];segment=data[pos+16:pos+32].split(b'\0')[0]
    if name==b'__text' and segment==b'__TEXT':
     length=struct.unpack_from('<Q',data,pos+40)[0];start=struct.unpack_from('<I',data,pos+48)[0];return {'bytes':length,'sha256':hashlib.sha256(data[start:start+length]).hexdigest()}
  offset+=size
 raise AssertionError('No executable text section')
check();record={'source':pins['source'],'scope':'Same actual fresh normal-release app from v1; corrected postbuild harness, no rebuild or repeated passed CLI commands. Strict ad-hoc signing is development packaging, not notarization/distribution or physical/interactive acceptance.','app':str(app),'rebuild':False,'originalHarnessFailure':json.loads((old/'postbuild-harness-failure-v1.json').read_text()),'inputsAndAllPriorActualEnginesUnchanged':True,'executables':{},'smoke':{}}
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 p=app/'Contents/MacOS'/name;product=r/'.build/release'/name;assert code(p)==code(product)
 record['executables'][name]={'packagedSHA256':sha(p),'buildProductSHA256':sha(product),'textSection':code(p),'bytes':p.stat().st_size}
with (out/'signature-verify.log').open('xb') as f:subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,stdout=f,stderr=subprocess.STDOUT)
info=plistlib.loads((app/'Contents/Info.plist').read_bytes());assert info['CFBundleIdentifier']=='com.oswind.desktop'
for key in ['NSCalendarsFullAccessUsageDescription','NSMicrophoneUsageDescription','NSScreenCaptureUsageDescription','NSAppleEventsUsageDescription']:assert info.get(key)
for name in ['NOTICES.txt','Apache-2.0.txt']:assert (app/'Contents/Resources/ThirdParty'/name).is_file()
values=json.loads((old/'literal-keyword.stdout').read_bytes());created=(old/'authored-note.stdout').read_text().strip();assert len(values)==1 and values[0]['match']=='keyword';memory=values[0]['memory'];assert memory['id']==created and memory['kind']=='note' and 'signedpackagedsentinel' in memory['text']
for label in ['empty-stats','authored-note','literal-keyword']:
 record['smoke'][label]={'exitCode':0,'scope':'Original command passed the v1 invoke return-code assertion; outputs retained, command not repeated.','stdoutSHA256':sha(old/(label+'.stdout')),'stderrSHA256':sha(old/(label+'.stderr'))}
record['smoke']['exactAuthoredIDMatchesKeywordResult']=True
record['resources']=[{'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((app/'Contents/Resources').rglob('*')) if p.is_file()]
archive=out/'OSwind-recording-names-development.zip';subprocess.run(['ditto','-c','-k','--sequesterRsrc','--keepParent',str(app),str(archive)],check=True,cwd=r)
record['developmentArchive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)};check();record['exitCode']=0;(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['resources','executables']}))
