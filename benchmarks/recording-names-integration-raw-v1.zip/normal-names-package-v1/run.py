from pathlib import Path
import json,hashlib,subprocess,time,os,struct,plistlib,shutil
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=b/'retained-names-current-optimized-regression-v1';gate=json.loads((prior/'result.json').read_text());assert gate['exitCode']==0
pins=json.loads((prior/'inputs.json').read_text())
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']
def code(p):
 data=p.read_bytes();assert struct.unpack_from('<I',data)[0]==0xfeedfacf
 n=struct.unpack_from('<I',data,16)[0];offset=32
 for _ in range(n):
  cmd,size=struct.unpack_from('<II',data,offset)
  if cmd==0x19:
   sections=struct.unpack_from('<I',data,offset+64)[0]
   for i in range(sections):
    pos=offset+72+i*80;name=data[pos:pos+16].split(b'\0')[0];segment=data[pos+16:pos+32].split(b'\0')[0]
    if name==b'__text' and segment==b'__TEXT':
     length=struct.unpack_from('<Q',data,pos+40)[0];start=struct.unpack_from('<I',data,pos+48)[0];return {'bytes':length,'sha256':hashlib.sha256(data[start:start+length]).hexdigest()}
  offset+=size
 raise AssertionError('No executable text section')
check();assert shutil.disk_usage(out).free>=16*1024**3;app=out/'OSwind.app';assert not app.exists();env=os.environ.copy();env.update({'OSWIND_APP_OUTPUT':str(app),'OSWIND_BUILD_ROOT':str(r/'.build')});started=time.monotonic()
with (out/'build.log').open('xb') as log:p=subprocess.run(['bash','scripts/build-app.sh','release'],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
check();record={'source':pins['source'],'previousTestRuntimeSource':pins['actualRuntimeSource'],'scope':'Fresh normal release app packaging with strict ad-hoc signing; not notarized distribution or physical/interactive acceptance. This normal build has a packaging purpose, not a provenance rebuild of earlier tests.','command':['bash','scripts/build-app.sh','release'],'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started,'inputsAndAllPriorActualEnginesUnchanged':True,'buildLogSHA256':sha(out/'build.log'),'app':str(app)}
if p.returncode:
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(p.returncode)
files={}
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 packaged=app/'Contents/MacOS'/name;original=r/'.build/release'/name;assert code(packaged)==code(original)
 files[name]={'packagedSHA256':sha(packaged),'unsignedBuildProductSHA256':sha(original),'textSection':code(packaged),'packagedBytes':packaged.stat().st_size}
record['executables']=files
with (out/'signature-verify.log').open('xb') as log:subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,stdout=log,stderr=subprocess.STDOUT)
info=plistlib.loads((app/'Contents/Info.plist').read_bytes());assert info['CFBundleIdentifier']=='com.oswind.desktop'
for key in ['NSCalendarsFullAccessUsageDescription','NSMicrophoneUsageDescription','NSScreenCaptureUsageDescription','NSAppleEventsUsageDescription']:assert info.get(key)
for name in ['NOTICES.txt','Apache-2.0.txt']:assert (app/'Contents/Resources/ThirdParty'/name).is_file()
cli=app/'Contents/MacOS/oswindctl';owned=out/'owned-cli-smoke';assert not owned.exists()
def invoke(label,args):
 start=time.monotonic();p=subprocess.run([str(cli),'--data',str(owned),*args],cwd=r,capture_output=True)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(label,p.returncode)
 return {'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()},p.stdout
record['smoke']={}
record['smoke']['emptyStats'],_=invoke('empty-stats',['stats'])
record['smoke']['authoredNote'],_=invoke('authored-note',['note','Authored signedpackagedsentinel for an owned package smoke test. No captured data.'])
record['smoke']['literalKeyword'],data=invoke('literal-keyword',['search','--mode','keyword','--literal','signedpackagedsentinel','--json'])
values=json.loads(data);assert isinstance(values,list) and len(values)==1 and 'signedpackagedsentinel' in values[0]['text'];record['smoke']['sourceCount']=len(values)
record['resources']=[{'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((app/'Contents/Resources').rglob('*')) if p.is_file()]
check();(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['resources','executables']}))
