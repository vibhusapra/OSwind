from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();base=root/'.artifacts/sync-membership-backfill-v1';frozenbase=root/'.artifacts/sync-membership-floor-v1';out=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();target=out/'reviewed-v1.json';assert not target.exists()
inputs=json.loads((out/'inputs.json').read_text());results=json.loads((out/'results.json').read_text());expected_base='01af1f470034ddbfabaff6c8014ce48db38b8e23'
assert inputs['baseSource']==results['baseSource']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected_base
assert len(inputs['inputFiles'])==687 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert sha(out/'inputs.json')==results['inputManifestSHA256'] and results['runnerSHA256']==sha(base/'qualify-v1.py') and len(inputs['workingChanges'])==9
listing=out/'discovered-tests.txt';discovery={line.replace('/','.') for line in listing.read_text().splitlines() if re.fullmatch(r'OSwind(?:Core|App)Tests\.\w+/test\w+',line)};assert len(discovery)==2691
classes=['SyncMembershipPreparationTests','SyncMembershipCrashTests','SyncMembershipFloorTests','SyncMembershipBackfillTests','SyncMembershipBackfillCrashTests','SyncMembershipBackfillNativeTests'];expected=set()
for cls in classes:
 for method in re.findall(r'func (test\w+)\(', (root/('Tests/OSwindCoreTests/'+cls+'.swift')).read_text()):expected.add('OSwindCoreTests.'+cls+'.'+method)
assert len(expected)==43
old=set()
for cls in classes:
 path='Tests/OSwindCoreTests/'+cls+'.swift'
 if subprocess.run(['git','cat-file','-e',expected_base+':'+path],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:
  prior=subprocess.check_output(['git','show',expected_base+':'+path],text=True)
  old.update('OSwindCoreTests.'+cls+'.'+method for method in re.findall(r'func (test\w+)\(',prior))
assert len(old)==30 and old<=expected
new=expected-old;assert len(new)==13
workers={'OSwindCoreTests.SyncMembershipCrashTests.testOwnedMembershipCrashWorker','OSwindCoreTests.SyncMembershipBackfillCrashTests.testOwnedMembershipBackfillCrashWorker'};parents={'OSwindCoreTests.SyncMembershipCrashTests.testOwnedProcessDeathAtFiveHandoverBoundariesRecoversExactForwardChoice','OSwindCoreTests.SyncMembershipBackfillCrashTests.testOwnedProcessDeathAtSixFloorBoundariesPreservesExactForwardChoice'}
keychains={'OSwindCoreTests.SyncMembershipPreparationTests.'+m for m in ['testOwnedNativeKeychainPreparationReopensAndCancelsOriginalAccounts','testOwnedNativeKeychainHandoverReopensNewMembershipWithOriginalAccounts']}
assert [s['name'] for s in results['stages']]==['full-debug','affected-tsan','affected-optimized','owned-native','owned-membership-tsan','owned-membership-optimized']
old36='OSwindCoreTests.SyncMembershipFloorTests.testOwnedFrozen36AdmitsLegacyButRefusesCompletedReplayFormat'
old36_marker='FROZEN36_FORMAT_FLOOR legacyAdmittedAndWritten=true cachedWriterFenced=true completedFormat2FreshRefused=true pendingReplayPresent=true retirementPreservedFloorAndClearedReplay=true originalAccountsCleaned=4'
backfill='OSwindCoreTests.SyncMembershipBackfillNativeTests.testOwnedFrozen36CachedWriterFencedAfterRejectedBackfillCommitAndExactRecovery'
backfill_marker='FROZEN36_BACKFILL_FLOOR legacyAdmittedAndWritten=true rejectedCommitRecoveredExactToken=true preFenceCapturePreserved=true cachedWriterFenced=true completedFormat2FreshRefused=true pendingReplayPreserved=true retirementPreservedFloorAndClearedReplay=true originalAccountsCleaned=4'
phases=['decision','pairing','delivery','commit','clear'];backfill_phases=['before-intent','intent','before-commit','commit','before-clear','clear']
profiles={
 'full-debug':(['swift','test'],{}),
 'affected-tsan':(['swift','test','--sanitize=thread','--filter','Sync|LibraryRecovery|PersonalSync'],{}),
 'affected-optimized':(['swift','test','-c','release','--filter','Sync|LibraryRecovery|PersonalSync'],{}),
 'owned-native':(['swift','test','--filter','SyncMembership|SyncCredentialMaterial|SyncPairingTests|SyncNativeWriterAdmission|SyncNativeReceivedRetirement|SyncDeliveryAnchor|LibraryRecovery'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_NATIVE_VAULT':'1'}),
 'owned-membership-tsan':(['swift','test','--sanitize=thread','--filter','SyncMembership'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),
 'owned-membership-optimized':(['swift','test','-c','release','--filter','SyncMembership'],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'})}
def validate(stage,text):
 assert (stage['command'],stage['environment'])==profiles[stage['name']]
 assert 'WARNING: ThreadSanitizer:' not in text
 if 'tsan' not in stage['name']:assert 'OWNED_SYNC_APP_READY sanitizer=true' not in text
 raw=re.findall(r"Test Case '-\[(\w+\.\w+) (test\w+)\]' (passed|skipped|failed)",text);states={a+'.'+b:v for a,b,v in raw};assert len(states)==len(raw)
 summaries=re.findall(r'Executed (\d+) tests?, with (?:(\d+) tests? skipped and )?(\d+) failures?',text);assert summaries
 count=summaries[-1];assert int(count[0])==len(states) and int(count[1] or 0)==sum(v=='skipped' for v in states.values()) and int(count[2])==0 and all(v in ['passed','skipped'] for v in states.values())
 selected=discovery if stage['name']=='full-debug' else {name for name in discovery if re.search(stage['command'][-1],name)};assert set(states)==selected
 assert expected<=set(states)
 owned=stage['name'].startswith('owned-')
 assert all(states[m]=='passed' for m in expected-(keychains|workers|parents|{old36,backfill}))
 assert all(states[w]=='skipped' for w in workers) and all(states[n]==('passed' if owned else 'skipped') for n in parents|{old36,backfill})
 assert text.count(old36_marker)==(1 if owned else 0) and text.count(backfill_marker)==(1 if owned else 0)
 assert all(states[m]==('passed' if owned else 'skipped') for m in keychains)
 assert text.count('NATIVE36_FROZEN35_FENCE positive33=true waitingBeforeEnrollmentRefused=true fresh36Refused=true originalBinaryUnchanged=true')==1
 for phase in phases:assert text.count('OWNED_MEMBERSHIP_PROCESS_DEATH phase='+phase+' signal=9 forwardRecovered=true originalAccounts=4 cleaned=true')==(1 if owned else 0)
 for phase in backfill_phases:assert text.count('OWNED_BACKFILL_PROCESS_DEATH phase='+phase+' signal=9 exactForwardRecovered=true replayPreserved=true originalAccounts=4 cleaned=true')==(1 if owned else 0)
 if owned:assert {n for n,v in states.items() if v=='skipped'}==workers,'Inspect any unexpected owned skip explicitly'
 return states
review=[];texts={}
for stage in results['stages']:
 log=root/stage['log'];assert stage['exit']==0 and sha(log)==stage['sha256'];text=log.read_text();states=validate(stage,text);texts[stage['name']]=text
 review.append({'mode':stage['name'],'defined':len(states),'passed':sum(v=='passed' for v in states.values()),'skipped':[name for name,v in states.items() if v=='skipped'],'failed':0,'newBackfillMethods':{n:states[n] for n in sorted(new)},'allFocusedMembershipAndBackfillMethods':{n:states[n] for n in sorted(expected)},'logSHA256':sha(log),'wallSeconds':stage['wallSeconds']})
# Mutated in-memory logs must be rejected; never rerun successful product tests.
regular=results['stages'][0];native=results['stages'][3];text=texts[regular['name']];case=re.search(r"Test Case '-\[\w+\.\w+ test\w+\]' passed[^\n]*",text).group(0)
faults={'duplicate-outcome':(regular,text+'\n'+case),'dropped-outcome':(regular,text.replace(case,'',1)),'hidden-skip':(regular,text.replace(case,case.replace(' passed',' skipped'),1)),'race-warning':(regular,text+'\nWARNING: ThreadSanitizer: injected invalid log'),'wrong-summary':(regular,re.sub(r'Executed 2691 tests,','Executed 2690 tests,',text)),'missing-owned-kill-gate':(native,texts[native['name']].replace('OWNED_MEMBERSHIP_PROCESS_DEATH phase=commit signal=9 forwardRecovered=true originalAccounts=4 cleaned=true','MISSING_GATE'))}
faults['missing-old36-format-control']=(native,texts[native['name']].replace(old36_marker,'MISSING_OLD36_CONTROL'))
faults['missing-backfill-kill-gate']=(native,texts[native['name']].replace('OWNED_BACKFILL_PROCESS_DEATH phase=before-intent signal=9 exactForwardRecovered=true replayPreserved=true originalAccounts=4 cleaned=true','MISSING_BACKFILL_GATE'))
faults['missing-backfill-old36-control']=(native,texts[native['name']].replace(backfill_marker,'MISSING_BACKFILL_OLD36'))
for label,(stage,changed) in faults.items():
 try:validate(stage,changed)
 except AssertionError:pass
 else:raise AssertionError('Fault control accepted '+label)
stage_faults={'narrowed-selection':{**native,'command':['swift','test','--filter','SyncMembershipBackfill']},'missing-owned-native-environment':{**native,'environment':{}}}
for label,changed in stage_faults.items():
 try:validate(changed,texts[native['name']])
 except AssertionError:pass
 else:raise AssertionError('Invalid stage accepted '+label)
readiness=re.findall(r'OWNED_SYNC_APP_READY sanitizer=true timeoutSeconds=120 elapsedSeconds=([0-9.eE+-]+) phase=(\w+)',texts['affected-tsan']);assert readiness
result={'instrumentedAppReadiness':{'observations':len(readiness),'overOriginal20Seconds':sum(float(seconds)>20 for seconds,phase in readiness),'maxSeconds':max(float(seconds) for seconds,phase in readiness),'normalBudgetSeconds':20,'instrumentedBudgetSeconds':120},'format':'OSwind recoverable membership format backfill qualification review v1','baseSource':inputs['baseSource'],'inputCount':687,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'discoverySHA256':sha(listing),'stages':review,'rejectedInMemoryLogFaults':list(faults),'rejectedInMemoryStageFaults':list(stage_faults),'inheritedBaseline':'PR146 and its frozen receipt retain actual unmodified d665a30 admission/writer baseline. This component reuses that exact frozen engine (679 original inputs plus one test-only harness); no older product source/bundle file is edited, rebuilt or resigned.',
'scope':'Already-cleared format1 previews migrate only through an owned exact one-token writer-generation fence in original accounts. Qualifies replay/raw capture/private material/provider preservation, rejected COMMIT and pre-fence capture, ambiguous save/clear recovery, active2 no-op, cancellation before intent and joined uncancelled completion/close after intent, six real process-death boundaries, actual old36 positive admission/cache/fresh refusal and retirement renewal. Legacy initial snapshots are authored old652 format1 states. Public owner-add exact response/session/UI, removal/epoch rotation, remote client negotiation, large/offline/provider-retention, production DP-Keychain, live GUI, physical two-Mac/provider, energy, notarization and whole-product ranking remain open; F059 stays TODO.'}
frozen=json.loads((frozenbase/'frozen36-manifest-v2.json').read_text());assert sha(frozenbase/'frozen36-manifest-v2.json')==results['frozen36ManifestSHA256']
assert frozen['originalRuntime']=='d665a30196b1609a2248cc1550fe3f817b3f8277' and frozen['originalInputCount']==679 and frozen['executableSHA256']=='80a09cbd70547dc61b1834bd6ef2f20a5867852a9b73ab38030391d0ac7959de'
assert results['frozen36Engine']=={k:frozen[k] for k in ['originalRuntime','originalInputCount','workerSHA256','executableSHA256','files']}
assert all(sha(Path(frozen['bundle'])/p)==h for p,h in frozen['files'].items())
original=json.loads((frozenbase/'frozen36-original-inputs-v1.json').read_text());assert len(original['inputFiles'])==679 and all(sha(frozenbase/'frozen36-build-v1'/p)==h for p,h in original['inputFiles'].items())
assert sha(frozenbase/'frozen36-build-v1/Tests/OSwindCoreTests/SyncNative36FrozenWorkerTests.swift')==frozen['workerSHA256']
linkage=frozenbase/'frozen36-linkage-v1.txt';dependencies=[line.strip().split(' (compatibility version')[0] for line in linkage.read_text().splitlines()[1:] if line.strip()]
assert dependencies and all(value.startswith(('/System/Library/','/usr/lib/','@rpath/libswift','/Applications/Xcode.app/','@rpath/Testing.framework/','@rpath/libXCTestSwiftSupport.dylib')) for value in dependencies)
result['frozen36LinkageSHA256']=sha(linkage)
result['frozen36Engine']=results['frozen36Engine'];result['frozen36ManifestSHA256']=results['frozen36ManifestSHA256']
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'review':str(target.relative_to(root)),'sha256':sha(target),'faultControls':list(faults),'stages':[{'mode':s['mode'],'defined':s['defined'],'passed':s['passed'],'skipped':len(s['skipped'])} for s in review]}))
