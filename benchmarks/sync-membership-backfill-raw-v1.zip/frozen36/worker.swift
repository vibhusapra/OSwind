import XCTest
import Foundation
import CSQLite
@testable import OSwindCore

/// Test-only entrypoint linked to unmodified d665a30 product sources.
final class SyncNative36FrozenWorkerTests:XCTestCase {
    func testOwnedNative36Worker()throws {
        let env=ProcessInfo.processInfo.environment,fm=FileManager.default
        guard let path=env["OSWIND_OLD36_ROOT"],let nonce=env["OSWIND_OLD36_NONCE"],let mode=env["OSWIND_OLD36_MODE"] else {throw XCTSkip("Owned frozen36 worker only")}
        guard UUID(uuidString:nonce)?.uuidString==nonce,["open","cached","refuse"].contains(mode) else {throw OSwindError.invalid("Invalid owned frozen36 scope")}
        let root=URL(fileURLWithPath:path),expected=fm.temporaryDirectory.appendingPathComponent("owned-membership-floor-"+nonce)
        guard root.resolvingSymlinksInPath()==expected.resolvingSymlinksInPath(),try String(contentsOf:root.appendingPathComponent("owner"),encoding:.utf8)==nonce else {throw OSwindError.invalid("Invalid owned frozen36 root")}
        let ids=try SyncPairingFormat.decode([String].self,Data(contentsOf:root.appendingPathComponent("accounts")),limit:1024)
        guard ids.count==4,Set(ids).count==4 else {throw OSwindError.invalid("Invalid frozen36 account inventory")};try ids.forEach {try SyncProtocolLimits.uuid($0)}
        let storage=Frozen36ReadStorage(ids:Set(ids)),native=SyncNativeWriterEnvironment(stateRoot:root.appendingPathComponent("state"),machine:MacSyncMachineFingerprint(),storage:{_ in storage})
        if mode=="refuse" {
            do {let library=try MemoryStore(root:root.appendingPathComponent("peer"),recoveryReadOnly:false,nativeWriterEnvironment:native);try library.close();XCTFail("Frozen36 accepted a replay-aware state")}
            catch {guard String(describing:error).contains("Invalid native membership phase") else {throw error};try Data("state-format-refused".utf8).write(to:root.appendingPathComponent("result-refuse"),options:.withoutOverwriting)}
            return
        }
        let library=try MemoryStore(root:root.appendingPathComponent("peer"),recoveryReadOnly:false,nativeWriterEnvironment:native);defer {try? library.close()}
        XCTAssertNotNil(try library.get("canary"))
        if mode=="open" {try Data("admitted".utf8).write(to:root.appendingPathComponent("result-open"),options:.withoutOverwriting);return}
        let db=try library.withRoutineDatabase {$0},statement=try db.statement("UPDATE memories SET title=? WHERE id='canary'");defer {sqlite3_finalize(statement)}
        db.bind(statement,1,"old36-positive");XCTAssertEqual(sqlite3_step(statement),SQLITE_DONE);sqlite3_reset(statement);sqlite3_clear_bindings(statement)
        XCTAssertEqual(sqlite3_get_autocommit(db.handle),1)
        let lease=try MediaAdmissionLease.acquire(root:library.root,exclusive:false,expectedRoot:library.mediaRootIdentity);defer {lease.release()}
        try Data("admitted-written-prepared".utf8).write(to:root.appendingPathComponent("ready-cached"),options:.withoutOverwriting)
        let deadline=ProcessInfo.processInfo.systemUptime+60
        while !fm.fileExists(atPath:root.appendingPathComponent("release-cached").path),ProcessInfo.processInfo.systemUptime<deadline {Thread.sleep(forTimeInterval:0.01)}
        guard fm.fileExists(atPath:root.appendingPathComponent("release-cached").path) else {throw OSwindError.invalid("Owned frozen36 release missing")}
        db.bind(statement,1,"old36-must-refuse");XCTAssertNotEqual(sqlite3_step(statement),SQLITE_DONE)
        XCTAssertThrowsError(try library.insert(Memory(id:"old36-must-refuse",text:"Must not enter the updated lifetime")))
        try Data("cached-and-normal-refused".utf8).write(to:root.appendingPathComponent("result-cached"),options:.withoutOverwriting)
    }
}
private struct Frozen36ReadStorage:SyncCredentialStorage {
    let protection:SyncCredentialProtection = .loginKeychain
    let ids:Set<String>
    private let backend=SyncKeychainCredentialStorage(protection:.loginKeychain)
    init(ids:Set<String>) {self.ids=ids}
    func read(id:String)throws->Data {guard ids.contains(id) else {throw OSwindError.invalid("Unowned frozen36 account")};return try backend.read(id:id)}
    func create(id:String,bytes:Data)throws {throw OSwindError.invalid("Frozen36 cannot create credentials")}
    func replace(id:String,expected:Data,bytes:Data)throws {throw OSwindError.invalid("Frozen36 cannot replace credentials")}
    func remove(id:String,expected:Data)throws {throw OSwindError.invalid("Frozen36 cannot remove credentials")}
}
