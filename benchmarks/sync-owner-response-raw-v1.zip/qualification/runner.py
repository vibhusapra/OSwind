from pathlib import Path
import hashlib,json,os,platform,subprocess,time

root=Path.cwd();base=root/'.artifacts/sync-owner-response-v1';out=base/'qualification-v2';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='9cefb02a588bfd107c94617319881bb73748b6c4'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines()
pins={p:sha(root/p) for p in sorted(set(paths)) if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved']) and (root/p).is_file()}
changes=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()))
assert len(pins)==698 and len(changes)==10 and all(p.startswith(('Sources/','Tests/')) for p in changes)
manifest={'format':'OSwind durable initial joining response inputs v2','baseSource':head,'inputFiles':pins,'workingChanges':{p:sha(root/p) for p in changes},'scope':'Initial pre-delivery approval exact encrypted response, signed binding, atomic original-account pointer, explicit UI recovery/expiry and legacy reissue. Post-delivery owner addition/completed delivery receipt and full sync remain unfinished.'}
manifest['retainedStoppedRun']={'inputsSHA256':sha(base/'qualification-v1/inputs.json'),'resultsSHA256':sha(base/'qualification-v1/results.json'),'stopReceiptSHA256':sha(base/'qualification-stopped-v1.json'),'scope':'Original full-debug stopped unfinished for exact-addition invariant fix; no full-suite pass claimed. Public clock now live inside owner and final private-boundary expiry rechecked.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
broad='Sync|PersonalSync|LibraryWipe|LibraryRecovery'
owned='SyncOwnerApproval|PersonalSyncApprovedResponseTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably'
ownedRelease='SyncOwnerApproval|PersonalSyncApprovedResponseTests|PersonalSyncPairingTests|PersonalSyncPairingModelTests|SyncMembershipPreparationTests'
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',broad],{}),('owned-response-tsan',['swift','test','--skip-build','--sanitize=thread','--filter',owned],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),('affected-optimized',['swift','test','-c','release','--filter',broad],{}),('owned-response-optimized',['swift','test','-c','release','--skip-build','--filter',ownedRelease],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,command,extra in stages:
    assert all(sha(root/p)==h for p,h in pins.items());print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb') as f:rc=subprocess.run(command,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT).returncode
    results['stages'].append({'name':name,'command':command,'environment':extra,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)})
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in pins.items())
    if rc:raise SystemExit(rc)
print('QUALIFICATION_COMPLETE',flush=True)
