from pathlib import Path
import hashlib,json,re,math,subprocess

root=Path.cwd();base=root/'.artifacts/sync-owner-response-v1';run=base/'qualification-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());result=json.loads((run/'results.json').read_text())
assert len(inputs['inputFiles'])==698 and len(inputs['workingChanges'])==10
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert result['baseSource']==inputs['baseSource']=='9cefb02a588bfd107c94617319881bb73748b6c4'
assert result['inputManifestSHA256']==sha(run/'inputs.json') and result['runnerSHA256']==sha(base/'qualify-v2.py')
prior=json.loads((root/'benchmarks/native-raster-fit-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==694
assert len(set(inputs['inputFiles'])-set(prior))==4 and sum(inputs['inputFiles'][p]==h for p,h in prior.items())==688
stopped=inputs['retainedStoppedRun']
assert stopped['inputsSHA256']==sha(base/'qualification-v1/inputs.json') and stopped['resultsSHA256']==sha(base/'qualification-v1/results.json') and stopped['stopReceiptSHA256']==sha(base/'qualification-stopped-v1.json')
assert json.loads((base/'qualification-stopped-v1.json').read_text())['state']=='stopped-unfinished'
pattern=re.compile(r"^Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)",re.M)
def rows(text):
    found=[(a+'.'+b,c) for a,b,c in pattern.findall(text)]
    assert len(found)==len(set(a for a,b in found))
    return dict(found)
def inspect(text,expected):
    found=rows(text);assert found==expected
    counts={k:list(found.values()).count(k) for k in ['passed','failed','skipped']}
    assert counts['failed']==0 and counts['passed']>0
    summary=f"Executed {len(found)} tests, with {counts['skipped']} tests skipped and 0 failures" if counts['skipped']!=1 else f"Executed {len(found)} tests, with 1 test skipped and 0 failures"
    if counts['skipped']==0:summary=f'Executed {len(found)} tests, with 0 failures'
    assert summary in text
    assert not any(s in text for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped')}
full=rows((run/'full-debug.log').read_text());assert len(full)==2731 and list(full.values()).count('passed')==2572 and list(full.values()).count('skipped')==159
required=set()
for name in ['SyncOwnerApprovalTests','PersonalSyncApprovedResponseTests','SyncOwnerApprovalCrashTests']:
    source=root/'Tests/OSwindCoreTests'/(name+'.swift')
    required|={'OSwindCoreTests.'+name+'.'+m for m in re.findall(r'func (test\w+)\(',source.read_text())}
required|={'OSwindAppTests.PersonalSyncPairingModelTests.'+name for name in ['testClosingSetupAndReopeningRecoversExactApprovalWithoutConnecting','testExplicitRecoveryWithoutApprovalReportsErrorAndCreatesNoCredentials','testDepartureJoinsActualBlockedResponseRecoveryDespiteCancellation','testOwnedApprovalRecoveryScreensRenderInBothThemes']}
assert len(required)==25
gated={'OSwindCoreTests.SyncOwnerApprovalCrashTests.testOwnedProcessDeathBeforeAfterSaveAndBeforeUIReturnRecoversResponse','OSwindCoreTests.SyncOwnerApprovalCrashTests.testOwnedApprovalCrashWorker','OSwindAppTests.PersonalSyncPairingModelTests.testOwnedApprovalRecoveryScreensRenderInBothThemes'}
assert all(full[k]==('skipped' if k in gated else 'passed') for k in required)
broad='Sync|PersonalSync|LibraryWipe|LibraryRecovery';owned='SyncOwnerApproval|PersonalSyncApprovedResponseTests|PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably';ownedRelease='SyncOwnerApproval|PersonalSyncApprovedResponseTests|PersonalSyncPairingTests|PersonalSyncPairingModelTests|SyncMembershipPreparationTests'
expectedCommands=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',broad],{}),('owned-response-tsan',['swift','test','--skip-build','--sanitize=thread','--filter',owned],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),('affected-optimized',['swift','test','-c','release','--filter',broad],{}),('owned-response-optimized',['swift','test','-c','release','--skip-build','--filter',ownedRelease],{'OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1'}),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(run/'OSwind.app')})]
assert [s['name'] for s in result['stages']]==[s[0] for s in expectedCommands]
reports=[];selections={}
for stage,(name,command,environment) in zip(result['stages'],expectedCommands):
    assert stage['name']==name and stage['command']==command and stage['environment']==environment and stage['exit']==0 and sha(root/stage['log'])==stage['sha256']
    assert root/stage['log']==run/(name+'.log') and math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ['debug-build-tests','release-build','package']:continue
    text=(root/stage['log']).read_text();expected=full if name=='full-debug' else {k:v for k,v in full.items() if re.search(broad if name.startswith('affected') else owned if name.endswith('tsan') else ownedRelease,k)}
    if name.startswith('owned'):
        # Explicit native account opt-in turns only the existing guarded native
        # methods into passes. Child-only workers and missing frozen-client/
        # component-render opt-ins remain honest skips; enumerate actual changes.
        observed=rows(text)
        assert set(observed)==set(expected)
        for k,v in observed.items():
            assert v==expected[k] or (expected[k]=='skipped' and v=='passed' and ('.testOwned' in k or '.testNative' in k))
        expected=observed
        for phase in ['before-save','after-save','after-return']:
            line=next(l for l in text.splitlines() if l.startswith('OWNED_APPROVAL_PROCESS_DEATH phase='+phase+' '))
            assert 'signal=9' in line and 'originalAccounts=2 cleaned=true' in line
            assert ('committedResponseExact=true' in line)==(phase!='before-save')
            assert ('beforeIntentOldStatePreserved=true' in line)==(phase=='before-save')
        assert observed['OSwindCoreTests.SyncOwnerApprovalCrashTests.testOwnedProcessDeathBeforeAfterSaveAndBeforeUIReturnRecoversResponse']=='passed'
        assert observed['OSwindCoreTests.SyncOwnerApprovalCrashTests.testOwnedApprovalCrashWorker']=='skipped'
        assert observed['OSwindCoreTests.PersonalSyncPairingTests.testOwnedNativeKeychainPairingSurvivesReopenAndConsumesResponseDurably']=='passed'
    summary=inspect(text,expected);selections[name]=expected
    reports.append({'mode':name,**summary,'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']})
assert selections['affected-tsan']==selections['affected-optimized']
assert all(selections[n][k]=='passed' for n in ['full-debug','affected-tsan','affected-optimized'] for k in required-gated)
text=(run/'affected-tsan.log').read_text();reference=selections['affected-tsan'];case=next(iter(required-gated));method=case.rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l);faults={}
for name,bad in {'drop-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'hidden-failure':text.replace(line,line.replace("' passed","' failed"),1),'missing-new-case':text.replace(method,'testWrongIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,reference)
    except (AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()}
assert {'Contents/MacOS/OSwind','Contents/MacOS/oswindctl','Contents/MacOS/oswind-preparation-guardian','Contents/Info.plist'}.issubset(files)
priorPackage=json.loads((root/'benchmarks/native-raster-fit-v1.json').read_text())['newPackage']['files']
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in priorPackage.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==priorPackage['Contents/Info.plist']
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
visualPath=base/'native-development-v1/visual-observation-v1.json';visual=json.loads(visualPath.read_text());assert len(visual['files'])==8 and all(sha(base/'native-development-v1'/p)==h for p,h in visual['files'].items())
review={'format':'OSwind durable initial joining response review v1','baseSource':inputs['baseSource'],'inputCount':698,'unchangedPriorInputs':688,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':result['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':reports,'newMethodIdentities':sorted(required),'newOrdinaryMethods':22,'newGatedMethods':sorted(gated),'alteredLogControls':faults,'retainedStoppedRun':stopped,'developmentVisualObservation':{'path':str(visualPath.relative_to(root)),'sha256':sha(visualPath),'scope':visual['nativeDevelopmentScope']},'newPackage':{'path':str(package),'files':files,'strictAdHocSignatureExit':signature.returncode,'allPriorResourcesAndBundleInfoUnchanged':True},'scope':'Initial approval exact response recovery only. FullDebug plus affected TSan/optimized, actual original-account SIGKILL/reopen in both owned modes, and fresh local ad-hoc package. Offscreen layouts are inherited development observations with unchanged UI/runtime display code, not final foreground GUI/keyboard/TCC acceptance. Public post-delivery owner-add session/drain/reconnect/completed-delivery-receipt remains disabled and unfinished. No physical twoMac/provider, fullsync, power/24h, notarized distribution, completev0 or topthree claim.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'inputCount':698,'stages':[{k:r[k] for k in ['mode','defined','passed','failed','skipped']} for r in reports],'alteredControls':len(faults),'reviewSHA256':sha(out)}))
