from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/sync-owner-response-v1';run=base/'qualification-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text())
assert review['reviewerSHA256']==sha(base/'review-v1.py') and review['inputManifestSHA256']==sha(run/'inputs.json')
assert len(review['alteredLogControls'])==5 and len(review['newMethodIdentities'])==25
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges'])
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputs['inputFiles'].items():
    p=root/path;b=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2]
        protected[path.decode()]=hashlib.sha256(b).hexdigest()
files={'qualification/inputs.json':run/'inputs.json','qualification/results.json':run/'results.json','qualification/review.json':reviewPath,'qualification/runner.py':base/'qualify-v2.py','qualification/reviewer.py':base/'review-v1.py','publisher.py':Path(__file__),'remaining/atomic-inbox-next.md':base/'atomic-inbox-next-v1.md','development/native-visual-observation.json':base/'native-development-v1/visual-observation-v1.json','development/native.log':base/'native-development-v1/native.log','retained/stopped-run.json':base/'qualification-stopped-v1.json','retained/stopped-inputs.json':base/'qualification-v1/inputs.json','retained/stopped-results.json':base/'qualification-v1/results.json','retained/stopped-runner.py':base/'qualify-v1.py','retained/stopped-full-debug.log':base/'qualification-v1/full-debug.log','retained/app-test-before-lease-assertion-fix.swift':base/'app-tests-before-owned-lease-assertion.swift'}
for stage in json.loads((run/'results.json').read_text())['stages']:files['qualification/logs/'+stage['name']+'.log']=root/stage['log']
for index in range(1,8):files['development/development-v'+str(index)+'.log']=base/('development-v'+str(index)+'.log')
for path in inputs['workingChanges']:files['source/'+path]=root/path
for p in (base/'native-development-v1/render').iterdir():
    assert p.suffix in ['.png','.txt'] and p.is_file()
    files['development/render/'+p.name]=p
payload={name:path.read_bytes() for name,path in files.items()}
payload['README.txt']=(f'OSwind durable INITIAL joining response runtime {source}.698 committed runtime/test/dependency inputs;688 preceding inputs unchanged;10 changed files. Full Debug2572pass159conditional skips0fail; see independently reviewed affected/owned TSan and optimized totals.25new identities:22ordinary methods plus native parent/child and component-render gates. Real original-account native response SIGKILL gates run in owned TSan/optimized at final source; child-only worker stays skipped when not directly invoked. Before-save preserves old private membership; after-save and after-return recover exact saved ciphertext digest/length; two original owned Keychain accounts cleaned. Initial plan root signature binds exact request, actual added member, predecessor/successor, ciphertext, group/epoch, account/lifetime and original time. The public API uses live clock inside ownership and rechecks expiry at the private boundary; deterministic clocks internal only. Exact initial membership+response pointer commits in one original account CAS. Explicit recovery never regenerates or extends deadline; legacy already-admitted reissue is separate and reviewed. Local inbox does not require an available provider; internal native handover preserves original response/keys. Tracked app cancellation joins actual blocked credential read. Fresh release app strict ad-hoc signature verified, not production signing/notarization. Earlier development four offscreen renders/two manually inspected and three native SIGKILL gates predate final verifier/time refinements; they are development observations, not final foreground GUI/TCC/keyboard acceptance. Initial test visibility compile failure and wrong busy/credential-lease assertion retained. Original full-debug run deliberately stopped unfinished for verifier/time review; its partial output is not a passing full stage. Existing non-atomic FIRST inbox directory creation needs its next hardening slice. Public post-delivery owner-add lifecycle/completed delivery receipt, capability negotiation/removal/rotation/provider/physical twoMac and full sync remain unfinished. All83 feature statuses/landscape/earlier benchmark bytes unchanged. No completev0/24h/energy/topthree claim. Explicit source/log/receipt/generated-layout archive only: no executable, library database, credential backend file, private key or account inventory.\n').encode()
archive=root/'benchmarks/sync-owner-response-raw-v1.zip';manifest=root/'benchmarks/sync-owner-response-inputs-v1.json';receipt=root/'benchmarks/sync-owner-response-v1.json'
assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,b in sorted(payload.items()):z.writestr(name,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and set(z.namelist())==set(payload) and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x') as f:json.dump({**inputs,'sourceCommit':source},f,indent=2);f.write('\n')
result={**review,'sourceCommit':source,'allCommittedInputBlobsMatch':True,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'qualificationInputs':{'archiveMember':'qualification/inputs.json','sha256':sha(run/'inputs.json')},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload),'allArchivedBytesComparedToInputs':True,'files':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True}}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'sourceCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
