from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/local-answer-context-v1';run=base/'qualification-v1';bare=root/'.artifacts/local-answer-preparation-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text())
assert review['reviewerSHA256']==sha(base/'review-v1.py')and review['inputManifestSHA256']==sha(run/'inputs.json')
assert len(review['newMethodIdentities'])==21 and len(review['alteredLogControls'])==5 and len(review['alteredLiveRecordControls'])==6
assert review['actualPreparation']['preparation']['contextLength']==8192
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']=='e5d3a8676a1136d0c8d02b4a8023388bbafdd8b6'
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges'])
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputs['inputFiles'].items():
    p=root/path;b=os.readlink(p).encode()if p.is_symlink()else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
featurePaths=subprocess.check_output(['git','diff','--name-only',inputs['featureBaseSource'],'HEAD'],text=True).splitlines();assert len(featurePaths)==11 and all(p in inputs['inputFiles']for p in featurePaths)
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',inputs['featureBaseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2];protected[path.decode()]=hashlib.sha256(b).hexdigest()
bareReviewPath=bare/'qualification-v1/reviewed-v2.json';assert sha(bareReviewPath)=='9544fbfc0cb474f631a8db1684a17995824ce66d2d7cd9ae4a25dde3faa114a8'
bareReview=json.loads(bareReviewPath.read_text());assert bareReview['reviewerSHA256']==sha(bare/'review-v2.py')and bareReview['actualPreparation']['preparation']['contextLength']==262144
files={'qualification/inputs.json':run/'inputs.json','qualification/results.json':run/'results.json','qualification/review.json':reviewPath,'qualification/runner.py':base/'qualify-v1.py','qualification/reviewer.py':base/'review-v1.py','publisher.py':Path(__file__),'development/context-contract.log':base/'development-v1.log','retained-bare-load/inputs.json':bare/'qualification-v1/inputs.json','retained-bare-load/results.json':bare/'qualification-v1/results.json','retained-bare-load/review.json':bareReviewPath,'retained-bare-load/runner.py':bare/'qualify-v1.py','retained-bare-load/failed-reviewer.py':bare/'review-v1.py','retained-bare-load/failed-review-note.json':bare/'review-v1-failure-note-v1.json','retained-bare-load/reviewer-v2.py':bare/'review-v2.py','retained-bare-load/context-finding.json':bare/'context-alignment-finding-v1.json','development/compile-failure-v1.log':bare/'development-v1.log','development/stream-inspection-failure-v2.log':bare/'development-v2.log','development/stream-inspection-control-v3.log':bare/'development-v3.log','development/failing-stream-inspection-source-v2.swift':bare/'development-source-v2-CoreTests.swift'}
for prefix,folder in [('qualification',run),('retained-bare-load',bare/'qualification-v1')]:
    for stage in json.loads((folder/'results.json').read_text())['stages']:
        p=root/stage['log'];assert stage['exit']==0 and sha(p)==stage['sha256'];files[prefix+'/logs/'+stage['name']+'.log']=p
for prefix,folder,record in [('qualification',run,review),('retained-bare-load',bare/'qualification-v1',bareReview)]:
    for path,h in record['actualEvidenceFiles'].items():
        p=folder/path;assert sha(p)==h;files[prefix+'/actual/'+path]=p
bareInputs=json.loads((bare/'qualification-v1/inputs.json').read_text())
for path,h in bareInputs['workingChanges'].items():
    p=bare/'retained-context-mismatch-source-v1'/path;assert sha(p)==h;files['retained-bare-load/source/'+path]=p
for path in featurePaths:files['source/'+path]=root/path
smoke=base/'prepared-answer-smoke-v1';smokeReviewPath=smoke/'reviewed-v1.json'
assert sha(smokeReviewPath)=='85e89b4d5370321c85e6cfd624ab179b7ede31f0c47dbb31f6434cb73a0628e7'
smokeReview=json.loads(smokeReviewPath.read_text());assert smokeReview['reviewerSHA256']==sha(base/'review-smoke-v1.py')and smokeReview['qualifiedCLISHA256']==review['newPackage']['files']['Contents/MacOS/oswindctl']
assert smokeReview['inputManifestSHA256']==sha(run/'inputs.json')and len(smokeReview['alteredAnswerControls'])==5
files.update({'prepared-answer/runner.py':base/'prepared-answer-smoke-v1.py','prepared-answer/reviewer.py':base/'review-smoke-v1.py','prepared-answer/review.json':smokeReviewPath,'prepared-answer/controller.log':base/'prepared-answer-controller-v1.log'})
for path,h in smokeReview['files'].items():
    p=smoke/path;assert sha(p)==h;files['prepared-answer/'+path]=p
payload={n:p.read_bytes()for n,p in files.items()}
oldAI=subprocess.check_output(['git','show',inputs['baseSource']+':Sources/OSwindCore/AI.swift']);assert hashlib.sha256(oldAI).hexdigest()==bareInputs['inputFiles']['Sources/OSwindCore/AI.swift'];payload['retained-bare-load/source/Sources/OSwindCore/AI.swift']=oldAI
payload['README.txt']=(
    f'OSwind answer-context-aligned local model preparation runtime {source}.\n'
    '711 committed inputs; 703 of 711 bare-load implementation inputs unchanged; eight follow-up files changed. '
    'The complete feature spans eleven files relative to PR156 and twenty-one new methods: twenty ordinary controls and one explicitly gated real-model case.\n\n'
    'One earlier empty model-load request succeeded but reported262144 context while real answer requests use8192. '
    'All seven earlier stages and source snapshots remain retained. The first checker failed singular-summary grammar; corrected checker2 passes without repeating runtime work. '
    'That earlier success is insufficient answer-context acceptance and is not the final feature result.\n\n'
    'The final empty request sends model, streamfalse, finite5m retention and options.num_ctx8192. The shared constant preserves the existing answer value. '
    'A real loopback contract executes AnswerEngine and checks matching8192 on load/chat with unchanged temperature0.2/output1000/thinkfalse. '
    'The final one explicitly gated actual-model request must independently report8192. Stable local model identity and matching unexpired residency are required. '
    'Cancellation retains task ownership, participates in retirement/drain and never unloads shared models. No captured context or weights download occurs in actual model-load checks. '
    'Actual model-service wire bodies are not independently recorded; their shape is verified with inert real HTTP servers and protocol controls.\n\n'
    'A separate newly authored single-note packaged CLI question after the aligned load returns the expected owner with exact source identity and unchanged settings. '
    'Its whole-process elapsed time and five altered-answer controls are retained separately; it is not a controlled speedup or aggregate semantic quality result.\n\n'
    'Five altered logs and six altered live observations are rejected. Production build/fresh strict ad-hoc package pass; resources/bundle information unchanged. '
    'No executables, weights, user corpus or keys included. Earlier published comparisons/qualifications remain unchanged. '
    'Client time, reported residency/expiry/context are observations, not controlled cold-start, first-answer speed, per-operation processor use or power measurements. '
    'GUI/TCC, older-Mac and managed process settlement remain separate. Complete sync, physical capture/energy, signed/notarized distribution, fullv0 and topthree acceptance remain open; all83 statuses unchanged.\n'
).encode()
archive=root/'benchmarks/local-answer-preparation-raw-v1.zip';manifest=root/'benchmarks/local-answer-preparation-inputs-v1.json';receipt=root/'benchmarks/local-answer-preparation-v1.json';assert all(not p.exists()for p in[archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive)as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload)and set(z.namelist())==set(payload)and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x')as f:json.dump({**inputs,'sourceCommit':source,'featureChangedFiles':{p:inputs['inputFiles'][p]for p in featurePaths}},f,indent=2);f.write('\n')
result={**review,'sourceCommit':source,'allCommittedInputBlobsMatch':True,'featureChangedFiles':featurePaths,'retainedBareLoad':{'source':inputs['baseSource'],'reviewSHA256':sha(bareReviewPath),'reportedContext':262144,'answerContext':8192,'isFinalAnswerContextAcceptance':False},'preparedAnswerSmoke':{**smokeReview,'reviewSHA256':sha(smokeReviewPath)},'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())}},'priorProtectedFiles':protected}
with receipt.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'sourceCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
