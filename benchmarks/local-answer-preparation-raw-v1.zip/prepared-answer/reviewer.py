from pathlib import Path
import copy,datetime,hashlib,json,math,re,sqlite3

root=Path.cwd();base=root/'.artifacts/local-answer-context-v1';run=base/'qualification-v1';out=base/'prepared-answer-smoke-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((out/'report.json').read_text());plan=json.loads((out/'plan.json').read_text());inputs=json.loads((run/'inputs.json').read_text());qualification=json.loads((run/'reviewed-v1.json').read_text())
assert report['state']=='completed'and report['runnerSHA256']==sha(base/'prepared-answer-smoke-v1.py')and report['planSHA256']==sha(out/'plan.json')
assert report['inputManifestSHA256']==sha(run/'inputs.json')and report['preparationReportSHA256']==sha(run/'live-preparation-v1.json')
assert report['binarySHA256']==qualification['newPackage']['files']['Contents/MacOS/oswindctl']==sha(run/'OSwind.app/Contents/MacOS/oswindctl')
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert len(report['commands'])==2 and[c['name']for c in report['commands']]==['seed','ask']and all(c['exit']==0 for c in report['commands'])
for command in report['commands']:
    assert math.isfinite(command['wallSeconds'])and 0<=command['wallSeconds']<=180
    for kind in['stdout','stderr']:
        p=out/command[kind];assert p.parent==out and sha(p)==command[kind+'SHA256']
identifier=(out/'seed.stdout').read_text().strip();answer=json.loads((out/'ask.stdout').read_text());assert identifier==report['sourceID']and answer==report['answer']
assert plan['note']=='Deya owns the fictional Harbor checklist. This is an authored functional test note, not user history.'and plan['question']=='Who owns Harbor checklist?'and plan['expectedOwner']=='Deya'
def inspectAnswer(value):
    assert value['provider']=='ollama'and plan['expectedOwner'].lower()in value['text'].lower()and re.search(r'\[1\]',value['text'])
    assert len(value['sources'])==1 and value['sources'][0]['memory']['id']==identifier and value['sources'][0]['memory']['text']==plan['note']
inspectAnswer(answer)
before=report['beforeAnswerResidency'];selection=inputs['liveSelection'];assert len(before)==1 and before[0]['name']==selection['model']and before[0]['digest']==selection['digest']and before[0]['context_length']==8192
askBirth=(out/'ask.stdout').stat().st_birthtime;expires=datetime.datetime.fromisoformat(before[0]['expires_at'].replace('Z','+00:00')).timestamp();assert expires>askBirth+19
assert report['settingsBytesUnchanged']and report['sourceIdentityAndStoredTextMatch']and sha(out/'owned-library/settings.json')==report['settingsSHA256']
db=sqlite3.connect('file:'+str(out/'owned-library/memory.sqlite')+'?mode=ro',uri=True)
try:rows=db.execute('SELECT id,payload FROM memories').fetchall();assert len(rows)==1 and rows[0][0]==identifier and json.loads(rows[0][1])['text']==plan['note'];payloadSHA256=hashlib.sha256(rows[0][1]if isinstance(rows[0][1],bytes)else rows[0][1].encode()).hexdigest()
finally:db.close()
faults={}
for kind in['wrong-owner','missing-citation','wrong-source','changed-source-text','wrong-citation']:
    bad=copy.deepcopy(answer)
    if kind=='wrong-owner':bad['text']=bad['text'].replace('Deya','Taro')
    if kind=='missing-citation':bad['text']=bad['text'].replace('[1]','')
    if kind=='wrong-source':bad['sources'][0]['memory']['id']='other-owned-note'
    if kind=='changed-source-text':bad['sources'][0]['memory']['text']='Different fictional evidence'
    if kind=='wrong-citation':bad['text']=bad['text'].replace('[1]','[2]')
    try:inspectAnswer(bad)
    except(AssertionError,KeyError):faults[kind]='rejected'
    else:raise AssertionError('Accepted altered smoke '+kind)
files={str(p.relative_to(out)):sha(p)for p in[out/'plan.json',out/'report.json',out/'seed.stdout',out/'seed.stderr',out/'ask.stdout',out/'ask.stderr',out/'owned-library/settings.json']}
result={'format':'OSwind single prepared-answer packaged process smoke review v1','reviewerSHA256':sha(Path(__file__)),'runnerSHA256':report['runnerSHA256'],'inputManifestSHA256':report['inputManifestSHA256'],'qualifiedCLISHA256':report['binarySHA256'],'preparationReportSHA256':report['preparationReportSHA256'],'files':files,'askWallSeconds':report['commands'][1]['wallSeconds'],'answerText':answer['text'],'sourceID':identifier,'sourcePayloadSHA256':payloadSHA256,'sourceIdentityAndStoredTextMatch':True,'settingsBytesUnchanged':True,'beforeAnswerModelContext':8192,'askStdoutCreatedUTC':datetime.datetime.fromtimestamp(askBirth,datetime.timezone.utc).isoformat(),'alteredAnswerControls':faults,'scope':'One new authored fictional-note packaged CLI question after the separately qualified load; already reported resident8192 at admission. Only owner/citation/source/settings functional checks and descriptive whole-process time. No controlled paired latency benefit, cold-start, semantic accuracy aggregate, processor/power or ranking proof. No explicit preload/unload/pull in this separate probe; server internal processing is not independently observed.'}
p=out/'reviewed-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'askWallSeconds':result['askWallSeconds'],'sourceMatch':True,'settingsUnchanged':True,'alteredControls':len(faults),'reviewSHA256':sha(p)}))
