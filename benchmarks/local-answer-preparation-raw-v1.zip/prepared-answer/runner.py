from pathlib import Path
import datetime,hashlib,http.client,json,os,re,sqlite3,subprocess,time

root=Path.cwd();base=root/'.artifacts/local-answer-context-v1';run=base/'qualification-v1';out=base/'prepared-answer-smoke-v1';out.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());stages=json.loads((run/'results.json').read_text())['stages'];assert len(stages)==7 and all(s['exit']==0 for s in stages)
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
binary=run/'OSwind.app/Contents/MacOS/oswindctl';binarySHA=sha(binary)
library=out/'owned-library';library.mkdir(mode=0o700)
settings=library/'settings.json';settings.write_text(json.dumps({'captureOnLaunch':False,'automaticMaintenance':False,'apiEnabled':False,'routinesEnabled':False,'search':{'provider':'apple','indexPolicy':'exact'}})+'\n');settings.chmod(0o600);settingsSHA=sha(settings)
plan={'note':'Deya owns the fictional Harbor checklist. This is an authored functional test note, not user history.','question':'Who owns Harbor checklist?','expectedOwner':'Deya','scope':'One new authored packaged CLI answer after the distinct actual8192 model preload. Functional support/source identity and descriptive whole-process time only; no controlledpaired speedup/cold-start/qualityaggregate/ranking. No retry, model reload request or old benchmark repetition.'};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
report={'state':'running','inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'binarySHA256':binarySHA,'planSHA256':sha(out/'plan.json'),'preparationReportSHA256':sha(run/'live-preparation-v1.json'),'commands':[],'scope':plan['scope']}
def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
env={k:v for k,v in os.environ.items()if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))}
def command(name,args):
    assert sha(binary)==binarySHA;stdout=out/(name+'.stdout');stderr=out/(name+'.stderr');start=time.monotonic()
    with stdout.open('xb')as o,stderr.open('xb')as e:r=subprocess.run([str(binary),'--data',str(library),*args],env=env,stdout=o,stderr=e,timeout=180)
    report['commands'].append({'name':name,'exit':r.returncode,'wallSeconds':time.monotonic()-start,'stdout':stdout.name,'stderr':stderr.name,'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr)});save();assert r.returncode==0,stderr.read_text()
    return stdout.read_text()
def residency():
    c=http.client.HTTPConnection('127.0.0.1',11434,timeout=5)
    try:c.request('GET','/api/ps');r=c.getresponse();data=json.loads(r.read());assert r.status==200
    finally:c.close()
    matches=[m for m in data['models']if m['name']==inputs['liveSelection']['model']and m['digest']==inputs['liveSelection']['digest']]
    return [{k:m.get(k)for k in ['name','digest','size','size_vram','context_length','expires_at']}for m in matches]
try:
    identifier=command('seed',['note',plan['note']]).strip();report['sourceID']=identifier
    before=residency();report['beforeAnswerResidency']=before
    expiry=datetime.datetime.fromisoformat(before[0]['expires_at'].replace('Z','+00:00'))if len(before)==1 else None
    if expiry is None or before[0]['context_length']!=8192 or expiry <= datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=20):
        report['state']='not-run-preparation-observation-unavailable';save();print('No question sent: prepared residency unavailable or near expiry. No load/retry.');raise SystemExit(2)
    result=json.loads(command('ask',['ask','--literal','--provider','ollama','--endpoint',inputs['liveSelection']['endpoint'],'--model',inputs['liveSelection']['model'],plan['question']]))
    report['answer']=result;report['afterAnswerResidency']=residency();save()
    assert result['provider']=='ollama'and plan['expectedOwner'].lower()in result['text'].lower()and re.search(r'\[1\]',result['text'])
    assert len(result['sources'])==1 and result['sources'][0]['memory']['id']==identifier and result['sources'][0]['memory']['text']==plan['note']
    db=sqlite3.connect('file:'+str(library/'memory.sqlite')+'?mode=ro',uri=True)
    try:rows=db.execute('SELECT id,payload FROM memories').fetchall();assert len(rows)==1 and rows[0][0]==identifier and json.loads(rows[0][1])['text']==plan['note']
    finally:db.close()
    assert sha(settings)==settingsSHA and sha(binary)==binarySHA and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
    report.update(state='completed',settingsSHA256=settingsSHA,settingsBytesUnchanged=True,sourceIdentityAndStoredTextMatch=True);save();print(json.dumps({'state':'completed','askWallSeconds':report['commands'][-1]['wallSeconds'],'sourceMatch':True,'settingsUnchanged':True,'answer':result['text']}))
except Exception as e:
    report.update(state='failed',error=str(e));save();raise
