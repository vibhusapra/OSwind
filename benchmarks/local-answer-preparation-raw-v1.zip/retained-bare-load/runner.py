from pathlib import Path
import hashlib,http.client,json,os,platform,re,subprocess,time

root=Path.cwd();base=root/'.artifacts/local-answer-preparation-v1';out=base/'qualification-v1';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='16769403a3eab02d01124abd43d83244ef765290'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();extra=['scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(root/p)for p in sorted(set(paths+extra))if(p.startswith(('Sources/','Tests/','Vendor/','vendor/'))or p in ['Package.swift','Package.resolved',*extra])and(root/p).is_file()}
prior=json.loads((root/'benchmarks/model-library-routing-inputs-v1.json').read_text())['inputFiles'];assert len(pins)==711 and len(prior)==706 and sum(pins[p]==h for p,h in prior.items())==701
changed=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())&set(pins));assert len(changed)==10
methods=[]
for folder,name in [('OSwindCoreTests','LocalModelPreparationTests'),('OSwindAppTests','LocalAnswerPreparationModelTests'),('OSwindAppTests','LocalAnswerPreparationHTTPTests'),('OSwindAppTests','LocalAnswerPreparationLiveTests')]:
    methods += [folder+'.'+name+'.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests'/folder/(name+'.swift')).read_text())]
assert len(methods)==len(set(methods))==20
model='qwen3.5:4b';digest='7f3251fa6878a78a606bcb3c074283306e5ad2ea411a7774a9dd98a4bc7f2d13'
def server():
    c=http.client.HTTPConnection('127.0.0.1',11434,timeout=5)
    try:
        records={}
        for p in ['/api/version','/api/tags','/api/ps']:
            c.request('GET',p);r=c.getresponse();body=r.read();assert r.status==200;records[p]=json.loads(body)
    finally:c.close()
    return {'version':records['/api/version']['version'],'installedDigests':{m['name']:m['digest']for m in records['/api/tags']['models']},'running':[{'name':m['name'],'digest':m['digest'],'size':m.get('size'),'size_vram':m.get('size_vram'),'expires_at':m.get('expires_at'),'context_length':m.get('context_length')}for m in records['/api/ps']['models']]}
initial=server();assert initial['version']=='0.40.8'and initial['installedDigests'][model]==digest and len(initial['installedDigests'])==5
manifest={'format':'OSwind explicit local answer preparation qualification inputs v1','baseSource':head,'inputFiles':pins,'unchangedPriorInputs':701,'workingChanges':{p:pins[p]for p in changed},'newMethodIdentities':sorted(methods),'initialServerObservation':initial,'liveSelection':{'endpoint':'http://127.0.0.1:11434','model':model,'digest':digest},'scope':'Optional selected-answer empty-request preload with finite5m retention, stable installed identity and typed matching unexpired residency. No captured context/weights download/global runtime settings/unload/answer inference. App model+endpoint generation fences, retained cancellation/task ownership, retirement/drain and settings preservation; actual two inert HTTP servers plus ONE explicitly gated optimized actual local-controller request. Existing prompt/generation/embedding/schema unchanged. Prior successful comparisons/qualifications/packages remain frozen. Server observations are not per-operation processor proof, controlled cold-start/first-answer speed, power or top-three ranking.'}
(out/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
focused='LocalModelPreparationTests|LocalAnswerPreparation|LocalModelLibraryTests|LocalModelLibraryHTTPTests|SemanticIndexTests|PrivacyAndIntegrationTests|LibraryOpeningTests|LibraryRecoveryTransferTests|RetiredLibraryActionTests|VaultSessionTests|SourceWorkSessionTests|LibraryWipeModelTests|WorkspaceWakeLifecycleTests|SearchIndexLifecycleTests'
liveEnvironment={'OSWIND_TEST_LOCAL_MODEL_PREPARE':'1','OSWIND_TEST_PREPARE_ENDPOINT':'http://127.0.0.1:11434','OSWIND_TEST_PREPARE_MODEL':model,'OSWIND_TEST_PREPARE_DIGEST':digest,'OSWIND_TEST_PREPARE_REPORT':str(out/'live-preparation-v1.json')}
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('actual-preparation-optimized',['swift','test','-c','release','--skip-build','--filter','LocalAnswerPreparationLiveTests'],liveEnvironment),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]
results={'baseSource':head,'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':sha(Path(__file__)),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'stages':[]}
env={k:v for k,v in os.environ.items()if not k.startswith('OSWIND_TEST_')}
for name,command,environment in stages:
    assert all(sha(root/p)==h for p,h in pins.items())
    if name=='actual-preparation-optimized':
        observation=server();assert observation['version']==initial['version']and observation['installedDigests']==initial['installedDigests'];assert not(out/'live-preparation-v1.json').exists();(out/'server-before-live-v1.json').write_text(json.dumps(observation,indent=2)+'\n')
    print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb')as f:rc=subprocess.run(command,env={**env,**environment},stdout=f,stderr=subprocess.STDOUT).returncode
    results['stages'].append({'name':name,'command':command,'environment':environment,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in pins.items())
    if name=='actual-preparation-optimized':
        observation=server();(out/'server-after-live-v1.json').write_text(json.dumps(observation,indent=2)+'\n');assert observation['version']==initial['version']and observation['installedDigests']==initial['installedDigests']
    if rc:raise SystemExit(rc)
print('QUALIFICATION_COMPLETE',flush=True)
