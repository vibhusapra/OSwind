from pathlib import Path
import copy,datetime,hashlib,json,math,re,subprocess

root=Path.cwd();base=root/'.artifacts/local-answer-preparation-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());result=json.loads((run/'results.json').read_text())
assert inputs['baseSource']==result['baseSource']=='16769403a3eab02d01124abd43d83244ef765290'
assert len(inputs['inputFiles'])==711 and len(inputs['workingChanges'])==10 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
prior=json.loads((root/'benchmarks/model-library-routing-inputs-v1.json').read_text())['inputFiles'];assert len(prior)==706 and sum(inputs['inputFiles'][p]==h for p,h in prior.items())==701
assert result['inputManifestSHA256']==sha(run/'inputs.json')and result['runnerSHA256']==sha(base/'qualify-v1.py')
new=[]
for folder,name in [('OSwindCoreTests','LocalModelPreparationTests'),('OSwindAppTests','LocalAnswerPreparationModelTests'),('OSwindAppTests','LocalAnswerPreparationHTTPTests'),('OSwindAppTests','LocalAnswerPreparationLiveTests')]:
    new += [folder+'.'+name+'.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests'/folder/(name+'.swift')).read_text())]
assert len(new)==len(set(new))==20 and sorted(new)==inputs['newMethodIdentities']
live='OSwindAppTests.LocalAnswerPreparationLiveTests.testExplicitExistingLocalModelLoadsWithoutEvidenceOrConfigurationChanges'
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def rows(text):
    found=[(a+'.'+b,c)for a,b,c in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
def inspect(text,expected):
    found=rows(text);assert found==expected;counts={k:list(found.values()).count(k)for k in ['passed','failed','skipped']};assert counts['failed']==0 and counts['passed']>0
    noun='test'if len(found)==1 else'tests'
    summary=f"Executed {len(found)} {noun}, with {counts['skipped']} tests skipped and 0 failures"
    if counts['skipped']==1:summary=f'Executed {len(found)} {noun}, with 1 test skipped and 0 failures'
    if counts['skipped']==0:summary=f'Executed {len(found)} {noun}, with 0 failures'
    assert summary in text and not any(s in text for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items()if v=='skipped')}
old=rows((root/'.artifacts/model-library-routing-v1/qualification-v1/full-debug.log').read_text());assert len(old)==2753 and not(set(old)&set(new))
full={**old,**{k:('skipped'if k==live else'passed')for k in new}}
assert len(full)==2773 and list(full.values()).count('passed')==2610 and list(full.values()).count('skipped')==163
focused='LocalModelPreparationTests|LocalAnswerPreparation|LocalModelLibraryTests|LocalModelLibraryHTTPTests|SemanticIndexTests|PrivacyAndIntegrationTests|LibraryOpeningTests|LibraryRecoveryTransferTests|RetiredLibraryActionTests|VaultSessionTests|SourceWorkSessionTests|LibraryWipeModelTests|WorkspaceWakeLifecycleTests|SearchIndexLifecycleTests'
selection=inputs['liveSelection'];liveEnvironment={'OSWIND_TEST_LOCAL_MODEL_PREPARE':'1','OSWIND_TEST_PREPARE_ENDPOINT':selection['endpoint'],'OSWIND_TEST_PREPARE_MODEL':selection['model'],'OSWIND_TEST_PREPARE_DIGEST':selection['digest'],'OSWIND_TEST_PREPARE_REPORT':str(run/'live-preparation-v1.json')}
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('actual-preparation-optimized',['swift','test','-c','release','--skip-build','--filter','LocalAnswerPreparationLiveTests'],liveEnvironment),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(run/'OSwind.app')})]
assert len(result['stages'])==len(stages)
reports=[];selected={k:v for k,v in full.items()if re.search(focused,k)};assert set(new)<=set(selected)and len(selected)==186
for stage,(name,command,environment)in zip(result['stages'],stages):
    assert stage['name']==name and stage['command']==command and stage['environment']==environment and stage['exit']==0
    assert root/stage['log']==run/(name+'.log')and sha(root/stage['log'])==stage['sha256']and math.isfinite(stage['wallSeconds'])and stage['wallSeconds']>=0
    if name in ['full-debug','affected-tsan','affected-optimized','actual-preparation-optimized']:
        expected=full if name=='full-debug'else{live:'passed'}if name=='actual-preparation-optimized'else selected
        reports.append({'mode':name,**inspect((root/stage['log']).read_text(),expected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']})
text=(run/'affected-tsan.log').read_text();method=next(k for k in new if k!=live).rsplit('.',1)[1];line=next(l for l in text.splitlines()if method in l and "' passed"in l);faults={}
for name,bad in {'missing-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'hidden-failure':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testWrongIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,selected)
    except(AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
livePath=run/'live-preparation-v1.json';actual=json.loads(livePath.read_text());before=json.loads((run/'server-before-live-v1.json').read_text());after=json.loads((run/'server-after-live-v1.json').read_text())
date=lambda value:datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
def inspectLive(report,before,after):
    assert report['state']=='completed'and isinstance(report['selectedModelAlreadyReportedLoaded'],bool)
    p=report['preparation'];assert p['endpoint']==selection['endpoint']and p['requestedModel']==p['model']==selection['model']and p['digest']==selection['digest']
    for observation in [before,after]:assert observation['version']==inputs['initialServerObservation']['version']=='0.40.8'and observation['installedDigests']==inputs['initialServerObservation']['installedDigests']
    assert report['selectedModelAlreadyReportedLoaded']==any(m['name']==selection['model']and m['digest']==selection['digest']for m in before['running'])
    assert p['residentBytes']>0 and (p.get('gpuBytes')is None or p['gpuBytes']>=0)and(p.get('contextLength')is None or p['contextLength']>0)
    assert math.isfinite(p['elapsedSeconds'])and 0<=p['elapsedSeconds']<=330
    assert p.get('serverLoadNanoseconds')is None or isinstance(p['serverLoadNanoseconds'],int)and p['serverLoadNanoseconds']>=0
    assert 0<(date(p['serverExpiresAt'])-date(p['observedAt'])).total_seconds()<=330
    residents=[m for m in after['running']if m['name']==selection['model']and m['digest']==selection['digest']];assert len(residents)==1 and residents[0]['size']>0
    assert date(residents[0]['expires_at'])>=date(p['observedAt'])
    return p
preparation=inspectLive(actual,before,after)
liveFaults={}
for kind in ['wrong-digest','wrong-model','expired','zero-residency','duplicate-running']:
    bad=copy.deepcopy(actual);badAfter=copy.deepcopy(after)
    if kind=='wrong-digest':bad['preparation']['digest']='0'*64
    if kind=='wrong-model':bad['preparation']['model']='other:small'
    if kind=='expired':bad['preparation']['serverExpiresAt']=bad['preparation']['observedAt']
    if kind=='zero-residency':bad['preparation']['residentBytes']=0
    if kind=='duplicate-running':badAfter['running'].append(next(m for m in badAfter['running']if m['name']==selection['model']))
    try:inspectLive(bad,before,badAfter)
    except(AssertionError,KeyError,ValueError):liveFaults[kind]='rejected'
    else:raise AssertionError('Accepted altered live '+kind)
package=run/'OSwind.app';files={str(p.relative_to(package)):sha(p)for p in package.rglob('*')if p.is_file()}
previous=json.loads((root/'benchmarks/model-library-routing-v1.json').read_text())['newPackage']['files']
assert{p:h for p,h in files.items()if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items()if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
signature=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert signature.returncode==0
review={'format':'OSwind explicit local answer preparation qualification review v1','baseSource':inputs['baseSource'],'inputCount':711,'unchangedPriorInputs':701,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':result['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'newMethodIdentities':sorted(new),'stages':reports,'alteredLogControls':faults,'alteredLiveRecordControls':liveFaults,'actualPreparation':actual,'actualEvidenceFiles':{p.name:sha(p)for p in[livePath,run/'server-before-live-v1.json',run/'server-after-live-v1.json']},'newPackage':{'path':str(package),'files':files,'strictAdHocSignatureExit':signature.returncode,'allPriorResourcesAndBundleInfoUnchanged':True},'scope':inputs['scope'],'limitations':'Actual controller/client existing-model load once; empty finite request shape separately verified on two inert actual HTTP servers and URLProtocol controls. Actual model service wire body not independently recorded. No user history/settings root or answer inference in live case. Client elapsed, server load/residency/expiry are observations, not controlled cold-start, first-answer benefit, per-operation processor use or energy. No new managed-process startup/exit or GUI/TCC/older-Mac acceptance. Complete sync, physical24h/power, distribution, fullv0/topthree remain open;all83 statuses unchanged.'}
out=run/'reviewed-v2.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'inputCount':711,'stages':[{k:r[k]for k in['mode','defined','passed','failed','skipped']}for r in reports],'newMethods':20,'alteredLogControls':len(faults),'alteredLiveControls':len(liveFaults),'actualModel':preparation['model'],'actualClientElapsedSeconds':preparation['elapsedSeconds'],'reviewSHA256':sha(out)}))
