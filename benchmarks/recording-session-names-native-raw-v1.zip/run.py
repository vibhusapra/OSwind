from pathlib import Path
import os,json,hashlib,subprocess,time,re
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins=json.loads((out/'inputs.json').read_text())
runner=subprocess.check_output(['xcrun','--find','xctest'],text=True).strip()
selection=','.join('OSwindAppTests.VaultSessionTests/'+n for n in ['testNativeRecordingNameReadIsJoinedBeforeVaultDetach','testNativeRecordingNameWriteIsJoinedAndCancelledBeforeVaultDetach'])
for mode in ['optimized','thread-sanitizer']:
 d=out/mode;d.mkdir();engine=json.loads((b/mode/'actual-engine.json').read_text())
 def check():
  for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
  for x in engine:assert sha(b/x['path'])==x['sha256'],x['path']
 check();env=os.environ.copy();env.update({'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_TEST_VAULT_TRACE_DIR':str(d/'native-traces')})
 if mode=='thread-sanitizer':env['DYLD_INSERT_LIBRARIES']='/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/lib/darwin/libclang_rt.tsan_osx_dynamic.dylib'
 command=[runner,'-XCTest',selection,str(b/mode/'actual-engine/OSwindPackageTests.xctest')];start=time.monotonic()
 with (d/'test.log').open('xb') as f:p=subprocess.run(command,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 check();text=(d/'test.log').read_text();methods=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",text)
 result={'source':pins['source'],'runtimeSource':'281582871034651d0990f73ae5b0164957255078','actualEngine':'../../'+mode+'/actual-engine','rebuild':False,'command':command,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'inputsAndActualEngineUnchanged':True,'methods':len(methods),'counts':{s:sum(status==s for _,status,_ in methods) for s in ['passed','skipped','failed']},'logSHA256':sha(d/'test.log'),'scope':'Two explicit VaultSessionTests methods defined in RecordingNameVaultTests.swift, omitted from earlier name-only class selection.'}
 (d/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if p.returncode:print(text[-2500:],flush=True);raise SystemExit(p.returncode)
 assert len(methods)==2 and all(s=='passed' for _,s,_ in methods)
