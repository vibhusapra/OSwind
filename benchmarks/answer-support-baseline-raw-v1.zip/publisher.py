from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/answer-support-baseline-v1';run=base/'run-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='afec09fb68857cf939c5ab496f94920ba57a946a'
reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text());assert review['reviewerSHA256']==sha(base/'review-v1.py')
assert sha(reviewPath)=='a9c48b04948183a1555463f4e27c349754ba34a299a23d2dd971ddbb6de121ad'
assert all(sha(base/p)==h for p,h in review['retainedFiles'].items())
inputsPath=root/'benchmarks/storage-setup-recovery-inputs-v1.json';inputFiles=json.loads(inputsPath.read_text())['inputFiles'];assert len(inputFiles)==700
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',head]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputFiles.items():
    p=root/path;b=os.readlink(p).encode()if p.is_symlink()else p.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',head,'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2]
        protected[path.decode()]=hashlib.sha256(b).hexdigest()
observationsPath=base/'source-based-observations-v1.json';observations=json.loads(observationsPath.read_text());assert len(observations['observations'])==10
report=json.loads((run/'report.json').read_text());rows={(r['provider'],r['question']):r for r in report['attempts']}
for item in observations['observations']:
    row=rows[item['provider'],item['question']];assert item['answerText']==row['answerText'] and item['answerRawSHA256']==row['stdoutSHA256']
assert observations['mechanicalReviewSHA256']==sha(reviewPath)
files={p:base/p for p in review['retainedFiles']}
files.update({'reviewer.py':base/'review-v1.py','mechanical-review.json':reviewPath,'publisher.py':Path(__file__),'source-based-observations.json':observationsPath,'retained-pre-inference-v1/memory.sqlite':base/'retained-pre-inference-v1/memory.sqlite','retained-pre-inference-v1/settings.json':base/'retained-pre-inference-v1/settings.json'})
assert sha(files['retained-pre-inference-v1/memory.sqlite'])==review['retainedPreInferenceSQLiteSHA256']
payload={name:p.read_bytes()for name,p in files.items()}
payload['README.txt']=b'OSwind answer-support baseline: runtime49f259d,700 unchanged committed runtime/test/dependency inputs, final qualified ad-hoc release CLI.24 transparent authored English questions over16 fictional notes;48 actual requests, Apple Intelligence and installed localQwen4B, one each. Original16 successful seed operations reused after retained BLOB/text harness fingerprint failure BEFORE any answer generation; no seed or inference retries. All48 requests return responses; same retrieved source order for both providers, all40 declared supporting-document cases covered,66 valid citation numbers and zero product warnings. These are mechanical counts, NOT factual/citation support or accuracy scores. Source-based Codex observations retain real obsolete-owner, wrong-date, missing-answer, cross-project attribution and wrong-source citation counterexamples plus qualified wording observations. All48 outputs are present, not just failures; no independent human semantic labels, separate judge-model API, natural-workload generalization or product/model ranking. Apple assets not exported/fingerprinted; Ollama model digest stable; later read-only/api/ps memory residency is not per-operation GPU proof or power/throughput. Source/plan/model/runner stability passes. Five altered-record admission controls reject. Exact own fictional pre-inference SQLite/settings snapshot included for inspection; no user history, credentials, normal library, modelweights or executable. Old runs/reviewers/publishers/packages and all83 feature statuses unchanged. No fullsync, physical24h/energy, signeddistribution, completev0/topthree claim. Successful v2 runner/reviewer/result/rawfiles and all earlier work are frozen.\n'
archive=root/'benchmarks/answer-support-baseline-raw-v1.zip';fixture=root/'benchmarks/fixtures/answer-support-authored-v1.json';manifest=root/'benchmarks/answer-support-baseline-inputs-v1.json';receipt=root/'benchmarks/answer-support-baseline-v1.json'
assert all(not p.exists()for p in [archive,fixture,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,b in sorted(payload.items()):z.writestr(name,b)
with zipfile.ZipFile(archive)as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and set(z.namelist())==set(payload) and all(z.read(n)==b for n,b in payload.items())
with fixture.open('xb')as f:f.write((base/'authored-plan-v1.json').read_bytes())
assert sha(fixture)==review['planSHA256']
with manifest.open('x')as f:json.dump({'format':'OSwind authored answer-support baseline inputs v1','runtimeSourceCommit':review['sourceCommit'],'publicationBaseCommit':head,'inputFiles':inputFiles,'runtimeReceipt':{'file':'storage-setup-recovery-v1.json','sha256':review['sourceReceiptSHA256']},'authoredPlan':{'file':str(fixture.relative_to(root)),'sha256':sha(fixture)},'scope':'No runtime source changes. Benchmark-only publication of exact frozen pre-inference plan, process/raw-source observations and source-based counterexamples; no semantic accuracy score.'},f,indent=2);f.write('\n')
result={**review,'publicationBaseCommit':head,'runtimeInputsUnchangedAndCommitted':True,'sourceBasedObservations':observations,'sourceBasedObservationsSHA256':sha(observationsPath),'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload),'allArchivedBytesComparedToInputs':True,'files':{n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True}}
with receipt.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'runtimeSource':review['sourceCommit'],'requests':review['processCounts']['completedResponses'],'semanticScoreComputed':False,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
