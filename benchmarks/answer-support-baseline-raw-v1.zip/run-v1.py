from pathlib import Path
import hashlib,json,math,os,platform,signal,sqlite3,subprocess,time,urllib.request

root=Path.cwd();base=root/'.artifacts/answer-support-baseline-v1';planPath=base/'authored-plan-v1.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
planSHA='93bd755141ee90f5675c3310f983a442a34afa16df9c41dee5296cd8fae74944'
assert sha(planPath)==planSHA
plan=json.loads(planPath.read_text());assert len(plan['documents'])==16 and len(plan['questions'])==24
receiptPath=root/'benchmarks/storage-setup-recovery-v1.json';receipt=json.loads(receiptPath.read_text())
inputs=json.loads((root/'benchmarks/storage-setup-recovery-inputs-v1.json').read_text())['inputFiles']
assert len(inputs)==700 and all(sha(root/p)==h for p,h in inputs.items())
binary=Path(receipt['newPackage']['path'])/'Contents/MacOS/oswindctl'
binarySHA=receipt['newPackage']['files']['Contents/MacOS/oswindctl'];assert sha(binary)==binarySHA
out=base/'run-v1';out.mkdir(mode=0o700,exist_ok=False);library=out/'library';library.mkdir(mode=0o700);(out/'raw').mkdir(mode=0o700)
def save(path,value):
    temporary=path.with_name(path.name+'.part');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.chmod(0o600);temporary.replace(path)
save(library/'settings.json',{'captureOnLaunch':False,'automaticMaintenance':False,'apiEnabled':False,'routinesEnabled':False,'ai':{'provider':'evidence'},'search':{'provider':'apple','indexPolicy':'exact'}})
env={k:v for k,v in os.environ.items() if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))}
def command(name,args,timeout=240):
    assert sha(binary)==binarySHA
    stdout=out/'raw'/(name+'.stdout');stderr=out/'raw'/(name+'.stderr');started=time.monotonic();timedOut=False
    with stdout.open('xb')as o,stderr.open('xb')as e:
        stdout.chmod(0o600);stderr.chmod(0o600)
        child=subprocess.Popen([str(binary),'--data',str(library),*args],stdout=o,stderr=e,env=env,start_new_session=True)
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timedOut=True;os.killpg(child.pid,signal.SIGTERM)
            try:code=child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
        except BaseException:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise
    return {'exit':code,'timedOut':timedOut,'wallSeconds':time.monotonic()-started,'stdout':str(stdout.relative_to(out)),'stderr':str(stderr.relative_to(out)),'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr)}
report={'format':'OSwind authored answer support baseline v1','state':'running','sourceCommit':receipt['sourceCommit'],'sourceReceiptSHA256':sha(receiptPath),'planSHA256':planSHA,'harnessSHA256':sha(Path(__file__)),'binarySHA256':binarySHA,'binary':str(binary),'platform':{'macOS':platform.mac_ver()[0],'machine':platform.machine()},'seed':[],'attempts':[],'qualityScoring':'UNREVIEWED: requires independent factual/citation/abstention audit of all outputs, including failures. No aggregate correctness score inferred from citation syntax or token matching.','scope':plan['scope'],'modelLimits':'Apple model bytes/version are not exported or fingerprinted here; OS version is recorded. Ollama exact installed model digest is observed before/after. One generation per question/profile, temperature/body unchanged from actual product. Host activity/caches uncontrolled; timings are diagnostic, not comparative latency or energy.'}
save(out/'report.json',report)
def localModel():
    try:
        with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=5)as response:data=json.load(response)
        matches=[m for m in data['models']if m['name']=='qwen3:4b-instruct-2507-q4_K_M']
        assert len(matches)<=1
        return {k:matches[0].get(k)for k in ['name','digest','size','details']}if matches else None
    except (OSError,ValueError,KeyError):return None
def savedRows():
    db=sqlite3.connect('file:'+str(library/'memory.sqlite')+'?mode=ro',uri=True)
    try:return {i:p for i,p in db.execute('SELECT id,payload FROM memories ORDER BY id')}
    finally:db.close()
try:
    mapping={}
    for doc in plan['documents']:
        result=command('seed-'+doc['key'],['note',doc['text']]);report['seed'].append({'key':doc['key'],**result})
        save(out/'report.json',report);assert result['exit']==0 and not result['timedOut']
        identifier=(out/result['stdout']).read_text().strip();assert identifier and identifier not in mapping
        mapping[identifier]=doc['key'];print('SEEDED '+doc['key'],flush=True)
    original=savedRows();assert len(original)==16 and set(original)==set(mapping)
    byKey={d['key']:d for d in plan['documents']}
    for identifier,payload in original.items():assert json.loads(payload)['text']==byKey[mapping[identifier]]['text']
    report['sourceRows']={i:{'key':mapping[i],'payloadSHA256':hashlib.sha256(p.encode()).hexdigest(),'textSHA256':byKey[mapping[i]]['sha256']}for i,p in original.items()}
    beforeModel=localModel();report['ollamaModelBefore']=beforeModel;save(out/'report.json',report)
    for provider in ['apple','ollama']:
        for q in plan['questions']:
            if provider=='ollama'and beforeModel is None:
                row={'question':q['id'],'provider':provider,'state':'provider-unavailable','scope':'Pinned installed local model not found/reachable. No download, substitution or paid/remote call.'}
            else:
                args=['ask','--literal','--provider',provider]
                if provider=='ollama':args+=['--model','qwen3:4b-instruct-2507-q4_K_M','--endpoint','http://127.0.0.1:11434']
                result=command(provider+'-'+q['id'],[*args,q['question']]);row={'question':q['id'],'provider':provider,'state':'failed-answer'if result['exit']or result['timedOut']else 'response-unreviewed',**result}
                if row['state']=='response-unreviewed':
                    answer=json.loads((out/result['stdout']).read_text());assert isinstance(answer['text'],str)and answer['text'].strip()and math.isfinite(answer['duration'])
                    assert answer['provider']in [provider,'evidence']
                    for hit in answer['sources']:
                        memory=hit['memory'];assert memory['id']in original and memory['text']==json.loads(original[memory['id']])['text']
                    row.update(answerText=answer['text'],sourceKeys=[mapping[h['memory']['id']]for h in answer['sources']],warnings=answer['warnings'],actualProvider=answer['provider'],referenceSupportRetrieved=None if not q['supportingDocumentKeys'] else all(k in {mapping[h['memory']['id']]for h in answer['sources']}for k in q['supportingDocumentKeys']))
            report['attempts'].append(row);save(out/'report.json',report);print(json.dumps({'question':q['id'],'provider':provider,'state':row['state']}),flush=True)
    afterModel=localModel();report['ollamaModelAfter']=afterModel;assert beforeModel==afterModel
    assert savedRows()==original and sha(planPath)==planSHA and sha(Path(__file__))==report['harnessSHA256']and sha(binary)==binarySHA
    assert all(sha(root/p)==h for p,h in inputs.items())and len(report['attempts'])==48
    assert len({(r['provider'],r['question'])for r in report['attempts']})==48
    report['state']='completed-unreviewed';report['sourceModelPlanRunnerStable']=True;save(out/'report.json',report)
    print('BASELINE_COMPLETED_UNREVIEWED no semantic score or ranking claimed',flush=True)
except BaseException as error:
    report['state']='failed';report['failure']=str(error);save(out/'report.json',report);raise
