from pathlib import Path
import copy,hashlib,json,math,re,sqlite3

root=Path.cwd();base=root/'.artifacts/answer-support-baseline-v1';run=base/'run-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
planPath=base/'authored-plan-v1.json';plan=json.loads(planPath.read_text());report=json.loads((run/'report.json').read_text())
assert sha(planPath)=='93bd755141ee90f5675c3310f983a442a34afa16df9c41dee5296cd8fae74944'
assert report['planSHA256']==sha(planPath) and report['harnessSHA256']==sha(base/'run-v2.py')
receiptPath=root/'benchmarks/storage-setup-recovery-v1.json';receipt=json.loads(receiptPath.read_text())
assert report['sourceReceiptSHA256']==sha(receiptPath) and report['sourceCommit']==receipt['sourceCommit']=='49f259da9140505fef5a3a1c6477bf0fdedc3ed0'
inputsPath=root/'benchmarks/storage-setup-recovery-inputs-v1.json';inputs=json.loads(inputsPath.read_text())['inputFiles']
assert len(inputs)==700 and all(sha(root/p)==h for p,h in inputs.items())
assert report['binarySHA256']==receipt['newPackage']['files']['Contents/MacOS/oswindctl']==sha(Path(report['binary']))
failed=json.loads((base/'run-v1/report.json').read_text());assert failed['state']=='failed' and not failed['attempts'] and len(failed['seed'])==16
failure=json.loads((base/'harness-failure-retained-v1.json').read_text());assert failure['answerAttempts']==0 and failure['seedOperations']==16
assert failure['originalScriptSHA256']==sha(base/'run-v1.py') and failure['originalReportSHA256']==sha(base/'run-v1/report.json')
assert all(sha(base/p)==h for p,h in report['retainedBeforeInference'].items())
snapshot=base/'retained-pre-inference-v1/memory.sqlite';db=sqlite3.connect(snapshot.as_uri()+'?immutable=1',uri=True)
try:saved={i:p for i,p in db.execute('SELECT id,payload FROM memories ORDER BY id')}
finally:db.close()
assert len(saved)==16
docs={d['key']:d for d in plan['documents']};questions={q['id']:q for q in plan['questions']}
assert len(docs)==16 and len(questions)==24
def digestPayload(p):return hashlib.sha256(p if isinstance(p,bytes)else p.encode()).hexdigest()
def check(value):
    assert value['state']=='completed-unreviewed' and value['sourceModelPlanRunnerStable'] is True
    assert len(value['attempts'])==48 and len({(r['question'],r['provider'])for r in value['attempts']})==48
    assert {(r['question'],r['provider'])for r in value['attempts']}=={(q,p)for q in questions for p in ['apple','ollama']}
    assert value['ollamaModelBefore']==value['ollamaModelAfter'] and value['ollamaModelBefore']['name']=='qwen3:4b-instruct-2507-q4_K_M'
    assert value['ollamaModelBefore']['digest']=='0edcdef34593eac1aa2be9c7d06c432dcf81945adca5eca2f27662c18f168ba0'
    mapping=value['sourceRows'];assert set(mapping)==set(saved) and {m['key']for m in mapping.values()}==set(docs)
    for identifier,payload in saved.items():
        source=mapping[identifier];doc=docs[source['key']]
        assert source['payloadSHA256']==digestPayload(payload) and source['textSHA256']==doc['sha256']
        assert json.loads(payload)['text']==doc['text'] and hashlib.sha256(doc['text'].encode()).hexdigest()==doc['sha256']
    assert len(value['seed'])==16 and value['seed']==failed['seed']
    for entry in value['seed']:
        assert entry['exit']==0 and not entry['timedOut']
        for kind in ['stdout','stderr']:assert sha(run/entry[kind])==entry[kind+'SHA256']==sha(base/'run-v1'/entry[kind])
        assert mapping[(run/entry['stdout']).read_text().strip()]['key']==entry['key']
    counts={'completedResponses':0,'warnings':0,'citationNumbers':0,'invalidCitationNumbers':0,'declaredSupportCases':0,'declaredSupportRetrieved':0}
    byPair={}
    for row in value['attempts']:
        assert row['state']=='response-unreviewed' and row['exit']==0 and not row['timedOut']
        assert row['wallSeconds']>=0 and math.isfinite(row['wallSeconds'])
        for kind in ['stdout','stderr']:assert sha(run/row[kind])==row[kind+'SHA256']
        answer=json.loads((run/row['stdout']).read_text());assert answer['provider']==row['provider']==row['actualProvider']
        assert answer['text']==row['answerText'] and answer['warnings']==row['warnings'] and answer['text'].strip()
        keys=[]
        for hit in answer['sources']:
            memory=hit['memory'];assert memory['id']in saved and memory['text']==json.loads(saved[memory['id']])['text']
            keys.append(mapping[memory['id']]['key'])
        assert keys==row['sourceKeys']
        expected=questions[row['question']]['supportingDocumentKeys']
        coverage=all(k in keys for k in expected)if expected else None;assert row['referenceSupportRetrieved']==coverage
        counts['completedResponses']+=1;counts['warnings']+=len(row['warnings'])
        numbers=[int(x)for x in re.findall(r'\[(\d+)\]',answer['text'])];counts['citationNumbers']+=len(numbers);counts['invalidCitationNumbers']+=sum(not 1<=n<=len(keys)for n in numbers)
        if expected:counts['declaredSupportCases']+=1;counts['declaredSupportRetrieved']+=bool(coverage)
        byPair[row['question'],row['provider']]=keys
    assert all(byPair[q,'apple']==byPair[q,'ollama']for q in questions)
    return counts
counts=check(report);assert counts['completedResponses']==48 and counts['declaredSupportCases']==counts['declaredSupportRetrieved']==40
assert counts['warnings']==0 and counts['invalidCitationNumbers']==0
faults={}
for name in ['missing-attempt','duplicate-attempt','altered-answer','altered-source-key','altered-saved-payload-digest']:
    bad=copy.deepcopy(report)
    if name=='missing-attempt':bad['attempts'].pop()
    elif name=='duplicate-attempt':bad['attempts'][-1]=copy.deepcopy(bad['attempts'][0])
    elif name=='altered-answer':bad['attempts'][0]['answerText']='Wrong retained answer'
    elif name=='altered-source-key':bad['attempts'][0]['sourceKeys'][0]='wrong-source'
    else:next(iter(bad['sourceRows'].values()))['payloadSHA256']='0'*64
    try:check(bad)
    except (AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
residencyPath=base/'model-residency-observed-v1.json';residency=json.loads(residencyPath.read_text())
assert len(residency['models'])==1 and residency['models'][0]['digest']==report['ollamaModelBefore']['digest']
assert residency['models'][0]['size_vram']>0 and residency['models'][0]['context_length']==8192
paths=[planPath,base/'run-v1.py',base/'run-v2.py',base/'harness-failure-retained-v1.json',base/'run-v1/report.json',base/'controller-v1.log',run/'report.json',base/'controller-v2.log',residencyPath]
paths+=sorted((run/'raw').glob('*'));assert all(p.is_file()for p in paths)
review={'format':'OSwind answer-support baseline mechanical review v1','state':'mechanically-reviewed-no-semantic-score','sourceCommit':report['sourceCommit'],'sourceReceiptSHA256':report['sourceReceiptSHA256'],'inputCount':700,'binarySHA256':report['binarySHA256'],'planSHA256':sha(planPath),'harnessSHA256':sha(base/'run-v2.py'),'reviewerSHA256':sha(Path(__file__)),'modelDigest':report['ollamaModelBefore']['digest'],'processCounts':counts,'sameRetrievedSourceOrderForBothProviders':24,'alteredRecordControls':faults,'retainedFiles':{str(p.relative_to(base)):sha(p)for p in paths},'retainedPreInferenceSQLiteSHA256':sha(snapshot),'scope':'24 transparent authored English questions over16 fictional notes; one actual CLI request per question/provider, original16 seed operations reused after a retained pre-answer-inference BLOB/text harness error. Apple assets unversioned/unfingerprinted; local Ollama digest stable and GPU-resident memory reported separately. All48responses, raw source identities/text and before/after700source/plan/model/runner checks retained. Zero warnings and valid citation numbers do not establish factual/citation support. No semantic correctness aggregate, independent human annotation, judge-model API, natural-user generalization, competitor, latency/power or completev0/topthree claim.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'processCounts':counts,'alteredControls':len(faults),'reviewSHA256':sha(out),'semanticScoreComputed':False}))
