from pathlib import Path
import copy,hashlib,json,math,re,sqlite3,statistics,collections

root=Path.cwd();base=root/'.artifacts/answer-model-refresh-v1';run=base/'evaluation-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((run/'report.json').read_text());preparation=json.loads((base/'preparation-v1/result.json').read_text());pull=json.loads((base/'pull-results-v1.json').read_text())
plans={'diagnostic':json.loads((root/'.artifacts/answer-support-baseline-v1/authored-plan-v1.json').read_text()),'extension':json.loads((base/'extension-plan-v1.json').read_text())}
assert report['oldPlanSHA256']=='93bd755141ee90f5675c3310f983a442a34afa16df9c41dee5296cd8fae74944' and report['extensionPlanSHA256']=='7aead43f50ba01cc6e64b35687c7f06ba53e0d9f46dde9aa3f36ae5120f5814c'
assert report['oldPlanSHA256']==sha(root/'.artifacts/answer-support-baseline-v1/authored-plan-v1.json') and report['extensionPlanSHA256']==sha(base/'extension-plan-v1.json')
assert report['harnessSHA256']==sha(base/'evaluate-v1.py') and report['preparationSHA256']==sha(base/'preparation-v1/result.json') and report['pullReceiptSHA256']==sha(base/'pull-results-v1.json')
runtimePath=root/'benchmarks/storage-setup-recovery-v1.json';runtime=json.loads(runtimePath.read_text());inputs=json.loads((root/'benchmarks/storage-setup-recovery-inputs-v1.json').read_text())['inputFiles']
assert report['runtimeReceiptSHA256']==sha(runtimePath) and report['runtimeSourceCommit']==runtime['sourceCommit']=='49f259da9140505fef5a3a1c6477bf0fdedc3ed0'
assert len(inputs)==700 and all(sha(root/p)==h for p,h in inputs.items())and sha(Path(report['binary']))==report['binarySHA256']==runtime['newPackage']['files']['Contents/MacOS/oswindctl']
assert pull['state']=='completed' and pull['existingModelDigestsUnchanged']is True and preparation['state']=='completed' and preparation['answerGenerationCalls']==0
assert len(preparation['commands'])==9 and all(c['exit']==0 for c in preparation['commands'])
for c in preparation['commands']:
    for kind in ['stdout','stderr']:assert sha(base/c[kind])==c[kind+'SHA256']
def payloadSHA(p):return hashlib.sha256(p if isinstance(p,bytes)else p.encode()).hexdigest()
saved={};maps={}
for corpus,name,key in [('diagnostic','diagnostic-library-v1','diagnosticRows'),('extension','extension-library-v1','extensionRows')]:
    db=sqlite3.connect('file:'+str(base/name/'memory.sqlite')+'?mode=ro',uri=True)
    try:saved[corpus]={i:p for i,p in db.execute('SELECT id,payload FROM memories ORDER BY id')}
    finally:db.close()
    maps[corpus]=preparation[key];docs={d['key']:d for d in plans[corpus]['documents']}
    assert set(saved[corpus])==set(maps[corpus])and {m['key']for m in maps[corpus].values()}==set(docs)
    for identifier,payload in saved[corpus].items():
        item=maps[corpus][identifier];assert payloadSHA(payload)==item['payloadSHA256']
        assert json.loads(payload)['text']==docs[item['key']]['text']and hashlib.sha256(json.loads(payload)['text'].encode()).hexdigest()==item['textSHA256']
old=json.loads((root/'.artifacts/answer-support-baseline-v1/run-v2/report.json').read_text());assert maps['diagnostic']==old['sourceRows']
profiles={'apple':None,'qwen3-instruct':'qwen3:4b-instruct-2507-q4_K_M','qwen3.5-4b':'qwen3.5:4b','gemma4-e4b':'gemma4:e4b'}
matrix={(c,p,q['id'])for c in plans for p in (['qwen3.5-4b','gemma4-e4b']if c=='diagnostic'else profiles)for q in plans[c]['questions']};assert len(matrix)==96
questions={c:{q['id']:q for q in p['questions']}for c,p in plans.items()}
def check(value):
    assert value['state']=='completed-unreviewed'and value['sourceModelPlanRunnerStable']is True and len(value['attempts'])==96
    assert {(r['corpus'],r['profile'],r['question'])for r in value['attempts']}==matrix and len({(r['corpus'],r['profile'],r['question'])for r in value['attempts']})==96
    assert {(r['corpus'],r['profile'],r['question'])for r in value['matrix']}==matrix and len(value['matrix'])==96
    assert value['modelsBefore']==value['modelsAfter']and value['ollamaVersionBefore']==value['ollamaVersionAfter']=={'version':'0.40.8'}
    for model in ['qwen3.5:4b','gemma4:e4b']:
        assert value['modelsBefore'][model]==pull['installedModelsAfter'][model]and value['modelsBefore'][model]['details']['runner']=='mlx'
    assert value['modelsBefore']['qwen3:4b-instruct-2507-q4_K_M']['digest']==old['ollamaModelBefore']['digest']
    summaries={p:{'planned':0,'responses':0,'failedAnswers':0,'evidenceFallbacks':0,'warnings':0,'citationNumbers':0,'invalidCitationNumbers':0,'supportCases':0,'supportRetrieved':0}for p in profiles}
    failed=[];context={};diagnosticMatches=0
    for row in value['attempts']:
        corpus,profile,qid=row['corpus'],row['profile'],row['question'];s=summaries[profile];s['planned']+=1
        assert row['model']==profiles[profile]and row['provider']==('apple'if profiles[profile]is None else'ollama')
        assert math.isfinite(row['wallSeconds'])and row['wallSeconds']>=0
        for kind in ['stdout','stderr']:assert sha(run/row[kind])==row[kind+'SHA256']
        if row['state']=='failed-answer':
            assert row['exit']!=0 or row['timedOut'];s['failedAnswers']+=1;failed.append((corpus,profile,qid));continue
        assert row['state']=='response-unreviewed'and row['exit']==0 and not row['timedOut']
        answer=json.loads((run/row['stdout']).read_text());assert answer['text']==row['answerText']and answer['text'].strip()and answer['warnings']==row['warnings']and answer['provider']==row['actualProvider']
        assert answer['provider']in [row['provider'],'evidence'];s['responses']+=1;s['evidenceFallbacks']+=answer['provider']=='evidence';s['warnings']+=len(row['warnings']);keys=[]
        for hit in answer['sources']:
            m=hit['memory'];assert m['id']in saved[corpus]and m['text']==json.loads(saved[corpus][m['id']])['text'];keys.append(maps[corpus][m['id']]['key'])
        assert keys==row['sourceKeys'];context[corpus,profile,qid]=keys
        support=questions[corpus][qid]['supportingDocumentKeys'];coverage=all(k in keys for k in support)if support else None;assert row['referenceSupportRetrieved']==coverage
        if support:s['supportCases']+=1;s['supportRetrieved']+=bool(coverage)
        numbers=[int(x)for x in re.findall(r'\[(\d+)\]',row['answerText'])];s['citationNumbers']+=len(numbers);s['invalidCitationNumbers']+=sum(not 1<=n<=len(keys)for n in numbers)
        if corpus=='diagnostic':
            prior=next(x for x in old['attempts']if x['provider']=='apple'and x['question']==qid)
            assert keys==prior['sourceKeys']and row['sameSourceOrderAsOriginalBaseline']is True;diagnosticMatches+=1
    for qid in questions['extension']:
        present=[context['extension',p,qid]for p in profiles if('extension',p,qid)in context];assert all(x==present[0]for x in present)
    return summaries,failed,diagnosticMatches
summaries,failed,matches=check(report)
assert failed==[('extension','apple','absent-address')]and matches==48
failureRow=next(r for r in report['attempts']if r['state']=='failed-answer');assert failureRow['exit']==1 and not failureRow['timedOut']
assert not(run/failureRow['stdout']).read_bytes()and(run/failureRow['stderr']).read_text()=='OSwind: The model cited an unavailable source. Try again or choose Evidence only.\n'
assert sum(s['responses']for s in summaries.values())==95 and sum(s['supportCases']for s in summaries.values())==sum(s['supportRetrieved']for s in summaries.values())==80
faults={}
for name in ['missing-failed-attempt','duplicate-attempt','altered-answer','altered-source-key','changed-model-digest']:
    bad=copy.deepcopy(report)
    if name=='missing-failed-attempt':bad['attempts']=[r for r in bad['attempts']if r['state']!='failed-answer']
    elif name=='duplicate-attempt':bad['attempts'][-1]=copy.deepcopy(bad['attempts'][0])
    elif name=='altered-answer':bad['attempts'][0]['answerText']='Forged answer'
    elif name=='altered-source-key':bad['attempts'][0]['sourceKeys'][0]='wrong-source'
    else:bad['modelsAfter']['qwen3.5:4b']['digest']='0'*64
    try:check(bad)
    except(AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered '+name)
timings={}
for profile in profiles:
    values=[r['wallSeconds']for r in report['attempts']if r['profile']==profile]
    timings[profile]={'firstObservedProcessRequestSeconds':values[0],'remainingObservedProcessRequestMedianSeconds':statistics.median(values[1:]),'scope':'Descriptive CLI observations only; model load, caches, ordering, output lengths and host activity uncontrolled. Not a controlled latency/throughput/energy comparison.'}
paths=[base/'plan-v1.json',base/'extension-plan-v1.json',base/'pull-v1.py',base/'pull-results-v1.json',base/'pull-controller-v1.log',base/'prepare-v1.py',base/'preparation-v1/result.json',base/'prepare-controller-v1.log',base/'evaluate-v1.py',run/'report.json',base/'evaluation-controller-v1.log']
paths+=sorted(base.glob('*-pull-v1.jsonl'))+sorted((base/'preparation-v1/raw').glob('*'))+sorted((run/'raw').glob('*'))
review={'format':'OSwind new local model comparison mechanical review v1','state':'mechanically-reviewed-no-semantic-score','runtimeSourceCommit':report['runtimeSourceCommit'],'inputCount':700,'runtimeReceiptSHA256':report['runtimeReceiptSHA256'],'binarySHA256':report['binarySHA256'],'harnessSHA256':report['harnessSHA256'],'reviewerSHA256':sha(Path(__file__)),'oldPlanSHA256':report['oldPlanSHA256'],'extensionPlanSHA256':report['extensionPlanSHA256'],'profiles':summaries,'failedAnswerIdentities':failed,'failedAnswerRawStderrSHA256':failureRow['stderrSHA256'],'diagnosticSourceOrdersMatchOriginalBaseline':48,'extensionReceivedSourceOrdersMatchAcrossProviders':12,'alteredRecordControls':faults,'models':report['modelsAfter'],'runtimeVersion':report['ollamaVersionAfter'],'residencyObservations':report['residencyObservations'],'descriptiveRequestObservations':timings,'preparedSourceRows':{'diagnostic':maps['diagnostic'],'extension':maps['extension']},'retainedFiles':{str(p.relative_to(base)):sha(p)for p in paths},'scope':'96 planned/retained requests:95responses and1rejectedApplecitation, no retry/exclusion; all80positive-support cases covered. Unchanged700runtime inputs/qualifiedCLI/product parameters,2newlocalMLXmodel tags,24prior diagnostics only for newmodels plus12newauthoredquestions for4profiles in separate exact corpora. Original48baseline never repeated. Server-reported model digests/version/source/plan/runner stable, not individual weight or Apple-asset fingerprinting. Citation-number validity and process success are not factual/citation support; no semanticaccuracy aggregate, independenthumanlabels, judgeAPI, natural-user generalization, product ranking or controlled latency/energy claim. All successful prior runners/reviewers/publishers/data remain immutable.'}
out=run/'reviewed-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'profiles':summaries,'failedAnswerIdentities':failed,'matchedDiagnosticContexts':matches,'alteredControls':len(faults),'reviewSHA256':sha(out),'semanticScoreComputed':False}))
