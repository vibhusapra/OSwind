from pathlib import Path
import hashlib,json,math,os,platform,signal,sqlite3,subprocess,time,urllib.request

root=Path.cwd();base=root/'.artifacts/answer-model-refresh-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pullPath=base/'pull-results-v1.json';pull=json.loads(pullPath.read_text());assert pull['state']=='completed' and pull['existingModelDigestsUnchanged'] is True
preparationPath=base/'preparation-v1/result.json';preparation=json.loads(preparationPath.read_text());assert preparation['state']=='completed' and preparation['answerGenerationCalls']==0
oldPlanPath=root/'.artifacts/answer-support-baseline-v1/authored-plan-v1.json';newPlanPath=base/'extension-plan-v1.json'
assert sha(oldPlanPath)=='93bd755141ee90f5675c3310f983a442a34afa16df9c41dee5296cd8fae74944' and sha(newPlanPath)=='7aead43f50ba01cc6e64b35687c7f06ba53e0d9f46dde9aa3f36ae5120f5814c'
plans={'diagnostic':json.loads(oldPlanPath.read_text()),'extension':json.loads(newPlanPath.read_text())}
runtimePath=root/'benchmarks/storage-setup-recovery-v1.json';runtime=json.loads(runtimePath.read_text());inputs=json.loads((root/'benchmarks/storage-setup-recovery-inputs-v1.json').read_text())['inputFiles']
assert len(inputs)==700 and all(sha(root/p)==h for p,h in inputs.items())
binary=Path(runtime['newPackage']['path'])/'Contents/MacOS/oswindctl';binarySHA=runtime['newPackage']['files']['Contents/MacOS/oswindctl'];assert sha(binary)==binarySHA
libraries={'diagnostic':base/'diagnostic-library-v1','extension':base/'extension-library-v1'}
profiles={'apple':None,'qwen3-instruct':'qwen3:4b-instruct-2507-q4_K_M','qwen3.5-4b':'qwen3.5:4b','gemma4-e4b':'gemma4:e4b'}
matrix=[('diagnostic',p,q)for p in ['qwen3.5-4b','gemma4-e4b']for q in plans['diagnostic']['questions']]+[('extension',p,q)for p in profiles for q in plans['extension']['questions']]
assert len(matrix)==96 and len({(c,p,q['id'])for c,p,q in matrix})==96
def api(path):
    with urllib.request.urlopen('http://127.0.0.1:11434/api/'+path,timeout=10)as response:return json.load(response)
def models():
    names={m for m in profiles.values()if m};result={}
    for item in api('tags')['models']:
        if item['name']in names:
            assert not item.get('remote_host') and not item.get('remote_model') and item.get('size',0)>0
            result[item['name']]={k:item.get(k)for k in ['name','digest','size','details']}
    assert set(result)==names;return result
def sourceRows(library):
    db=sqlite3.connect('file:'+str(library/'memory.sqlite')+'?mode=ro',uri=True)
    try:return {i:p for i,p in db.execute('SELECT id,payload FROM memories ORDER BY id')}
    finally:db.close()
original={c:sourceRows(p)for c,p in libraries.items()}
for corpus,key in [('diagnostic','diagnosticRows'),('extension','extensionRows')]:
    assert set(original[corpus])==set(preparation[key]);docs={d['key']:d for d in plans[corpus]['documents']}
    for identifier,payload in original[corpus].items():
        item=preparation[key][identifier];raw=payload if isinstance(payload,bytes)else payload.encode()
        assert hashlib.sha256(raw).hexdigest()==item['payloadSHA256'] and json.loads(payload)['text']==docs[item['key']]['text']
beforeModels=models();beforeVersion=api('version');oldReport=json.loads((root/'.artifacts/answer-support-baseline-v1/run-v2/report.json').read_text())
assert beforeModels['qwen3:4b-instruct-2507-q4_K_M']['digest']==oldReport['ollamaModelBefore']['digest']
for model in ['qwen3.5:4b','gemma4:e4b']:assert beforeModels[model]['digest']==pull['installedModelsAfter'][model]['digest']
out=base/'evaluation-v1';out.mkdir(mode=0o700,exist_ok=False);(out/'raw').mkdir(mode=0o700)
def save(report):
    p=out/'report.json.part';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');p.chmod(0o600);p.replace(out/'report.json')
report={'format':'OSwind unchanged-engine new local model comparison v1','state':'running','runtimeSourceCommit':runtime['sourceCommit'],'runtimeReceiptSHA256':sha(runtimePath),'inputCount':700,'binary':str(binary),'binarySHA256':binarySHA,'harnessSHA256':sha(Path(__file__)),'oldPlanSHA256':sha(oldPlanPath),'extensionPlanSHA256':sha(newPlanPath),'preparationSHA256':sha(preparationPath),'pullReceiptSHA256':sha(pullPath),'modelsBefore':beforeModels,'ollamaVersionBefore':beforeVersion,'platform':{'macOS':platform.mac_ver()[0],'machine':platform.machine()},'matrix':[{'corpus':c,'profile':p,'question':q['id']}for c,p,q in matrix],'attempts':[],'residencyObservations':[],'scope':'Unchanged qualified actual CLI and product defaults;24 prior diagnostic questions only for two newly installed local models,12 new authored questions for all4profiles.96planned requests; original48baseline requests not repeated. Exact16-source original snapshot copied into own distinct library with identical payloads/IDs/timestamps, separate8-source new corpus. Not natural-user generalization, independent human semantic labels, semantic accuracy aggregate, competitor ranking, latency/power or completev0. Apple asset bytes unversioned/unfingerprinted. Existing conditional/no_think modifier and inherited model parameters may differ by tag, so prompt/sampling bytes are not claimed identical across model families. No prompt/config/default change or paid/remote inference.'}
save(report);env={k:v for k,v in os.environ.items()if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))}
try:
    observed=set()
    for corpus,profile,q in matrix:
        model=profiles[profile];provider='apple'if model is None else 'ollama';mapping=preparation['diagnosticRows'if corpus=='diagnostic'else'extensionRows']
        name=corpus+'-'+profile+'-'+q['id'];stdout=out/'raw'/(name+'.json');stderr=out/'raw'/(name+'.stderr');args=[str(binary),'--data',str(libraries[corpus]),'ask','--literal','--provider',provider]
        if model:args+=['--model',model,'--endpoint','http://127.0.0.1:11434']
        args.append(q['question']);assert sha(binary)==binarySHA;started=time.monotonic();timedOut=False
        with stdout.open('xb')as o,stderr.open('xb')as e:
            stdout.chmod(0o600);stderr.chmod(0o600);child=subprocess.Popen(args,env=env,stdout=o,stderr=e,start_new_session=True)
            try:code=child.wait(timeout=240)
            except subprocess.TimeoutExpired:
                timedOut=True;os.killpg(child.pid,signal.SIGTERM)
                try:code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
            except BaseException:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                raise
        row={'corpus':corpus,'profile':profile,'question':q['id'],'model':model,'provider':provider,'state':'failed-answer'if code or timedOut else'response-unreviewed','exit':code,'timedOut':timedOut,'wallSeconds':time.monotonic()-started,'stdout':str(stdout.relative_to(out)),'stderr':str(stderr.relative_to(out)),'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr)}
        if row['state']=='response-unreviewed':
            answer=json.loads(stdout.read_text());assert answer['provider']in [provider,'evidence'] and answer['text'].strip()and math.isfinite(answer['duration'])
            keys=[]
            for hit in answer['sources']:
                memory=hit['memory'];assert memory['id']in original[corpus] and memory['text']==json.loads(original[corpus][memory['id']])['text'];keys.append(mapping[memory['id']]['key'])
            support=q['supportingDocumentKeys'];row.update(answerText=answer['text'],sourceKeys=keys,warnings=answer['warnings'],actualProvider=answer['provider'],referenceSupportRetrieved=all(k in keys for k in support)if support else None)
            if corpus=='diagnostic':
                prior=next(r for r in oldReport['attempts']if r['provider']=='apple'and r['question']==q['id']);row['sameSourceOrderAsOriginalBaseline']=keys==prior['sourceKeys']
        report['attempts'].append(row)
        if model and model not in observed:
            observation={'afterQuestion':name,'model':model,'scope':'Read-only/api/ps after first attempt, reported residency not per-operation GPU/power proof.'}
            try:
                data=api('ps');observation['models']=[{k:m.get(k)for k in ['name','digest','size','size_vram','context_length','details']}for m in data.get('models',[])if m.get('name')==model]
            except (OSError,ValueError) as error:observation.update(models=[],observationError=type(error).__name__)
            report['residencyObservations'].append(observation);observed.add(model)
        save(report);print(json.dumps({'corpus':corpus,'profile':profile,'question':q['id'],'state':row['state']}),flush=True)
    afterModels=models();afterVersion=api('version');report.update(modelsAfter=afterModels,ollamaVersionAfter=afterVersion)
    assert afterModels==beforeModels and afterVersion==beforeVersion
    assert all(sourceRows(libraries[c])==saved for c,saved in original.items())
    assert all(sha(root/p)==h for p,h in inputs.items())and sha(binary)==binarySHA and sha(Path(__file__))==report['harnessSHA256']
    assert sha(oldPlanPath)==report['oldPlanSHA256']and sha(newPlanPath)==report['extensionPlanSHA256']and sha(preparationPath)==report['preparationSHA256']and sha(pullPath)==report['pullReceiptSHA256']
    assert len(report['attempts'])==96;report.update(state='completed-unreviewed',sourceModelPlanRunnerStable=True);save(report);print('COMPARISON_COMPLETE_UNREVIEWED all96 attempts retained; no semantic score/ranking',flush=True)
except BaseException as error:
    report.update(state='failed',failure=str(error));save(report);raise
