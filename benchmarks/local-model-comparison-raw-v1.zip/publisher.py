from pathlib import Path
import hashlib,json,os,sqlite3,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/answer-model-refresh-v1';run=base/'evaluation-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='f9f12bcbf5287fc5f9e0bfce26f061988eaedec4'
reviewPath=run/'reviewed-v1.json';review=json.loads(reviewPath.read_text());assert sha(reviewPath)=='568a7505c3b95e6ab2da2847f95ffa33389709064760540945d4d8f2cf018554'
assert review['reviewerSHA256']==sha(base/'review-v1.py')and all(sha(base/p)==h for p,h in review['retainedFiles'].items())
inputs=json.loads((root/'benchmarks/storage-setup-recovery-inputs-v1.json').read_text())['inputFiles'];assert len(inputs)==700
tree={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',head]).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in inputs.items():
    p=root/path;b=os.readlink(p).encode()if p.is_symlink()else p.read_bytes();assert hashlib.sha256(b).hexdigest()==h and tree[path]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',head,'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if item:
        header,path=item.split(b'\t',1);b=(root/path.decode()).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==header.decode().split()[2];protected[path.decode()]=hashlib.sha256(b).hexdigest()
observationsPath=base/'source-based-observations-v1.json';observations=json.loads(observationsPath.read_text());assert len(observations['observations'])==14 and observations['mechanicalReviewSHA256']==sha(reviewPath)
report=json.loads((run/'report.json').read_text());rows={(r['corpus'],r['profile'],r['question']):r for r in report['attempts']}
for item in observations['observations']:
    row=rows[item['corpus'],item['profile'],item['question']]
    if item.get('answerRejected'):assert row['state']=='failed-answer'and item['rawStderrSHA256']==row['stderrSHA256']
    else:assert item['answerText']==row['answerText']and item['answerRawSHA256']==row['stdoutSHA256']
files={p:base/p for p in review['retainedFiles']};files.update({'reviewer.py':base/'review-v1.py','mechanical-review.json':reviewPath,'publisher.py':Path(__file__),'source-based-observations.json':observationsPath,'hardware-observation.json':base/'hardware-observation-v1.json','original-authored-plan.json':root/'.artifacts/answer-support-baseline-v1/authored-plan-v1.json'})
snapshots=base/'publication-corpora-v1';snapshots.mkdir(mode=0o700,exist_ok=False)
for corpus,name in [('diagnostic','diagnostic-library-v1'),('extension','extension-library-v1')]:
    source=sqlite3.connect('file:'+str(base/name/'memory.sqlite')+'?mode=ro',uri=True);snapshot=snapshots/(corpus+'.sqlite');target=sqlite3.connect(snapshot)
    try:source.backup(target);target.commit();stored={i:p for i,p in target.execute('SELECT id,payload FROM memories ORDER BY id')}
    finally:target.close();source.close()
    expected=review['preparedSourceRows'][corpus];assert set(stored)==set(expected)
    assert all(hashlib.sha256(p if isinstance(p,bytes)else p.encode()).hexdigest()==expected[i]['payloadSHA256']for i,p in stored.items())
    snapshot.chmod(0o400);files['owned-corpora/'+snapshot.name]=snapshot;files['owned-corpora/'+corpus+'-settings.json']=base/name/'settings.json'
payload={n:p.read_bytes()for n,p in files.items()}
payload['README.txt']=b'OSwind unchanged-engine local model comparison, runtime49f259d/700 committed inputs.96 unique planned attempts retained:95 returned responses plus1 Apple invalid-citation refusal, no retry/exclusion.24 original diagnostics only for2 newly downloaded model tags;12 new authored questions for4profiles in a separate8-note corpus. Original48baseline never repeated. Both MLX candidates return36/36 responses; Apple11/12 and originalQwen12/12 on newextension. All80declared positive support sets retrieved; all48new diagnostic source orders match original; receivedextension sources match acrossproviders. Mechanical counts/citation numbers are not factual support, semanticaccuracy or product/model ranking. All95responses plus1refusal read in Codex engineering review;14 source-based/qualified observations include improvements and remaining wrong-source citation on extraQwen3.5detail. No independenthumansemanticlabels or separate judgeAPI. Existing product prompts/defaults and model-specific modifiers unchanged; inherited model params/backends differ. Server-reported model digests/Ollama0.40.8/source/plan/runner stable, not individualweight or Appleasset fingerprinting. Raw modelpull progress, model metadata/residency, exactown fictional SQLite corpora/settings, commands/streams/plans/reviewer/publisher retained. No userhistory/credentials/normal library/weights/executable. First observed request63.13s Qwen3.5 and110.64s Gemma, later observations lower: uncontrolled cache/order/output/host context, NOT controlled latency/throughput/power proof. Native capture/24h/power/fullsync/distribution/fullv0/topthree remain open. Prior successful runs/reviewers/publishers/packages/benchmarks and all83statuses immutable.\n'
archive=root/'benchmarks/local-model-comparison-raw-v1.zip';fixture=root/'benchmarks/fixtures/answer-model-extension-v1.json';manifest=root/'benchmarks/local-model-comparison-inputs-v1.json';receipt=root/'benchmarks/local-model-comparison-v1.json';assert all(not p.exists()for p in [archive,fixture,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive)as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload)and set(z.namelist())==set(payload)and all(z.read(n)==b for n,b in payload.items())
with fixture.open('xb')as f:f.write((base/'extension-plan-v1.json').read_bytes())
assert sha(fixture)==review['extensionPlanSHA256']
with manifest.open('x')as f:json.dump({'format':'OSwind local model comparison inputs v1','runtimeSourceCommit':review['runtimeSourceCommit'],'publicationBaseCommit':head,'inputFiles':inputs,'oldAuthoredPlan':{'file':'benchmarks/fixtures/answer-support-authored-v1.json','sha256':review['oldPlanSHA256']},'newAuthoredPlan':{'file':str(fixture.relative_to(root)),'sha256':sha(fixture)},'models':review['models'],'runtimeReceiptSHA256':review['runtimeReceiptSHA256'],'scope':'No runtime source change in this evaluation.96 single attempts/95 responses/one refusal, transparent authored diagnostic/extension scopes, no semanticaccuracy aggregate.'},f,indent=2);f.write('\n')
result={**review,'publicationBaseCommit':head,'runtimeInputsUnchangedAndCommitted':True,'sourceBasedObservations':observations,'hardware':json.loads((base/'hardware-observation-v1.json').read_text()),'sourceBasedObservationsSHA256':sha(observationsPath),'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload),'allArchivedBytesComparedToInputs':True,'files':{n:hashlib.sha256(b).hexdigest()for n,b in sorted(payload.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True}}
with receipt.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'requests':96,'responses':95,'failed':1,'semanticScoreComputed':False,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
