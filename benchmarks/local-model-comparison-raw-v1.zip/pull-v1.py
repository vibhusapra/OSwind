from pathlib import Path
import json,os,shutil,time,urllib.request

base=Path.cwd()/'.artifacts/answer-model-refresh-v1';state=base/'pull-results-v1.json';assert not state.exists()
endpoint='http://127.0.0.1:11434'
def tags():
    with urllib.request.urlopen(endpoint+'/api/tags',timeout=10)as r:return {m['name']:{k:m.get(k)for k in ['name','digest','size','details']}for m in json.load(r)['models']}
def save(value):
    p=state.with_suffix('.part');p.write_text(json.dumps(value,indent=2)+'\n');p.chmod(0o600);p.replace(state)
before=tags();models=['qwen3.5:4b','gemma4:e4b'];assert not set(models)&set(before)
result={'state':'running','existingModelsBefore':before,'models':models,'pulls':[],'runtime':'Ollama0.40.8 observed before run; existing local service unchanged','scope':'Authorized local model downloads only; no generation, user history, paid/remote inference, configuration/default changes or model ranking. Official tag pages declare Apache2 and alternate MLX/llamacpp variants. Exact downloaded manifests/details recorded after completion; aliases are not assumed immutable.'};save(result)
try:
    for model in models:
        free=shutil.disk_usage(base).free;assert free>=16*1024**3,'Less than16GiB free before the next bounded model download'
        name=model.replace(':','-');started=time.monotonic();item={'model':model,'freeBytesBefore':free,'status':'running'};result['pulls'].append(item);save(result)
        req=urllib.request.Request(endpoint+'/api/pull',data=json.dumps({'model':model,'stream':True}).encode(),headers={'Content-Type':'application/json'},method='POST')
        last=None;bucket=-1
        with (base/(name+'-pull-v1.jsonl')).open('xb')as log,urllib.request.urlopen(req,timeout=1800)as response:
            for line in response:
                log.write(line);log.flush();event=json.loads(line)
                if 'error'in event:raise RuntimeError(event['error'])
                item['lastEvent']=event;item['elapsedSeconds']=time.monotonic()-started
                current=(event.get('status'),event.get('digest'));percent=int(100*event.get('completed',0)/event['total'])if event.get('total')else None
                if current!=last or percent is not None and percent//5>bucket:
                    print(json.dumps({'model':model,'status':event.get('status'),'percent':percent}),flush=True);last=current;bucket=percent//5 if percent is not None else -1;save(result)
        assert item['lastEvent'].get('status')=='success';after=tags();assert model in after
        item.update(status='completed',elapsedSeconds=time.monotonic()-started,installed=after[model],freeBytesAfter=shutil.disk_usage(base).free);save(result)
    after=tags();assert all(name in after and after[name]['digest']==m['digest']for name,m in before.items())
    result.update(state='completed',existingModelDigestsUnchanged=True,installedModelsAfter={m:after[m]for m in models});save(result);print('MODEL_PULLS_COMPLETE no inference/default change',flush=True)
except BaseException as error:
    result.update(state='failed',error=str(error));save(result);raise
