from pathlib import Path
import hashlib,json,os,shutil,sqlite3,subprocess,time

root=Path.cwd();base=root/'.artifacts/answer-model-refresh-v1';out=base/'preparation-v1';out.mkdir(mode=0o700,exist_ok=False);(out/'raw').mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=root/'.artifacts/answer-support-baseline-v1';oldReport=json.loads((baseline/'run-v2/report.json').read_text());oldReceipt=json.loads((root/'benchmarks/answer-support-baseline-v1.json').read_text())
extensionPath=base/'extension-plan-v1.json';extension=json.loads(extensionPath.read_text());assert sha(extensionPath)=='7aead43f50ba01cc6e64b35687c7f06ba53e0d9f46dde9aa3f36ae5120f5814c'
runtime=json.loads((root/'benchmarks/storage-setup-recovery-v1.json').read_text());binary=Path(runtime['newPackage']['path'])/'Contents/MacOS/oswindctl';assert sha(binary)==runtime['newPackage']['files']['Contents/MacOS/oswindctl']
inputs=json.loads((root/'benchmarks/storage-setup-recovery-inputs-v1.json').read_text())['inputFiles'];assert len(inputs)==700 and all(sha(root/p)==h for p,h in inputs.items())
settings=baseline/'retained-pre-inference-v1/settings.json';snapshot=baseline/'retained-pre-inference-v1/memory.sqlite';assert sha(snapshot)==oldReceipt['retainedPreInferenceSQLiteSHA256']
diagnostic=base/'diagnostic-library-v1';holdout=base/'extension-library-v1'
for folder in [diagnostic,holdout]:folder.mkdir(mode=0o700,exist_ok=False);shutil.copyfile(settings,folder/'settings.json');(folder/'settings.json').chmod(0o600)
shutil.copyfile(snapshot,diagnostic/'memory.sqlite');(diagnostic/'memory.sqlite').chmod(0o600);assert sha(diagnostic/'memory.sqlite')==sha(snapshot)
env={k:v for k,v in os.environ.items()if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))}
report={'state':'running','sourceCommit':runtime['sourceCommit'],'binarySHA256':sha(binary),'extensionPlanSHA256':sha(extensionPath),'oldPlanSHA256':oldReceipt['planSHA256'],'copiedOwnedSnapshotSHA256':sha(snapshot),'commands':[],'scope':'Owned fictional source preparation only; no answer generation. Separate exact snapshot copy for24 existing diagnostics and new8-source corpus for12 new questions. Original frozen libraries/runners/results untouched.'}
def save():
    p=out/'result.json';p.write_text(json.dumps(report,indent=2)+'\n');p.chmod(0o600)
def command(name,library,args):
    stdout=out/'raw'/(name+'.stdout');stderr=out/'raw'/(name+'.stderr');start=time.monotonic()
    with stdout.open('xb')as o,stderr.open('xb')as e:r=subprocess.run([str(binary),'--data',str(library),*args],env=env,stdout=o,stderr=e,timeout=120)
    value={'name':name,'exit':r.returncode,'stdout':str(stdout.relative_to(base)),'stderr':str(stderr.relative_to(base)),'stdoutSHA256':sha(stdout),'stderrSHA256':sha(stderr),'wallSeconds':time.monotonic()-start};report['commands'].append(value);save();assert r.returncode==0
    return stdout.read_text().strip()
def rows(library):
    db=sqlite3.connect('file:'+str(library/'memory.sqlite')+'?mode=ro',uri=True)
    try:return {i:p for i,p in db.execute('SELECT id,payload FROM memories ORDER BY id')}
    finally:db.close()
try:
    json.loads(command('diagnostic-clone-stats',diagnostic,['stats']))
    copied=rows(diagnostic);assert set(copied)==set(oldReport['sourceRows'])
    mapping={}
    for identifier,payload in copied.items():
        raw=payload if isinstance(payload,bytes)else payload.encode();assert hashlib.sha256(raw).hexdigest()==oldReport['sourceRows'][identifier]['payloadSHA256'];mapping[identifier]=oldReport['sourceRows'][identifier]['key']
    report['diagnosticRows']={i:{'key':mapping[i],'payloadSHA256':hashlib.sha256(p if isinstance(p,bytes)else p.encode()).hexdigest(),'textSHA256':hashlib.sha256(json.loads(p)['text'].encode()).hexdigest()}for i,p in copied.items()}
    mapping={}
    for doc in extension['documents']:
        identifier=command('extension-seed-'+doc['key'],holdout,['note',doc['text']]);assert identifier and identifier not in mapping;mapping[identifier]=doc['key'];print('PREPARED '+doc['key'],flush=True)
    saved=rows(holdout);assert len(saved)==8 and set(saved)==set(mapping)
    docs={d['key']:d for d in extension['documents']}
    for identifier,payload in saved.items():assert json.loads(payload)['text']==docs[mapping[identifier]]['text']
    report['extensionRows']={i:{'key':mapping[i],'payloadSHA256':hashlib.sha256(p if isinstance(p,bytes)else p.encode()).hexdigest(),'textSHA256':docs[mapping[i]]['sha256']}for i,p in saved.items()}
    assert sha(snapshot)==report['copiedOwnedSnapshotSHA256'] and all(sha(root/p)==h for p,h in inputs.items())
    report['state']='completed';report['answerGenerationCalls']=0;save();print('PREPARATION_COMPLETE exact16 old rows and8 new notes; no answer generation',flush=True)
except BaseException as error:
    report.update(state='failed',error=str(error));save();raise
