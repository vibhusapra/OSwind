from pathlib import Path
import copy,hashlib,json,subprocess
root=Path.cwd();base=root/'.artifacts/capture-request-admission-v1';out=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();target=out/'reviewed-v1.json';assert not target.exists()
inputs=json.loads((out/'inputs.json').read_text());results=json.loads((out/'results.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==inputs['baseSource']==results['baseSource']=='fc4a9a7fe39d530334db11b7b351dd8f93aea66a'
assert len(inputs['inputFiles'])==689 and len(inputs['workingChanges'])==6 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items()) and all(sha(root/p)==h for p,h in inputs['workingChanges'].items())
assert results['inputManifestSHA256']==sha(out/'inputs.json') and results['runnerSHA256']==sha(base/'qualify-v1.py')
prior=json.loads((root/'benchmarks/sync-membership-backfill-inputs-v1.json').read_text());assert len(prior['inputFiles'])==687
changed_prior={p for p,h in prior['inputFiles'].items() if inputs['inputFiles'][p]!=h};assert changed_prior=={'Sources/OSwindCLI/main.swift'}
assert set(inputs['inputFiles'])-set(prior['inputFiles'])=={'Sources/OSwindCLI/CaptureRequestCLI.swift','Tests/Fixtures/CaptureRequestParserContract.swift'}
old=results['legacyCLI'];assert sha(Path(old['file']))==old['sha256'];legacy_manifest=root/'.artifacts/sync-membership-backfill-v1/package-manifest-v1.json';legacy=json.loads(legacy_manifest.read_text());assert sha(legacy_manifest)==results['legacyPackageManifestSHA256'] and all(sha(Path(legacy['app'])/p)==h for p,h in legacy['files'].items())
package=out/'OSwind.app';profiles=[('debug-build',['swift','build','--product','oswindctl'],{},0),('debug-process',['python3','scripts/capture-request-admission-smoke.py','--binary',str(root/'.build/debug/oswindctl'),'--output',str(out/'debug-process.json')],{},0),('release-build',['swift','build','-c','release','--product','oswindctl'],{},0),('release-process',['python3','scripts/capture-request-admission-smoke.py','--binary',str(root/'.build/release/oswindctl'),'--output',str(out/'release-process.json')],{},0),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(package)},0),('packaged-process',['python3','scripts/capture-request-admission-smoke.py','--binary',str(package/'Contents/MacOS/oswindctl'),'--output',str(out/'packaged-process.json')],{},0),('old-binary-control',['python3','scripts/capture-request-admission-smoke.py','--binary',old['file'],'--output',str(out/'old-must-not-pass.json')],{},1)]
assert len(results['stages'])==len(profiles)
for stage,(name,command,env,exit_code) in zip(results['stages'],profiles):
 assert (stage['name'],stage['command'],stage['environment'],stage['exit'],stage['expectedExit'])==(name,command,env,exit_code,exit_code)
 assert sha(root/stage['log'])==stage['sha256']
old_log=(out/'old-binary-control.log').read_text();assert 'capture/missing-target' in old_log and 'Invalid capture area' in old_log and not (out/'old-must-not-pass.json').exists()
unit_ref=results['reusedParserContract'];unit_path=root/unit_ref['file'];unit=json.loads(unit_path.read_text());assert sha(unit_path)==unit_ref['sha256'] and unit['passed'] and unit['inputFiles']==unit_ref['validatedActualInputHashes'] and all(sha(root/p)==h for p,h in unit['inputFiles'].items())
expected_checks=[]
for command in ['capture','capture-text','capture-replay']:
 expected_checks += [command+' retains exact explicit target bytes',command+' preserves intended duration',command+' allows current window only when target was omitted',command+' preserves target with a spaced vault path']
 for i in range(6):expected_checks.append(command+' refuses malformed intent '+str(len(expected_checks)))
expected_checks += ['replay preserves finite bound '+v for v in ['1','1e0','120','120.0']]+['replay refuses invalid duration '+v for v in ['NaN','inf','-inf','-1','0','0.99','120.01']]+['non-capture '+v+' keeps its own argument semantics' for v in ['note','stats','config','pii','help']]
assert unit['checks']==expected_checks and len(unit['checks'])==46
common=['missing-target','empty-target','whitespace-target','flag-as-target','duplicate-target','unknown-option','stray-argument','oversized-target','multibyte-oversized-target','control-in-target','leading-dash-target','space-in-target'];globals_=['missing-data','empty-data','flag-as-data','duplicate-data','missing-vault','duplicate-vault','conflicting-roots','oversized-data'];durations=['missing-seconds','missing-seconds-value','empty-seconds','duplicate-seconds','nan-seconds','infinite-seconds','negative-infinite-seconds','zero-seconds','negative-seconds','subsecond-duration','over-limit-duration','nonnumeric-duration']
negative={c+'/'+k for c in ['capture','capture-text','capture-replay'] for k in common+globals_}|{'capture-replay/'+k for k in durations};positive={c+'/'+k for c in ['capture','capture-text','capture-replay'] for k in ['valid-current-request','valid-explicit-target']}|{'capture-replay/valid-reordered-upper-bound'};assert len(negative)==72 and len(positive)==7
harness_sha=sha(root/'scripts/capture-request-admission-smoke.py')
def validate(report,binary_sha):
 assert report['passed'] and report['harnessSHA256']==harness_sha and report['binarySHA256']==binary_sha
 assert (report['malformedCases'],report['positivePolicyControls'])==(72,7)
 rows=report['rows'];states={r['case']:r for r in rows};assert len(states)==len(rows)==79 and set(states)==negative|positive
 for name,r in states.items():
  assert r['capturedMemories']==0
  if name in negative:assert r['expected']=='preflight-refusal-without-filesystem-change' and r['exit']==1 and r['stdout']=='' and r['stderr'].startswith('OSwind: ') and r['filesystemUnchanged'] is True
  else:
   assert r['expected']=='configured-policy-refusal' and r['filesystemUnchanged'] is False
   if name.startswith('capture/'):assert r['exit']==0 and 'Invalid capture area' in r['stdout']
   else:assert r['exit']==1 and ('capture area' in r['stderr'].lower() or 'Select and save Text only' in r['stderr'])
 compat=report['nonCaptureCompatibility'];assert [r['command'] for r in compat]==['stats','config'] and all(r['exit']==0 for r in compat)
 assert json.loads(compat[0]['stdout'])['count']==0
 config=json.loads(compat[1]['stdout']);assert config['captureOnLaunch'] is False and config['apiEnabled'] is False
 return {'malformed':72,'positive':7,'compatibility':2,'capturedMemories':0}
review=[];reports={}
for name in ['debug-process','release-process','packaged-process']:
 p=out/(name+'.json');d=json.loads(p.read_text());binary_sha=sha(Path(d['binary']));row=validate(d,binary_sha);reports[name]=d;review.append({'mode':name,**row,'binarySHA256':binary_sha,'receiptSHA256':sha(p)})
faults={};original=reports['debug-process'];binary_sha=original['binarySHA256']
for label in ['dropped-row','duplicate-row','hidden-filesystem-change','hidden-captured-memory','missing-compatibility','wrong-binary','wrong-policy-outcome']:
 d=copy.deepcopy(original)
 if label=='dropped-row':d['rows'].pop()
 elif label=='duplicate-row':d['rows'].append(copy.deepcopy(d['rows'][0]))
 elif label=='hidden-filesystem-change':d['rows'][0]['filesystemUnchanged']=False
 elif label=='hidden-captured-memory':d['rows'][0]['capturedMemories']=1
 elif label=='missing-compatibility':d['nonCaptureCompatibility'].pop()
 elif label=='wrong-binary':d['binarySHA256']='0'*64
 elif label=='wrong-policy-outcome':next(r for r in d['rows'] if r['case'] in positive)['stdout']='wrong output'
 try:validate(d,binary_sha)
 except AssertionError:faults[label]='rejected'
 else:raise AssertionError('Altered receipt accepted '+label)
package_files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()}
result={'format':'OSwind CLI capture request admission review v1','baseSource':inputs['baseSource'],'inputCount':689,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'unchangedPriorInputs':686,'newInputFiles':sorted(set(inputs['inputFiles'])-set(prior['inputFiles'])),'parserContract':{'file':unit_ref['file'],'sha256':unit_ref['sha256'],'checks':46,'actualInputHashesMatch':True,'reusedWithoutRepeatingUnchangedSuccessfulContract':True},'modes':review,'stages':[{'name':s['name'],'exit':s['exit'],'expectedExit':s['expectedExit'],'logSHA256':s['sha256'],'wallSeconds':s['wallSeconds']} for s in results['stages']],'rejectedAlteredReceiptControls':faults,'actualOlderBinaryRejected':{'sha256':old['sha256'],'logSHA256':sha(out/'old-binary-control.log'),'firstCase':'capture/missing-target','capturedMemories':0,'scope':'Owned disabled policy; older CLI incorrectly returns0 and opens its owned database. The new process harness rejects that behavior, without capturing the user foreground.'},'newPackage':{'path':str(package),'files':package_files,'scope':'New local ad-hoc package built with existing strict codesign verification; no DeveloperID/notarization/DP-Keychain or signed GUI acceptance.'},'scope':'CLI capture/capture-text/capture-replay argument preflight before library/vault/model/native capture access. Actual parser preserves explicit target bytes and finite1..120 replay duration; current-window intent is deliberate. No change to Core or GUI capture policy; all686other prior runtime/test/dependency inputs remain unchanged. No native pixel/AX/audio, GUI/TCC, GPU/model quality, power, soak, complete sync or competitor-ranking qualification.'}
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'review':str(target.relative_to(root)),'sha256':sha(target),'parserChecks':46,'modes':review,'receiptFaultControls':len(faults),'oldBinaryRejected':True}))
