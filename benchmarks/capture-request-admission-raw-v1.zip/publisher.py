from pathlib import Path
import hashlib,json,os,subprocess,zipfile
root=Path.cwd();base=root/'.artifacts/capture-request-admission-v1';run=base/'qualification-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review_path=run/'reviewed-v1.json'
assert sha(review_path)=='23cb75448d069a10cd3b144c3f820ff148544062eac98624cab45314cf0d6c4f'
review=json.loads(review_path.read_text());inputs=json.loads((run/'inputs.json').read_text());results=json.loads((run/'results.json').read_text())
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='20ce51f1551955e1c74449074dbc5a2c7d7483cf'
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']==review['baseSource']=='fc4a9a7fe39d530334db11b7b351dd8f93aea66a'
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges']) and len(inputs['workingChanges'])==6
assert len(inputs['inputFiles'])==689 and inputs['workingChanges']==review['workingChanges']
assert results['runnerSHA256']==review['runnerSHA256']==sha(base/'qualify-v1.py') and review['reviewerSHA256']==sha(base/'review-v1.py')
assert review['inputManifestSHA256']==sha(run/'inputs.json') and len(review['stages'])==7
assert all(s['exit']==s['expectedExit'] for s in review['stages'])
assert len(review['rejectedAlteredReceiptControls'])==7
assert subprocess.check_output(['git','rev-parse','--show-object-format'],text=True).strip()=='sha1'
tree={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
 if entry:
  header,path=entry.split(b'\t',1);tree[path.decode()]=header.decode().split()[2]
for path,h in {**inputs['inputFiles'],**inputs['workingChanges']}.items():
 p=root/path;body=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 assert hashlib.sha256(body).hexdigest()==h
 assert tree[path]==hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
protected={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
 if entry:
  header,path=entry.split(b'\t',1);p=root/path.decode();body=p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()==header.decode().split()[2]
  protected[path.decode()]=sha(p)
files={'runner.py':base/'qualify-v1.py','reviewer.py':base/'review-v1.py','publisher.py':Path(__file__),'inputs.json':run/'inputs.json','results.json':run/'results.json','reviewed-v1.json':review_path,'controller.log':base/'qualification-controller-v1.log','review-controller.log':run/'review-controller-v1.log','parser-contract.json':base/'parser-contract-v1.json','parser-contract.log':base/'parser-contract-v1.log','baseline.py':base/'baseline-v1.py','baseline.json':base/'baseline-v1.json','prior-package-provenance.json':root/'.artifacts/sync-membership-backfill-v1/package-manifest-v1.json'}
for stage in results['stages']:
 p=root/stage['log'];assert sha(p)==stage['sha256'];files['logs/'+stage['name']+'.log']=p
for mode in review['modes']:
 p=run/(mode['mode']+'.json');assert sha(p)==mode['receiptSHA256'];files['receipts/'+p.name]=p
assert sha(base/'parser-contract-v1.json')==review['parserContract']['sha256']
for path in inputs['workingChanges']:files['source/'+path]=root/path
payloads={name:path.read_bytes() for name,path in files.items()}
payloads['README.txt']=(f'OSwind capture request admission runtime {source}. Exact689 runtime/test/dependency inputs plus6 changed-file hashes verified against committed Git blobs. Actual parser contract46 checks reused for exact unchanged inputs. Debug/release/packaged each72 malformed refusals,7 valid guarded requests,2 stats/config compatibility controls,0 captured memories. Malformed requests preserve full owned filesystem footprint before library/native access. Older actual CLI fails firstcase capture/missing-target under disabled snapshot policy; safe baseline records5 malformed snapshot successes and7 library opens without capturing foreground. Seven altered-receipt controls reject. Explicit source/log/receipt files only; no database, credential backend, keys, account inventory or executables. New package is local ad-hoc; no DeveloperID/notarization/production DP-Keychain or GUI acceptance. All feature statuses/landscape unchanged. No new native pixel/AX/audio, GPU/model, sustained energy,24h soak, full sync or competitor ranking claim. Prior successful reviewers/publications/packages remain frozen.\n').encode()
receipt=root/'benchmarks/capture-request-admission-v1.json';manifest=root/'benchmarks/capture-request-admission-inputs-v1.json';archive=root/'benchmarks/capture-request-admission-raw-v1.zip'
assert all(not p.exists() for p in [receipt,manifest,archive])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,body in sorted(payloads.items()):z.writestr(name,body)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(payloads) and set(z.namelist())==set(payloads)
 assert all(z.read(n)==b for n,b in payloads.items())
with manifest.open('x') as f:
 json.dump({'format':'OSwind capture request admission inputs v1','runtimeCommit':source,'developmentBase':inputs['baseSource'],'inputFiles':inputs['inputFiles'],'workingChanges':inputs['workingChanges'],'developmentManifestSHA256':sha(run/'inputs.json')},f,indent=2);f.write('\n')
result={**review,'runtimeCommit':source,'allCommittedInputBlobsMatch':True,'inputManifest':manifest.name,'inputManifestSHA256':sha(manifest),'reviewSHA256':sha(review_path),'publisherSHA256':sha(Path(__file__)),'host':results['host'],'toolchain':results['toolchain'],'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payloads),'allArchivedBytesComparedToReviewedInputs':True,'files':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(payloads.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True,'manifestSHA256':hashlib.sha256(json.dumps(protected,sort_keys=True,separators=(',',':')).encode()).hexdigest()},'featureBoundary':'CLI-only admission. All83feature records and landscape unchanged; full v0 acceptance remains open.'}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'runtimeCommit':source,'receipt':receipt.name,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payloads),'protectedBaseFiles':len(protected)}))
