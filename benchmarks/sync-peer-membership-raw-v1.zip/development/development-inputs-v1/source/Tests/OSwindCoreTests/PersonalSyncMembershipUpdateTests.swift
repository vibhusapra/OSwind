import XCTest
import CSQLite
@testable import OSwindCore

final class PersonalSyncMembershipUpdateTests:XCTestCase {
    private var root:URL!,stores=[MemoryStore](),pairings=[PersonalSyncPairing](),sessions=[PersonalSyncSession](),changes=[PersonalSyncMembershipChange]()
    private let storage=PairingTestStorage(),now=Date(timeIntervalSince1970:1_800_000_000)
    private let machine=SyncCredentialBindingTests.Machine(value:String(repeating:"d",count:64))
    private var serial=0
    private var environment:SyncNativeWriterEnvironment {.init(stateRoot:root.appendingPathComponent("state"),machine:machine,storage:{[storage] _ in storage})}
    private struct Fixture {
        let ownerStore:MemoryStore,peerStore:MemoryStore,joining:PersonalSyncPairing
        let ownerSession:PersonalSyncSession,peerSession:PersonalSyncSession
        let firstCertificate:SyncMembershipCertificate,request:String,fingerprint:String,folder:URL
        var exporting:PersonalSyncPairing?
    }
    override func setUpWithError()throws {
        root=FileManager.default.temporaryDirectory.appendingPathComponent("owned-membership-update-"+UUID().uuidString)
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:false,attributes:[.posixPermissions:0o700])
    }
    override func tearDown()async throws {
        for session in sessions {try await session.stop()}
        try changes.forEach {try $0.close()};pairings.forEach {$0.close()};try stores.forEach {try $0.close()}
        try FileManager.default.removeItem(at:root)
    }
    private func store(_ path:URL)throws->MemoryStore {
        let value=try MemoryStore(root:path,recoveryReadOnly:false,nativeWriterEnvironment:environment);stores.append(value);return value
    }
    private func pair(_ store:MemoryStore)throws->PersonalSyncPairing {
        let value=try PersonalSyncPairing(store:store,stateRoot:environment.stateRoot,machine:machine,storage:storage);pairings.append(value);return value
    }
    private func fixture(advanceOwner:Bool=true)async throws->Fixture {
        serial+=1;let base=root.appendingPathComponent("fixture-\(serial)"),ownerStore=try store(base.appendingPathComponent("owner")),peerStore=try store(base.appendingPathComponent("peer")),owner=try pair(ownerStore),peer=try pair(peerStore)
        _=try owner.createGroup(deviceName:"Owned desk",now:now)
        let fingerprint=try XCTUnwrap(owner.status().rootFingerprint),first=try SyncMembershipUpdateRequest.decode(Data(owner.membershipUpdateRequest().utf8)).certificate
        let request=try XCTUnwrap(peer.requestJoin(deviceName:"Owned travel",now:now).request)
        _=try peer.acceptResponse(owner.approve(owner.reviewRequest(request,now:now),now:now),trustedRootFingerprint:fingerprint,now:now)
        let folder=base.appendingPathComponent("provider"),ownerSession=try owner.prepareSession(sharedFolder:folder,createSharedFolder:true),peerSession=try peer.prepareSession(sharedFolder:folder)
        sessions += [ownerSession,peerSession]
        let joining=try pair(store(base.appendingPathComponent("joining"))),joiningRequest=try XCTUnwrap(joining.requestJoin(deviceName:"Owned third Mac",now:now).request)
        var fixture=Fixture(ownerStore:ownerStore,peerStore:peerStore,joining:joining,ownerSession:ownerSession,peerSession:peerSession,firstCertificate:first,request:joiningRequest,fingerprint:fingerprint,folder:folder)
        if advanceOwner {
            let review=try await ownerSession.reviewOwnerAddition(joiningRequest,now:now);try await ownerSession.stop()
            let time=now,change=try await ownerSession.ownerChangeAfterStopping(review,clock:{time});changes.append(change)
            let response=try XCTUnwrap(change.apply(clock:{self.now}));try change.close()
            _=try joining.acceptResponse(response.response,trustedRootFingerprint:fingerprint,now:now)
            fixture.exporting=try pair(store(ownerStore.root))
        }
        return fixture
    }
    private func page(_ fixture:Fixture)async throws->String {
        let request=try await fixture.peerSession.membershipUpdateRequest()
        return try XCTUnwrap(fixture.exporting).membershipUpdatePage(for:request).map {$0} ?? {throw OSwindError.invalid("Owned successor page missing")}()
    }
    private func change(_ session:PersonalSyncSession,_ review:PersonalSyncMembershipReview)async throws->PersonalSyncMembershipChange {
        let value=try await session.membershipChangeAfterStopping(review);changes.append(value);return value
    }
    private func refused(_ session:PersonalSyncSession,_ review:PersonalSyncMembershipReview)async {
        do {_=try await change(session,review);XCTFail("A live, stale, consumed or foreign membership review must refuse")}
        catch {}
    }
    private func pairingID(_ store:MemoryStore)throws->String {
        try store.withRoutineDatabase {db in
            let row=try db.statement("SELECT value FROM store_metadata WHERE key='sync-pairing-handle-v1'");defer {sqlite3_finalize(row)}
            guard sqlite3_step(row)==SQLITE_ROW else {throw OSwindError.invalid("Owned pairing handle missing")}
            let object=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(db.text(row,0).utf8)) as? [String:Any]);return try XCTUnwrap(object["id"] as? String)
        }
    }
    private func futurePage(_ f:Fixture)throws->String {
        let envelope=try XCTUnwrap(JSONSerialization.jsonObject(with:storage.read(id:pairingID(f.ownerStore))) as? [String:Any])
        let raw=try XCTUnwrap(Data(base64Encoded:XCTUnwrap(envelope["material"] as? String))),authority=try XCTUnwrap(SyncCredentialMaterial.decodeFromKeychain(raw).owner)
        let future=try authority.admitting(SyncJoinRequest.decode(Data(f.request.utf8),now:now),now:now)
        return String(decoding:try SyncMembershipRefresh(base:authority.certificate,updates:[future.certificate]).encoded(),as:UTF8.self)
    }
    func testPublicRequestAndPageExposeOnlySignedHistoryAndExactCurrentReturnsNil()async throws {
        let f=try await fixture(),request=try await f.peerSession.membershipUpdateRequest(),decoded=try SyncMembershipUpdateRequest.decode(Data(request.utf8)),page=try await page(f),proof=try SyncMembershipRefresh.decode(Data(page.utf8))
        XCTAssertEqual(decoded.certificate.body.members.count,2);XCTAssertEqual(proof.base,decoded.certificate);XCTAssertEqual(proof.head.body.members.count,3)
        XCTAssertEqual(try proof.advance(from:decoded.certificate),proof.head)
        let exporter=try XCTUnwrap(f.exporting);XCTAssertNil(try exporter.membershipUpdatePage(for:exporter.membershipUpdateRequest()))
        for text in [request,page] {for key in ["signingPrivate","agreementPrivate","groupSecret","ownerPrivate","pairingBefore","materialBefore"] {XCTAssertFalse(text.contains("\""+key+"\""))}}
    }
    func testPublicRequestRejectsNoncanonicalUnknownFormatTamperingAndOversize()async throws {
        let f=try await fixture(),request=try await f.peerSession.membershipUpdateRequest(),exporter=try XCTUnwrap(f.exporting)
        XCTAssertThrowsError(try exporter.membershipUpdatePage(for:request+" "))
        XCTAssertThrowsError(try exporter.membershipUpdatePage(for:String(repeating:" ",count:SyncMembershipUpdateRequest.maximumBytes+1)))
        for field in ["format","version","unknown","certificate"] {
            var object=try XCTUnwrap(JSONSerialization.jsonObject(with:Data(request.utf8)) as? [String:Any])
            switch field {
            case "format":object[field]="untrusted"
            case "version":object[field]=2
            case "unknown":object[field]=true
            default:var certificate=try XCTUnwrap(object[field] as? [String:Any]);certificate["signature"]=Data(repeating:0,count:64).base64EncodedString();object[field]=certificate
            }
            let bytes=try JSONSerialization.data(withJSONObject:object,options:[.sortedKeys,.withoutEscapingSlashes])
            XCTAssertThrowsError(try exporter.membershipUpdatePage(for:String(decoding:bytes,as:UTF8.self)),field)
        }
    }
    func testExactReviewedPeerStopsBeforeRetainedIntentAndAppliesWithoutJoiningResponse()async throws {
        let f=try await fixture(),review=try await f.peerSession.reviewMembershipUpdate(page(f)),saved=storage.values
        XCTAssertEqual(review.rootFingerprint,f.fingerprint);XCTAssertEqual(review.currentMemberCount,2);XCTAssertEqual(review.updatedMemberCount,3);XCTAssertEqual(review.addedDeviceNames,["Owned third Mac"])
        await refused(f.peerSession,review);XCTAssertTrue(storage.values==saved)
        try await f.peerSession.stop();let operation=try await change(f.peerSession,review)
        XCTAssertTrue(operation.belongs(to:f.peerStore));XCTAssertTrue(storage.values==saved,"Draft wrote a private intent before the caller retained it")
        XCTAssertNil(try operation.apply());let admitted=storage.values
        XCTAssertNil(try operation.apply());XCTAssertTrue(storage.values==admitted);await refused(f.peerSession,review)
        try operation.close();XCTAssertTrue(f.peerStore.isClosed)
        let fresh=try store(f.peerStore.root),paired=try pair(fresh);try review.validateReopenedStore(fresh)
        XCTAssertEqual(try paired.status().memberNames.count,3);XCTAssertEqual(Set(storage.values.keys),Set(saved.keys))
        try fresh.insert(Memory(id:"after-update",text:"Original peer can write after exact membership catch-up"));XCTAssertNotNil(try fresh.get("after-update"))
    }
    func testLatestReviewInvalidatesPriorTokenWithoutConsumingCurrentOne()async throws {
        let f=try await fixture(),page=try await page(f),first=try await f.peerSession.reviewMembershipUpdate(page),second=try await f.peerSession.reviewMembershipUpdate(page),saved=storage.values
        XCTAssertNotEqual(first,second);try await f.peerSession.stop();await refused(f.peerSession,first)
        let operation=try await change(f.peerSession,second);try operation.close();XCTAssertTrue(storage.values==saved)
    }
    func testDifferentSessionAndReplacementSessionOnSameStoreRefuseOldReview()async throws {
        let a=try await fixture(),b=try await fixture(),page=try await page(a),review=try await a.peerSession.reviewMembershipUpdate(page)
        try await a.peerSession.stop();try await b.peerSession.stop();await refused(b.peerSession,review)
        let owner=try pair(a.peerStore),replacement=try owner.prepareSavedSession();sessions.append(replacement)
        let current=try await replacement.reviewMembershipUpdate(page);try await replacement.stop();await refused(replacement,review)
        let operation=try await change(replacement,current);try operation.close()
    }
    func testBusyCloseKeepsOriginalPairingLeaseUntilExactRetry()async throws {
        let f=try await fixture(),account=try pairingID(f.peerStore),review=try await f.peerSession.reviewMembershipUpdate(page(f))
        try await f.peerSession.stop();let operation=try await change(f.peerSession,review);XCTAssertNil(try operation.apply())
        var statement:OpaquePointer?=try f.peerStore.withMembershipDatabase {try $0.statement("SELECT 1")};defer {sqlite3_finalize(statement)}
        XCTAssertThrowsError(try operation.close());XCTAssertFalse(f.peerStore.isClosed)
        XCTAssertThrowsError(try SyncCredentialExclusiveLease(id:account,stateRoot:environment.stateRoot))
        sqlite3_finalize(statement);statement=nil;try operation.close();XCTAssertTrue(f.peerStore.isClosed)
        let lease=try SyncCredentialExclusiveLease(id:account,stateRoot:environment.stateRoot);lease.close()
    }
    func testAlreadyAppliedForeignAndMalformedPagesDoNotChangeAuthority()async throws {
        let f=try await fixture(),other=try await fixture(),request=try await f.peerSession.membershipUpdateRequest(),trusted=try SyncMembershipUpdateRequest.decode(Data(request.utf8)).certificate
        let already=String(decoding:try SyncMembershipRefresh(base:f.firstCertificate,updates:[trusted]).encoded(),as:UTF8.self),foreign=try await page(other),saved=storage.values
        for invalid in [already,foreign,"untrusted",String(repeating:" ",count:SyncMembershipRefresh.maximumBytes+1)] {
            do {_=try await f.peerSession.reviewMembershipUpdate(invalid);XCTFail("Invalid membership page accepted")}
            catch {}
        }
        XCTAssertTrue(storage.values==saved)
    }
    func testOwnerAndPeerReviewsInvalidateEachOtherAndShareOneTransferReservation()async throws {
        let a=try await fixture(advanceOwner:false),ownerReview=try await a.ownerSession.reviewOwnerAddition(a.request,now:now)
        let peerReview=try await a.ownerSession.reviewMembershipUpdate(futurePage(a));try await a.ownerSession.stop()
        do {_=try await a.ownerSession.ownerChangeAfterStopping(ownerReview);XCTFail("Peer review left owner approval current")}
        catch {}
        let peerChange=try await change(a.ownerSession,peerReview);try peerChange.close()
        let b=try await fixture(advanceOwner:false),oldPeer=try await b.ownerSession.reviewMembershipUpdate(futurePage(b)),current=try await b.ownerSession.reviewOwnerAddition(b.request,now:now)
        try await b.ownerSession.stop();await refused(b.ownerSession,oldPeer)
        let time=now,ownerChange=try await b.ownerSession.ownerChangeAfterStopping(current,clock:{time});changes.append(ownerChange);try ownerChange.close()
    }
}
