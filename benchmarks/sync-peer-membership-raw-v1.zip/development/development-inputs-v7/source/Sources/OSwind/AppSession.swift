import SwiftUI
import AppKit
import Combine
import Darwin
import OSwindCore

struct PersonalSyncErasureRecovery:Sendable {
    let pending:@Sendable (URL)async->Bool
    let retry:@Sendable (URL,@escaping @Sendable (LibraryBackupProgress)->Void)async throws->LibraryWipeResult
    static let native=Self(pending:{await PersonalSyncRetirementRecovery.hasPending(root:$0)},retry:{try await PersonalSyncRetirementRecovery.retry(root:$0,progress:$1)})
}

@MainActor final class AppSession: ObservableObject {
    static weak var current:AppSession?
    @Published var model:AppModel?
    @Published var failure:String?
    @Published var requested:URL
    @Published private(set) var vaultPackage:URL?
    @Published private(set) var vaultStatus:LibraryVaultStatus?
    @Published private(set) var busy=false
    @Published private(set) var progress:LibraryBackupProgress?
    @Published var message=""
    @Published var showVaultSetup=false
    @Published private(set) var createdVault:URL?
    @Published private(set) var snapshotNeedsReview=false
    @Published private(set) var syncErasurePending=false
    @Published private(set) var syncMembershipPending=false
    @Published var syncApprovalPresentation:SyncApprovalPresentation?
    private var membershipChange:PersonalSyncOwnerChange?
    private var membershipClosing=false
    private struct MembershipFinish {
        let root:URL,review:PersonalSyncOwnerReview?
        var peerReview:PersonalSyncMembershipReview?=nil
        var response:PersonalSyncApprovedResponse?,error:String?,cancelled=false
        var closedChange:PersonalSyncOwnerChange?
    }
    private var membershipFinish:MembershipFinish?
    var hasPendingMembershipClose:Bool {membershipClosing || membershipChange != nil}
    private let membershipRecovery:@Sendable (URL)->PersonalSyncOwnerChange
    private let ownerAdditionPreview:Bool
    let recoveryTransfer:LibraryTransferModel
    private var selection:LibraryLocationSelection
    private let defaults:UserDefaults
    private let locked:() -> Bool
    private var operation:Task<Void,Never>?
    private var pendingLock=false
    private var terminationRequested=false
    private var closingStore:MemoryStore?
    private weak var pendingSyncReopen:AppModel?
    private var workspaceSubscriptions=Set<AnyCancellable>()
    private var watcher:DispatchSourceFileSystemObject?
    private var lockMonitor:Timer?
    private var watchFD:Int32?
    private var watchedVaultID:String?
    private let personalSyncSetup:((MemoryStore)->PersonalSyncModel)?
    private let openStore:@Sendable (URL) throws -> MemoryStore
    private let syncRecovery:PersonalSyncErasureRecovery
    init(selection:LibraryLocationSelection?=nil,defaults:UserDefaults = .standard,locked:@escaping () -> Bool={SessionState.locked},openStore:@escaping @Sendable (URL) throws -> MemoryStore={try MemoryStore(root:$0)},personalSyncSetup:((MemoryStore)->PersonalSyncModel)?=nil,recoveryTransfer:LibraryTransferModel?=nil,syncRecovery:PersonalSyncErasureRecovery = .native,membershipRecovery:@escaping @Sendable (URL)->PersonalSyncOwnerChange={PersonalSyncOwnerChange.recover(root:$0)},ownerAdditionPreview:Bool=ProcessInfo.processInfo.environment["OSWIND_OWNER_ADDITION_PREVIEW"]=="1") {
        let resolved=selection ?? LibraryLocationPreferences.selection(demo:CommandLine.arguments.contains("--demo"),defaults:defaults)
        self.selection=resolved;self.defaults=defaults;self.locked=locked;self.openStore=openStore;self.personalSyncSetup=personalSyncSetup;requested=resolved.url;self.recoveryTransfer=recoveryTransfer ?? LibraryTransferModel();self.syncRecovery=syncRecovery;self.membershipRecovery=membershipRecovery;self.ownerAdditionPreview=ownerAdditionPreview
        self.recoveryTransfer.allowed={[weak self] in guard let self else {return false};return !self.terminationRequested && !self.busy && !self.locked()}
        do {
            if let package=try LibraryVault.package(containing:resolved.url) {
                vaultPackage=package;requested=package.appendingPathComponent("Library");watch(package)
                run {try await self.loadVault(startServices:true)}
            } else {try resolved.validate();run {self.model=try await self.preparedModel(root:resolved.url,startServices:true)}}
        } catch {failure=error.localizedDescription}
        for name in [NSWorkspace.willSleepNotification,NSWorkspace.screensDidSleepNotification,NSWorkspace.sessionDidResignActiveNotification] {
            NSWorkspace.shared.notificationCenter.publisher(for:name).sink {[weak self] _ in Task {@MainActor in self?.requestLock()}}.store(in:&workspaceSubscriptions)
        }
        Self.current=self
    }
    deinit {watcher?.cancel();lockMonitor?.invalidate();operation?.cancel()}
    func retry() {
        guard !terminationRequested,!busy else {return}
        if hasPendingMembershipClose || membershipFinish != nil && !syncMembershipPending {retryMembershipClose();return}
        if syncMembershipPending {resumeSyncMembership();return}
        if vaultPackage != nil {run {try await self.loadVault(startServices:false)}}
        else if model==nil {run {try self.selection.validate();self.model=try await self.preparedModel(root:self.selection.url,startServices:false)}}
    }
    func open(_ url:URL,persist:Bool=true) {
        guard maySwitch else {return}
        run {
            let package=try LibraryVault.package(containing:url)
            if let package,package==self.vaultPackage,self.model != nil {return}
            if package==nil {try LibraryLocationSelection(url:url,requiresExisting:true,origin:"selected").validate()}
            try await self.departCurrent()
            self.selection = .init(url:package?.appendingPathComponent("Library") ?? url,requiresExisting:true,origin:"selected")
            self.requested=self.selection.url;self.vaultPackage=package;self.vaultStatus=nil;self.message="";self.createdVault=nil;self.snapshotNeedsReview=false
            self.watch(package)
            if let package {
                if persist {try LibraryLocationPreferences.save(package,defaults:self.defaults)}
                try await self.loadVault(startServices:false)
            } else {
                let candidate=try await self.preparedModel(root:url,startServices:false)
                if persist {try LibraryLocationPreferences.save(url,defaults:self.defaults)}
                self.model=candidate
            }
        }
    }
    private var maySwitch:Bool {
        guard !terminationRequested,!busy,!hasPendingMembershipClose,model?.libraryTransfer.busy != true,model?.libraryWipe.busy != true,!recoveryTransfer.busy else {failure="Complete or cancel the current library operation before switching libraries.";return false};return true
    }
    func choose() {
        guard maySwitch else {return}
        let panel=NSOpenPanel();panel.canChooseFiles=true;panel.canChooseDirectories=true;panel.treatsFilePackagesAsDirectories=false;panel.allowsMultipleSelection=false;panel.prompt="Open library"
        guard panel.runModal() == .OK,let url=panel.url else {return};open(url)
    }
    func openDefault() {
        guard maySwitch else {return}
        run {
            try await self.departCurrent()
            let next=LibraryLocationSelection(url:Paths.data,requiresExisting:false,origin:"default");try next.validate()
            self.selection=next;self.requested=next.url;self.vaultPackage=nil;self.vaultStatus=nil;self.watch(nil)
            let candidate=try await self.preparedModel(root:next.url,startServices:false)
            self.defaults.removeObject(forKey:LibraryLocationPreferences.key);self.selection=next;self.requested=next.url;self.vaultPackage=nil;self.vaultStatus=nil;self.watch(nil);self.model=candidate
        }
    }
    private func loadVault(startServices:Bool) async throws {
        guard let package=vaultPackage else {return}
        let vault=try LibraryVault(package:package);vaultStatus=try await vault.status()
        if vaultStatus?.state == .unlocked {
            if terminationRequested || locked() {try await performLock();return}
            // A directory notification is observation, never permission to
            // bypass an original device-update owner or its reopened identity
            // check. Only the retained close/retry path may attach that model.
            guard !hasPendingMembershipClose,membershipFinish==nil else {return}
            if model==nil {model=try await preparedModel(root:vault.libraryURL,startServices:startServices)}
        } else if let previous=model {
            await stageForClosing(previous)
            // A competing CLI may have already replaced the public handle. The
            // store retains its verified canonical root solely for safe close.
            let store=previous.store;try await Task.detached(priority:.utility) {try store.close()}.value;closingStore=nil
        }
    }
    func unlock(passphrase:String,remember:Bool,using provider:any VaultSecretProvider=UserPresenceVaultSecrets()) {
        guard !terminationRequested,!busy,let package=vaultPackage else {return}
        message=""
        run {
            var secret=Data(passphrase.utf8);defer {secret.resetBytes(in:0..<secret.count)}
            let vault=try LibraryVault(package:package);self.vaultStatus=try await vault.unlock(passphrase:secret)
            try Task.checkCancellation()
            if remember {
                do {try await vault.rememberPassphrase(secret,using:provider);self.vaultStatus=try await vault.status()}
                catch {self.message="Library unlocked. Keychain was not updated: "+error.localizedDescription}
            }
            if self.locked() {try await self.performLock();return}
            self.model=try await self.preparedModel(root:vault.libraryURL,startServices:false)
            if self.message.isEmpty {self.message="Library unlocked. Recording starts when you resume it."}
        }
    }
    func unlockWithKeychain(using provider:any VaultSecretProvider=UserPresenceVaultSecrets()) {
        guard !terminationRequested,!busy,let package=vaultPackage else {return}
        message=""
        run {
            let vault=try LibraryVault(package:package);self.vaultStatus=try await vault.unlockUsingKeychain(using:provider);try Task.checkCancellation()
            if self.locked() {try await self.performLock();return}
            self.model=try await self.preparedModel(root:vault.libraryURL,startServices:false)
            self.message="Library unlocked. Recording starts when you resume it."
        }
    }
    func forgetKeychain() {
        guard !busy,let package=vaultPackage else {return}
        run {let vault=try LibraryVault(package:package);try await vault.forgetPassphrase();self.vaultStatus=try await vault.status();self.message="Saved unlock removed. Your vault passphrase still works."}
    }
    func requestLock() {
        syncApprovalPresentation=nil;membershipFinish?.cancelled=true
        guard vaultPackage != nil || busy || recoveryTransfer.busy || hasPendingMembershipClose else {return}
        if busy {pendingLock=true;operation?.cancel();return}
        run {try await self.performLock()}
    }
    private func performLock() async throws {
        syncApprovalPresentation=nil
        await recoveryTransfer.cancelAndWait()
        if hasPendingMembershipClose {try await closeMembershipResources()}
        membershipFinish=nil
        guard let package=vaultPackage else {return}
        if let previous=model {await stageForClosing(previous)}
        let vault=try LibraryVault(package:package)
        vaultStatus=try await vault.lock(store:closingStore);closingStore=nil
        guard vaultStatus?.state == .locked else {throw OSwindError.unavailable("The encrypted volume is still attached. Retry locking when other readers finish.")}
        message="Encrypted volume detached. Recording, audio and local API access are stopped."
    }
    private func departCurrent() async throws {
        syncApprovalPresentation=nil
        await recoveryTransfer.cancelAndWait()
        if hasPendingMembershipClose {try await closeMembershipResources()}
        membershipFinish=nil;syncMembershipPending=false
        if vaultPackage != nil {try await performLock()}
        else if let previous=model {
            await stageForClosing(previous)
            let store=previous.store;try await Task.detached(priority:.utility) {try store.close()}.value;closingStore=nil
        } else if let store=closingStore {try await Task.detached(priority:.utility) {try store.close()}.value;closingStore=nil}
    }
    /// Remove visible access first, then join imports before a SQLite close or
    /// image mutation. Even a worker not yet holding a reservation must finish.
    private func stageForClosing(_ previous:AppModel) async {
        syncApprovalPresentation=nil
        previous.clearForVaultLock();closingStore=previous.store
        if model === previous {model=nil}
        await previous.cancelExternalWorkAndWait()
    }
    func createVault(at package:URL,name:String,capacityGiB:Int,passphrase:String,copyHistory:Bool,remember:Bool,observeMigration:@escaping @Sendable (LibraryBackupProgress)->Void={_ in}) {
        guard maySwitch else {return}
        let original=model,source=copyHistory ? original?.store:nil
        if copyHistory,source==nil {failure="Open the source library before copying history.";return}
        message="";snapshotNeedsReview=false
        original?.prepareForLibrarySwitch()
        run {
            await original?.cancelExternalWorkAndWait()
            let relay=LibraryProgressRelay(),observer=Task {while !Task.isCancelled {do {try await Task.sleep(for:.milliseconds(100))} catch {break};self.progress=relay.get() ?? self.progress}}
            defer {observer.cancel();self.progress=nil}
            var secret=Data(passphrase.utf8);defer {secret.resetBytes(in:0..<secret.count)}
            self.progress = .init(phase:"Creating encrypted storage")
            do {
                if let source {
                    let result=try await LibraryVault.migrate(from:source,to:package,name:name,capacityGiB:capacityGiB,passphrase:secret,progress:{relay.set($0);observeMigration($0)})
                    self.createdVault=package
                    if !result.sourceStable {
                        if let original {try await self.restorePreparedOriginal(original)}
                        self.snapshotNeedsReview=true
                        self.message="A verified encrypted snapshot was saved, but the original changed during the copy. OSwind kept the original selected. Open the snapshot explicitly or make another copy after stopping other writers."
                        self.showVaultSetup=false;return
                    }
                } else {_=try await LibraryVault.create(at:package,name:name,capacityGiB:capacityGiB,passphrase:secret);self.createdVault=package}
                try Task.checkCancellation();try await self.departCurrent()
                let managed=try LibraryVault(package:package)
                self.vaultPackage=managed.packageURL;self.requested=managed.libraryURL;self.selection = .init(url:self.requested,requiresExisting:true,origin:"selected");self.watch(managed.packageURL)
                try LibraryLocationPreferences.save(package,defaults:self.defaults)
                let vault=try LibraryVault(package:package);self.vaultStatus=try await vault.unlock(passphrase:secret)
                try Task.checkCancellation()
                if remember {do {try await vault.rememberPassphrase(secret);self.vaultStatus=try await vault.status()} catch {self.message="Encrypted library created. Keychain was not updated: "+error.localizedDescription}}
                if self.locked() {try await self.performLock()} else {self.model=try await self.preparedModel(root:vault.libraryURL,startServices:false)}
                if self.message.isEmpty {self.message=copyHistory ? "Encrypted copy verified. The original library is still on disk; recording starts when you resume it.":"Encrypted library ready. Recording starts when you resume it."}
                self.showVaultSetup=false
            } catch {
                // A failed or cancelled copy never selects its destination. A
                // prepared source resumes as a fresh, quiet model when possible.
                if let original,self.model === original,!original.store.isClosed {try await self.restorePreparedOriginal(original)}
                throw error
            }
        }
    }
    private func restorePreparedOriginal(_ original:AppModel) async throws {
        await original.cancelExternalWorkAndWait()
        let store=original.store;try await Task.detached(priority:.utility) {try store.close()}.value
        // Restoring the original is cancellation cleanup: a stopped migration
        // still needs a quiet original workspace, with no resumed services.
        model=try await preparedModel(root:store.root,startServices:false,restoringOriginal:true)
    }
    private func preparedModel(root:URL,startServices:Bool,restoringOriginal:Bool=false,validateStore:((MemoryStore)throws->Void)?=nil) async throws -> AppModel {
        let opener=openStore,previousProgress=progress
        progress = .init(phase:"Preparing local search")
        defer {progress=previousProgress}
        let worker=Task.detached(priority:.utility) {try opener(root)}
        let store:MemoryStore
        do {
            if restoringOriginal {store=try await worker.value}
            else {store=try await withTaskCancellationHandler {try await worker.value} onCancel:{worker.cancel()}}
        }catch {syncMembershipPending=error is PersonalSyncMembershipRecoveryRequired;syncErasurePending=await syncRecovery.pending(root);throw error}
        do {
            if !restoringOriginal {
                try Task.checkCancellation()
                if terminationRequested || pendingLock {throw CancellationError()}
            }
            if vaultPackage != nil && (locked() || pendingLock || terminationRequested) {throw CancellationError()}
            try validateStore?(store)
            let candidate=try AppModel(root:root,startServices:false,preparedStore:store,personalSyncSetup:personalSyncSetup)
            if ownerAdditionPreview {
                candidate.personalSync.approveOwnerAddition={[weak self,weak candidate] review in
                    guard let self,let candidate else {return};self.approveSyncDevice(review,from:candidate)
                }
                candidate.personalSync.approveMembershipUpdate={[weak self,weak candidate] review in
                    guard let self,let candidate else {return};self.approveSyncMembership(review,from:candidate)
                }
            }
            candidate.syncErasureFinished={[weak self,weak candidate] in
                guard let self,let candidate else {return};self.reopenAfterSyncErasure(candidate)
            }
            syncErasurePending=false;syncMembershipPending=false
            if startServices {candidate.startConfiguredServices()}
            return candidate
        } catch {
            if membershipFinish != nil {
                closingStore=store;membershipClosing=true
                try await Task.detached(priority:.utility) {try store.close()}.value
                closingStore=nil;membershipClosing=false
            }else {try? await Task.detached(priority:.utility) {try store.close()}.value}
            throw error
        }
    }
    private func reopenAfterSyncErasure(_ previous:AppModel) {
        guard !terminationRequested,model === previous else {return}
        if busy {pendingSyncReopen=previous;return}
        // Remove visible access synchronously. A retired controller must not
        // accept a new capture while the quiet replacement is being prepared.
        let completed=previous.libraryWipe.result?.cleanupComplete==true,erasureStatus=previous.libraryWipe.status
        model=nil;closingStore=previous.store
        run(cancellationMessage:"Opening stopped. Reopen this library to check saved erasure or recovery.") {
            await self.stageForClosing(previous)
            let store=previous.store;try await Task.detached(priority:.utility) {try store.close()}.value;self.closingStore=nil
            self.model=try await self.preparedModel(root:self.requested,startServices:false)
            self.message=completed ? "History erasure finished. Recording stays paused until you resume it.":"Library reopened with recording paused. "+erasureStatus
        }
    }
    func approveSyncDevice(_ review:PersonalSyncOwnerReview,from previous:AppModel) {
        guard ownerAdditionPreview,!terminationRequested,!busy,!hasPendingMembershipClose,model === previous,!locked(),
              let current=previous.personalSync.sessionForOwnerApproval(review) else {return}
        syncApprovalPresentation=nil;membershipFinish = .init(root:previous.store.root,review:review)
        closingStore=previous.store;membershipClosing=true;model=nil
        // Deny all new work synchronously before the first suspension.
        previous.clearForVaultLock()
        run(cancellationMessage:"Approval stopped. Reopen this library to finish any saved device update.") {
            self.progress = .init(phase:"Stopping recording and local work")
            await previous.cancelExternalWorkAndWait()
            do {
                try await current.stop();try Task.checkCancellation()
                let change=try await current.ownerChangeAfterStopping(review)
                self.membershipChange=change
                self.progress = .init(phase:"Approving the device")
                let worker=Task.detached(priority:.utility) {try change.apply()}
                let response=try await withTaskCancellationHandler(operation:{try await worker.value},onCancel:{worker.cancel()})
                self.membershipFinish?.response=response
            }catch {self.membershipFinish?.error=error.localizedDescription}
            self.membershipFinish?.cancelled=Task.isCancelled
            try await self.finishMembershipCloseAndReopen()
        }
    }
    private func closeMembershipResources()async throws {
        if let change=membershipChange {
            try await Task.detached(priority:.utility) {try change.close()}.value
            membershipFinish?.closedChange=change
            membershipChange=nil;closingStore=nil
        }else if let store=closingStore {
            try await Task.detached(priority:.utility) {try store.close()}.value;closingStore=nil
        }
        membershipClosing=false
    }
    func approveSyncMembership(_ review:PersonalSyncMembershipReview,from previous:AppModel) {
        guard ownerAdditionPreview,!terminationRequested,!busy,!hasPendingMembershipClose,model === previous,!locked(),
              let current=previous.personalSync.sessionForMembershipUpdate(review) else {return}
        syncApprovalPresentation=nil;membershipFinish = .init(root:previous.store.root,review:nil,peerReview:review)
        closingStore=previous.store;membershipClosing=true;model=nil
        previous.clearForVaultLock()
        run(cancellationMessage:"Update stopped. Reopen this library to finish any saved device update.") {
            self.progress = .init(phase:"Stopping recording and local work")
            await previous.cancelExternalWorkAndWait()
            do {
                try await current.stop();try Task.checkCancellation()
                let change=try await current.membershipChangeAfterStopping(review)
                self.membershipChange=change
                self.progress = .init(phase:"Updating trusted devices")
                let worker=Task.detached(priority:.utility) {try change.apply()}
                _=try await withTaskCancellationHandler(operation:{try await worker.value},onCancel:{worker.cancel()})
            }catch {self.membershipFinish?.error=error.localizedDescription}
            self.membershipFinish?.cancelled=Task.isCancelled
            try await self.finishMembershipCloseAndReopen()
        }
    }
    private func finishMembershipCloseAndReopen()async throws {
        progress = .init(phase:"Finishing the local device update")
        defer {progress=nil}
        try await closeMembershipResources()
        guard let finish=membershipFinish else {return}
        if terminationRequested || pendingLock || locked() {
            membershipFinish=nil;syncApprovalPresentation=nil
            message="Device update stopped. Reopen this library to check its saved result.";return
        }
        let fresh=try await preparedModel(root:finish.root,startServices:false,restoringOriginal:true,validateStore:{store in
            try finish.review?.validateReopenedStore(store)
            try finish.peerReview?.validateReopenedStore(store)
            try finish.closedChange?.validateReopenedStore(store)
        })
        if terminationRequested || pendingLock || locked() {
            fresh.clearForVaultLock();await fresh.cancelExternalWorkAndWait()
            closingStore=fresh.store;membershipClosing=true
            try await closeMembershipResources();membershipFinish=nil;syncApprovalPresentation=nil
            message="Device update stopped. Reopen this library to check its saved result.";return
        }
        model=fresh;membershipFinish=nil
        if !Task.isCancelled,!finish.cancelled,finish.error==nil,let response=finish.response,let review=finish.review,
           response.requestFingerprint==review.requestFingerprint {
            syncApprovalPresentation = .init(response:response,rootFingerprint:review.rootFingerprint)
        }
        if let error=finish.error {failure=error}
        message="Library reopened. Recording and sync stay paused until you resume them."
    }
    func retryMembershipClose() {
        guard !terminationRequested,!busy,hasPendingMembershipClose || membershipFinish != nil else {return}
        run {try await self.finishMembershipCloseAndReopen()}
    }
    func resumeSyncMembership() {
        guard canRecoverContent,syncMembershipPending,!hasPendingMembershipClose else {return}
        let root=requested
        membershipFinish = .init(root:root,review:nil);membershipClosing=true
        // Retain before opening a restricted connection or original accounts.
        let change=membershipRecovery(root);membershipChange=change
        run(cancellationMessage:"Recovery stopped. Finish the saved device update before recording.") {
            self.progress = .init(phase:"Finishing saved device update")
            let worker=Task.detached(priority:.utility) {try change.apply()}
            do {_=try await withTaskCancellationHandler(operation:{try await worker.value},onCancel:{worker.cancel()})}
            catch {self.membershipFinish?.error=error.localizedDescription}
            self.membershipFinish?.cancelled=Task.isCancelled
            try await self.finishMembershipCloseAndReopen()
        }
    }
    func resumeSyncErasure() {
        guard canRecoverContent,syncErasurePending else {return}
        let location=requested,recovery=syncRecovery
        run(cancellationMessage:"Erasure stopped. Any committed deletion remains; resume saved cleanup before recording.") {
            let relay=LibraryProgressRelay()
            let observer=Task {while !Task.isCancelled {do {try await Task.sleep(for:.milliseconds(100))}catch {break};self.progress=relay.get()}}
            defer {observer.cancel();self.progress=nil}
            let result=try await recovery.retry(location,{relay.set($0)})
            guard result.cleanupComplete,!result.cancelled else {self.syncErasurePending=true;self.message="Erasure cleanup remains pending. Resume when you are ready.";return}
            self.syncErasurePending=false;try Task.checkCancellation()
            self.model=try await self.preparedModel(root:location,startServices:false)
            self.message="Saved erasure finished. Recording stays paused until you resume it."
        }
    }
    func cancelOperation() {membershipFinish?.cancelled=true;if vaultPackage != nil {pendingLock=true};operation?.cancel()}
    func lockForTermination() async -> Bool {
        terminationRequested=true;syncApprovalPresentation=nil;membershipFinish?.cancelled=true
        await recoveryTransfer.cancelAndWait()
        if busy {cancelOperation();while busy {if let operation {await operation.value} else {break}}}
        if hasPendingMembershipClose {
            do {try await closeMembershipResources();membershipFinish=nil}
            catch {failure=error.localizedDescription;terminationRequested=false;return false}
        }
        guard vaultPackage != nil else {
            model?.prepareForLibrarySwitch();await model?.cancelExternalWorkAndWait();return true
        }
        if vaultStatus?.state != .locked {requestLock();while busy {if let operation {await operation.value} else {break}}}
        let detached=vaultStatus?.imageAttached == false
        if !detached {terminationRequested=false}
        return detached
    }
    var canRecoverContent:Bool {
        !terminationRequested && !busy && !hasPendingMembershipClose && model==nil && !locked() && (vaultPackage==nil || vaultStatus?.state == .unlocked) && FileManager.default.fileExists(atPath:requested.appendingPathComponent("memory.sqlite").path)
    }
    private func run(cancellationMessage:String?=nil,_ work:@escaping @MainActor () async throws -> Void) {
        guard !busy else {return};busy=true;failure=nil
        operation=Task {
            do {try await work()}
            catch is CancellationError {self.message=cancellationMessage ?? (self.vaultPackage == nil ? "Opening stopped. Existing history was preserved.":"Operation stopped. Existing libraries were preserved. Check vault status before retrying.");if self.vaultPackage != nil,self.locked() {self.pendingLock=true}}
            catch {self.failure=error.localizedDescription}
            do {
                if try self.reconcileMovedPackage() {
                    if let previous=self.model {await self.stageForClosing(previous)}
                    self.pendingLock=true
                }
            } catch {self.failure=error.localizedDescription}
            if let package=self.vaultPackage {
                let status=Task.detached {try await LibraryVault(package:package).status()}
                if let fresh=try? await status.value {self.vaultStatus=fresh}
            }
            self.busy=false;self.operation=nil
            if self.pendingLock {self.pendingLock=false;self.requestLock()}
            else if let previous=self.pendingSyncReopen {self.pendingSyncReopen=nil;self.reopenAfterSyncErasure(previous)}
        }
    }
    #if DEBUG
    static func previewOpening(in root:URL)->AppSession {
        let session=AppSession(selection:.init(url:root.appendingPathComponent("Sample-library-being-prepared"),requiresExisting:true,origin:"preview"))
        session.failure=nil;session.busy=true;session.progress = .init(phase:"Preparing local search")
        return session
    }
    static func previewVault(in root:URL,state:LibraryVaultState) async throws -> AppSession {
        let package=root.appendingPathComponent("Preview-"+UUID().uuidString+".oswindvault");try Paths.ensure(package)
        let info=LibraryVaultInfo(name:"Private memory · sample",capacityGiB:128,volumeUUID:UUID().uuidString,keychainEnabled:true)
        try JSONEncoder().encode(info).write(to:package.appendingPathComponent("oswind-vault.json"));try Data("Owned closed preview handle".utf8).write(to:package.appendingPathComponent("Library"))
        let session=AppSession(selection:.init(url:package,requiresExisting:true,origin:"preview"),locked:{false})
        while session.busy {try await Task.sleep(for:.milliseconds(10))}
        session.vaultStatus = .init(info:info,state:state,libraryPath:package.appendingPathComponent("Library").path,message:state == .closing ? "The encrypted volume is still mounted. Finish the current operation or retry locking.":"Encrypted image is detached",volumeMounted:state == .closing,imageAttached:state == .closing)
        session.failure=nil
        if state == .closing {session.failure="Locking is incomplete. macOS has not confirmed that the encrypted image is detached. Close any other readers and retry locking."}
        return session
    }
    #endif
    private func reconcileMovedPackage() throws -> Bool {
        guard let package=vaultPackage,let fd=watchFD else {return false}
        var buffer=[CChar](repeating:0,count:Int(MAXPATHLEN))
        guard fcntl(fd,F_GETPATH,&buffer)==0 else {throw OSwindError.unavailable("The encrypted-library location is unavailable. Its lock could not be verified.")}
        let current=URL(fileURLWithPath:String(cString:buffer),isDirectory:true).standardizedFileURL
        guard current.path != package.standardizedFileURL.path else {return false}
        var retained=stat(),named=stat()
        guard fstat(fd,&retained)==0,lstat(current.path,&named)==0,retained.st_dev==named.st_dev,retained.st_ino==named.st_ino else {throw OSwindError.invalid("The moved library path no longer matches its retained directory")}
        let info=try LibraryVault.metadata(at:current)
        guard info.id==watchedVaultID else {throw OSwindError.invalid("The moved directory does not match this encrypted library")}
        vaultPackage=current;requested=current.appendingPathComponent("Library");selection = .init(url:requested,requiresExisting:true,origin:"selected")
        try LibraryLocationPreferences.save(current,defaults:defaults);watch(current)
        message="The library moved while open. Recording stopped; OSwind is locking it at its new location."
        return true
    }
    private func watch(_ package:URL?) {
        watcher?.cancel();watcher=nil;watchFD=nil;watchedVaultID=nil;lockMonitor?.invalidate();lockMonitor=nil
        guard let package else {return}
        // Workspace sleep/session events are the fast path. This bounded check
        // also covers a locked session that produces no workspace notification.
        lockMonitor=Timer.scheduledTimer(withTimeInterval:1,repeats:true) {[weak self] _ in Task {@MainActor in
            guard let self,self.model != nil,self.locked() else {return};self.requestLock()
        }}
        lockMonitor?.tolerance=0.25
        let fd=Darwin.open(package.path,O_EVTONLY | O_CLOEXEC);guard fd>=0 else {return}
        watchFD=fd;watchedVaultID=try? LibraryVault.metadata(at:package).id
        let source=DispatchSource.makeFileSystemObjectSource(fileDescriptor:fd,eventMask:[.write,.rename,.delete],queue:.main)
        source.setCancelHandler {close(fd)}
        source.setEventHandler {[weak self] in
            guard let self,!self.busy,self.vaultPackage==package else {return}
            self.run {
                do {
                    if try self.reconcileMovedPackage() {try await self.performLock()}
                    else {try await self.loadVault(startServices:false)}
                } catch {
                    if let previous=self.model {
                        await self.stageForClosing(previous)
                        let store=previous.store;try? await Task.detached(priority:.utility) {try store.close()}.value
                    }
                    self.vaultStatus?.state = .unavailable
                    self.vaultStatus?.message="The library location is unavailable. Detach has not been verified."
                    throw error
                }
            }
        }
        watcher=source;source.resume()
    }
}
struct LibraryRecoveryView:View {
    @ObservedObject var session:AppSession
    var locationLabel:String?=nil
    var body:some View {
        ScrollView {VStack(alignment:.leading,spacing:22) {
            Image(systemName:session.busy ? "externaldrive.badge.timemachine":"externaldrive.badge.exclamationmark").font(.system(size:42)).foregroundStyle(OSwindTheme.accent)
            Text(session.hasPendingMembershipClose ? "Finish closing the device update.":session.syncMembershipPending ? "Finish saved device update.":session.syncErasurePending ? "Finish saved erasure.":session.busy ? "Opening your library.":"Your library is unavailable.").font(.largeTitle.weight(.semibold))
            Text(session.hasPendingMembershipClose ? "The original library still has local work open. Retry closing it before opening another workspace.":session.syncMembershipPending ? "A device update has a saved recovery step. Finish it before recording or reconnecting sync.":session.syncErasurePending ? "History deletion has a saved cleanup step. Finish it before opening the library or recording again.":session.busy ? "Preparing local search. Large histories can take a moment; you can stop safely.":session.failure ?? (session.message.isEmpty ? "Reconnect its drive or choose another library.":session.message)).foregroundStyle(.secondary).textSelection(.enabled)
            Text(locationLabel ?? session.requested.path).font(.system(.caption,design:.monospaced)).foregroundStyle(.secondary).textSelection(.enabled)
            if session.busy {HStack {ProgressView(session.progress?.phase ?? (session.syncErasurePending ? "Finishing erasure cleanup…":"Opening library…"));Button("Stop") {session.cancelOperation()}}}
            if !session.busy {
            if session.hasPendingMembershipClose {Button("Retry closing device update") {session.retryMembershipClose()}.buttonStyle(.borderedProminent)}
            if session.syncMembershipPending,session.canRecoverContent {Button("Finish saved device update") {session.resumeSyncMembership()}.buttonStyle(.borderedProminent)}
            if session.syncErasurePending,session.canRecoverContent {
                Button("Resume erasure cleanup") {session.resumeSyncErasure()}.buttonStyle(.borderedProminent)
                if !session.message.isEmpty {Text(session.message).font(.callout).foregroundStyle(.secondary)}
            }
            HStack {Button("Try again") {session.retry()};Button("Choose library…") {session.choose()};Button("Open default library") {session.openDefault()}}.disabled(session.busy || session.recoveryTransfer.busy)
            Button("Create encrypted library…") {session.showVaultSetup=true}.disabled(session.busy)
            if session.canRecoverContent {
                Divider();Text("Recover local content").font(.title2.weight(.medium))
                Text("Export existing content when this library cannot open. Restore the backup as a new library, then set up device pairing again.").font(.callout).foregroundStyle(.secondary)
                Button("Export recovery backup…") {session.recoveryTransfer.chooseRecovery(source:session.requested)}.disabled(session.recoveryTransfer.busy)
            }
            Divider();Text("Restore from a backup").font(.title2.weight(.medium));LibraryTransferView(transfer:session.recoveryTransfer,store:nil).disabled(session.busy)
            }
        }.padding(40).frame(maxWidth:800,alignment:.leading).frame(maxWidth:.infinity)}
    }
}
