from pathlib import Path
import hashlib,json,subprocess,zipfile,shutil
ROOT=Path.cwd();BASE=ROOT/'.artifacts/peer-membership-update-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reviewPath=BASE/'current-peer-native-reviewed-v15-v2.json';review=json.loads(reviewPath.read_text());inputs=json.loads((BASE/'development-inputs-v15/inputs.json').read_text());source=review['sourceCommit']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert review['defined']==review['passed']==31 and review['skipped']==review['failedMethods']==0
assert review['reviewerSHA256']==sha(BASE/'review-peer-native-v15-v2.py') and review['inputSHA256']==sha(BASE/'development-inputs-v15/inputs.json')
assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
old=json.loads((BASE/'checkout-reuse-v1.json').read_text());assert all(sha(ROOT/p)==h for p,h in old['frozen35PackageFiles'].items())
priorInputs=json.loads(Path('/Users/vibhusapra/.codex/worktrees/sync-owner-app-lifecycle/oswind/.artifacts/owner-app-integration-v1/qualification-v5/inputs.json').read_text());prior={p:h for p,h in priorInputs['protectedPriorFiles'].items() if p.startswith('benchmarks/')};assert len(prior)==505 and all(sha(ROOT/p)==h for p,h in prior.items())
files={}
for p in BASE.iterdir():
 if p.is_file() and p.suffix in ('.log','.json'):files['development/'+p.name]=p
for d in BASE.glob('development-inputs-v*'):
 for p in d.rglob('*'):
  if p.is_file():files['development/'+str(p.relative_to(BASE))]=p
for d in BASE.glob('frozen-*'):
 p=d/'manifest.json'
 if p.is_file():files['development/'+str(p.relative_to(BASE))]=p
for name in ['review-peer-native-v15.py','review-peer-native-v15-v2.py','publish-peer-preview-v1.py']:files['reviewers/'+name]=BASE/name
for d in ['ui-development-v11','ui-development-v12','ui-peer-v15','ui-folder-v15']:
 for p in (BASE/d).glob('*.png'):files['renders/'+d+'/'+p.name]=p
changed=subprocess.check_output(['git','diff','--name-only','5efde85a5c84a877c787afe9f700276d4aef61d3',source],text=True).splitlines();assert len(changed)==12
for p in changed:files['source/'+p]=ROOT/p
payload={name:p.read_bytes() for name,p in files.items()};payload['README.txt']=('OSwind peer membership preview '+source+'\n31 current Core/App native Debug methods pass with no skips. Exact committed runtime inputs, per-method starts/terminals, original generated Keychain account/private-field booleans and12manually reviewed current component images are bound.\nIncludes retained failures and earlier generated renders. Reproduced metadata watcher close ordering and overlapping-page private-base defects were fixed separately. Earlier missing-vault-session and new-fixture readiness failures retain their limits; later passes do not prove their original causes. The first reviewer regex did not accept module-qualified class names; only a versioned parser correction was applied to the unchanged successful test log.\nThree-library all13-kind graph and all13postreplay counts include a real owned login-Keychain/Mac-binding variant. Three actual app sessions with generated software credentials exchange sources using explicit connection/network cycles; two peers exchange while the owner is closed, then reconnect it with exact source counts and original account IDs. Public history export reaches64members via bounded pages. None is a physical-device, automatic cadence, controlled-power, fullsync/v0 or ranking benchmark.\nPublic generated signed membership pages may appear in authored component renders. No private credential values, databases, encrypted images, weights or executables are included. The preserved native35 package is rehashed unchanged. All505 preceding benchmark files remain unchanged.\n').encode()
archive=ROOT/'benchmarks/sync-peer-membership-raw-v1.zip';manifest=ROOT/'benchmarks/sync-peer-membership-inputs-v1.json';receipt=ROOT/'benchmarks/sync-peer-membership-v1.json';assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and z.testzip() is None and all(z.read(n)==data for n,data in payload.items())
manifest.open('x').write(json.dumps(inputs|{'committedQualificationSource':source},indent=2)+'\n')
result=review|{'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewSHA256':sha(reviewPath),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{n:hashlib.sha256(data).hexdigest() for n,data in payload.items()},'allArchivedBytesCompared':True},'priorBenchmarkFilesUnchanged':505,'frozen35PackageFilesUnchanged':len(old['frozen35PackageFiles']),'featureStatusesPromoted':0,'qualificationLabel':'Current selected native Debug passes; full qualification and sync remain WIP','openParentFailures':['PendingMediaSchedulerTests.testLibrarySwitchJoinsActualPendingMediaWorkerBeforeClosingStore: retained broadTSAN readiness failure, two assertion issues','NativeVaultCancellationTests.testCancellationDuringMediaDrainStillClosesStoreAliasAndOwnedImage: retained native optimized moved-image binding failure; one unexpected issue']}
receipt.open('x').write(json.dumps(result,indent=2)+'\n')
qa=json.loads((BASE/'ui-current-reviewed-v15.json').read_text())
for group,rows in qa['files'].items():
 for name,row in rows.items():
  p=BASE/group/name;assert sha(p)==row['sha256'];target=ROOT/'assets'/('peer-membership-' if group=='ui-peer-v15' else 'folder-membership-');target=target.with_name(target.name+name);assert not target.exists();shutil.copyfile(p,target)
doc=ROOT/'docs/SYNC-PEER-MEMBERSHIP-WIP.md';assert not doc.exists();doc.open('x').write(f'''# Peer membership update preview

Runtime `{source}` adds signed membership requests, bounded public update pages, reviewed existing-peer catch-up and enlarged-group folder controls. It also guards vault metadata notifications from opening a fresh model while the original membership close remains pending. This is an opt-in development preview; F059 and the full-sync acceptance remain unfinished.

Enable `OSWIND_OWNER_ADDITION_PREVIEW=1` when launching a development build. Default setup remains two-Mac. Use generated development libraries while the remaining acceptance below is open.

1. The owner approves the joining Mac through **Add another Mac** and returns its encrypted joining response. The owner library reopens with recording and sync paused.
2. Each existing connected peer uses **Update paired Macs → Prepare membership request**. This is a public signed certificate request.
3. In the owner's disconnected pairing setup, paste that request under **Help an existing Mac catch up** and prepare a signed update page. Export does not change private accounts or return private keys.
4. On the existing peer, paste the page, review the added names and group/update fingerprints, compare the group, then confirm **Apply device update**. The exact reviewed session and latest review token must still be current.
5. The original app producers/session stop before private intent. The retained operation owns original leases through close failures and retry. It reopens the same workspace quietly and returns no joining response. Saved recovery works without the provider folder, including the owned encrypted-vault fixture.
6. Repeat pages when needed. Compare signed revisions on every participating Mac before explicitly reconnecting the same locally available shared folder. In preview, three-or-more-member groups have reconnect/locate-folder controls. Default mode continues to gate them.

The entire incoming signed path is verified, including any already-applied prefix. Private preparation uses only the suffix after this peer's exact current certificate; the review fingerprint remains bound to the supplied canonical page. A signed fork at the same revision cannot substitute for the exact trusted certificate. Requests/pages have explicit byte limits, and public history export was exercised through 64 admitted members in multiple bounded pages. This does not establish global provider freshness, removal or rotation.

## Current evidence

**31 selected methods passed, zero skips**, with both generated native Keychain/Mac-binding and encrypted APFS fixture flags enabled. All 726 declared runtime/test/build inputs match the committed qualification source. The reviewer checks each exact method's start/terminal state and both complete aggregate summaries. The first parser attempt failed because current XCTest names included their module; the versioned correction reviews the unchanged log without repeating tests.

- The public three-library graph preserves all 13 data kinds, three-direction writes, two peer writes while the owner is offline, and exact counts for all 13 tables after reconnect/replay. A real owned login-Keychain variant compares original account IDs and private fields in RAM, checks their continued readability, and verifies generated-account cleanup. It logs no private values.
- Three actual AppSession models exchange generated source notes using explicit folder connections and network-toggle cycles. The owner is drained and closed; both remaining peers receive each other's new writes before it returns. The owner reopens quietly, reconnects and retains exact source counts and the original account-ID set. This uses software test credentials on one Mac; it is separate from the native graph variant.
- App tests cover held producers, cancellation, exact/stale reviews, substituted root/database refusal, actual SQLite busy close and both retained leases, saved intent, provider-free recovery, late Lock, encrypted detach/unlock and a positively acknowledged actual vault metadata notification.
- Twelve current light/dark components were visually inspected: request/review/export, three-member preview, three-member default gate and ordinary two-member default setup. Labels/borders/placeholders make empty paste fields visible. These are offscreen components, not interactive GUI acceptance.

The watcher defect and overlapping-page defect each have retained failing controls before their separate production corrections. Earlier development failures remain in the raw evidence. The first three-app attempt timed out at a nil session state; the corrected fixture explicitly completes onboarding only in its own models and records that the replacement peer initially had onboarding enabled/admission blocked. The original run did not record that state, so its exact cause is not claimed. No user defaults or readiness deadlines were changed.

[Receipt](../benchmarks/sync-peer-membership-v1.json) · [Pinned inputs](../benchmarks/sync-peer-membership-inputs-v1.json) · [Raw logs, source snapshots and generated renders](../benchmarks/sync-peer-membership-raw-v1.zip).

## Remaining work

- [ ] Current broader owner/pairing regression, Thread Sanitizer and optimized selections; normal production build/package.
- [ ] Enlarged-group policy/exclusion and approved erase acceptance, capability/version negotiation, device removal and group rotation.
- [ ] Physical multi-Mac/provider behavior, pressure/resource limits and production credential/distribution acceptance.
- [ ] Current automatic 24-hour capture, controlled energy and whole-product comparison.

The parent qualification retains an existing PendingMedia readiness failure in broad TSAN and a moved-image binding failure in native optimized; these selected peer passes do not erase or explain either. All 505 preceding benchmark files and the frozen native35 package remain unchanged. No requirement status, full-v0 completion or competitive ranking is promoted.

## Reviewed components

![Three-member preview](../assets/folder-membership-three-preview-light.png)

[Dark preview](../assets/folder-membership-three-preview-dark.png) · [Default three-member gate](../assets/folder-membership-three-default-gate-light.png) · [Ordinary two-Mac setup](../assets/folder-membership-two-default-light.png).

![Peer update review](../assets/peer-membership-review-light.png)

[Dark review](../assets/peer-membership-review-dark.png) · [Labelled peer request](../assets/peer-membership-request-light.png) · [Owner public export](../assets/peer-membership-export-light.png).
''')
assert all(sha(ROOT/p)==h for p,h in prior.items()) and all(sha(ROOT/p)==h for p,h in old['frozen35PackageFiles'].items())
print(json.dumps({'source':source,'archiveBytes':archive.stat().st_size,'archiveMembers':len(payload),'defined':31,'passed':31,'assets':12,'priorPublicationsUnchanged':505}))
