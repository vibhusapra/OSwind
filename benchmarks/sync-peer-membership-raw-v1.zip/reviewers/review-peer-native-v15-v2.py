from pathlib import Path
import hashlib,json,re,struct,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/peer-membership-update-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((BASE/'development-inputs-v15/inputs.json').read_text());result=json.loads((BASE/'development-inputs-v15/result.json').read_text());expected=json.loads((BASE/'expected-peer-methods-v1.json').read_text())
assert inputs['inputFiles']==result['inputFiles'] and all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert all(subprocess.check_output(['git','show',sourceCommit+':'+p])==(ROOT/p).read_bytes() for p in inputs['inputFiles'])
assert result['exit']==0 and result['logSHA256']==sha(BASE/'current-peer-native-classes-v15.log')
assert inputs['environment']['OSWIND_TEST_NATIVE_SYNC_KEYCHAIN']=='1' and inputs['environment']['OSWIND_TEST_NATIVE_VAULT']=='1'
text=(BASE/'current-peer-native-classes-v15.log').read_text();states={};starts={}
for module,cls,name,state in re.findall(r"Test Case '-\[(?:(\w+)\.)?(\w+) (test\w+)\]' (started|passed|failed|skipped)",text):
 assert cls in expected and (not module or module==expected[cls]['module'])
 key=expected[cls]['module']+'.'+cls+'.'+name
 if state=='started':starts[key]=starts.get(key,0)+1
 else:
  assert key not in states,key;states[key]=state
wanted={row['module']+'.'+cls+'.'+m for cls,row in expected.items() for m in row['methods']}
assert len(wanted)==31 and set(states)==set(starts)==wanted and set(starts.values())=={1}
assert set(states.values())=={'passed'}
assert len(re.findall(r'Executed 31 tests, with 0 failures \(0 unexpected\)',text))==2
assert 'ThreadSanitizer: data race' not in text
marker='OWNED_NATIVE_PUBLIC_THREE_DEVICE originalAccountIDsPreserved=true originalPrivateFieldsPreserved=true actualMacBinding=true graphKinds=13 offlinePeerWrites=2 reconnect=true';assert text.count(marker)==1
admission=re.findall(r'OWNED_THREE_APP_ADMISSION index=(\d) onboardingBefore=(true|false) workAvailable=(true|false) allowedBefore=(true|false)',text)
assert len(admission)==3 and {x[0] for x in admission}=={'0','1','2'} and all(x[2]=='true' for x in admission)
qa=json.loads((BASE/'ui-current-reviewed-v15.json').read_text());assert qa['allTwelveVisuallyInspected'] and qa['inputSHA256']==sha(BASE/'development-inputs-v15/inputs.json')
for group,files in qa['files'].items():
 for name,row in files.items():
  p=BASE/group/name;assert sha(p)==row['sha256'];data=p.read_bytes();pixels=list(struct.unpack('>II',data[16:24]));assert pixels==row['pixels']
  points=row['authoredPoints'];assert pixels[0]/points[0]==pixels[1]/points[1] in (1,2)
assert sum(len(v) for v in qa['files'].values())==12
record={'format':'OSwind current peer Core/App native Debug review v15-v2','sourceCommit':sourceCommit,'sourceBeforeUIChanges':inputs['source'],'inputSHA256':sha(BASE/'development-inputs-v15/inputs.json'),'logSHA256':result['logSHA256'],'reviewerSHA256':sha(Path(__file__)),'defined':31,'passed':31,'skipped':0,'failedMethods':0,'methods':states,'completeStartTerminalBalance':True,'actualNativeFlags':inputs['environment'],'nativeOriginalAccountMarker':marker,'threeAppInitialAdmission':admission,'UIReviewSHA256':sha(BASE/'ui-current-reviewed-v15.json'),'scope':result['scope'],'earlierFailuresRemain':['v3 overbroad private-bytes assertion; fixture corrected','v5 native busy-close missing vault session, exact cause unproved','v6 reproduced metadata watcher opens while original close blocked; production guard added','v9 reproduced overlapping-page private-base refusal; production suffix normalization added','v13 new three-app fixture nil-state readiness timeout; per-model onboarding made explicit, original admission not recorded'],'limitations':'Generated fixtures on one Mac and explicit UI network cycles. Actual native APFS/login-Keychain cases are included; this is not ThreadSanitizer/optimized, interactive GUI/physical devices, controlled power, automatic24h capture, complete sync/v0 or ranking acceptance.'}
(BASE/'current-peer-native-reviewed-v15-v2.json').open('x').write(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['methods','actualNativeFlags','earlierFailuresRemain']}))
