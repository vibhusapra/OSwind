from pathlib import Path
import subprocess,time,json
out=Path(__file__).resolve().parent;r=out.parents[1];start=time.monotonic();command=['swift','test','--jobs','4','--filter','RecordingScopeTests']
with (out/'core-v1.log').open('xb') as log:result=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT)
(out/'core-v1-result.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start},indent=2)+'\n');print((out/'core-v1.log').read_text()[-6500:]);raise SystemExit(result.returncode)
