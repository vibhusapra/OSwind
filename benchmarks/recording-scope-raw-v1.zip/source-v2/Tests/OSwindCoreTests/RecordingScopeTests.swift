import XCTest
@testable import OSwindCore

final class RecordingScopeTests:XCTestCase {
    private var root:URL!,store:MemoryStore!
    override func setUpWithError()throws {root=FileManager.default.temporaryDirectory.appendingPathComponent("owned-recording-scope-"+UUID().uuidString);store=try MemoryStore(root:root)}
    override func tearDownWithError()throws {try store.close();try FileManager.default.removeItem(at:root)}
    @discardableResult private func audio(_ id:String,_ session:String?,text:String="Apollo owner Mira")throws->Memory {
        var m=Memory(id:id,timestamp:Date(timeIntervalSince1970:100),kind:.audio,app:"Authored scope",title:"Same title",text:text)
        m.audioSessionID=session;m.transcript = .init(text:text,duration:30,segments:[.init(start:0,end:30,text:text)],model:"Authored fixture")
        try store.insert(m);return m
    }
    func testSessionSelectsAllMatchingClipsAndNeverNeighborsWithSameTimeTitleOrWords()throws {
        for index in 0..<520 {try audio("a-\(index)","selected")}
        try audio("neighbor","other");try audio("legacy",nil)
        var f=SearchFilter(query:"Apollo",recordingScope:try .init(sessionID:"selected"));f.limit=500
        let result=try store.search(f,mode:.keyword)
        XCTAssertEqual(result.count,500);XCTAssertTrue(result.allSatisfy {$0.memory.audioSessionID=="selected"})
        XCTAssertEqual(try store.matchingCount(SearchFilter(recordingScope:f.recordingScope)),520)
        XCTAssertTrue(try store.timelineSample(f).allSatisfy {$0.audioSessionID=="selected"})
        try audio("new-clip","selected");XCTAssertEqual(try store.matchingCount(SearchFilter(recordingScope:f.recordingScope)),521)
    }
    func testSingleSourceVersionDoesNotFollowAnEditedOrReplacedClip()throws {
        var source=try audio("clip",nil),f=SearchFilter(recordingScope:try .init(sourceID:source.id,revision:source.evidenceHash))
        XCTAssertEqual(try store.search(f,mode:.keyword).map(\.id),["clip"])
        source.text="Apollo owner Bob";source.transcript?.text=source.text;source.transcript?.segments[0].text=source.text;try store.insert(source)
        XCTAssertTrue(try store.search(f,mode:.keyword).isEmpty)
        f.recordingScope = .unavailable;XCTAssertThrowsError(try store.resolveQueryScope(f))
    }
    func testCodecRoundTripAndOlderStringKindReaderRefusesRestriction()throws {
        struct OlderFilter:Decodable {let kind:MemoryKind?}
        let original=SearchFilter(recordingScope:try .init(sessionID:"e\u{301}\0session")),encoded=try JSONEncoder().encode(original)
        XCTAssertEqual(try JSONDecoder().decode(SearchFilter.self,from:encoded),original)
        XCTAssertThrowsError(try JSONDecoder().decode(OlderFilter.self,from:encoded))
        let plain=SearchFilter(kind:.audio);XCTAssertNoThrow(try JSONDecoder().decode(OlderFilter.self,from:JSONEncoder().encode(plain)))
        var json=try XCTUnwrap(JSONSerialization.jsonObject(with:encoded) as? [String:Any]);json.removeValue(forKey:"recordingScope")
        XCTAssertThrowsError(try JSONDecoder().decode(SearchFilter.self,from:JSONSerialization.data(withJSONObject:json)))
    }
    func testScopeRecheckedAfterRegroupingAndSavedAnswerCannotBroadenIt()throws {
        var source=try audio("a","selected");let scope=try RecordingScope(sessionID:"selected"),hit=SearchHit(memory:source,score:1,match:"authored")
        source.audioSessionID="other";try store.insert(source)
        XCTAssertThrowsError(try store.requireRecordingEvidence([hit],scope:scope),"Evidence hash alone does not detect regrouping")
        XCTAssertThrowsError(try store.saveChatTurn(question:"Who?",answer:.init(text:"Mira [1]",sources:[hit],provider:"evidence",duration:0),filter:.init(recordingScope:scope)))
        XCTAssertTrue(try store.chats().isEmpty)
    }
    func testEvidenceOnlyAnswerAndSavedHistoryKeepScopeWithoutModelCalls()async throws {
        try audio("allowed","selected");try audio("wrong","other",text:"Apollo owner Bob")
        let scope=try RecordingScope(sessionID:"selected"),configuration=AIConfiguration()
        var ai=configuration;ai.provider = .evidence
        let answer=try await AnswerEngine(store:store,embedder:LocalEmbedder(loadModel:{nil})).answer("Apollo owner",configuration:ai,filter:.init(recordingScope:scope),searchConfiguration:SearchConfiguration(),interpretQuery:false)
        XCTAssertEqual(answer.sources.map(\.id),["allowed"]);XCTAssertEqual(answer.resolution?.filter.recordingScope,scope)
        let turn=try store.saveChatTurn(question:"Who owns Apollo?",answer:answer,filter:.init(recordingScope:scope))
        XCTAssertEqual(try store.chatTurns(turn.sessionID).first?.filter.recordingScope,scope)
    }
}
