from pathlib import Path
import json,hashlib,subprocess,shutil,zipfile
base=Path(__file__).resolve().parent;r=base.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((base/'qualification-review-v1.json').read_text());source=review['source'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
package=json.loads((base/'package-v1/package.json').read_text());assert package['source']==source and package['exitCode']==package['signature']['exitCode']==package['smoke']['exitCode']==package['packagedScopeControl']['exitCode']==0
assert package['developmentArchive']['allExtractedFilesAndModesMatch'] and package['developmentArchive']['signatureAfterRoundTripExitCode']==0
assert all(not x['enableTesting'] for x in package['normalCoreCommands'])
for item in json.loads((base/'qualification-v2/inputs.json').read_text())['inputs']:assert sha(r/item['path'])==item['sha256']
protected=json.loads((base/'publication-protected-inputs.json').read_text())
for item in protected:assert sha(r/item['path'])==item['sha256']
visual=json.loads((base/'navigation-fixed-v14/visual-review.json').read_text());assert visual['passed'] and len(visual['scenes'])==12
assets=[]
for item in visual['scenes']:
 original=base/'navigation-fixed-v14'/item['path'];assert sha(original)==item['sha256'];dest=r/'assets'/('recording-scope-v1-'+original.name);assert not dest.exists();shutil.copy2(original,dest);assets.append({'path':str(dest.relative_to(r)),'sha256':sha(dest)})
# Publish authored source snapshots, logs, inputs, receipts and UI controls.
# Compiled engines, model weights, app archives and generated fixture libraries remain local.
allowed={'.json','.log','.py','.swift','.png','.stdout','.stderr','.md','.txt','.yml','.yaml','.c','.h'}
items=[]
for p in sorted(base.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(base);parents=rel.parts[:-1]
 if any(x.startswith('frozen-') or x.endswith('.app') or x=='__pycache__' or x.startswith('owned-') or x=='archive-check' for x in parents):continue
 if p.suffix not in allowed:continue
 if p.name=='publication-result.json':continue
 data=p.read_bytes();items.append((str(rel),data))
manifest={'source':source,'scope':'Authored text fixtures, exact source/input/result/engine manifests, failed and successful development attempts, selected qualification, native package checks and generated component renders. Actual compiled engines/app archive stay local. No user recordings, weights or credentials are included.','entries':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in items]}
raw=r/'benchmarks/recording-scope-raw-v1.zip';assert not raw.exists()
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in items:z.writestr(name,data)
 z.writestr('RAW-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(raw) as z:
 assert z.testzip() is None
 for item in manifest['entries']:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
notes=[
 'core-v1/core-v2 and development-v4/v7 were compile-only failures. core-v3 was a six-case development pass without a contemporaneously frozen engine/source qualification; it is not promoted.',
 'development-v5 passed 11 behavioral cases but failed visual review: both recording-action panels were blank. The original four renders and failed review remain retained. A plain HStack layout corrected the authored panels; later renders were inspected.',
 'development-v8 had 14 passed/one failed method with three assertion issues in the expanded real Metal fixture. The fetched payload omitted separately stored vectors. The corrected fixture explicitly supplies its original vectors and asserts 20k; no production Metal fix is claimed. v9 and v10 real GPU methods then passed. All original source/log/engine controls remain.',
 'development-v9 had 16 passed/one unexpectedly failed method because an authored run filter discarded its required bounds. The fixture now preserves the real claimed bounds; restore validation was not weakened.',
 'development-v10 had 24 passed/two failed methods: a render asserted Whisper setup while its retained image shows Locked / audio suspended, and fresh sync after quiet restore refused a lost original peer session binding. An owned unlocked audio startup is now injected only in the render fixture. Production lock defaults remain real. The portability test checks the exact grouped-session refusal, local restored scope and safe single-source re-export.',
 'development-v11 passed 26 cases with no skips and 12 reviewed components, including actual prior-reader refusal and actual current-versus-retained-v10 CLI followup controls.',
 'navigation-negative-v12 reproduced two failed methods/eight assertion issues using delayed real scope reads. New chat/history/navigation and newer recording selections were overwritten by older completions. Original source, inputs, log and actual engines remain frozen. Current request UUID, originating section and selected source revision guards fix this; navigation-fixed-v14 passes all 13 model methods and 12 reviewed scenes.',
 'navigation-fixed-v13 was a compile-only SwiftUI type-checker failure in a count label. Splitting a local countLabel expression corrected it before v14; the failed source/log remain retained.',
 'qualification-v1 belongs to e01c94b: 518 defined, 502 passed, 16 skipped, zero failures. Current 7ab704b changes only App navigation/count labels and their tests; Core/CLI are byte-identical. Both current v2 runs have 520 defined, 504 passed, 16 explicit skips, zero failures and no race report.'
]
receipt={'format':'Recording-scoped Ask and portable history qualification v1','source':source,'review':review,'package':package,'assets':assets,'developmentNotes':notes,'rawArchive':{'path':str(raw.relative_to(r)),'bytes':raw.stat().st_size,'members':len(items)+1,'sha256':sha(raw)},'scope':'Selected correctness/portability/native fixtures and local normal development packaging. No full current-suite, hosted, native interaction, physical audio, model factual-quality, power, automatic24h, feature-complete or ranking claim. Earlier failed owner/peer broad gates and historical benchmarks remain separate.'}
(r/'benchmarks/recording-scope-v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
ci=json.loads((base/'ci-review-v1.json').read_text());assert ci['workflowUnchangedSinceOriginalStaticReview'] and ci['currentSelectedDefinitions']==51
(r/'benchmarks/recorded-meetings-ci-selection-v4.json').write_text(json.dumps(ci,indent=2)+'\n')
p=r/'docs/RECORDED-MEETINGS-WIP.md';text=p.read_text();text=text.replace('- [ ] Named recording sessions, durable reviewed calendar-occurrence links and session-scoped Ask/recaps with exact source scope.','- [ ] Named recording sessions and durable reviewed calendar-occurrence links.\n- [x] Exact session/source-version Ask, bounded recording recaps, saved-history scope and portable filter adapters with selected regression.\n- [ ] Fresh sync enrollment after quiet restore of grouped peer audio needs its original session bindings; current code refuses to rehash a projection.')
text=text.replace('- [ ] Current normal-release package after the identifier change; earlier package evidence is pinned to ac5bf82.','- [x] Current normal release/ad-hoc development package at 7ab704b, packaged CLI scope control and exact ZIP/signature round trip. Native interaction and release acceptance remain open.')
section=f'''
## Exact recording-scoped Ask and portable history

Source `{source[:7]}` adds **Ask about recording** and **Recap** to the selected recording. Session queries follow all current matching canonical clips, including clips beyond the 512 loaded rows. An ungrouped clip follows one exact evidence version. Nearby dates, matching titles, shared words or speaker labels do not establish membership. App and CLI follow-ups retain the saved restriction; Core admission refuses a dropped or changed recording scope.

The Ask banner shows the restriction and offers an explicit new general chat. Recording recap shortcuts use All time rather than silently applying Today. Recaps disclose their distributed source sample and bounded excerpts; they are not complete transcripts. Source membership is rechecked after hydration and again before saving. Ready recording queries and evidence checks can read while another connection holds the capture writer reservation. Scope keys distinguish byte-different Unicode IDs on the real indexed Metal path.

Native and portable filters use a typed known-field discriminator so older String-kind decoders reject the restriction. An actual retained prior CLI reads a plain conversation and refuses its scoped counterpart. A separate actual retained development CLI reproduces an unscoped follow-up including a neighboring recording; the corrected current and normal packaged CLIs exclude that neighbor and retain scope. These are codec/CLI controls, not prior GUI acceptance.

Quiet backup/restore retains native history and scope. Incoming scopes preserve the source origin's session namespace or exact source-version binding; local same-ID sessions remain separate. Generic retained-run adapters are tested too, although the routine editor does not offer recording-scoped schedules. After a quiet restore removes sync bindings, grouped peer audio explicitly refuses fresh-catalog re-export without original session provenance; local scoped queries remain available. The single-source path re-exports. No title/time matching or projection rehash substitutes for the missing original.

**Current selected optimized and Thread Sanitizer runs each have 520 defined / 504 passed / 16 skipped / 0 failures, with no race report.** The 16 skips are nine child entry helpers, three explicit scale probes, two exact prior32-binary probes and two renderer opt-ins. This includes actual encrypted APFS detach, original Keychain/all-13-kind graph invariants, real 20k-vector Metal scope switching/regrouping, backup/erasure/privacy, API handler and incoming/outgoing sync regression. The complete current suite and hosted CI are separate gates.

All 13 current recording-model Debug methods pass with no skips. Twelve current light/dark populated, compact, empty, setup-refusal and scoped-Ask components were manually inspected. Delayed-read controls first reproduced two failed methods/eight issues; request identity, originating section and selected-source revision now prevent old completion from replacing a new chat, selected history or a newer recording. Earlier blank renders, compile errors, vector/run fixture errors, lock refusal and provenance refusal remain in the raw evidence. No successful frozen engines or earlier observations were rebuilt for metadata.

The normal development app contains **{len(package['files'])} files**, passes strict deep ad-hoc signature verification, an owned empty-library smoke and an actual packaged-CLI scoped follow-up control. Its ZIP was extracted and all file bytes/modes and signature verified. It is a normal compiler product without `-enable-testing`, separate from optimized test engines. This does not establish notarization, live GUI/audio/physical acceptance or release readiness.

[Source/input/test/package receipt](../benchmarks/recording-scope-v1.json) · [All original controls, logs, source snapshots and renders](../benchmarks/recording-scope-raw-v1.zip) · [Static CI selection review](../benchmarks/recorded-meetings-ci-selection-v4.json).

![Recording actions](../assets/recording-scope-v1-recording-actions-light.png)
![Scoped Ask](../assets/recording-scope-v1-scoped-ask-dark.png)

F042 and the full v0 remain unfinished. Names/calendar links, incoming-change UI/frame-cost auditing, native keyboard/VoiceOver/record/import/open/playback, physical speech/device quality, power and current automatic 24h acceptance remain open. The 83-feature ledger, dated 20-offering comparison, earlier benchmark observations and earlier failed broad gates remain unchanged; no ranking is promoted.
'''
p.write_text(text+section)
p=r/'docs/PROGRESS.md';text=p.read_text();anchor='# OSwind delivery ledger\n';assert text.startswith(anchor)
entry=f'''
## 2026-11-03 — exact recording Ask, history and portable scope

Source `{source[:7]}` adds full-session or exact single-source-version Ask and bounded recording recaps, retained App/CLI follow-up scope, explicit scope UI, current evidence revalidation, portable backup/sync filters and stale-navigation protection. Current selected optimized/Thread Sanitizer selections each have **520 defined / 504 passed / 16 explicit skips / 0 failures**, with no race report. All 13 recording-model Debug methods and 12 manually reviewed components pass separately. A normal ad-hoc package, actual packaged CLI scope control and exact ZIP/signature round trip pass. Original negative CLI/navigation controls, blank renders and all failed attempts remain retained. F042 names/calendar links, restored peer-session re-enrollment provenance, incoming UI invalidation, physical/native interaction, power and current automatic 24h acceptance remain open. Whole-current-suite, hosted CI, parity and ranking are not promoted. [Details/TODOs](RECORDED-MEETINGS-WIP.md#exact-recording-scoped-ask-and-portable-history) · [Receipt](../benchmarks/recording-scope-v1.json) · [Raw evidence](../benchmarks/recording-scope-raw-v1.zip).
'''
p.write_text(anchor+entry+text[len(anchor):])
body=f'''Recorded audio now has a source-linked Recordings workspace beside Upcoming, with Ask and bounded Recap actions constrained to the selected recording. Queries follow all current session clips; an ungrouped clip pins one evidence version. App/CLI follow-ups, saved history, backup and portable sync retain that restriction. Matching titles or times never stand in for source membership.

The change also adds lazy thin metadata indexing, byte-exact canonical-ID handling, current privacy/source guards and joined app lifecycle ownership. Explicit scope UI, All-time recording recap shortcuts and per-request navigation guards prevent accidental scope loss or stale completion. Counts distinguish loaded clips, interval overlap/gaps and saved import dates. Recaps disclose sampled sources and bounded excerpts.

Validation at `{source[:7]}`:

- Selected optimized and Thread Sanitizer: **520 defined, 504 passed, 16 explicit skips, zero failures; no race report**. Skips:9 child helpers,3 scale opt-ins,2 exact old32-binary probes,2 component-render opt-ins.
- Actual encrypted APFS detach, original Keychain/all 13-kind graph, real 20k-vector Metal scopes/regrouping, privacy/erasure, backup and incoming/outgoing sync checks pass. All 13 recording-model Debug methods and 12 reviewed light/dark components pass separately.
- Actual prior CLI refuses scoped history; a retained development CLI reproduces a broad follow-up, while current and normal packaged CLIs preserve restriction. Delayed-read negative controls reproduce 2 failed methods/8 issues before the request-intent fix. Failed controls and all original artifacts are retained.
- Normal ad-hoc development package: strict deep signature, owned empty-library smoke, actual packaged-CLI scope test and exact ZIP file/mode/signature round trip pass. Normal and optimized-test compiler products remain separate.

[Scope, evidence and TODOs](https://github.com/vibhusapra/OSwind/blob/{source}/docs/RECORDED-MEETINGS-WIP.md) are published on this branch with [qualification receipt](https://github.com/vibhusapra/OSwind/blob/codex/meeting-sessions/benchmarks/recording-scope-v1.json), [raw evidence](https://github.com/vibhusapra/OSwind/blob/codex/meeting-sessions/benchmarks/recording-scope-raw-v1.zip) and the [dated 20-offering comparison](https://github.com/vibhusapra/OSwind/blob/codex/meeting-sessions/docs/desktop-memory-landscape-2026-11-03.html). The existing recorded CI step now includes scoped cases/renders; static review preserves all other fields and 87 native/101 total steps. No hosted success is claimed.

Draft: F042 names/calendar links, incoming-change UI/frame-cost audit, native keyboard/VoiceOver/record/import/playback, physical speech/device quality, power and current automatic 24h acceptance remain unfinished. Quiet restore keeps local scopes, but grouped peer audio refuses fresh sync without original session bindings; it never rehashes a peer projection. Routine filter adapters are covered; recording-scoped schedule editing is not offered. Earlier owner/peer failed broad gates remain separate. The 83-feature ledger, historical benchmarks and ranking are unchanged. Based on `codex/peer-membership-update`.
'''
# The new documentation is metadata after the runtime commit; use branch links for it.
body=body.replace(f'/blob/{source}/docs/RECORDED-MEETINGS-WIP.md','/blob/codex/meeting-sessions/docs/RECORDED-MEETINGS-WIP.md')
(base/'pr-body-v5.md').write_text(body)
for item in protected:assert sha(r/item['path'])==item['sha256']
assert not subprocess.check_output(['git','diff',source,'--','Sources','Tests','.github','Package.swift','Package.resolved'],cwd=r)
result={'source':source,'raw':receipt['rawArchive'],'newAssets':assets,'priorProtectedFilesUnchanged':len(protected),'newFiles':['benchmarks/recording-scope-v1.json','benchmarks/recording-scope-raw-v1.zip','benchmarks/recorded-meetings-ci-selection-v4.json'],'updatedDocs':['docs/RECORDED-MEETINGS-WIP.md','docs/PROGRESS.md'],'scope':'Publication metadata only; no runtime changes, test reruns or frozen-engine rebuilds.'}
(base/'publication-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='newAssets'}));print('newAssets',len(assets))
