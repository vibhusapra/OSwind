from pathlib import Path
import json,hashlib,re,subprocess
base=Path(__file__).resolve().parent;r=base.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((base/'qualification-v2/inputs.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==pins['source']
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
for item in pins['comparators']:assert sha(Path(item['path']))==item['sha256']
results={}
for label in ['optimized','tsan']:
 result=json.loads((base/'qualification-v2'/f'{label}.json').read_text());assert result['exitCode']==0 and result['source']==pins['source']
 logPath=base/'qualification-v2'/f'{label}.log';assert sha(logPath)==result['logSHA256'];log=logPath.read_text()
 cases=re.findall(r"Test Case '([^']+)' (passed|skipped|failed) \(([0-9.]+) seconds\)\.",log);assert len(cases)==len(set(x[0] for x in cases))==520
 reasons=re.findall(r"(\-\[[^\]]+\]) : Test skipped - ([^\n]+)",log);assert len(reasons)==16
 counts={s:sum(x[1]==s for x in cases) for s in ['passed','skipped','failed']};assert counts=={'passed':504,'skipped':16,'failed':0}
 raceReports=len(re.findall(r'WARNING: ThreadSanitizer|ThreadSanitizer: (?:data race|reported [1-9])',log));assert raceReports==0
 times=re.findall(r'Executed 520 tests, with 16 tests skipped and 0 failures \(0 unexpected\) in ([0-9.]+) \(([0-9.]+)\) seconds',log);assert times
 review={'defined':520,**counts,'testWallSeconds':float(times[-1][1]),'raceReports':raceReports,'skipCategories':{'childEntryOnly':9,'explicitScaleOptIn':3,'exactPrior32BinaryRequired':2,'generatedUIOptIn':2},'skipReasons':[{'name':a,'reason':b} for a,b in reasons],'methods':[{'name':a,'status':b,'seconds':float(c)} for a,b,c in cases]}
 (base/'qualification-v2'/f'{label}-methods-review.json').write_text(json.dumps(review,indent=2)+'\n');results[label]={'run':result,'methods':{k:v for k,v in review.items() if k!='methods'}}
frozen=[]
for manifest in sorted(base.glob('frozen-*.json')):
 entries=json.loads(manifest.read_text())
 for item in entries:assert sha(base/item['path'])==item['sha256']
 frozen.append({'manifest':manifest.name,'sha256':sha(manifest),'files':len(entries)})
for folder,total in [('development-v11',26),('navigation-fixed-v14',13)]:
 result=json.loads((base/folder/'result.json').read_text());assert result['exitCode']==0 and result['inputsUnchanged'];assert sha(base/folder/'test.log')==result['logSHA256']
 imageReview=json.loads((base/folder/'visual-review.json').read_text());assert imageReview['passed'] and len(imageReview['scenes'])==12
 for item in imageReview['scenes']:assert sha(base/folder/item['path'])==item['sha256']
negative=json.loads((base/'navigation-negative-v12/result.json').read_text());assert negative['exitCode']==1 and negative['inputsUnchanged'];negativeLog=(base/'navigation-negative-v12/test.log').read_text();assert 'Executed 2 tests, with 8 failures (0 unexpected)' in negativeLog
assert not subprocess.check_output(['git','diff','e01c94b7f558b0fd43f04ec5c6d52e3dee196065',pins['source'],'--','Sources/OSwindCore','Sources/OSwindCLI'],cwd=r)
protected=json.loads((base/'publication-protected-inputs.json').read_text())
for item in protected:assert sha(r/item['path'])==item['sha256']
review={'source':pins['source'],'inputs':len(pins['inputs']),'sourceAndComparatorsUnchanged':True,'coreAndCLIIdenticalTo':'e01c94b7f558b0fd43f04ec5c6d52e3dee196065','results':results,'frozenEngines':frozen,'debugEvidence':'development-v11:26pass; navigation-fixed-v14:13pass, each12manuallyreviewed components; exactsource/input/result manifests retained. No physical/interactive acceptance.','negativeNavigation':'Two failed methods/eight assertion issues, original engines/source/log preserved; current guarded13-model selection passes.','protectedHistoricalArtifacts':len(protected),'scope':'Selected source-pinned optimized/TSAN and owned APFS/Keychain/GPU/portable fixtures only. Other broad failed WIP gates, physical/native interactions, audio quality, power, automatic24h and competitive ranking are not superseded.'}
(base/'qualification-review-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'source':review['source'],'inputs':review['inputs'],'counts':{k:{x:v['methods'][x] for x in ['defined','passed','skipped','failed','raceReports','testWallSeconds']} for k,v in results.items()},'frozenManifests':len(frozen),'protectedHistoricalArtifacts':len(protected)}))
