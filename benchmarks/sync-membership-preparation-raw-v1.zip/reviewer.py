from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();out=root/'.artifacts/sync-membership-preparation-v1/qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();target=out/'reviewed-v1.json';assert not target.exists()
inputs=json.loads((out/'inputs.json').read_text());results=json.loads((out/'results.json').read_text())
assert inputs['baseSource']==results['baseSource']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='11f7f6a91af4a0c37b61600755da75e5fa3b3d24'
assert len(inputs['inputFiles'])==679 and all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert sha(out/'inputs.json')==results['inputManifestSHA256'] and results['runnerSHA256']==sha(root/'.artifacts/sync-membership-preparation-v1/qualify-v1.py')
assert len(inputs['workingChanges'])==10
listing=out/'discovered-tests.txt';discovery={line.replace('/','.') for line in listing.read_text().splitlines() if re.fullmatch(r'OSwind(?:Core|App)Tests\.\w+/test\w+',line)}
assert len(discovery)==2661
expected=set(re.findall(r'func (test\w+)\(', (root/'Tests/OSwindCoreTests/SyncMembershipPreparationTests.swift').read_text()));assert len(expected)==13
keychain='testOwnedNativeKeychainPreparationReopensAndCancelsOriginalAccounts'
frozen='testActualFrozen35ClientWaitingBeforeEnrollmentAndFreshOpenRefuseNative36'
selector=results['stages'][1]['command'][-1];native=results['stages'][3]['command'][-1]
assert [s['name'] for s in results['stages']]==['full-debug','affected-tsan','affected-optimized','owned-native']
review=[]
for stage in results['stages']:
 log=root/stage['log'];assert stage['exit']==0 and sha(log)==stage['sha256'];text=log.read_text();assert 'WARNING: ThreadSanitizer:' not in text
 raw=re.findall(r"Test Case '-\[(\w+\.\w+) (test\w+)\]' (passed|skipped|failed)",text);states={a+'.'+b:v for a,b,v in raw};assert len(states)==len(raw)
 count=re.findall(r'Executed (\d+) tests?, with (?:(\d+) tests? skipped and )?(\d+) failures?',text)[-1]
 assert int(count[0])==len(states) and int(count[1] or 0)==sum(v=='skipped' for v in states.values()) and int(count[2])==0 and all(v in ['passed','skipped'] for v in states.values())
 selected=discovery if stage['name']=='full-debug' else {name for name in discovery if re.search(native if stage['name']=='owned-native' else selector,name)};assert set(states)==selected
 new={name.split('.')[-1]:v for name,v in states.items() if name.startswith('OSwindCoreTests.SyncMembershipPreparationTests.')};assert set(new)==expected
 assert new[keychain]==('passed' if stage['name']=='owned-native' else 'skipped') and all(new[m]=='passed' for m in expected-{keychain})
 assert text.count('NATIVE36_FROZEN35_FENCE positive33=true waitingBeforeEnrollmentRefused=true fresh36Refused=true originalBinaryUnchanged=true')==1
 if stage['name']=='owned-native':assert all(v=='passed' for v in states.values()),'Inspect any owned native skip explicitly; do not hide it'
 review.append({'mode':stage['name'],'defined':len(states),'passed':sum(v=='passed' for v in states.values()),'skipped':[name for name,v in states.items() if v=='skipped'],'failed':0,'newPreparationMethods':new,'logSHA256':sha(log),'wallSeconds':stage['wallSeconds']})
result={'format':'OSwind native membership preparation qualification review v1','baseSource':inputs['baseSource'],'inputCount':679,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(out/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'discoverySHA256':sha(listing),'stages':review,'scope':'Native36 preparation with old private membership, restricted exact recovery and cancellation retaining the old-writer fence. No private membership handover/new-peer bootstrap, reviewed owner addition after delivery, revocation/rotation, real process death/task-drain, physical devices/provider, energy or production-signing acceptance. The real frozen35 collector waits before pairing/enrollment, not as an already Keychain-admitted native35 client. Current-code cached admitted/prepared SQL is tested separately. Fake protection-tier routing is not real data-protection-Keychain acceptance.'}
with target.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'review':str(target.relative_to(root)),'sha256':sha(target),'stages':[{'mode':s['mode'],'passed':s['passed'],'skipped':len(s['skipped'])} for s in review]}))
