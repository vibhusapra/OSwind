import XCTest
import CSQLite
import CryptoKit
@testable import OSwindCore

final class SyncMembershipPreparationTests:XCTestCase {
    private var root:URL!,stores=[MemoryStore](),pairings=[PersonalSyncPairing](),services=[SyncLibraryService](),operations=[SyncMembershipPreparationOwner]()
    private var storage=MembershipPreparationStorage(),serial=0
    private let machine=SyncCredentialBindingTests.Machine(value:String(repeating:"a",count:64))
    private let now=Date(timeIntervalSince1970:1_800_000_000)
    private var environment:SyncNativeWriterEnvironment {.init(stateRoot:root.appendingPathComponent("state"),machine:machine,storage:{[storage] _ in storage})}
    private struct Fixture {
        let store:MemoryStore,proof:SyncMembershipRefresh,shared:URL,pairingID:String,deliveryID:String,oldPairing:Data,oldMaterial:String,peerCount:Int
    }
    override func setUpWithError()throws {root=FileManager.default.temporaryDirectory.appendingPathComponent("owned-membership-preparation-"+UUID().uuidString)}
    override func tearDownWithError()throws {
        storage.didReplace=nil
        try operations.forEach {try $0.close()};services.forEach {try? $0.stop();$0.inbox.close();$0.transport.close()};pairings.forEach {$0.close()};try stores.forEach {try $0.close()};try FileManager.default.removeItem(at:root)
    }
    private func store(_ url:URL)throws->MemoryStore {
        let value=try MemoryStore(root:url,recoveryReadOnly:false,nativeWriterEnvironment:environment);stores.append(value);return value
    }
    private func pair(_ store:MemoryStore)throws->PersonalSyncPairing {
        let value=try PersonalSyncPairing(store:store,stateRoot:environment.stateRoot,machine:machine,storage:storage);pairings.append(value);return value
    }
    private func join(_ peer:PersonalSyncPairing,to owner:PersonalSyncPairing,name:String)throws {
        let request=try XCTUnwrap(peer.requestJoin(deviceName:name,now:now).request),response=try owner.approve(owner.reviewRequest(request,now:now),now:now)
        _=try peer.acceptResponse(response,trustedRootFingerprint:XCTUnwrap(owner.status().rootFingerprint),now:now)
    }
    private func object(_ data:Data)throws->[String:Any] {try XCTUnwrap(JSONSerialization.jsonObject(with:data) as? [String:Any])}
    private func read(_ library:URL,_ sql:String)throws->String {
        var db:OpaquePointer?;guard sqlite3_open_v2(library.appendingPathComponent("memory.sqlite").path,&db,SQLITE_OPEN_READONLY|SQLITE_OPEN_FULLMUTEX,nil)==SQLITE_OK else {sqlite3_close(db);throw OSwindError.invalid("Owned immutable membership read failed")};defer {sqlite3_close(db)}
        var row:OpaquePointer?;guard sqlite3_prepare_v2(db,sql,-1,&row,nil)==SQLITE_OK else {throw OSwindError.invalid("Owned membership query failed")};defer {sqlite3_finalize(row)}
        guard sqlite3_step(row)==SQLITE_ROW,sqlite3_column_bytes(row,0)<=262144,let text=sqlite3_column_text(row,0) else {throw OSwindError.invalid("Owned membership query has no bounded result")}
        return String(decoding:UnsafeBufferPointer(start:text,count:Int(sqlite3_column_bytes(row,0))),as:UTF8.self)
    }
    private func fixture()throws->Fixture {
        serial+=1;let base=root.appendingPathComponent("case-\(serial)"),a=try store(base.appendingPathComponent("owner")),b=try store(base.appendingPathComponent("peer")),c=try store(base.appendingPathComponent("third"))
        let owner=try pair(a),peer=try pair(b),third=try pair(c);_=try owner.createGroup(deviceName:"Owned desk",now:now)
        try join(peer,to:owner,name:"Owned travel");let prior=try peer.membershipCertificateForRefresh();try join(third,to:owner,name:"Owned third")
        let proof=try XCTUnwrap(owner.membershipRefresh(after:prior)),shared=base.appendingPathComponent("shared")
        let service=try peer.prepareAnchoredService(shared:shared,createShared:true);services.append(service);try service.installNativeWriterAdmission()
        try b.insert(Memory(id:"canary",kind:.note,text:"Owned local intent before membership fence"))
        try service.stop();service.inbox.close();service.transport.close();peer.close()
        let handle=try object(Data(read(b.root,"SELECT value FROM store_metadata WHERE key='sync-pairing-handle-v1'").utf8)),pairingID=try XCTUnwrap(handle["id"] as? String),deliveryID=try read(b.root,"SELECT id FROM personal_sync_delivery_anchor")
        let saved=try XCTUnwrap(storage.values[pairingID]),material=try XCTUnwrap(object(saved)["material"] as? String)
        XCTAssertEqual(try read(b.root,"PRAGMA user_version"),"35")
        return .init(store:b,proof:proof,shared:shared,pairingID:pairingID,deliveryID:deliveryID,oldPairing:saved,oldMaterial:material,peerCount:2)
    }
    private func prepare(_ f:Fixture)throws->SyncMembershipPreparationOwner {
        let op=try SyncMembershipPreparationOwner.prepare(library:f.store,proof:f.proof,environment:environment);operations.append(op);return op
    }
    private func recover(_ f:Fixture)throws->SyncMembershipPreparationOwner {
        let op=try SyncMembershipPreparationOwner.open(root:f.store.root,environment:environment);operations.append(op);return op
    }
    private func files(_ root:URL)throws->[String:String] {
        let enumerator=try XCTUnwrap(FileManager.default.enumerator(at:root,includingPropertiesForKeys:[.isRegularFileKey]));var result=[String:String]()
        for case let path as URL in enumerator where try path.resourceValues(forKeys:[.isRegularFileKey]).isRegularFile==true {result[String(path.path.dropFirst(root.path.count+1))]=SyncProtocolLimits.hex(try Data(contentsOf:path))};return result
    }
    private func assertOriginal(_ f:Fixture,file:StaticString=#filePath,line:UInt=#line)throws {
        XCTAssertTrue(storage.values[f.pairingID]==f.oldPairing,"Preparation changed pairing authority",file:file,line:line)
        let envelope=try object(XCTUnwrap(storage.values[f.deliveryID]));XCTAssertEqual(envelope["material"] as? String,f.oldMaterial,file:file,line:line)
        XCTAssertEqual(try read(f.store.root,"SELECT COUNT(*) FROM personal_sync_peers"),String(f.peerCount),file:file,line:line)
    }
    private func finish(_ f:Fixture,_ operation:SyncMembershipPreparationOwner)throws->MemoryStore {
        try operation.cancelBeforeHandover();try operation.close();let fresh=try store(f.store.root)
        XCTAssertEqual(try read(f.store.root,"PRAGMA user_version"),"36");XCTAssertEqual(try read(f.store.root,"SELECT value FROM store_metadata WHERE key='sync-native-membership-phase-v1'"),"active")
        try assertOriginal(f);XCTAssertNotNil(try fresh.get("canary"));return fresh
    }
    func testCommittedFenceRejectsCachedPreparedWritersAndCancellationKeepsOriginalMembership()throws {
        let f=try fixture(),provider=try files(f.shared),accounts=storage.values.count,stale=try store(f.store.root)
        let row=try stale.withRoutineDatabase {try $0.statement("UPDATE memories SET title='Stale prepared writer' WHERE id='canary'")};defer {sqlite3_finalize(row)}
        let op=try prepare(f)
        XCTAssertEqual(try read(f.store.root,"PRAGMA user_version"),"36");XCTAssertEqual(try read(f.store.root,"SELECT value FROM store_metadata WHERE key='sync-native-membership-phase-v1'"),"prepared")
        XCTAssertThrowsError(try f.store.get("canary"));XCTAssertThrowsError(try store(f.store.root));XCTAssertNotEqual(sqlite3_step(row),SQLITE_DONE)
        try assertOriginal(f);let fresh=try finish(f,op)
        XCTAssertNotEqual(sqlite3_step(row),SQLITE_DONE);XCTAssertThrowsError(try stale.get("canary"))
        try fresh.insert(Memory(id:"fresh",text:"Fresh verified native36 writer"));XCTAssertNotNil(try fresh.get("fresh"))
        XCTAssertEqual(try files(f.shared),provider);XCTAssertEqual(storage.values.count,accounts)
        XCTAssertGreaterThan(Int(try read(f.store.root,"SELECT COUNT(*) FROM personal_sync_changes")) ?? 0,0)
    }
    func testRejectedPreparationCommitRecoversExactFenceAndPreservesLegitimatePreFenceWrite()throws {
        let f=try fixture(),stale=try store(f.store.root),provider=try files(f.shared),gate=MembershipCommitGate()
        let handle=try f.store.withRoutineDatabase {$0.handle}
        storage.didReplace={_ in sqlite3_commit_hook(handle,MembershipCommitGate.callback,Unmanaged.passUnretained(gate).toOpaque())}
        XCTAssertThrowsError(try prepare(f));storage.didReplace=nil;sqlite3_commit_hook(handle,nil,nil)
        XCTAssertEqual(gate.rejections,1);try assertOriginal(f)
        XCTAssertEqual(try read(f.store.root,"PRAGMA user_version"),"35")
        try stale.insert(Memory(id:"pre-fence",text:"Legitimate raw capture before the fence committed"))
        try f.store.close();XCTAssertThrowsError(try store(f.store.root))
        let resumed=try recover(f);try resumed.resumeFence();XCTAssertThrowsError(try stale.insert(Memory(id:"post-fence",text:"Must refuse")))
        let fresh=try finish(f,resumed);XCTAssertNotNil(try fresh.get("pre-fence"));XCTAssertNil(try fresh.get("post-fence"));XCTAssertEqual(try files(f.shared),provider)
    }
    func testAmbiguousPreparationSaveCannotAdvancePrivateMembershipAndResumesWithoutReplacementAccounts()throws {
        let f=try fixture(),count=storage.values.count;storage.failAt=storage.attempts+1;storage.failAfter=true
        XCTAssertThrowsError(try prepare(f));try f.store.close();try assertOriginal(f)
        XCTAssertThrowsError(try store(f.store.root));let resumed=try recover(f);try resumed.resumeFence();_=try finish(f,resumed)
        XCTAssertEqual(storage.values.count,count)
    }
    func testCancellationRecoversBeforeAndAfterEveryExternalBoundary()throws {
        for boundary in 1...3 {for after in [false,true] {
            let f=try fixture(),op=try prepare(f),provider=try files(f.shared),count=storage.values.count
            storage.failAt=storage.attempts+boundary;storage.failAfter=after
            XCTAssertThrowsError(try op.cancelBeforeHandover(),"Owned boundary \(boundary), after=\(after)");try op.close();try assertOriginal(f)
            let envelope=try object(XCTUnwrap(storage.values[f.deliveryID]))
            if envelope["membershipPreparation"]==nil {
                // The final clear committed before its injected error.
                let fresh=try store(f.store.root);XCTAssertNotNil(try fresh.get("canary"));XCTAssertThrowsError(try recover(f))
            }else {let resumed=try recover(f);_=try finish(f,resumed)}
            XCTAssertEqual(storage.values.count,count);XCTAssertEqual(try files(f.shared),provider)
        }}
    }
    func testRejectedCancellationCommitReplaysDirectlyAboveSavedExternalFloor()throws {
        let f=try fixture(),op=try prepare(f),handle=try f.store.withMembershipDatabase {$0.handle},gate=MembershipCommitGate(),target=storage.attempts+2
        storage.didReplace={ordinal in if ordinal==target {sqlite3_commit_hook(handle,MembershipCommitGate.callback,Unmanaged.passUnretained(gate).toOpaque())}}
        XCTAssertThrowsError(try op.cancelBeforeHandover());storage.didReplace=nil;sqlite3_commit_hook(handle,nil,nil);try op.close();XCTAssertEqual(gate.rejections,1)
        let envelope=try object(XCTUnwrap(storage.values[f.deliveryID])),token=try XCTUnwrap(envelope["token"] as? [String:Any]),floor=try XCTUnwrap(token["serial"] as? Int64)
        let resumed=try recover(f);_=try finish(f,resumed)
        XCTAssertGreaterThan(Int64(try read(f.store.root,"SELECT serial FROM personal_sync_delivery_anchor")) ?? 0,floor)
    }
    func testRecoveryRefusesCloneMissingEncryptedPlanAndChangedPairingWithoutRegeneration()throws {
        let f=try fixture(),op=try prepare(f),provider=try files(f.shared);try op.close();let accounts=storage.values
        let clone=root.appendingPathComponent("clone");try FileManager.default.copyItem(at:f.store.root,to:clone)
        XCTAssertThrowsError(try SyncMembershipPreparationOwner.open(root:clone,environment:environment));XCTAssertTrue(storage.values==accounts)
        let inbox=f.store.root.appendingPathComponent("images/device-sync-"+f.proof.base.body.members.first(where:{$0.name=="Owned travel"})!.replica),parked=f.store.root.appendingPathComponent("images/parked-inbox")
        try FileManager.default.moveItem(at:inbox,to:parked);XCTAssertThrowsError(try recover(f));XCTAssertFalse(FileManager.default.fileExists(atPath:inbox.path));XCTAssertTrue(storage.values==accounts)
        try FileManager.default.moveItem(at:parked,to:inbox)
        var changed=try object(f.oldPairing);changed["consumedRequest"]=String(repeating:"0",count:64)
        storage.overwrite(f.pairingID,bytes:try JSONSerialization.data(withJSONObject:changed,options:[.sortedKeys,.withoutEscapingSlashes]))
        XCTAssertThrowsError(try recover(f));storage.overwrite(f.pairingID,bytes:f.oldPairing)
        let resumed=try recover(f);_=try finish(f,resumed);XCTAssertEqual(try files(f.shared),provider)
    }
    func testNativePhaseAndReservedMetadataCannotBeChangedByOrdinaryWriters()throws {
        let f=try fixture(),op=try prepare(f),fresh=try finish(f,op)
        for sql in ["UPDATE store_metadata SET value='prepared' WHERE key='sync-native-membership-phase-v1'","DELETE FROM store_metadata WHERE key='sync-native-membership-state-v1'","INSERT OR REPLACE INTO store_metadata VALUES('sync-native-membership-phase-v1','active')","UPDATE store_metadata SET key='renamed-state' WHERE key='sync-native-membership-state-v1'"] {XCTAssertThrowsError(try fresh.withRoutineDatabase {try $0.execute(sql)})}
        try fresh.insert(Memory(id:"after-refused-change",text:"Ordinary content remains writable"));XCTAssertNotNil(try fresh.get("after-refused-change"))
        try fresh.close()
        let g=try fixture(),prepared=try prepare(g)
        try g.store.withMembershipDatabase {db in try g.store.nativeWriterAdmission.withMembershipMutation(db) {try db.execute("UPDATE store_metadata SET value='active' WHERE key='sync-native-membership-phase-v1'")}}
        try prepared.close();let values=storage.values
        XCTAssertThrowsError(try recover(g));XCTAssertTrue(storage.values==values)
    }
    func testNative36RetirementAndPortableRecoveryKeepOriginalSafetyBoundaries()throws {
        let f=try fixture(),op=try prepare(f),fresh=try finish(f,op);try fresh.close()
        let backup=root.appendingPathComponent("portable.oswindbackup"),restored=root.appendingPathComponent("restored")
        _=try LibraryRecovery.createBackup(from:f.store.root,destination:backup);_=try LibraryBackup.restore(backup,to:restored)
        let quiet=try store(restored);XCTAssertEqual(try pair(quiet).status().phase,.unconfigured);XCTAssertEqual(try read(restored,"SELECT COUNT(*) FROM store_metadata WHERE key LIKE 'sync-native-membership-%'"),"0")
        let active=try store(f.store.root),peer=try pair(active),service=try peer.prepareAnchoredService(shared:f.shared,createShared:false);services.append(service)
        _=try service.stageLocalRetirement();try service.stop();service.inbox.close();service.transport.close();peer.close();try active.close()
        let recovery=try SyncRetirementCleanupOwner.open(root:active.root,environment:environment);defer {try? recovery.close()}
        XCTAssertTrue(try recovery.cleanup().cleanupComplete);_=try recovery.completeLocalRetirement();try recovery.close()
        let renewed=try store(active.root);try renewed.insert(Memory(id:"renewed",text:"Native36 whole erase renewal"));XCTAssertNotNil(try renewed.get("renewed"));XCTAssertEqual(try read(active.root,"PRAGMA user_version"),"36")
    }
}

private final class MembershipPreparationStorage:SyncCredentialStorage,@unchecked Sendable {
    let protection:SyncCredentialProtection = .loginKeychain
    private let lock=NSLock();private var saved=[String:Data](),count=0
    var failAt:Int?,failAfter=false,didReplace:((Int)->Void)?
    var values:[String:Data] {lock.lock();defer {lock.unlock()};return saved}
    var attempts:Int {lock.lock();defer {lock.unlock()};return count}
    func create(id:String,bytes:Data)throws {lock.lock();defer {lock.unlock()};guard saved[id]==nil else {throw SyncCredentialStorageError.alreadyExists};saved[id]=bytes}
    func read(id:String)throws->Data {lock.lock();defer {lock.unlock()};guard let bytes=saved[id] else {throw SyncCredentialStorageError.missing};return bytes}
    func replace(id:String,expected:Data,bytes:Data)throws {
        lock.lock();count+=1;let ordinal=count,fail=ordinal==failAt,after=failAfter
        if fail && !after {lock.unlock();throw SyncCredentialStorageError.unavailable(-1)}
        guard saved[id]==expected else {lock.unlock();throw SyncCredentialStorageError.changed};saved[id]=bytes;lock.unlock();didReplace?(ordinal)
        if fail && after {throw SyncCredentialStorageError.unavailable(-1)}
    }
    func remove(id:String,expected:Data)throws {lock.lock();defer {lock.unlock()};guard saved[id]==expected else {throw SyncCredentialStorageError.changed};saved.removeValue(forKey:id)}
    func overwrite(_ id:String,bytes:Data) {lock.lock();saved[id]=bytes;lock.unlock()}
}
private final class MembershipCommitGate {
    private(set) var rejections=0
    static let callback:@convention(c) (UnsafeMutableRawPointer?)->Int32 = {pointer in
        let gate=Unmanaged<MembershipCommitGate>.fromOpaque(pointer!).takeUnretainedValue()
        if gate.rejections==0 {gate.rejections+=1;return 1};return 0
    }
}
