from pathlib import Path
import json,hashlib,re,subprocess
base=Path(__file__).resolve().parent;r=base.parents[1];out=base/'qualification-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((out/'inputs.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==pins['source']
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
for item in pins['comparators']+pins['protectedFrozen']:assert sha(Path(item['path']))==item['sha256']
results={}
for label in ['optimized','tsan']:
 result=json.loads((out/f'{label}.json').read_text());assert result['exitCode']==0 and result['source']==pins['source']
 logPath=out/f'{label}.log';assert sha(logPath)==result['logSHA256'];log=logPath.read_text()
 cases=re.findall(r"Test Case '([^']+)' (passed|skipped|failed) \(([0-9.]+) seconds\)\.",log);assert len(cases)==len(set(x[0] for x in cases))==563
 reasons=re.findall(r"(\-\[[^\]]+\]) : Test skipped - ([^\n]+)",log);assert len(reasons)==17
 counts={s:sum(x[1]==s for x in cases) for s in ['passed','skipped','failed']};assert counts=={'passed':546,'skipped':17,'failed':0}
 raceReports=len(re.findall(r'WARNING: ThreadSanitizer|ThreadSanitizer: (?:data race|reported [1-9])',log));assert raceReports==0
 times=re.findall(r'Executed 563 tests, with 17 tests skipped and 0 failures \(0 unexpected\) in ([0-9.]+) \(([0-9.]+)\) seconds',log);assert times
 categories={'childEntryOnly':0,'explicitScaleOptIn':0,'exactPrior32BinaryRequired':0,'generatedUIOptIn':0,'ownedPerformanceOptIn':0}
 for name,reason in reasons:
  if 'crash child' in reason:categories['childEntryOnly']+=1
  elif 'scale output' in reason or 'fanout output' in reason:categories['explicitScaleOptIn']+=1
  elif 'prior' in reason.lower() and '32' in reason:categories['exactPrior32BinaryRequired']+=1
  elif 'component' in reason:categories['generatedUIOptIn']+=1
  elif 'performance fixture' in reason:categories['ownedPerformanceOptIn']+=1
  else:raise AssertionError((name,reason))
 assert categories=={'childEntryOnly':9,'explicitScaleOptIn':3,'exactPrior32BinaryRequired':2,'generatedUIOptIn':2,'ownedPerformanceOptIn':1},categories
 for method in ['testGroupingRunsOffMainThreadAndRechecksPrivacyBeforePublication','testActualAppDepartureJoinsBlockedGroupingBeforeStoreClose']:
  assert any(name.endswith(' '+method+']') and status=='passed' for name,status,_ in cases)
 for needle in ['NativeRecordedMeetingTests','testOwnedNativeThreePublicSessionsPreserveThirteenKindsAndOriginalAccounts']:
  native=[x for x in cases if needle in x[0]];assert native and all(x[1]=='passed' for x in native)
 review={'defined':563,**counts,'testWallSeconds':float(times[-1][1]),'raceReports':raceReports,'skipCategories':categories,'skipReasons':[{'name':a,'reason':b} for a,b in reasons],'methods':[{'name':a,'status':b,'seconds':float(c)} for a,b,c in cases]}
 destination=out/f'{label}-methods-review.json';assert not destination.exists();destination.write_text(json.dumps(review,indent=2)+'\n');results[label]={'run':result,'methods':{k:v for k,v in review.items() if k!='methods'}}
frozen=[]
for frozenBase in [base,r/'.artifacts/recording-scope-v1']:
 for manifest in sorted(frozenBase.glob('frozen-*.json')):
  entries=json.loads(manifest.read_text())
  for item in entries:assert sha(frozenBase/item['path'])==item['sha256']
  frozen.append({'manifest':str(manifest.relative_to(r)),'sha256':sha(manifest),'files':len(entries)})
assert not subprocess.check_output(['git','diff','9bdd3032af90086e012eb75d4e7c2c34abb0a6fa',pins['source'],'--','Sources/OSwindCLI'],cwd=r)
changed=subprocess.check_output(['git','diff','--name-only','85029eabbf6272a06a4fa2831497e9d58f86f393',pins['source'],'--','Sources'],cwd=r,text=True).splitlines();assert set(changed)=={'Sources/OSwind/RecordedMeetingsModel.swift','Sources/OSwindCore/RecordedMeetings.swift'}
result={'source':pins['source'],'inputs':len(pins['inputs']),'sourceComparatorsAndHistoricalEnginesUnchanged':True,'cliSourceIdenticalTo':'9bdd3032af90086e012eb75d4e7c2c34abb0a6fa','productionFilesChanged':changed,'results':results,'frozenEngines':frozen,'scope':'Selected committed-source optimized/TSAN, actual owned APFS/Keychain/GPU/portable and app departure fixtures. Not whole-current-suite, hosted-native, physical/native interaction, speech, power, automatic24h or competitor ranking. Earlier owner/peer broad failures remain separate; prior twelve component renders were not rerun for this nonvisual optimization.'}
destination=base/'qualification-review-v1.json';assert not destination.exists();destination.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'source':result['source'],'inputs':result['inputs'],'counts':{k:{x:v['methods'][x] for x in ['defined','passed','skipped','failed','raceReports','testWallSeconds']} for k,v in results.items()},'frozenManifests':len(frozen)}))
