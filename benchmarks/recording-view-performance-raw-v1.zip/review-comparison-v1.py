from pathlib import Path
import json,hashlib,statistics,math,re,subprocess,datetime
root=Path(__file__).resolve().parent;r=root.parents[1];out=root/'comparison-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=json.loads((root/'protocol-v1.json').read_text());pins=json.loads((root/'comparison-inputs-v1.json').read_text());completion=json.loads((out/'result.json').read_text())
assert completion['source']==pins['source'] and completion['observations']==32 and completion['pageObservations']==656
assert sha(root/'protocol-v1.json')==pins['protocolSHA256']==completion['protocolSHA256']
assert sha(out/'observations.jsonl')==completion['journalSHA256']
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
for corpus in pins['originalCorpora'].values():
 for item in corpus['files']:assert sha(r/item['path'])==item['sha256']
for engine in ['baseline','candidate']:
 for item in json.loads((root/f'frozen-{engine}-v1.json').read_text()):assert sha(root/item['path'])==item['sha256']
benchmark='Tests/OSwindAppTests/RecordedMeetingViewBenchmarkTests.swift'
a=subprocess.check_output(['git','show','85029eabbf6272a06a4fa2831497e9d58f86f393:'+benchmark],cwd=r)
b=subprocess.check_output(['git','show',pins['source']+':'+benchmark],cwd=r);assert a==b==(r/benchmark).read_bytes()
obs=[json.loads(x) for x in (out/'observations.jsonl').read_text().splitlines()];assert len(obs)==32
runs={}
for item in obs:
 assert item['exitCode']==0 and not item['harnessDeadlineExceeded']
 log=out/(item['trial']+'.log');assert sha(log)==item['logSHA256']
 text=log.read_text();assert 'Executed 1 test, with 0 failures (0 unexpected)' in text and ' skipped' not in text
 path=root/item['result'];assert sha(path)==item['resultSHA256'];data=json.loads(path.read_text())
 expected=20000 if item['corpus']=='live20k' else 256;pages=40 if expected==20000 else 1
 assert data['expected']==data['uniqueSources']==expected and len(data['pages'])==pages
 assert data['loadedSources']==[min(512*(i+1),expected) for i in range(pages)]
 assert sum(x['rows'] for x in data['pages'])==expected
 assert item['canonicalAfter']==pins['originalCorpora'][item['corpus']]['canonical']
 assert item['order']==(['baseline','candidate'] if item['pair']%2==0 else ['candidate','baseline'])
 key=item['corpus'],item['pair'],item['engine'];assert key not in runs;runs[key]=data
for corpus in ['live20k','imports256']:
 for pair in range(8):
  a,b=[runs[corpus,pair,engine] for engine in ['baseline','candidate']]
  assert a['metricChecksums']==b['metricChecksums']
summary=json.loads((out/'summary.json').read_text())
def values(run,field):
 if field=='sqlReadSeconds':return [x['seconds'] for x in run['pages']]
 return run[field] if isinstance(run[field],list) else [run[field]]
def stats(v):
 s=sorted(x*1000 for x in v);return {'n':len(s),'medianMs':statistics.median(s),'p95NearestRankMs':s[math.ceil(.95*len(s))-1],'maxMs':max(s),'minMs':min(s)}
for corpus in ['live20k','imports256']:
 for engine in ['baseline','candidate']:
  for field,record in summary['results'][corpus][engine].items():
   per=[values(runs[corpus,pair,engine],field) for pair in range(8)]
   assert record['allObservations']==stats([v for run in per for v in run])
   assert record['processMedians']==stats([statistics.median(run) for run in per])
   assert record['perProcessValuesMs']==[[v*1000 for v in run] for run in per]
 for field,record in summary['results'][corpus]['pairedMedianReductionsPercent'].items():
  expected=[100*(1-statistics.median(values(runs[corpus,pair,'candidate'],field))/statistics.median(values(runs[corpus,pair,'baseline'],field))) for pair in range(8)]
  assert record==expected
result={'reviewedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':pins['source'],'observations':32,'pageObservations':656,'passedMethods':32,'skippedMethods':0,'failedMethods':0,'allUniqueRunsLogsAndResultsVerified':True,'allExpectedCountsAndPairedMetricChecksumsVerified':True,'allInputOriginalAndEngineHashesUnchanged':True,'benchmarkDefinitionByteIdentical':True,'summaryRecomputedWithoutReruns':True,'summarySHA256':sha(out/'summary.json'),'machine':{'model':subprocess.check_output(['sysctl','-n','hw.model']).decode().strip(),'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string']).decode().strip(),'memoryBytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'])),'macOS':subprocess.check_output(['sw_vers','-productVersion']).decode().strip(),'build':subprocess.check_output(['sw_vers','-buildVersion']).decode().strip()},'limitations':protocol['controls']}
destination=out/'review-v1.json';assert not destination.exists();destination.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
