from pathlib import Path
import os,subprocess,json,time,hashlib
out=Path(__file__).resolve().parent;root=out.parent;r=root.parents[1];pins=json.loads((out/'inputs.json').read_text());env=os.environ.copy();env.update({'OSWIND_RECORDING_VIEW_ROOT':str(root),'OSWIND_RECORDING_VIEW_CORPUS':'imports256','OSWIND_RECORDING_VIEW_TRIAL':pins['trial']})
command=['swift','test','-c','release','--jobs','4','--filter','RecordedMeetingViewBenchmarkTests'];start=time.monotonic()
with (out/'test.log').open('xb') as log:result=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
for item in pins['inputs']+pins['originalCorpus']:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'inputsAndOriginalCorpusUnchanged':True,'logSHA256':hashlib.sha256((out/'test.log').read_bytes()).hexdigest(),'scope':'First development probe only, not a controlled paired benchmark.'};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/'test.log').read_text()[-4500:]);raise SystemExit(result.returncode)
