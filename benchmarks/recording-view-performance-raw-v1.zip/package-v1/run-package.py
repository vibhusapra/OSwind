from pathlib import Path
import os,subprocess,json,hashlib,time,shutil,datetime
out=Path(__file__).resolve().parent;r=out.parents[2];base=out.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((base/'qualification-v1/inputs.json').read_text())
assert json.loads((base/'qualification-v1/optimized.json').read_text())['exitCode']==0
assert json.loads((base/'qualification-v1/tsan.json').read_text())['exitCode']==0
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
packagePaths=[r/'scripts/build-app.sh']
for name in ['assets','ThirdParty','scripts']:packagePaths += [p for p in (r/name).rglob('*') if p.is_file()]
packagePins=[{'path':str(p.relative_to(r)),'sha256':sha(p)} for p in sorted(set(packagePaths))]
(out/'package-inputs.json').write_text(json.dumps(packagePins,indent=2)+'\n')
frozenPins=[]
for frozenBase in [base,r/'.artifacts/recording-scope-v1']:
 for manifest in sorted(frozenBase.glob('frozen-*.json')):
  for item in json.loads(manifest.read_text()):
   path=frozenBase/item['path'];assert sha(path)==item['sha256'];frozenPins.append({'path':str(path),'sha256':item['sha256']})
app=out/'OSwind.app';assert not app.exists();env=os.environ.copy();env['OSWIND_APP_OUTPUT']=str(app)
command=['bash','scripts/build-app.sh','release'];start=time.monotonic()
with (out/'package.log').open('xb') as log:build=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'source':pins['source'],'command':command,'exitCode':build.returncode,'elapsedSeconds':time.monotonic()-start,'logSHA256':sha(out/'package.log'),'scope':'Normal release, local ad-hoc development app and owned empty-library CLI smoke. Separate from optimized-test engines; no notarization, physical/native interaction, power, automatic24h or release-readiness claim.'}
(out/'build-result.json').write_text(json.dumps(record,indent=2)+'\n')
assert build.returncode==0
verify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(app)],capture_output=True)
record['signature']={'exitCode':verify.returncode,'output':(verify.stdout+verify.stderr).decode()}
for item in pins['inputs']+packagePins:assert sha(r/item['path'])==item['sha256']
for item in frozenPins:assert sha(Path(item['path']))==item['sha256']
record['sourceAndPackageInputsUnchanged']=True;record['allHistoricalFrozenEnginesUnchanged']=True
files=[{'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(app.rglob('*')) if p.is_file()]
record['files']=files
frozen=base/'frozen-normal-release-v1';frozen.mkdir();normal=[]
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 source=app/'Contents/MacOS'/name;assert source.stat().st_mode&0o777==0o755;target=frozen/name;shutil.copy2(source,target);normal.append({'path':str(target.relative_to(base)),'bytes':target.stat().st_size,'sha256':sha(target),'mode':oct(target.stat().st_mode&0o777)})
(base/'frozen-normal-release-v1.json').write_text(json.dumps(normal,indent=2)+'\n')
smokeRoot=out/'owned-package-smoke';assert not smokeRoot.exists();smokeCommand=[str(app/'Contents/MacOS/oswindctl'),'stats','--data',str(smokeRoot)]
smoke=subprocess.run(smokeCommand,capture_output=True);(out/'smoke.stdout').write_bytes(smoke.stdout);(out/'smoke.stderr').write_bytes(smoke.stderr)
record['smoke']={'command':smokeCommand,'exitCode':smoke.returncode,'stdoutSHA256':sha(out/'smoke.stdout'),'stderrSHA256':sha(out/'smoke.stderr')}
if smoke.returncode==0:
 stats=json.loads(smoke.stdout);record['smoke'].update({'sources':stats['count'],'audio':stats['audioSegments']});assert stats['count']==stats['audioSegments']==0
scopeEnvironment=os.environ.copy();scopeEnvironment.update({'OSWIND_RECORDING_CURRENT_CLI':str(app/'Contents/MacOS/oswindctl'),'OSWIND_RECORDING_UNSCOPED_CLI':str(r/'.artifacts/recording-scope-v1/frozen-development-v10/oswindctl'),'OSWIND_RECORDING_CLI_QA_DIR':str(out/'package-cli-control')})
method='OSwindCoreTests.RecordingScopeTests/testActualCLIRecordingFollowupExcludesNeighborAgainstRetainedUnscopedControl'
scopeCommand=['xcrun','xctest','-XCTest',method,str(base/'frozen-optimized-v1/OSwindPackageTests.xctest')]
with (out/'package-scope.log').open('xb') as output:scopeTest=subprocess.run(scopeCommand,cwd=r,env=scopeEnvironment,stdout=output,stderr=subprocess.STDOUT)
scopeLog=(out/'package-scope.log').read_text();record['packagedScopeControl']={'command':scopeCommand,'exitCode':scopeTest.returncode,'logSHA256':sha(out/'package-scope.log'),'testEngineManifest':'frozen-optimized-v1.json','normalPackageCLI':str(app/'Contents/MacOS/oswindctl'),'scope':'Reuses actual frozen current optimized Core test engine; its fixture invokes actual normal packaged CLI and retained v10 negative control. No rebuild or resignation of frozen engines.'}
assert scopeTest.returncode==0 and 'OWNED_RECORDING_CLI negativeNeighborIncluded=true currentNeighborExcluded=true scopePreserved=true' in scopeLog and 'Test skipped' not in scopeLog
record['normalPackageCLIHash']=sha(app/'Contents/MacOS/oswindctl');record['optimizedTestCLIHash']=sha(base/'frozen-optimized-v1/oswindctl');record['buildProductCLIHash']=sha(r/'.build/arm64-apple-macosx/release/oswindctl')
description=json.loads((r/'.build/arm64-apple-macosx/release/description.json').read_text())
coreCommands=[{'name':key,'enableTesting':'-enable-testing' in value.get('otherArguments',[])} for key,value in description.get('swiftCommands',{}).items() if value.get('moduleName')=='OSwindCore']
record['normalCoreCommands']=coreCommands
for item in pins['inputs']+packagePins:assert sha(r/item['path'])==item['sha256']
for item in frozenPins:assert sha(Path(item['path']))==item['sha256']
archive=out/'OSwind-development-195b4ad.zip';assert not archive.exists()
zipResult=subprocess.run(['/usr/bin/ditto','-c','-k','--sequesterRsrc','--keepParent',str(app),str(archive)],capture_output=True);assert zipResult.returncode==0,(zipResult.stdout+zipResult.stderr).decode()
extracted=out/'archive-check';assert not extracted.exists();extract=subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(extracted)],capture_output=True);assert extract.returncode==0
restored=extracted/'OSwind.app';restoredFiles=[{'path':str(p.relative_to(restored)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(restored.rglob('*')) if p.is_file()]
assert restoredFiles==files
archiveVerify=subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(restored)],capture_output=True);assert archiveVerify.returncode==0
record['developmentArchive']={'path':str(archive.relative_to(base)),'bytes':archive.stat().st_size,'sha256':sha(archive),'allExtractedFilesAndModesMatch':True,'signatureAfterRoundTripExitCode':archiveVerify.returncode,'scope':'Local ad-hoc development archive; independent exact signed-app round trip verified, no notarization or live activation.'}
record['reviewedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'package.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'}));print('packageFiles',len(files))
assert verify.returncode==smoke.returncode==0
assert coreCommands and all(not item['enableTesting'] for item in coreCommands)
