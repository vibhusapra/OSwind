from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,sqlite3,struct,urllib.parse
root=Path(__file__).resolve().parent;r=root.parents[1];out=root/'comparison-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol=json.loads((root/'protocol-v1.json').read_text());pins=json.loads((root/'comparison-inputs-v1.json').read_text())
assert sha(root/'protocol-v1.json')==pins['protocolSHA256']
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
engines={name:json.loads((root/f'frozen-{name}-v1.json').read_text()) for name in ['baseline','candidate']}
originals=pins['originalCorpora']
def check():
 for items in engines.values():
  for item in items:assert sha(root/item['path'])==item['sha256']
 for corpus in originals.values():
  for item in corpus['files']:assert sha(r/item['path'])==item['sha256']
 for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
def canonical(path):
 digest=hashlib.sha256();count=0
 uri='file:'+urllib.parse.quote(str(path),safe='/')+'?mode=ro&immutable=1'
 with sqlite3.connect(uri,uri=True) as db:
  for row in db.execute('SELECT id,timestamp,kind,app,title,url,text,favorite,payload,embedding,embedding_model FROM memories ORDER BY id COLLATE BINARY'):
   count+=1
   for value in row:
    if value is None:kind,data=b'N',b''
    elif isinstance(value,bytes):kind,data=b'B',value
    elif isinstance(value,str):kind,data=b'S',value.encode()
    elif isinstance(value,int):kind,data=b'I',struct.pack('>q',value)
    else:kind,data=b'F',struct.pack('>d',value)
    digest.update(kind+struct.pack('>Q',len(data))+data)
 return {'count':count,'sha256':digest.hexdigest()}
check();out.mkdir()
for name,corpus in originals.items():
 value=canonical(r/corpus['directory']/'memory.sqlite');assert value==corpus['canonical'],name
observations=[];journal=(out/'observations.jsonl').open('x')
try:
 for corpus in protocol['corpora']:
  name=corpus['name'];original=originals[name];directory=r/original['directory']
  for pair in range(protocol['pairsPerCorpus']):
   order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
   for engine in order:
    check();trial=f'{name}-pair{pair:02d}-{engine}';target=root/'trials'/trial/'library';target.parent.mkdir(parents=True)
    assert shutil.disk_usage(r).free>16*1024**3+2*sum(x['bytes'] for x in original['files'])
    shutil.copytree(directory,target)
    env=os.environ.copy();env.update({'OSWIND_RECORDING_VIEW_ROOT':str(root),'OSWIND_RECORDING_VIEW_CORPUS':name,'OSWIND_RECORDING_VIEW_TRIAL':trial})
    command=['xcrun','xctest','-XCTest',protocol['testMethod'],str(root/f'frozen-{engine}-v1/OSwindPackageTests.xctest')]
    log=out/(trial+'.log');started=time.monotonic();deadline=False
    with log.open('xb') as output:
     try:process=subprocess.run(command,cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=300);code=process.returncode
     except subprocess.TimeoutExpired:code=None;deadline=True
    result=root/'trials'/trial/'result.json'
    entry={'corpus':name,'pair':pair,'order':order,'engine':engine,'trial':trial,'command':command,'exitCode':code,'harnessDeadlineExceeded':deadline,'commandSeconds':time.monotonic()-started,'logSHA256':sha(log),'result':str(result.relative_to(root)) if result.exists() else None}
    if result.exists():
     data=json.loads(result.read_text());entry['resultSHA256']=sha(result)
     assert data['expected']==data['uniqueSources']==corpus['rows'] and len(data['pages'])==corpus['pages']
     assert len(data['publicationSeconds'])==len(data['allGroupMetricSweepSeconds'])==len(data['completionWallSeconds'])==corpus['pages']
     entry['canonicalAfter']=canonical(target/'memory.sqlite');assert entry['canonicalAfter']==original['canonical']
    observations.append(entry);journal.write(json.dumps(entry)+'\n');journal.flush();check()
    assert code==0 and not deadline and result.exists(),entry
    print(json.dumps({'trial':trial,'exitCode':code,'seconds':entry['commandSeconds']}),flush=True)
finally:journal.close()
assert len(observations)==protocol['observations']
for name in originals:
 for pair in range(protocol['pairsPerCorpus']):
  rows=[x for x in observations if x['corpus']==name and x['pair']==pair];assert len(rows)==2
  a,b=[json.loads((root/x['result']).read_text()) for x in rows]
  assert a['loadedSources']==b['loadedSources'] and a['metricChecksums']==b['metricChecksums'],(name,pair)
check()
result={'source':pins['source'],'protocolSHA256':pins['protocolSHA256'],'observations':len(observations),'pageObservations':sum(len(json.loads((root/x['result']).read_text())['pages']) for x in observations),'allOriginalsInputsAndFrozenEnginesUnchanged':True,'allCanonicalRowsAndMetricChecksumsVerified':True,'journalSHA256':sha(out/'observations.jsonl'),'scope':protocol['controls']};assert result['pageObservations']==protocol['pageObservations'];(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
