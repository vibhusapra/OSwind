from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime,re
base=Path(__file__).resolve().parent;r=base.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source='195b4ada122e08d0552af29fdc13e9894ce84efb'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=r)
q=json.loads((base/'qualification-review-v1.json').read_text());comparison=json.loads((base/'comparison-v1/review-v1.json').read_text());package=json.loads((base/'package-v1/package.json').read_text());pins=json.loads((base/'qualification-v1/inputs.json').read_text())
assert q['source']==comparison['source']==package['source']==source
for result in q['results'].values():assert result['methods']['passed']==546 and result['methods']['skipped']==17 and result['methods']['failed']==result['methods']['raceReports']==0
assert package['exitCode']==package['signature']['exitCode']==package['smoke']['exitCode']==package['packagedScopeControl']['exitCode']==0
assert len(package['files'])==34
assert package['developmentArchive']['allExtractedFilesAndModesMatch'] and package['developmentArchive']['signatureAfterRoundTripExitCode']==0
for item in pins['inputs']:assert sha(r/item['path'])==item['sha256']
for item in pins['comparators']+pins['protectedFrozen']:assert sha(Path(item['path']))==item['sha256']
for frozenBase in [base,r/'.artifacts/recording-scope-v1']:
 for manifestPath in sorted(frozenBase.glob('frozen-*.json')):
  for item in json.loads(manifestPath.read_text()):assert sha(frozenBase/item['path'])==item['sha256']
for corpus in pins['originalCorpora'].values():
 for item in corpus['files']:assert sha(r/item['path'])==item['sha256']
for item in json.loads((base/'package-v1/package-inputs.json').read_text()):assert sha(r/item['path'])==item['sha256']
for item in package['files']:assert sha(base/'package-v1/OSwind.app'/item['path'])==item['sha256']
assert sha(base/package['developmentArchive']['path'])==package['developmentArchive']['sha256']
protected=[]
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','assets','benchmarks','docs/features.json','docs/desktop-memory-landscape-2026-11-03.html'],cwd=r,text=True).splitlines()
for path in paths:protected.append({'path':path,'sha256':sha(r/path)})
(base/'publication-protected-inputs.json').write_text(json.dumps(protected,indent=2)+'\n')
section=(base/'performance-section-draft.md').read_text().replace('__QUALIFICATION__','Current selected optimized and Thread Sanitizer runs each have **563 defined / 546 passed / 17 skipped / 0 failures**, with no race report. They include actual owned APFS retained-page detach, original Keychain/all-13-kind sync, recording scope/backup/restore/erasure/privacy, large indexed Metal retrieval and app-worker lifecycle checks. The 17 skips are nine child entry helpers, three explicit scale opt-ins, two exact prior32-binary opt-ins, two renderer opt-ins and this owned performance fixture. The performance method separately passed in every one of the 32 comparison processes. New blocked-grouping tests verify off-main execution, a changed privacy policy refusing publication, and actual AppSession departure waiting for grouping before store close. All inputs, actual test engines and prior frozen controls remained unchanged.').replace('__PACKAGE__','A fresh normal release development app passed strict deep ad-hoc signature verification, an owned empty-library smoke, and the actual packaged-CLI recording-scope control. All 34 signed app files and modes matched after ZIP extraction, with signature verification passing again. Its normal compiler product excludes `-enable-testing` and is kept separate from both optimized test engines and the earlier 7ab package. No notarization or current live activation is claimed.')
assert '__QUALIFICATION__' not in section and '__PACKAGE__' not in section
(base/'published-doc-section-v1.md').write_text(section)
# Explicit allowlist: preserve raw logs, measurements, drivers and manifests;
# no library databases, media, model weights, credentials or executable engines.
files=set()
for pattern in ['*.json','*.py']:
 files.update(p for p in base.glob(pattern) if not p.name.startswith('publish-result'))
files.add(base/'published-doc-section-v1.md')
for folder in ['development-v1','development-v2','candidate-development-v1','comparison-v1','qualification-v1','package-v1']:
 for pattern in ['*.json','*.py','*.log','*.jsonl','*.stdout','*.stderr']:
  files.update((base/folder).glob(pattern))
for folder in ['development-v1/source','candidate-development-v1/source','source-snapshots-v1']:
 files.update(p for p in (base/folder).rglob('*') if p.is_file())
files.update((base/'trials').glob('*/result.json'))
for folder in ['qualification-v1/optimized-cli','qualification-v1/tsan-cli','package-v1/package-cli-control']:
 for pattern in ['*.stdout','*.stderr']:files.update((base/folder).glob(pattern))
assert len(list((base/'trials').glob('*/result.json')))==34
raw=r/'benchmarks/recording-view-performance-raw-v1.zip';assert not raw.exists()
manifest=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
with zipfile.ZipFile(raw,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for item in manifest:z.write(base/item['path'],item['path'])
 z.writestr('raw-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(raw) as z:
 assert set(z.namelist())==set(x['path'] for x in manifest)|{'raw-manifest.json'}
 for item in manifest:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
summary=json.loads((base/'comparison-v1/summary.json').read_text())
receipt={'schema':'oswind.recording-view-performance.v1','runtimeSource':source,'benchmarkDefinition':json.loads((base/'baseline-definition.json').read_text()),'candidateDefinition':json.loads((base/'candidate-definition.json').read_text()),'comparisonProtocol':json.loads((base/'protocol-v1.json').read_text()),'comparison':json.loads((base/'comparison-v1/result.json').read_text()),'comparisonReview':comparison,'timings':summary,'qualification':q,'development':{folder:json.loads((base/folder/'result.json').read_text()) for folder in ['development-v1','development-v2','candidate-development-v1']},'package':package,'raw':{'path':str(raw.relative_to(r)),'bytes':raw.stat().st_size,'sha256':sha(raw),'members':len(manifest)+1,'manifestMembers':len(manifest),'allExtractedBytesVerified':True,'excluded':'All executable engines, original/copied library databases, media, weights and credentials. Actual engine hashes and source snapshots included; binaries remain in the ignored local artifact root.'},'historicalFilesProtected':len(protected),'ci':'Existing recorded-meeting class selector includes both new grouping methods without a workflow edit. Owned benchmark runs only with its explicit copied-corpus environment. No hosted-native success or whole-current-suite qualification is inferred.','remaining':['incoming-change recording UI handling and coherent pagination','F042 recording names and durable reviewed calendar occurrence links','native keyboard/VoiceOver/record/import/open/playback','physical speech and multi-device quality','energy, thermals, actual current automatic24h','earlier owner/peer failed broad gates','full feature parity and comparative ranking'],'scope':'Single-machine authored warm-cache component measurements with an older manual capture soak active; all 32 processes/656 pages and outliers retained. No GUI-frame/vsync/input-latency, OS-cold, speech, power, current automatic24h, physical multi-device or top-three/parity claim. Source/hash/test evidence is separate from interactive acceptance.','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
destination=r/'benchmarks/recording-view-performance-v1.json';assert not destination.exists();destination.write_text(json.dumps(receipt,indent=2)+'\n')
wip=r/'docs/RECORDED-MEETINGS-WIP.md';wip.write_text(wip.read_text().rstrip()+'\n\n'+section)
p=r/'docs/PROGRESS.md';old=p.read_text();lead='# OSwind delivery ledger\n';assert old.startswith(lead)
entry='''
## 2026-11-03 — recording archive work moved off the main thread

Source `195b4ad` moves merging/group preparation into the owned worker and caches immutable recording metrics. Eight counterbalanced pairs per authored corpus passed: **32 separate processes / 656 page measurements**, identical source IDs/canonical rows/metric totals, original corpora and actual frozen engines unchanged. On 20k clips, pooled median publication fell **52.742 → 0.757 ms** and page completion **67.250 → 50.417 ms**. Long-import overall completion stayed essentially unchanged; all outliers remain visible. Current selected optimized and Thread Sanitizer runs each have **563 defined / 546 passed / 17 explicit skips / 0 failures**, with no race report. A fresh normal development package, actual packaged-CLI scope control and exact ZIP/signature round trip pass. These are component/software results, without frame-rate, power, full-current-suite, physical/automatic24h, parity or ranking promotion. Incoming UI updates, names/calendar links and other v0 gates remain open. [Details/TODOs](RECORDED-MEETINGS-WIP.md#recording-archive-publication-performance) · [Receipt](../benchmarks/recording-view-performance-v1.json) · [Raw evidence](../benchmarks/recording-view-performance-raw-v1.zip).
'''
p.write_text(lead+entry+old[len(lead):])
for item in protected:assert sha(r/item['path'])==item['sha256']
subprocess.run(['git','diff','--check'],cwd=r,check=True)
result={'source':source,'raw':receipt['raw'],'historicalFilesUnchanged':len(protected),'reportSHA256':sha(r/'docs/desktop-memory-landscape-2026-11-03.html'),'featureLedgerSHA256':sha(r/'docs/features.json'),'qualificationSourceInputsVerifiedBeforeMetadata':len(pins['inputs']),'onlyTrackedMutations':['docs/PROGRESS.md','docs/RECORDED-MEETINGS-WIP.md','benchmarks/recording-view-performance-v1.json','benchmarks/recording-view-performance-raw-v1.zip']}
(base/'publish-result-v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
