from pathlib import Path
import json,subprocess,hashlib,time
out=Path(__file__).resolve().parent;root=out.parent;r=root.parents[1];pins=json.loads((out/'inputs.json').read_text());command=['swift','test','-c','release','--jobs','4','--filter','RecordedMeetingTests|RecordedMeetingIdentifierTests|RecordedMeetingPortabilityTests|RecordedMeetingsModelTests'];start=time.monotonic()
with (out/'test.log').open('xb') as log:result=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT)
for item in pins['inputs']:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest()==item['sha256']
for item in json.loads((root/'frozen-baseline-v1.json').read_text()):assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256']
record={'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start,'inputsAndFrozenBaselineUnchanged':True,'logSHA256':hashlib.sha256((out/'test.log').read_bytes()).hexdigest()};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/'test.log').read_text()[-5000:]);raise SystemExit(result.returncode)
