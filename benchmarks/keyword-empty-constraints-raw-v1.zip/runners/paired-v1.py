from pathlib import Path
import datetime,hashlib,json,math,os,platform,random,shutil,sqlite3,statistics,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';OUT=BASE/'paired-v1/run-v1';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((BASE/'paired-plan-v1.json').read_text());qual=BASE/'qualification-v1';inputs=json.loads((qual/'inputs.json').read_text());stages=json.loads((qual/'effective-results-v2.json').read_text())['stages']
assert len(stages)==7 and all(s['exit']==0 for s in stages)
assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
source=BASE/'paired-v1/authored-source';assert json.loads((source/'fixture.json').read_text())['format']=='OSwind owned feasibility archive v1'
for suffix in ['-wal','-journal']:
    p=source/('memory.sqlite'+suffix);assert not p.exists() or p.stat().st_size==0
binaries={'baseline':ROOT/plan['baselinePackage']/'Contents/MacOS/oswindctl','candidate':ROOT/plan['candidatePackage']/'Contents/MacOS/oswindctl'};binaryPins={k:sha(p) for k,p in binaries.items()}
assert len(set(binaryPins.values()))==2
assert binaryPins['baseline']==json.loads((ROOT/'benchmarks/local-answer-preparation-v1.json').read_text())['newPackage']['files']['Contents/MacOS/oswindctl']
report={'format':'OSwind paired empty-constraint actual CLI observations v1','state':'running','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'planSHA256':sha(BASE/'paired-plan-v1.json'),'runnerSHA256':sha(__file__),'qualificationInputSHA256':sha(qual/'inputs.json'),'binarySHA256':binaryPins,'scope':plan['scope'],'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine(),'logicalCPUs':os.cpu_count(),'activityBefore':list(os.getloadavg()),'backgroundControlled':False},'records':[]}
def save(): (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def source_data(library):
    c=sqlite3.connect((library/'memory.sqlite').as_uri()+'?mode=ro',uri=True)
    try:
        assert c.execute('PRAGMA user_version').fetchone()==(33,)
        data=c.execute('SELECT id,app,title,text,timestamp,payload FROM memories ORDER BY id').fetchall();assert len(data)==48000
        digest=hashlib.sha256();truth={}
        for identifier,app,title,text,stamp,payload in data:
            n=int(identifier.removeprefix('profile-'));assert identifier==f'profile-{n:05}' and 0<=n<48000
            assert app==('Admitted group' if n>=47958 else 'Authored desktop')
            assert title==('Nebula review '*4 if n<300 else 'Generated note')
            starts=['Nebula review greenlit.','Nebula preliminary review postponed.','Nebulous reviewers archive.','Archive review completed.','Nebula roadmap blocked.','Unrelated cedar orchard.']
            assert text==starts[n%6]+f' Authored entry {n}. '+('context '*((n//6)%7)) and stamp==978307200+700000000+n
            decoded=json.loads(payload);assert decoded['id']==identifier and decoded['text']==text and decoded['app']==app and decoded['title']==title and decoded['timestamp']==700000000+n
            truth[identifier]={'app':app,'title':title,'text':text,'id':identifier}
            digest.update(json.dumps([identifier,app,title,text,stamp],separators=(',',':')).encode()+b'\0'+payload+b'\0')
        return digest.hexdigest(),truth
    finally:c.close()
def signature(result):
    value={k:v for k,v in result.items() if k!='duration'}
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def check(result,case,truth):
    ids=[]
    for hit in result['hits']:
        m=hit['memory'];identifier=m['id'];n=int(identifier.removeprefix('profile-'))
        assert identifier in truth and all(m[k]==truth[identifier][k] for k in ('id','app','title','text'))
        assert hit['match']=='keyword' and math.isfinite(hit['score']) and hit['score']>0
        if case in ('required-broad','nested-or'):assert n<300 or n%6==0
        if case=='required-rare':assert n==47994
        if case=='boolean-exclusion':assert (n<300 or n%6 in (0,1)) and n%6!=4
        if case=='metadata-after-ranked-decoys':assert n>=47958 and n%6==0
        ids.append(identifier)
    assert len(ids)==len(set(ids))
    expected={'required-rare':1,'metadata-after-ranked-decoys':7,'absent-phrase':0}.get(case,100)
    assert len(ids)==expected
    assert type(result['duration']) in (int,float) and math.isfinite(result['duration']) and result['duration']>=0
    return ids
try:
    save();sourceSHA,truth=source_data(source);report['sourceRowsSHA256']=sourceSHA;report['sourceDatabaseSHA256']=sha(source/'memory.sqlite')
    for profile in binaries:
        library=OUT/profile;library.mkdir(mode=0o700);shutil.copyfile(source/'memory.sqlite',library/'memory.sqlite');shutil.copyfile(source/'settings.json',library/'settings.json');assert source_data(library)[0]==sourceSHA
    settingsSHA=sha(source/'settings.json');report['settingsSHA256']=settingsSHA
    env={k:v for k,v in os.environ.items() if not k.startswith(('OSWIND_','OPENAI_','ANTHROPIC_'))}
    def run(profile,case,query,flags,round):
        index=len(report['records']);out=OUT/f'{index:03}.stdout.json';err=OUT/f'{index:03}.stderr';argv=[str(binaries[profile]),'--data',str(OUT/profile),'search','--details','--mode','keyword','--limit','100',*flags,query]
        assert sha(binaries[profile])==binaryPins[profile]
        begin=time.perf_counter()
        with out.open('xb') as o,err.open('xb') as e:p=subprocess.run(argv,env=env,cwd=ROOT,stdout=o,stderr=e,timeout=90)
        elapsed=(time.perf_counter()-begin)*1000
        record={'profile':profile,'case':case,'round':round,'warmup':round==-1,'returncode':p.returncode,'wallMS':elapsed,'stdout':out.name,'stdoutSHA256':sha(out),'stderr':err.name,'stderrSHA256':sha(err)};report['records'].append(record);save()
        assert p.returncode==0,err.read_text()[-1000:]
        value=json.loads(out.read_text());record.update(searchMS=value['duration']*1000,orderedIDs=check(value,case,truth),signature=signature(value));assert record['searchMS']<=elapsed+10;save();return record
    rng=random.Random(731158);reference={}
    for iteration in [-1,*range(7)]:
        cases=plan['cases'].copy();rng.shuffle(cases)
        for index,(label,query,flags) in enumerate(cases):
            order=['baseline','candidate'] if (iteration+index)%2==0 else ['candidate','baseline']
            pair={p:run(p,label,query,flags,iteration) for p in order};assert pair['baseline']['signature']==pair['candidate']['signature'],label
            if label in reference:assert pair['baseline']['signature']==reference[label]
            else:reference[label]=pair['baseline']['signature']
        print('paired round',iteration,'complete',flush=True)
    after={p:source_data(OUT/p)[0] for p in binaries};assert set(after.values())=={sourceSHA}
    assert all(sha(OUT/p/'settings.json')==settingsSHA for p in binaries) and sha(source/'memory.sqlite')==report['sourceDatabaseSHA256']
    assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items()) and all(sha(p)==binaryPins[k] for k,p in binaries.items())
    summary={}
    for label,_,_ in plan['cases']:
        summary[label]={}
        for p in binaries:
            records=[r for r in report['records'] if r['case']==label and r['profile']==p and not r['warmup']]
            summary[label][p]={metric:{'observations':len(records),'medianMS':statistics.median([r[metric] for r in records]),'p95MS':max(r[metric] for r in records)} for metric in ('wallMS','searchMS')}
    report.update(state='completed',summary=summary,sourceRowsSHA256After=after,allOrderedResultSignaturesEqual=True,settingsUnchanged=True,hostActivityAfter=list(os.getloadavg()),finishedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(json.dumps({'state':'completed','measuredProcesses':98,'warmups':14,'summary':summary}))
except BaseException as e:report.update(state='failed',errorType=type(e).__name__,error=str(e)[:1000]);save();raise
