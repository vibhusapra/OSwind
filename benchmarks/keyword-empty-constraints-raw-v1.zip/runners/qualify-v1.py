from pathlib import Path
import hashlib,json,os,platform,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';OUT=BASE/'qualification-v1';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b9355f77dd00132ec7810c6d714ac5a39424d2f7'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines()
extra=['scripts/setup-models.sh','scripts/test-setup-models.py','.github/workflows/ci.yml']
pins={p:sha(ROOT/p) for p in sorted(set(paths+extra)) if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved',*extra]) and (ROOT/p).is_file()}
prior=json.loads((ROOT/'.artifacts/local-answer-context-v1/qualification-v1/inputs.json').read_text())['inputFiles']
assert len(pins)==712 and sum(pins[p]==h for p,h in prior.items())==709
changed=sorted(p for p in pins if p not in prior or pins[p]!=prior[p]);assert changed==['Sources/OSwindCore/MemoryStore.swift','Sources/OSwindCore/SearchExpression.swift','Tests/OSwindCoreTests/SearchExpressionFeasibilityTests.swift']
manifest={'format':'OSwind keyword empty-constraint qualification inputs v1','baseSource':'b9355f77dd00132ec7810c6d714ac5a39424d2f7','inputFiles':pins,'changedInputs':changed,'unchangedPriorInputs':709,'componentObservation':{'reportSHA256':sha(BASE/'run-v1/report.json'),'reviewSHA256':sha(BASE/'run-v1/reviewed-v1.json')},'scope':'Same-snapshot necessary expression feasibility using content+speaker indexes; complete before-LIMIT predicates/rank/ties remain. No cross-search cache, query-format/schema/generation change. Eight new ordinary behavior/cancellation methods and one opt-in create-only actual MemoryStore fixture seed. Original successful component/profile/model/capture evidence remains frozen.'}
(OUT/'inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
focused='SearchExpression|KeywordConstraint|KeywordRanking|FullTextIdentity|SearchScope|SearchPreview|Speaker|SemanticIndex|PrivacyAndIntegration|LibraryOpening|SearchIndexLifecycle|SourceWorkSession|LibraryWipe|Erasure|Retention'
seedEnv={'OSWIND_TEST_FEASIBILITY_FIXTURE':'1','OSWIND_TEST_FEASIBILITY_DESTINATION':str(BASE/'paired-v1/authored-source')}
(BASE/'paired-v1').mkdir(mode=0o700,exist_ok=False)
stages=[('debug-build-tests',['swift','build','--build-tests'],{}),('full-debug',['swift','test','--skip-build'],{}),('affected-tsan',['swift','test','--sanitize=thread','--filter',focused],{}),('affected-optimized',['swift','test','-c','release','--filter',focused],{}),('authored-seed-optimized',['swift','test','-c','release','--skip-build','--filter','SearchExpressionScaleFixtureTests'],seedEnv),('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(OUT/'OSwind.app')})]
result={'inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(__file__),'host':{'macOS':platform.mac_ver()[0],'architecture':platform.machine()},'stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,command,environment in stages:
    assert all(sha(ROOT/p)==h for p,h in pins.items())
    print('START',name,flush=True);begin=time.monotonic();log=OUT/(name+'.log')
    with log.open('xb') as f:code=subprocess.run(command,env=env|environment,stdout=f,stderr=subprocess.STDOUT).returncode
    result['stages'].append({'name':name,'command':command,'environment':environment,'exit':code,'wallSeconds':time.monotonic()-begin,'log':str(log.relative_to(ROOT)),'sha256':sha(log)})
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH',name,code,flush=True)
    assert all(sha(ROOT/p)==h for p,h in pins.items())
    if code:raise SystemExit(code)
print('QUALIFICATION_COMPLETE',flush=True)
