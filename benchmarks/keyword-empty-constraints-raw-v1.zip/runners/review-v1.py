from pathlib import Path
import copy, hashlib, json, math, re, sqlite3, statistics
ROOT=Path.cwd(); BASE=ROOT/'.artifacts/native-keyword-profile-v1'; OUT=BASE/'run-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((BASE/'plan-v1.json').read_text());report=json.loads((OUT/'report.json').read_text());queries=json.loads((OUT/'queries.json').read_text())
assert not (OUT/'reviewed-v1.json').exists()
# Read source facts, SQL outputs and raw metrics; do not rerun the successful profile.
assert report['state']=='completed' and report['sqliteVersion']=='3.51.0' and report['sqliteLibrary']=='/usr/lib/libsqlite3.dylib'
assert report['planSHA256']==sha(BASE/'plan-v1.json') and report['harnessSHA256']==sha(BASE/'profile-v1.py')
assert all(sha(ROOT/p)==h for p,h in report['sourcePins'].items())
assert report['databaseSHA256Before']==report['databaseSHA256After']==sha(OUT/'authored-native.sqlite')
assert report['sourceFilesUnchanged'] is True and report['unchangedDatabase'] is True
assert report['databaseBytes']==(OUT/'authored-native.sqlite').stat().st_size<64*1024*1024
assert len(queries)==30 and {(q['case'],q['profile']) for q in queries}=={(c,p) for c in plan['cases'] for p in plan['profiles']}
con=sqlite3.connect((OUT/'authored-native.sqlite').as_uri()+'?immutable=1',uri=True)
source={}
try:
    rows=con.execute('SELECT id,app,title,text,payload FROM memories ORDER BY id').fetchall();assert len(rows)==48000
    for n,(identifier,app,title,text,payload) in enumerate(rows):
        assert identifier==f'profile-{n:05}' and app==('Admitted group' if n>=47958 else 'Authored desktop')
        assert title==('Nebula review '*4 if n<300 else 'Generated note')
        starts=['Nebula review greenlit.','Nebula preliminary review postponed.','Nebulous reviewers archive.','Archive review completed.','Nebula roadmap blocked.','Unrelated cedar orchard.']
        assert text==starts[n%6]+f' Authored entry {n}. '+('context '*((n//6)%7))
        value=json.loads(payload)
        assert value=={'id':identifier,'kind':'note','app':app,'title':title,'text':text,'timestamp':700000000+n,'favorite':False,'tags':[],'regions':[],'bundleID':''}
        source[identifier]=(n,payload)
    assert con.execute('SELECT COUNT(*) FROM memory_fts_keys k JOIN memory_fts f ON f.rowid=k.key JOIN memories m ON m.id=k.memory_id WHERE f.id=m.id AND f.title=m.title AND f.app=m.app AND f.text=m.text').fetchone()==(48000,)
    assert con.execute('SELECT COUNT(*) FROM speaker_fts').fetchone()==(0,)
finally:con.close()
# Independent generated-case membership math, not the harness phrase tokenizer.
eligible={}
for case in plan['cases']:
    values=set()
    for identifier,(n,_) in source.items():
        if case=='soft-broad':accept=n<300 or n%6 in (0,1,2,3,4)
        elif case=='required-broad':accept=n<300 or n%6==0
        elif case=='required-rare':accept=n==47994
        elif case=='boolean-exclusion':accept=(n<300 or n%6 in (0,1)) and n%6!=4
        elif case=='metadata-after-ranked-decoys':accept=n>=47958 and n%6==0
        else:accept=False
        if accept:values.add(identifier)
    eligible[case]=values
outputs={}
for q in queries:
    case,profile=q['case'],q['profile']; path=OUT/f'{case}-{profile}.json';raw=json.loads(path.read_text())
    ids=[json.loads(r[0])['id'] if profile.endswith('-payload') else r[0] for r in raw]
    assert len(ids)==len(set(ids)) and set(ids)<=set(source)
    if profile not in ('ranked-ids','ranked-canonical-join'):
        assert set(ids)<=eligible[case] and len(ids)==min(100,len(eligible[case]))
    if profile.endswith('-payload'):assert all(r[0]==source[i][1] for i,r in zip(ids,raw))
    outputs[(case,profile)]={'ids':ids,'sha':sha(path)}
for case in plan['cases']:
    assert outputs[(case,'ranked-ids')]['ids']==outputs[(case,'ranked-canonical-join')]['ids']
    assert outputs[(case,'ranked-constraints')]['ids']==outputs[(case,'ranked-constraints-payload')]['ids']
    assert report['truth'][case]['eligible']==len(eligible[case])
assert len(eligible['metadata-after-ranked-decoys'])==7
assert not set(outputs[('metadata-after-ranked-decoys','ranked-ids')]['ids'])&eligible['metadata-after-ranked-decoys']
assert report['metadataBeforeLimitControl']=={'eligible':7,'firstUnconstrainedLimitEligible':0}

def validate_record(m):
    key=(m['case'],m['profile']);assert key in outputs
    assert type(m['round'])==int and -1<=m['round']<9 and type(m['warmup'])==bool and m['warmup']==(m['round']==-1)
    assert type(m['wallMS']) in (int,float) and math.isfinite(m['wallMS']) and m['wallMS']>=0
    assert m['rows']==len(outputs[key]['ids']) and m['typedOutputSHA256']==outputs[key]['sha']
    assert set(m['counters'])=={'fullscan','sort','autoindex','vm','runs','statementHeapBytes'}
    assert all(type(n)==int and n>=0 for n in m['counters'].values())
    assert m['counters']['runs']==1 and m['counters']['vm']>0

records=report['measurements'];assert len(records)==300
assert {(m['case'],m['profile'],m['round']) for m in records}=={(c,p,r) for c in plan['cases'] for p in plan['profiles'] for r in range(-1,9)}
for m in records:validate_record(m)
for case in plan['cases']:
    for profile in plan['profiles']:
        values=[m['wallMS'] for m in records if m['case']==case and m['profile']==profile and not m['warmup']]
        assert report['summary'][case][profile]=={'observations':9,'medianMS':statistics.median(values),'p95MS':sorted(values)[-1]}
controls=report['speakerControls'];assert [c['name'] for c in controls]==['speaker-only-phrase','body-and-speaker','split-speaker-atoms']
assert [c['actual'] for c in controls]==[['speaker-only','split-body-speaker'],['split-body-speaker'],['gap-body','speaker-only','split-body-speaker','split-labels']]
assert all(c['expected']==c['actual'] for c in controls)
# Invalid retained-record rejection controls, no native query or timing repetition.
mutations=[('nan-time',lambda m:m.update(wallMS=float('nan'))),('negative-time',lambda m:m.update(wallMS=-1)),('wrong-output-digest',lambda m:m.update(typedOutputSHA256='0'*64)),('wrong-count',lambda m:m.update(rows=m['rows']+1)),('wrong-round',lambda m:m.update(round=9)),('wrong-warmup',lambda m:m.update(warmup=not m['warmup'])),('wrong-native-runs',lambda m:m['counters'].update(runs=2)),('negative-counter',lambda m:m['counters'].update(vm=-1))]
rejected=[]
for name,mutate in mutations:
    record=copy.deepcopy(records[0]);mutate(record)
    try:validate_record(record)
    except AssertionError:rejected.append(name)
    else:raise AssertionError('Altered record accepted: '+name)
result={'state':'reviewed','scope':'Independent source/payload membership and raw-record review by Codex; no native query/timing repetition, no independent human audit or shipping performance acceptance. Minimal reconstructed component schema; no Swift hydration/startup or product equivalence claim.','reportSHA256':sha(OUT/'report.json'),'planSHA256':sha(BASE/'plan-v1.json'),'harnessSHA256':sha(BASE/'profile-v1.py'),'reviewerSHA256':sha(__file__),'queriesSHA256':sha(OUT/'queries.json'),'databaseSHA256':sha(OUT/'authored-native.sqlite'),'rowsVerified':48000,'measurements':270,'excludedWarmups':30,'beforeLimitEligibleOutsideInitial100':7,'speakerControlNames':[c['name'] for c in controls],'alteredRecordsRejected':rejected,'summary':report['summary']}
with (OUT/'reviewed-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'state':'reviewed','rows':48000,'measurements':270,'warmups':30,'alteredRecordControls':len(rejected),'reviewSHA256':sha(OUT/'reviewed-v1.json')}))
