from pathlib import Path
import hashlib,json,os,subprocess,zipfile
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';QUAL=BASE/'qualification-v1';PAIR=BASE/'paired-v1/run-v1';COMP=BASE/'run-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((QUAL/'inputs.json').read_text());review=json.loads((QUAL/'reviewed-v1.json').read_text());pair=json.loads((PAIR/'reviewed-v1.json').read_text());component=json.loads((COMP/'reviewed-v1.json').read_text());base=inputs['baseSource']
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==base
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['changedInputs'])
for path,h in inputs['inputFiles'].items():
    p=ROOT/path; b=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();assert hashlib.sha256(b).hexdigest()==h
    assert subprocess.check_output(['git','rev-parse',source+':'+path],text=True).strip()==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
assert review['reviewerSHA256']==sha(BASE/'review-qualification-v1.py') and review['inputManifestSHA256']==sha(QUAL/'inputs.json')
assert pair['reviewerSHA256']==sha(BASE/'review-paired-v1.py') and pair['qualifiedReviewSHA256']==sha(QUAL/'reviewed-v1.json')
assert pair['measuredProcesses']==98 and pair['excludedWarmups']==14 and pair['all112OrderedSignaturesEqualWithinCase'] is True
assert component['reviewerSHA256']==sha(BASE/'review-v1.py') and component['measurements']==270 and len(component['alteredRecordsRejected'])==8
assert sha(COMP/'reviewed-v1.json')=='a8246ab717b0139677401a4b165f3384804cf17ef15cf41f06ce9e25d65053e7'
files={}
for name in ['plan-v1.json','profile-v1.py','review-v1.py','qualify-v1.py','review-qualification-v1.py','paired-plan-v1.json','paired-v1.py','review-paired-v1.py','prior-publications-v1.json','development-v1.log','controller-v1.log','qualification-controller-v1.log','paired-controller-v1.log','publish-v1.py']:
    files['runners/'+name]=BASE/name
for name in ['resume-release-v2.py','continuation-controller-v2.log','preserve-debug-module-cache-v1.py','inactive-debug-caches-reclamation-v1.json','reclaim-inactive-module-caches-v2.py','inactive-module-caches-reclamation-v2.json','cache-preservation-failure-note-v1.json']:
    files['build-continuation/'+name]=BASE/name
for p in (BASE/'qualification-continuation-v2').iterdir():
    if p.is_file() and p.suffix in ('.json','.log'):files['build-continuation/'+p.name]=p
for name in ['report.json','reviewed-v1.json','queries.json']:
    files['component/'+name]=COMP/name
for p in COMP.glob('*.json'):files['component/'+p.name]=p
for p in QUAL.iterdir():
    if p.is_file() and p.suffix in ('.json','.log'):files['qualification/'+p.name]=p
for p in PAIR.iterdir():
    if p.is_file() and p.suffix in ('.json','.stderr'):files['paired/'+p.name]=p
for p,h in pair['files'].items():assert sha(PAIR/p)==h;files['paired/'+p]=PAIR/p
payload={name:p.read_bytes() for name,p in files.items()}
for path in inputs['changedInputs']:payload['source/'+path]=(ROOT/path).read_bytes()
for path,h in json.loads((COMP/'report.json').read_text())['sourcePins'].items():
    data=subprocess.check_output(['git','show',base+':'+path]);assert hashlib.sha256(data).hexdigest()==h;payload['component/source/'+path]=data
protected=json.loads((BASE/'prior-publications-v1.json').read_text());assert len(protected)==496 and all(sha(ROOT/p)==h for p,h in protected.items())
assert sha(ROOT/'docs/features.json')=='0d47186450d9fdcae6cd9248afd5fe6af6d02dcea974a45d6fb238426b0bcbfa'
payload['README.txt']=(f'OSwind keyword necessary-constraint feasibility runtime {source}.\n'
    '712 committed inputs,709 prior inputs unchanged;3 source/test files.8 new ordinary behavior methods plus1 gated owned48k MemoryStore seed. '
    'Full row-level constraints remain before LIMIT; ranking/ties, source data, schemas and generation unchanged. '
    'Global absence checks use both content and speaker FTS inside the same snapshot, with per-search atom deduplication. AND/OR propagate only necessary conditions; negation always remains possible. '
    'Missing globally required operands return empty without archive-wide candidate rejection. Possible atoms on different rows still need complete predicates.\n'
    'A new minimal native48k component fixture retained270 timing samples/30 warmups, all SQL plans/results and eight altered-record checks. '
    'The component profile precedes the implementation; it is not the shipping API, Swift hydration or startup, and its different SQL timings are not additive. '
    'The separate actual MemoryStore seeded48k paired CLI workload retains98 measured processes/14 warmups; every ordered result signature, complete returned source and score matches within each case across both binaries, with only duration excluded. '
    'Seven new cases include positive/negative phrases, Boolean exclusion, metadata beyond unconstrained top100 and possible OR branches. '
    'Same-host caches/background/owned capture soak uncontrolled; seven measurements per cell. No competitor, cold-start, general latency, power or product ranking claim. '
    'No successful earlier benchmark repeated. No database, executable, key, model weight or user history in this archive. '
    'Full sync, physical capture/energy, production DP-Keychain, Developer ID/notary, fullv0 and topthree remain open; all83 feature statuses unchanged.\n').encode()
archive=ROOT/'benchmarks/keyword-empty-constraints-raw-v1.zip';manifest=ROOT/'benchmarks/keyword-empty-constraints-inputs-v1.json';receipt=ROOT/'benchmarks/keyword-empty-constraints-v1.json';assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x') as f:json.dump(inputs|{'sourceCommit':source},f,indent=2);f.write('\n')
result={'format':'OSwind keyword empty-constraint qualification v1','sourceCommit':source,'baseSource':base,'allCommittedInputBlobsMatch':True,'qualification':review,'component':component,'paired':pair,'publishedInputs':{'file':manifest.name,'sha256':sha(manifest)},'reviewsSHA256':{'qualification':sha(QUAL/'reviewed-v1.json'),'component':sha(COMP/'reviewed-v1.json'),'paired':sha(PAIR/'reviewed-v1.json')},'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{name:hashlib.sha256(data).hexdigest() for name,data in payload.items()}},'publisherSHA256':sha(__file__),'priorBenchmarkFilesUnchanged':protected}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'source':source,'archiveSHA256':sha(archive),'archiveBytes':archive.stat().st_size,'members':len(payload),'priorBenchmarkFilesUnchanged':496}))
