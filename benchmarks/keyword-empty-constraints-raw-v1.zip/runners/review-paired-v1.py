from pathlib import Path
import copy,hashlib,json,math,sqlite3,statistics
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';OUT=BASE/'paired-v1/run-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (OUT/'reviewed-v1.json').exists()
plan=json.loads((BASE/'paired-plan-v1.json').read_text());report=json.loads((OUT/'report.json').read_text());qual=json.loads((BASE/'qualification-v1/reviewed-v1.json').read_text())
assert report['state']=='completed' and report['allOrderedResultSignaturesEqual'] is True and report['settingsUnchanged'] is True
assert report['planSHA256']==sha(BASE/'paired-plan-v1.json') and report['runnerSHA256']==sha(BASE/'paired-v1.py')
assert report['qualificationInputSHA256']==sha(BASE/'qualification-v1/inputs.json')==qual['inputManifestSHA256']
for label,p in [('baseline',plan['baselinePackage']),('candidate',plan['candidatePackage'])]:assert report['binarySHA256'][label]==sha(ROOT/p/'Contents/MacOS/oswindctl')
assert report['binarySHA256']['candidate']==qual['package']['files']['Contents/MacOS/oswindctl']
assert len(set(report['binarySHA256'].values()))==2
source=BASE/'paired-v1/authored-source';assert sha(source/'memory.sqlite')==report['sourceDatabaseSHA256']
assert all(sha(p/'settings.json')==report['settingsSHA256'] for p in (source,OUT/'baseline',OUT/'candidate'))
def rows(path):
    c=sqlite3.connect((path/'memory.sqlite').as_uri()+'?mode=ro',uri=True)
    try:return c.execute('SELECT id,app,title,text,timestamp,payload FROM memories ORDER BY id').fetchall()
    finally:c.close()
original=rows(source);assert len(original)==48000 and original==rows(OUT/'baseline')==rows(OUT/'candidate')
truth={r[0]:r for r in original};assert len(truth)==48000
for n,r in enumerate(original):assert r[0]==f'profile-{n:05}' and r[4]==1678307200+n
cases={x[0] for x in plan['cases']}
def validate_answer(value,case):
    assert isinstance(value['hits'],list);ids=[]
    for hit in value['hits']:
        memory=hit['memory'];identifier=memory['id'];assert identifier in truth
        r=truth[identifier];n=int(identifier[8:])
        assert [memory[k] for k in ('id','app','title','text')]==list(r[:4])
        assert hit['match']=='keyword' and type(hit['score']) in (int,float) and math.isfinite(hit['score']) and hit['score']>0
        if case in ('required-broad','nested-or'):assert n<300 or n%6==0
        if case=='required-rare':assert n==47994
        if case=='boolean-exclusion':assert (n<300 or n%6 in (0,1)) and n%6!=4
        if case=='metadata-after-ranked-decoys':assert n>=47958 and n%6==0
        if case=='soft-broad':assert n<300 or n%6!=5
        ids.append(identifier)
    assert len(ids)==len(set(ids)) and len(ids)=={'required-rare':1,'metadata-after-ranked-decoys':7,'absent-phrase':0}.get(case,100)
    duration=value['duration'];assert type(duration) in (int,float) and math.isfinite(duration) and duration>=0
    signature=hashlib.sha256(json.dumps({k:v for k,v in value.items() if k!='duration'},sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return ids,signature,duration*1000
records=report['records'];assert len(records)==112
assert {(m['profile'],m['case'],m['round']) for m in records}=={(p,c,r) for p in ('baseline','candidate') for c in cases for r in range(-1,7)}
files={};decoded={}
for m in records:
    assert m['returncode']==0 and m['warmup']==(m['round']==-1) and type(m['wallMS']) in (int,float) and math.isfinite(m['wallMS']) and m['wallMS']>=0
    for field in ('stdout','stderr'):
        p=OUT/m[field];assert p.parent==OUT and sha(p)==m[field+'SHA256'];files[p.name]=sha(p)
    value=json.loads((OUT/m['stdout']).read_text());ids,signature,duration=validate_answer(value,m['case'])
    assert ids==m['orderedIDs'] and signature==m['signature'] and duration==m['searchMS'] and duration<=m['wallMS']+10
    decoded[(m['profile'],m['case'],m['round'])]=value
for case in cases:
    signatures={m['signature'] for m in records if m['case']==case};assert len(signatures)==1
    for profile in ('baseline','candidate'):
        subset=[m for m in records if m['profile']==profile and m['case']==case and not m['warmup']];assert len(subset)==7
        for metric in ('wallMS','searchMS'):
            v=[m[metric] for m in subset];assert report['summary'][case][profile][metric]=={'observations':7,'medianMS':statistics.median(v),'p95MS':max(v)}
# Actual source content, constraint presence, counts and metric refusal controls.
base=decoded[('candidate','required-broad',0)]
def mutate_first(value,field,entry):value['hits'][0]['memory'][field]=entry
alterations=[('unknown-source','required-broad',base,lambda x:mutate_first(x,'id','foreign-source')),('wrong-source-text','required-broad',base,lambda x:mutate_first(x,'text','forged text')),('missing-result','required-broad',base,lambda x:x['hits'].pop()),('duplicate-result','required-broad',base,lambda x:x['hits'].__setitem__(1,copy.deepcopy(x['hits'][0]))),('wrong-phrase','required-broad',base,lambda x:x['hits'][0].update(memory=json.loads(truth['profile-00301'][-1]))),('nan-duration','required-broad',base,lambda x:x.update(duration=float('nan'))),('negative-score','required-broad',base,lambda x:x['hits'][0].update(score=-1))]
rejected=[]
for name,case,original,mutate in alterations:
    value=copy.deepcopy(original);mutate(value)
    try:validate_answer(value,case)
    except (AssertionError,KeyError,ValueError):rejected.append(name)
    else:raise AssertionError('Altered answer accepted '+name)
result={'format':'OSwind paired empty-constraint CLI review v1','state':'reviewed','reportSHA256':sha(OUT/'report.json'),'reviewerSHA256':sha(__file__),'runnerSHA256':sha(BASE/'paired-v1.py'),'planSHA256':sha(BASE/'paired-plan-v1.json'),'qualifiedReviewSHA256':sha(BASE/'qualification-v1/reviewed-v1.json'),'sourceDatabaseSHA256':report['sourceDatabaseSHA256'],'binarySHA256':report['binarySHA256'],'measuredProcesses':98,'excludedWarmups':14,'all112OrderedSignaturesEqualWithinCase':True,'physicalSourceRowsIdenticalInBothCopies':48000,'settingsUnchanged':True,'alteredAnswersRejected':rejected,'files':files,'summary':report['summary'],'scope':plan['scope'],'reviewScope':'Codex raw file/metric/case-membership/physical-source review; no query/process repetition and no independent human accuracy audit.'}
with (OUT/'reviewed-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'state':'reviewed','measured':98,'warmups':14,'alteredAnswers':len(rejected),'reviewSHA256':sha(OUT/'reviewed-v1.json'),'summary':report['summary']}))
