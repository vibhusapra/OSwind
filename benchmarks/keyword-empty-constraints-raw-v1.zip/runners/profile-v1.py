from pathlib import Path
import ctypes as C, datetime, hashlib, json, math, os, platform, random, re, statistics, struct, subprocess, time

ROOT=Path.cwd(); BASE=ROOT/'.artifacts/native-keyword-profile-v1'; OUT=BASE/'run-v1'; OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((BASE/'plan-v1.json').read_text()); assert plan['rows']==48000 and plan['repetitions']==9
pins={str(p):sha(ROOT/p) for p in ['Sources/OSwindCore/MemoryStore.swift','Sources/OSwindCore/SearchExpression.swift','Sources/OSwindCore/FullTextIdentitySchema.swift']}
lib=C.CDLL('/usr/lib/libsqlite3.dylib'); P=C.c_void_p; I=C.c_int; T=C.c_char_p

def api(name,args,result=I):
    fn=getattr(lib,name); fn.argtypes=args; fn.restype=result; return fn
version=api('sqlite3_libversion',[],T)
opening=api('sqlite3_open_v2',[T,C.POINTER(P),I,T]); closing=api('sqlite3_close',[P]); error=api('sqlite3_errmsg',[P],T)
preparing=api('sqlite3_prepare_v2',[P,T,I,C.POINTER(P),C.POINTER(T)]); finalizing=api('sqlite3_finalize',[P]); stepping=api('sqlite3_step',[P])
bindtext=api('sqlite3_bind_text',[P,I,T,I,P]); bindint=api('sqlite3_bind_int64',[P,I,C.c_int64]); columncount=api('sqlite3_column_count',[P]); columntype=api('sqlite3_column_type',[P,I]); columnbytes=api('sqlite3_column_bytes',[P,I]); columnblob=api('sqlite3_column_blob',[P,I],P); counter=api('sqlite3_stmt_status',[P,I,I]); readonly=api('sqlite3_db_readonly',[P,T])

class DB:
    def __init__(self,path,immutable=False):
        self.handle=P(); target=path.as_uri()+'?immutable=1' if immutable else str(path)
        assert opening(target.encode(),C.byref(self.handle),1|64 if immutable else 2|4,None)==0
        assert readonly(self.handle,b'main')==int(immutable)
    def close(self):
        assert closing(self.handle)==0
    def execute(self,sql,args=()):
        begin=time.perf_counter_ns(); statement=P(); tail=T()
        assert preparing(self.handle,sql.encode(),-1,C.byref(statement),C.byref(tail))==0,error(self.handle)
        assert not tail.value or not tail.value.strip(),tail.value
        try:
            for index,value in enumerate(args,1):
                code=bindint(statement,index,value) if type(value)==int else bindtext(statement,index,value.encode(),-1,P(-1))
                assert code==0
            rows=[]
            while True:
                code=stepping(statement)
                if code==101:break
                assert code==100,error(self.handle)
                row=[]
                for col in range(columncount(statement)):
                    kind=columntype(statement,col); n=columnbytes(statement,col); ptr=columnblob(statement,col)
                    row.append(None if kind==5 else C.string_at(ptr,n).decode())
                rows.append(row)
            elapsed=(time.perf_counter_ns()-begin)/1e6
            counts={label:counter(statement,n,0) for label,n in [('fullscan',1),('sort',2),('autoindex',3),('vm',4),('runs',6),('statementHeapBytes',99)]}
            return rows,elapsed,counts
        finally:assert finalizing(statement)==0

report={'format':'OSwind new native keyword component observations v1','state':'running','source':plan['source'],'runtimeSource':plan['runtimeSource'],'harnessSHA256':sha(__file__),'planSHA256':sha(BASE/'plan-v1.json'),'sourcePins':pins,'sqliteLibrary':'/usr/lib/libsqlite3.dylib','sqliteVersion':version().decode(),'scope':plan['scope'],'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'measurements':[]}
def save(): (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def activity():return {'loadAverage':list(os.getloadavg()),'logicalCPUs':os.cpu_count(),'controlled':False}
def tokens(s):return re.findall(r'[a-z0-9]+',s.lower())
def atom(row,text,phrase):
    wanted=tokens(text)
    def match(s):
        values=tokens(s)
        return any(values[i:i+len(wanted)]==wanted for i in range(len(values)-len(wanted)+1)) if phrase else any(x.startswith(wanted[0]) for x in values)
    return any(match(row[k]) for k in ['title','app','text']) or any(match(x) for x in row['speakers'])
def fixture():
    rows=[]
    texts=['Nebula review greenlit.','Nebula preliminary review postponed.','Nebulous reviewers archive.','Archive review completed.','Nebula roadmap blocked.','Unrelated cedar orchard.']
    for n in range(plan['rows']):
        group=n%6; identifier=f'profile-{n:05}'
        text=texts[group]+f' Authored entry {n}. '+('context '*((n//6)%7))
        row={'id':identifier,'app':'Admitted group' if n>=plan['rows']-42 else 'Authored desktop','title':('Nebula review '*4 if n<300 else 'Generated note'),'text':text,'speakers':[]}
        row['payload']=json.dumps({'id':identifier,'kind':'note','app':row['app'],'title':row['title'],'text':text,'timestamp':700000000+n,'favorite':False,'tags':[],'regions':[],'bundleID':''},sort_keys=True,separators=(',',':'))
        rows.append(row)
    return rows

try:
    save(); assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==plan['source']
    sourceRows=fixture(); originals={r['id']:r for r in sourceRows}
    database=OUT/'authored-native.sqlite'; db=DB(database)
    schemas=["CREATE TABLE memories(id TEXT PRIMARY KEY,app TEXT NOT NULL,title TEXT NOT NULL,text TEXT NOT NULL,payload BLOB NOT NULL)","CREATE TABLE memory_fts_keys(key INTEGER PRIMARY KEY,memory_id TEXT UNIQUE NOT NULL)","CREATE VIRTUAL TABLE memory_fts USING fts5(id UNINDEXED,title,app,text,tokenize='unicode61 remove_diacritics 2')","CREATE VIRTUAL TABLE speaker_fts USING fts5(memory_id UNINDEXED,label,tokenize='unicode61 remove_diacritics 2')","CREATE INDEX memories_app ON memories(app)"]
    try:
        for sql in schemas:db.execute(sql)
        db.execute('BEGIN IMMEDIATE')
        for n,r in enumerate(sourceRows,1):
            db.execute('INSERT INTO memories VALUES(?,?,?,?,?)',[r[k] for k in ['id','app','title','text','payload']])
            db.execute('INSERT INTO memory_fts_keys VALUES(?,?)',[n,r['id']])
            db.execute('INSERT INTO memory_fts(rowid,id,title,app,text) VALUES(?,?,?,?,?)',[n,*[r[k] for k in ['id','title','app','text']]])
        db.execute('COMMIT')
        assert db.execute('PRAGMA quick_check')[0]==[['ok']]
        db.execute("INSERT INTO memory_fts(memory_fts,rank) VALUES('integrity-check',1)")
    finally:db.close()
    before=sha(database); report.update(databaseSHA256Before=before,databaseBytes=database.stat().st_size,fixtureRows=len(sourceRows),schemas=schemas,host={'macOS':platform.mac_ver()[0],'architecture':platform.machine()},activityBefore=activity()); save()
    db=DB(database,True)
    def pred(text,phrase=True):
        operand='"'+text+'"'+('' if phrase else '*')
        return "(EXISTS(SELECT 1 FROM memory_fts WHERE rowid=(SELECT key FROM memory_fts_keys WHERE memory_id=m.id) AND memory_fts MATCH ?) OR m.id IN (SELECT memory_id FROM speaker_fts WHERE speaker_fts MATCH ?))",[operand,operand]
    broad='("nebula"* OR "review"*) OR ("Nebula review")'
    ph,pv=pred('Nebula review'); ne,nv=pred('nebula',False); reSQL,rv=pred('review',False); bl,bv=pred('blocked',False)
    cases=[('soft-broad','"nebula"* OR "review"*','1=1',[],lambda r:True),('required-broad',broad,ph,pv,lambda r:atom(r,'Nebula review',True)),('required-rare','("47994"*) OR ("47994")',*pred('47994'),lambda r:atom(r,'47994',True)),('boolean-exclusion','"nebula"* OR "review"*',f'({ne} AND {reSQL} AND NOT ({bl}))',nv+rv+bv,lambda r:atom(r,'nebula',False) and atom(r,'review',False) and not atom(r,'blocked',False)),('metadata-after-ranked-decoys',broad,'m.app=? AND '+ph,['Admitted group']+pv,lambda r:r['app']=='Admitted group' and atom(r,'Nebula review',True)),('absent-phrase','("nebula"* OR "review"*) OR ("never offered")',*pred('never offered'),lambda r:atom(r,'never offered',True))]
    queries=[]; truths={}; outputRows={}
    for name,fts,predicate,values,oracle in cases:
        truth={r['id'] for r in sourceRows if oracle(r)};truths[name]=truth
        matches={r[0] for r in db.execute('SELECT id FROM memory_fts WHERE memory_fts MATCH ?',[fts])[0]}
        truth &= matches
        base=" FROM memory_fts f JOIN memories m ON m.id=f.id WHERE memory_fts MATCH ? AND f.rank MATCH 'bm25(0,3,1,1)'"
        items=[('ranked-ids',"SELECT f.id FROM memory_fts f WHERE memory_fts MATCH ? AND f.rank MATCH 'bm25(0,3,1,1)' ORDER BY f.rank LIMIT ?",[fts,plan['limit']]),('ranked-canonical-join','SELECT m.id'+base+' ORDER BY f.rank LIMIT ?',[fts,plan['limit']]),('ranked-constraints','SELECT m.id'+base+' AND '+predicate+' ORDER BY f.rank LIMIT ?',[fts,*values,plan['limit']]),('ranked-constraints-payload','SELECT m.payload'+base+' AND '+predicate+' ORDER BY f.rank LIMIT ?',[fts,*values,plan['limit']]),('unranked-constraints','SELECT m.id'+base+' AND '+predicate+' ORDER BY f.rowid LIMIT ?',[fts,*values,plan['limit']])]
        for profile,sql,args in items:
            queries.append({'case':name,'profile':profile,'sql':sql,'arguments':args,'plan':db.execute('EXPLAIN QUERY PLAN '+sql,args)[0]})
        report.setdefault('truth',{})[name]={'ftsMatched':len(matches),'eligible':len(truth),'eligibleIDSHA256':hashlib.sha256('\n'.join(sorted(truth)).encode()).hexdigest()}
    (OUT/'queries.json').write_text(json.dumps(queries,indent=2)+'\n')
    rng=random.Random(plan['seed']); rounds=[-1,*range(plan['repetitions'])]
    for iteration in rounds:
        order=queries.copy();rng.shuffle(order)
        for q in order:
            raw,ms,counts=db.execute(q['sql'],q['arguments']); isPayload=q['profile'].endswith('-payload')
            ids=[json.loads(r[0])['id'] if isPayload else r[0] for r in raw]
            assert len(ids)==len(set(ids)) and len(ids)<=plan['limit']
            if q['profile'] not in ['ranked-ids','ranked-canonical-join']:
                assert set(ids)<=truths[q['case']] and len(ids)==min(plan['limit'],report['truth'][q['case']]['eligible'])
            if isPayload:assert all(r[0]==originals[i]['payload'] for i,r in zip(ids,raw))
            key=q['case']+'/'+q['profile']; typed=json.dumps(raw,separators=(',',':')).encode(); digest=hashlib.sha256(typed).hexdigest()
            if iteration==-1:outputRows[key]=ids;(OUT/(q['case']+'-'+q['profile']+'.json')).write_bytes(typed)
            else:assert ids==outputRows[key] and digest==sha(OUT/(q['case']+'-'+q['profile']+'.json'))
            report['measurements'].append({'case':q['case'],'profile':q['profile'],'round':iteration,'warmup':iteration==-1,'wallMS':ms,'rows':len(ids),'typedOutputSHA256':digest,'counters':counts})
        save(); print('round',iteration,'complete',flush=True)
    for name,*_ in cases:
        assert outputRows[name+'/ranked-ids']==outputRows[name+'/ranked-canonical-join']
        assert outputRows[name+'/ranked-constraints']==outputRows[name+'/ranked-constraints-payload']
    late=outputRows['metadata-after-ranked-decoys/ranked-constraints']; top=outputRows['metadata-after-ranked-decoys/ranked-ids']
    assert late and not set(late)&set(top),'Metadata gate must actually exercise beyond-LIMIT sources'
    report['metadataBeforeLimitControl']={'eligible':len(late),'firstUnconstrainedLimitEligible':len(set(late)&set(top))}
    db.close(); assert sha(database)==before
    # Separate tiny native controls: no timing aggregation and no workload mutation.
    controls=OUT/'speaker-controls.sqlite'; c=DB(controls)
    try:
        for sql in schemas:c.execute(sql)
        entries=[('speaker-only','unrelated',['Maya Chen']),('split-body-speaker','archive',['Maya Chen']),('split-labels','unrelated',['Maya','Chen']),('gap-body','Maya owns Chen archive',[])]
        for n,(identifier,text,labels) in enumerate(entries,1):
            c.execute('INSERT INTO memories VALUES(?,?,?,?,?)',[identifier,'Control','Control',text,'{}']);c.execute('INSERT INTO memory_fts_keys VALUES(?,?)',[n,identifier]);c.execute('INSERT INTO memory_fts(rowid,id,title,app,text) VALUES(?,?,?,?,?)',[n,identifier,'Control','Control',text])
            for label in labels:c.execute('INSERT INTO speaker_fts VALUES(?,?)',[identifier,label])
        checks=[]
        for label,terms,expected in [('speaker-only-phrase',[('Maya Chen',True)],['speaker-only','split-body-speaker']),('body-and-speaker',[('archive',False),('Maya Chen',True)],['split-body-speaker']),('split-speaker-atoms',[('Maya',False),('Chen',False)],['gap-body','speaker-only','split-body-speaker','split-labels'])]:
            predicates=[pred(*term) for term in terms]; sql='SELECT m.id FROM memories m WHERE '+' AND '.join(x[0] for x in predicates)+' ORDER BY m.id'; args=sum((x[1] for x in predicates),[])
            actual=[r[0] for r in c.execute(sql,args)[0]];assert actual==expected,(label,actual)
            checks.append({'name':label,'sql':sql,'arguments':args,'expected':expected,'actual':actual})
        report['speakerControls']=checks
    finally:c.close()
    report['summary']={}
    for q in queries:
        values=[m['wallMS'] for m in report['measurements'] if m['case']==q['case'] and m['profile']==q['profile'] and not m['warmup']]
        report['summary'].setdefault(q['case'],{})[q['profile']]={'observations':len(values),'medianMS':statistics.median(values),'p95MS':sorted(values)[math.ceil(.95*len(values))-1]}
    assert all(sha(ROOT/p)==h for p,h in pins.items())
    assert len(report['measurements'])==300
    report.update(state='completed',databaseSHA256After=sha(database),unchangedDatabase=True,activityAfter=activity(),sourceFilesUnchanged=True,finishedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    print(json.dumps({'state':report['state'],'samples':300,'summary':report['summary'],'databaseBytes':report['databaseBytes']}))
except BaseException as e:
    report.update(state='failed',errorType=type(e).__name__,error=str(e)[:1500]);save();raise
