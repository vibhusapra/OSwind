from pathlib import Path
import hashlib,json,math,re,subprocess
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';OUT=BASE/'qualification-v1';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((OUT/'inputs.json').read_text());results=json.loads((OUT/'effective-results-v2.json').read_text());assert not (OUT/'reviewed-v1.json').exists()
assert len(inputs['inputFiles'])==712 and all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
assert results['inputManifestSHA256']==sha(OUT/'inputs.json') and results['runnerSHA256']==sha(BASE/'qualify-v1.py')
continuation=json.loads((BASE/'qualification-continuation-v2/results.json').read_text())
originalResults=json.loads((OUT/'results.json').read_text())
assert len(originalResults['stages'])==6 and all(s['exit']==0 for s in originalResults['stages'][:5]) and originalResults['stages'][5]['exit']==1
assert originalResults['stages'][5]['name']=='release-build' and 'No space left on device' in (ROOT/originalResults['stages'][5]['log']).read_text()
assert results['stages'][:5]==originalResults['stages'][:5]==continuation['adoptedSuccessfulStages']
assert results['stages'][5:]==continuation['stages'] and len(continuation['stages'])==2
assert continuation['originalResultsSHA256']==sha(OUT/'results.json') and continuation['runnerSHA256']==sha(BASE/'resume-release-v2.py')
assert results['continuation']['resultsSHA256']==sha(BASE/'qualification-continuation-v2/results.json')
assert continuation['failedReleaseLogSHA256']==sha(ROOT/originalResults['stages'][5]['log'])==originalResults['stages'][5]['sha256']

prior=json.loads((ROOT/'.artifacts/local-answer-context-v1/qualification-v1/inputs.json').read_text())['inputFiles'];assert len(prior)==711 and sum(inputs['inputFiles'][p]==h for p,h in prior.items())==709
pattern=re.compile(r"Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)")
def cases(text):
    found=[(a+'.'+b,status) for a,b,status in pattern.findall(text)];assert len(found)==len(set(k for k,v in found));return dict(found)
old=cases((ROOT/'.artifacts/local-answer-context-v1/qualification-v1/full-debug.log').read_text());assert len(old)==2774
source=(ROOT/'Tests/OSwindCoreTests/SearchExpressionFeasibilityTests.swift').read_text()
methods=re.findall(r'func (test\w+)\(',source);assert len(methods)==len(set(methods))==9
seed='OSwindCoreTests.SearchExpressionScaleFixtureTests.testCreateExplicitlyOwnedFeasibilityArchive'
new={('OSwindCoreTests.SearchExpressionScaleFixtureTests.' if m=='testCreateExplicitlyOwnedFeasibilityArchive' else 'OSwindCoreTests.SearchExpressionFeasibilityTests.')+m:('skipped' if m=='testCreateExplicitlyOwnedFeasibilityArchive' else 'passed') for m in methods}
assert not set(new)&set(old);full=old|new
assert len(full)==2783 and list(full.values()).count('passed')==2619 and list(full.values()).count('skipped')==164
focused='SearchExpression|KeywordConstraint|KeywordRanking|FullTextIdentity|SearchScope|SearchPreview|Speaker|SemanticIndex|PrivacyAndIntegration|LibraryOpening|SearchIndexLifecycle|SourceWorkSession|LibraryWipe|Erasure|Retention'
selected={k:v for k,v in full.items() if re.search(focused,k)}
def inspect(text,expected):
    found=cases(text);assert found==expected
    counts={s:list(found.values()).count(s) for s in ('passed','failed','skipped')};assert counts['failed']==0
    noun='test' if len(found)==1 else 'tests'
    skipped='' if counts['skipped']==0 else f", with {counts['skipped']} "+('test' if counts['skipped']==1 else 'tests')+' skipped and'
    summary=f"Executed {len(found)} {noun}{skipped if skipped else ', with'} 0 failures"
    assert summary in text and not any(x in text for x in ('WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['))
    return {'defined':len(found),**counts,'skippedIdentities':sorted(k for k,v in found.items() if v=='skipped')}
expectedNames=['debug-build-tests','full-debug','affected-tsan','affected-optimized','authored-seed-optimized','release-build','package'];assert len(results['stages'])==7
reports=[]
for stage,name in zip(results['stages'],expectedNames):
    assert stage['name']==name and stage['exit']==0 and sha(ROOT/stage['log'])==stage['sha256']
    assert math.isfinite(stage['wallSeconds']) and stage['wallSeconds']>=0
    if name in ('full-debug','affected-tsan','affected-optimized','authored-seed-optimized'):
        expected=full if name=='full-debug' else {seed:'passed'} if name=='authored-seed-optimized' else selected
        reports.append({'name':name,**inspect((ROOT/stage['log']).read_text(),expected),'logSHA256':stage['sha256'],'wallSeconds':stage['wallSeconds']})
text=(OUT/'affected-tsan.log').read_text();method=next(k for k,v in new.items() if v=='passed').rsplit('.',1)[1];line=next(l for l in text.splitlines() if method in l and "' passed" in l)
faults={}
for label,bad in {'missing-method':text.replace(line,'',1),'duplicate-method':text+'\n'+line,'failed-method':text.replace(line,line.replace("' passed","' failed"),1),'wrong-identity':text.replace(method,'testAlteredIdentity'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,selected)
    except (AssertionError,KeyError):faults[label]='rejected'
    else:raise AssertionError('Altered log accepted '+label)
package=OUT/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()}
previous=json.loads((ROOT/'benchmarks/local-answer-preparation-v1.json').read_text())['newPackage']['files']
assert {p:h for p,h in files.items() if p.startswith('Contents/Resources/')}=={p:h for p,h in previous.items() if p.startswith('Contents/Resources/')}
assert files['Contents/Info.plist']==previous['Contents/Info.plist']
sign=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True);assert sign.returncode==0
result={'format':'OSwind keyword empty-constraint qualification review v1','inputManifestSHA256':sha(OUT/'inputs.json'),'runnerSHA256':sha(BASE/'qualify-v1.py'),'reviewerSHA256':sha(__file__),'retainedDiskFullContinuation':results['continuation'],'inputCount':712,'unchangedPriorInputs':709,'newMethodIdentities':new,'stages':reports,'alteredLogControls':faults,'package':{'files':files,'strictAdHocSignatureExit':0,'allPriorResourcesAndInfoUnchanged':True},'scope':inputs['scope'],'limitations':'Software qualification and owned authored fixture only. Native component/profile and paired product timing are distinct evidence. No energy, capture/GUI, physical sync, production DP-Keychain/Developer ID/notary/full-v0/top-three qualification.'}
with (OUT/'reviewed-v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'state':'reviewed','inputs':712,'newMethods':9,'stages':[ {k:v for k,v in r.items() if k not in ('skippedIdentities',)} for r in reports],'reviewSHA256':sha(OUT/'reviewed-v1.json')}))
