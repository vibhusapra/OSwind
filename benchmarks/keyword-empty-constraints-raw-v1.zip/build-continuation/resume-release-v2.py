from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path.cwd();BASE=ROOT/'.artifacts/native-keyword-profile-v1';QUAL=BASE/'qualification-v1';OUT=BASE/'qualification-continuation-v2';OUT.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((QUAL/'inputs.json').read_text());original=json.loads((QUAL/'results.json').read_text())
assert len(original['stages'])==6 and all(s['exit']==0 for s in original['stages'][:5]) and original['stages'][5]['name']=='release-build' and original['stages'][5]['exit']==1
failed=ROOT/original['stages'][5]['log'];assert sha(failed)==original['stages'][5]['sha256'] and 'No space left on device' in failed.read_text()
assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
assert not (QUAL/'OSwind.app').exists()
result={'inputManifestSHA256':sha(QUAL/'inputs.json'),'runnerSHA256':sha(__file__),'originalResultsSHA256':sha(QUAL/'results.json'),'failedReleaseLogSHA256':sha(failed),'adoptedSuccessfulStages':original['stages'][:5],'scope':'Resume only the disk-full failed normal release build and previously unstarted package at unchanged712inputs. Successful Debug/TSan/optimized/owned48k seed stages never repeated. Original failed stage/log retained. Inactive generated compiler caches reclaimed with scope/hash receipts; source/runtime binaries/benchmark evidence/models preserved.','stages':[]}
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,command,environment in [('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(QUAL/'OSwind.app')})]:
 assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items());print('START',name,flush=True);start=time.monotonic();log=OUT/(name+'.log')
 with log.open('xb') as f:code=subprocess.run(command,env=env|environment,stdout=f,stderr=subprocess.STDOUT).returncode
 stage={'name':name,'command':command,'environment':environment,'exit':code,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(ROOT)),'sha256':sha(log)};result['stages'].append(stage);(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH',name,code,flush=True)
 assert all(sha(ROOT/p)==h for p,h in inputs['inputFiles'].items())
 if code:raise SystemExit(code)
effective=original|{'stages':original['stages'][:5]+result['stages'],'continuation':{'results':str((OUT/'results.json').relative_to(ROOT)),'resultsSHA256':sha(OUT/'results.json'),'runnerSHA256':sha(__file__),'originalResultsSHA256':sha(QUAL/'results.json'),'retainedFailedReleaseLogSHA256':sha(failed)}}
with (QUAL/'effective-results-v2.json').open('x') as f:json.dump(effective,f,indent=2);f.write('\n')
print('CONTINUATION_COMPLETE',flush=True)
