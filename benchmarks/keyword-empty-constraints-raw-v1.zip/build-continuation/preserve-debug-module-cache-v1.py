from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,zipfile
root=Path.cwd();base=root/'.artifacts/native-keyword-profile-v1';source=root/'.build/arm64-apple-macosx/debug/ModuleCache';archive=base/'inactive-debug-module-cache-v1.zip';receipt=base/'inactive-debug-module-cache-v1.json'
assert source.is_dir() and not source.is_symlink() and not archive.exists() and not receipt.exists()
assert '/debug/ModuleCache' not in (root/'.build/arm64-apple-macosx/release/description.json').read_text()
files={str(p.relative_to(source)):p for p in source.rglob('*') if p.is_file()};assert files and all(not p.is_symlink() for p in source.rglob('*'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={n:{'sha256':sha(p),'mode':p.stat().st_mode&0o777,'bytes':p.stat().st_size} for n,p in files.items()}
freeBefore=shutil.disk_usage(root).free
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(files) and set(z.namelist())==set(files)
    for n,p in files.items():
        assert sha(p)==pins[n]['sha256'] and hashlib.sha256(z.read(n)).hexdigest()==pins[n]['sha256']
        assert (z.getinfo(n).external_attr>>16)&0o777==pins[n]['mode']
record={'state':'preserved-before-removal','source':str(source),'archive':str(archive),'archiveSHA256':sha(archive),'archiveBytes':archive.stat().st_size,'originalBytes':sum(p['bytes'] for p in pins.values()),'files':pins,'scope':'Inactive Debug compiler module cache only. Current runner is building release with a separate ModuleCache path. Full Debug and TSan tests already finished. No source/test executable/package/weights/benchmark evidence removed; byte and file-mode verified ZIP permits restoration. Not product cleanup/performance evidence.','freeBytesBefore':freeBefore}
with receipt.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
shutil.rmtree(source);record.update(state='preserved-and-removed-inactive-cache',freeBytesAfter=shutil.disk_usage(root).free);receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('state','originalBytes','archiveBytes','freeBytesBefore','freeBytesAfter')}))
