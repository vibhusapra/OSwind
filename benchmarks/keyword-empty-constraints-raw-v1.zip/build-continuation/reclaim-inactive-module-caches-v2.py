from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
root=Path.cwd();base=root/'.artifacts/native-keyword-profile-v1';receipt=base/'inactive-module-caches-reclamation-v2.json';assert not receipt.exists()
procs=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
assert not any(Path(line.strip().split(None,1)[1]).name in ['swift-frontend','swiftc','clang','swift-build','ld'] for line in procs.splitlines() if len(line.strip().split(None,1))==2),'A compiler became active'
paths=[Path('/Users/vibhusapra/.codex/worktrees')/work/'oswind/.build/arm64-apple-macosx'/profile/'ModuleCache' for work in ['sync-enrollment','sync-late-dependencies'] for profile in ['debug','release']]
report={'state':'inspected-before-reclamation','observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeBefore':shutil.disk_usage(root).free,'scope':'Only generated compiler ModuleCache directories in two older OSwind worktrees; no active compiler observed immediately before operation. Source/test/build executables, qualified packages, original frozen36 engine, model weights and all benchmark artifacts preserved. Cache files regenerate on a future compile; no claim that cache bytes are an artifact needing runtime qualification. No build/test/benchmark rerun.','directories':{}}
for path in paths:
 assert path.is_dir() and not path.is_symlink() and path.name=='ModuleCache' and '.build' in path.parts
 assert all(not p.is_symlink() for p in path.rglob('*'))
 files={}
 for p in path.rglob('*'):
  if p.is_file():
   with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
   files[str(p.relative_to(path))]={'sha256':h,'bytes':p.stat().st_size}
 report['directories'][str(path)]={'files':files,'bytes':sum(v['bytes'] for v in files.values()),'removed':False}
 receipt.write_text(json.dumps(report,indent=2)+'\n')
 shutil.rmtree(path);report['directories'][str(path)]['removed']=True
 receipt.write_text(json.dumps(report,indent=2)+'\n')
report.update(state='reclaimed-inactive-module-caches',freeAfter=shutil.disk_usage(root).free);receipt.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'state':report['state'],'freeBefore':report['freeBefore'],'freeAfter':report['freeAfter'],'removedBytes':sum(d['bytes'] for d in report['directories'].values())}))
