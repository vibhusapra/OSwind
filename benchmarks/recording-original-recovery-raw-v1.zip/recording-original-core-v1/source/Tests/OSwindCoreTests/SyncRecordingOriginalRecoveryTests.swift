import XCTest
import CSQLite
@testable import OSwindCore

extension SyncOutgoingTests {
    private func retainRecordingOriginal(_ record:SyncPortableRecord)throws->HistoricalEvidence {
        try store.withRoutineDatabase {db in
            try store.historicalCatalog(db).adopt(record.reference,cache:cache,pathsFor:{_,_ in [:]},admit:{_ in},verifyMedia:{_,_,_ in})
        }
    }
    private func loseOnlyRecordingWireCache(_ reference:SyncVersionReference)throws {
        try store.withRoutineDatabase {db in
            let row=try db.statement("DELETE FROM personal_sync_versions WHERE object_digest=? AND content_sha=?");defer {sqlite3_finalize(row)}
            db.bind(row,1,try reference.identity.key.digest);db.bind(row,2,reference.content.sha256);try db.done(row)
            XCTAssertEqual(sqlite3_changes(db.handle),1,"The owned fault removes exactly the replaceable body, not canonical history or affiliation")
        }
    }
    func testRecordingNameRecoversOnlyItsExactRetainedOriginalAfterWireCacheLoss()throws {
        let (audio,caption)=try namedClip();try install();_=try finish()
        let original=try recordingPacket(audio.id),retained=try retainRecordingOriginal(original),reference=try original.reference
        try store.setFavorite(audio.id,value:true);_=try finish()
        XCTAssertNotEqual(try recordingPacket(audio.id).reference,reference)
        try loseOnlyRecordingWireCache(reference);XCTAssertNil(try cache.record(reference,admit:{_ in}))
        XCTAssertEqual(try store.withRoutineDatabase {try store.historicalCatalog($0).read(retained.handle,sourceID:audio.id,verifyMedia:{_,_,_ in}).record},original)
        XCTAssertEqual(try store.withRoutineDatabase {try RecordingAffiliationStore.read($0,id:caption.id)?.reference},reference)
        let source=try XCTUnwrap(store.recordedMeetingPage().sources.first),expected=try XCTUnwrap(store.recordedMeetingDetails(for:source).first)
        _=try store.saveRecordedMeetingName("Renamed with retained original",for:source,replacing:expected);_=try finish()
        guard case .source(let body)=try recordingPacket(caption.id).body else {return XCTFail("Missing recording metadata")}
        XCTAssertEqual(body.recordingDetails?.scope.source,reference,"Recover the known exact original, never select a newer equivalent audio wire version")
        XCTAssertEqual(try cache.record(reference,admit:{_ in}),original,"The exact recovered body must be available to the outgoing dependency graph")
        XCTAssertEqual(try store.get(audio.id)?.favorite,true)
    }
    func testRecordingNativeTranscriptEditDoesNotRecoverPurgedHistoricalOriginal()throws {
        var (audio,caption)=try namedClip();try install();_=try finish()
        let original=try recordingPacket(audio.id),retained=try retainRecordingOriginal(original)
        audio.text="Authored replacement after deliberate native transcript edit";try store.insert(audio);_=try finish()
        XCTAssertThrowsError(try store.withRoutineDatabase {try store.historicalCatalog($0).read(retained.handle,sourceID:audio.id,verifyMedia:{_,_,_ in})})
        XCTAssertNil(try cache.record(original.reference,admit:{_ in}))
        try store.setFavorite(caption.id,value:true);_=try finish()
        guard case .source(let body)=try recordingPacket(caption.id).body else {return XCTFail("Missing recording metadata")}
        XCTAssertEqual(body.recordingDetails?.scope.selector,.unavailable)
        XCTAssertNil(try cache.record(original.reference,admit:{_ in}),"Recovery must never recreate privacy-purged speech from a label or hash")
    }
}
