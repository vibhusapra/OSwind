from pathlib import Path
import json,hashlib,subprocess,time,shutil,os
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];pins=json.loads((out/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']
check();command=['swift','build','-c','release','--build-tests','--jobs','2'];start=time.monotonic();env=os.environ.copy();env.pop('DYLD_INSERT_LIBRARIES',None)
with (out/'build.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
process={'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start,'testExecution':False};(out/'process-result.json').write_text(json.dumps(process,indent=2)+'\n')
check();result={**process,'inputsAndProtectedFilesUnchanged':True,'logSHA256':sha(out/'build.log'),'scope':'Actual optimized build only; execution qualification separate.'}
if p.returncode==0:
 products=r/'.build/arm64-apple-macosx/release';frozen=out/'actual-engine';frozen.mkdir();shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
 manifest=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()];(out/'actual-engine.json').write_text(json.dumps(manifest,indent=2)+'\n');result['actualEngineFrozen']=True
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(p.returncode)
