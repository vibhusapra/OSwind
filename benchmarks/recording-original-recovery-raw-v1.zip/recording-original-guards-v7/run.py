from pathlib import Path
import json,hashlib,subprocess,time,re,shutil,os
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins=json.loads((out/'inputs.json').read_text())
def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']
check()
env=os.environ.copy();env.update({'OSWIND_RECORDING_ORIGINAL_QA_DIR':str(out/'outgoing-cases'),'OSWIND_TEST_INCOMING_SOURCE_ROOT':str(out/'incoming-cases')})
selection='SyncOutgoingTests.testRecordingOriginalRecovery|SyncOutgoingTests.testRecordingNameRecovers|SyncOutgoingTests.testRecordingNativeTranscript|SyncIncomingSourceTests.testRecordingOriginalRecovery|SyncOutgoingTests.testRecordingAffiliationScopeChangeAndNativeDeleteInvalidateItsLifetime|SyncOutgoingTests.testRecordingMetadataExplicitDifferentNativeTargetCannotReuseOldAffiliation'
command=['swift','test','--jobs','4','--filter',selection];start=time.monotonic()
with (out/'test.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
process={'sourceBase':pins['baseSource'],'command':command,'exitCode':p.returncode,'commandWallSeconds':time.monotonic()-start};(out/'process-result.json').write_text(json.dumps(process,indent=2)+'\n')
check();s=(out/'test.log').read_text();methods=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",s)
result={**process,'inputsAndPriorActualFilesUnchanged':True,'defined':len(methods),'counts':{v:sum(y==v for _,y,_ in methods) for v in ['passed','skipped','failed']},'logSHA256':sha(out/'test.log'),'actualEngineFrozen':False,'scope':'Authored cache-loss/rollback/authority controls plus two local typed journal endpoints and real authored PCM asset bytes. Runtime fixtures retained. No real capture, device enrollment, background service, provider or complete v0 acceptance.'}
if 'Build complete!' in s and methods:
 frozen=b/'frozen-recording-original-guards-v7';frozen.mkdir();products=r/'.build/arm64-apple-macosx/debug';shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
 manifest=[{'path':str(p.relative_to(b)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()]
 (b/'frozen-recording-original-guards-v7.json').write_text(json.dumps(manifest,indent=2)+'\n');result['actualEngineFrozen']=True
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print(s[-3000:]);raise SystemExit(p.returncode)
