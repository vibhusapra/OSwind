from pathlib import Path
import json,hashlib,subprocess,time,os,struct,plistlib,shutil,zipfile
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();pins=json.loads((out/'inputs.json').read_text());assert sourceCommit==pins['baseSource'];qualified=json.loads((b/'recording-original-qualification-v1/execution-inputs.json').read_text());prior=b/'recording-original-qualification-v1'
assert json.loads((out/'package-driver-exit-v1.json').read_text())['exitCode']==1
assert json.loads((out/'process-result.json').read_text())['exitCode']==0
products=json.loads((out/'actual-canonical-products.json').read_text())
def check():
 for row in pins['inputs']:assert sha(r/row['path'])==row['sha256'],row['path']
 for row in pins['protectedFrozen']:assert sha(Path(row['path']))==row['sha256'],row['path']
 for row in products:assert sha(out/'actual-canonical-products'/row['name'])==row['actualProductSHA256']
check();app=out/'OSwind.app';started=time.monotonic();record={'source':sourceCommit,'testInputBaseSource':qualified['baseSource'],'testInputManifestSHA256':sha(prior/'execution-inputs.json'),'command':['bash','scripts/build-app.sh','release'],'exitCode':0,'buildSubprocessExitCode':0,'originalPackageDriverExitCode':1,'repairDoesNotRebuildOrReplay':True,'earlierCrossBuildMismatch':products,'scope':'Canonical normal development build reused after correcting an overstrict cross-build comparison. Every packaged __text section is compared with the actual retained product of that SAME canonical build. Actual earlier prebuild, canonical products, original failed driver/app/input hashes preserved. Strict ad-hoc development package only; no notarization/physical/interactive/full-v0 claim.','app':str(app),'inputsAndAllPriorActualEnginesUnchanged':True,'buildLogSHA256':sha(out/'build.log')}

def code(p):
    data = p.read_bytes()
    assert struct.unpack_from('<I', data)[0] == 4277009103
    n = struct.unpack_from('<I', data, 16)[0]
    offset = 32
    for _ in range(n):
        cmd, size = struct.unpack_from('<II', data, offset)
        if cmd == 25:
            sections = struct.unpack_from('<I', data, offset + 64)[0]
            for i in range(sections):
                pos = offset + 72 + i * 80
                name = data[pos:pos + 16].split(b'\x00')[0]
                segment = data[pos + 16:pos + 32].split(b'\x00')[0]
                if name == b'__text' and segment == b'__TEXT':
                    length = struct.unpack_from('<Q', data, pos + 40)[0]
                    start = struct.unpack_from('<I', data, pos + 48)[0]
                    return {'bytes': length, 'sha256': hashlib.sha256(data[start:start + length]).hexdigest()}
        offset += size
    raise AssertionError('No executable text section')
files={}
for name in ['OSwind','oswindctl','oswind-preparation-guardian']:
 packaged=app/'Contents/MacOS'/name;original=out/'actual-canonical-products'/name;assert code(packaged)==code(original)
 files[name]={'packagedSHA256':sha(packaged),'unsignedBuildProductSHA256':sha(original),'textSection':code(packaged),'packagedBytes':packaged.stat().st_size}
record['executables']=files
with (out/'signature-verify.log').open('xb') as log:subprocess.run(['codesign','--verify','--deep','--strict',str(app)],check=True,stdout=log,stderr=subprocess.STDOUT)
info=plistlib.loads((app/'Contents/Info.plist').read_bytes());assert info['CFBundleIdentifier']=='com.oswind.desktop'
for key in ['NSCalendarsFullAccessUsageDescription','NSMicrophoneUsageDescription','NSScreenCaptureUsageDescription','NSAppleEventsUsageDescription']:assert info.get(key)
for name in ['NOTICES.txt','Apache-2.0.txt']:assert (app/'Contents/Resources/ThirdParty'/name).is_file()
cli=app/'Contents/MacOS/oswindctl';owned=out/'owned-cli-smoke';assert not owned.exists()
def invoke(label,args):
 start=time.monotonic();p=subprocess.run([str(cli),'--data',str(owned),*args],cwd=r,capture_output=True)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);(out/(label+'.result.json')).write_text(json.dumps({'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()},indent=2)+'\n');assert p.returncode==0,(label,p.returncode)
 return {'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()},p.stdout
record['smoke']={}
record['smoke']['emptyStats'],_=invoke('empty-stats',['stats'])
record['smoke']['authoredNote'],_=invoke('authored-note',['note','Authored signedpackagedsentinel for an owned package smoke test. No captured data.'])
record['smoke']['literalKeyword'],data=invoke('literal-keyword',['search','--mode','keyword','--literal','signedpackagedsentinel','--json'])
values=json.loads(data);assert isinstance(values,list) and len(values)==1 and values[0]['match']=='keyword' and 'signedpackagedsentinel' in values[0]['memory']['text'] and values[0]['memory']['id']==(out/'authored-note.stdout').read_text().strip();record['smoke']['sourceCount']=len(values);record['smoke']['exactAuthoredIDMatchesKeywordResult']=True
record['resources']=[{'path':str(p.relative_to(app)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((app/'Contents/Resources').rglob('*')) if p.is_file()]
archive=out/'OSwind-recording-original-development.zip';subprocess.run(['ditto','-c','-k','--sequesterRsrc','--keepParent',str(app),str(archive)],check=True,cwd=r)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
roundtrip=out/'round-trip';roundtrip.mkdir();subprocess.run(['ditto','-x','-k',str(archive),str(roundtrip)],check=True,cwd=r)
with (out/'round-trip-signature.log').open('xb') as log:subprocess.run(['codesign','--verify','--deep','--strict',str(roundtrip/'OSwind.app')],check=True,stdout=log,stderr=subprocess.STDOUT)
for p in sorted(app.rglob('*')):
 if p.is_file():assert sha(p)==sha(roundtrip/'OSwind.app'/p.relative_to(app)),str(p)
record['developmentArchive']={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'roundTripAllFileHashesAndStrictSignature':True}
durable=Path('/Users/vibhusapra/Documents/OSwind-builds')/('2026-11-04-recording-original-'+sourceCommit[:7]);durable.mkdir()
shutil.copy2(archive,durable/archive.name);assert sha(durable/archive.name)==sha(archive)
record['durableDelivery']={'directory':str(durable),'archive':str(durable/archive.name),'sha256':sha(archive)}
record['verificationWallSeconds']=time.monotonic()-started
check();(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(durable/'build-info.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['resources','executables']}))
