from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parent;r=b.parents[1];q=b/'recording-original-qualification-v1'
assert json.loads((q/'driver-exit-v1.json').read_text())['exitCode']==0
for mode in ['optimized','thread-sanitizer']:
 v=json.loads((q/mode/'result.json').read_text());assert v['exitCode']==0 and v['counts']['failed']==0 and v['inputsAndPriorActualFilesUnchanged']
assert not json.loads((q/'thread-sanitizer/result.json').read_text())['diagnostics']
pins=json.loads((q/'execution-inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']
normal=b/'recording-original-normal-build-v1';assert json.loads((normal/'result.json').read_text())['exitCode']==0
for x in json.loads((normal/'actual-engine.json').read_text()):assert sha(normal/x['path'])==x['sha256']
p=r/'.github/workflows/ci.yml';s=p.read_text();a='          OSWIND_TEST_VAULT_TRACE_DIR: ${{ runner.temp }}/oswind-recording-names/native-traces';assert s.count(a)==1
s=s.replace(a,a+'\n          OSWIND_RECORDING_ORIGINAL_QA_DIR: ${{ runner.temp }}/oswind-recording-names/originals/outgoing\n          OSWIND_TEST_INCOMING_SOURCE_ROOT: ${{ runner.temp }}/oswind-recording-names/originals/incoming')
a='          mkdir -p "$RUNNER_TEMP/oswind-recording-names"';assert s.count(a)==1;s=s.replace(a,'          mkdir -p "$RUNNER_TEMP/oswind-recording-names/originals"')
a="|VaultSessionTests.testNativeRecordingCalendar'";assert s.count(a)==1;s=s.replace(a,"|VaultSessionTests.testNativeRecordingCalendar|SyncOutgoingTests.testRecordingOriginalRecovery|SyncOutgoingTests.testRecordingNameRecovers|SyncOutgoingTests.testRecordingNativeTranscript|SyncOutgoingTests.testRecordingReassignment|SyncOutgoingTests.testRecordingAffiliationScopeChangeAndNativeDeleteInvalidateItsLifetime|SyncOutgoingTests.testRecordingMetadataExplicitDifferentNativeTargetCannotReuseOldAffiliation|SyncIncomingSourceTests.testRecordingOriginalRecovery'")
a='      - name: Retain owned recording-name components and lookup observations';assert s.count(a)==1;s=s.replace(a,'      - name: Retain owned recording-name components, lookup observations and authored original recovery corpora')
a='            ${{ runner.temp }}/oswind-recording-names/native-traces/*.json';assert s.count(a)==1;s=s.replace(a,a+'\n            ${{ runner.temp }}/oswind-recording-names/originals/\n          include-hidden-files: true');p.write_text(s)
(b/'recording-original-ci-edit-v1.json').write_text(json.dumps({'oldInputSHA256':next(x['sha256'] for x in pins['inputs'] if x['path']=='.github/workflows/ci.yml'),'newSHA256':sha(p),'sourceAndActualEnginePinsVerifiedBeforeEdit':True,'scope':'Only the existing recording-names CI job now additionally executes and retains the 26 focused authored original/reassignment controls. The full native job independently discovers all tests.'},indent=2)+'\n');print('CI updated after both exact qualifications passed')
