import AppKit
import Foundation
let app=NSApplication.shared;app.setActivationPolicy(.regular)
guard CommandLine.arguments.count==2 else {fatalError("Owned readiness path required")}
let ready=URL(fileURLWithPath:CommandLine.arguments[1]),window=NSWindow(contentRect:NSRect(x:200,y:180,width:960,height:600),styleMask:[.titled,.closable,.resizable],backing:.buffered,defer:false)
let view=NSView(frame:NSRect(x:0,y:0,width:960,height:600));view.wantsLayer=true
let label=NSTextField(wrappingLabelWithString:"");label.frame=NSRect(x:55,y:65,width:850,height:470);label.font = .systemFont(ofSize:36);view.addSubview(label);window.contentView=view
var sample=0
func update() {
    sample+=1;let dark=sample%2==0
    view.layer?.backgroundColor=(dark ? NSColor(calibratedWhite:0.18,alpha:1):NSColor(calibratedWhite:0.93,alpha:1)).cgColor;label.textColor=dark ? .white:.black
    window.title="OSwind owned changing capture fixture";label.stringValue="OSwind generated capture baseline\n\nSample \(sample) · SOAKFRAME\(sample)\n\nMaya owns the Friday checklist.\nOnly this synthetic window is targeted."
    window.displayIfNeeded()
    let state:[String:Any]=["pid":ProcessInfo.processInfo.processIdentifier,"bundle":Bundle.main.bundleIdentifier ?? "","sample":sample,"wall":Date().timeIntervalSince1970,"executable":Bundle.main.executablePath ?? ""]
    if let data=try? JSONSerialization.data(withJSONObject:state,options:[.sortedKeys]) {try? data.write(to:ready,options:.atomic)}
}
let menu=NSMenu(),item=NSMenuItem(),submenu=NSMenu();submenu.addItem(withTitle:"Quit",action:#selector(NSApplication.terminate(_:)),keyEquivalent:"q");item.submenu=submenu;menu.addItem(item);app.mainMenu=menu
update();window.makeKeyAndOrderFront(nil);app.activate(ignoringOtherApps:true)
let timer=Timer.scheduledTimer(withTimeInterval:30,repeats:true){_ in update()};app.run()
