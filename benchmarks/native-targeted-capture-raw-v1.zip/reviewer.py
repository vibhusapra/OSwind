from pathlib import Path
import argparse,copy,hashlib,json,math,re,sqlite3
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.root.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/'run-manifest.json').read_text());final=json.loads((root/'controller-final.json').read_text());status=json.loads((root/'status.json').read_text());configuration=json.loads((root/'configuration.json').read_text());handle=json.loads((root/'process-handle.json').read_text());ready=json.loads((root/'fixture-ready.json').read_text());prerequisites=json.loads((root/'prerequisites.json').read_text());fixtureExit=json.loads((root/'fixture-exit.json').read_text());attempts=[json.loads(x) for x in (root/'attempts.jsonl').read_text().splitlines()]
assert root.name=='owned-soak-'+configuration['nonce'] and manifest['root']==configuration['root']==str(root) and configuration['bundle']==manifest['fixtureBundle']==ready['bundle']
assert prerequisites==final['prerequisites'] and prerequisites['ready'] and prerequisites['sourceIdentityMatches'] and not prerequisites['screenLocked'] and prerequisites['screenRecording'] and prerequisites['accessibility'] and prerequisites['permissionRequestsMade'] is False
assert manifest['requestedSeconds']==configuration['seconds'] and manifest['intervalSeconds']==configuration['interval'] and ready['pid']==handle['fixturePID']==fixtureExit['pid'] and ready['stableSCObservations']>=3 and fixtureExit['ownedSourceReaped'] is True
assert final['status']==status and final['state']=='completed' and final['workerExit']==0 and final['libraryCreated'] is True
assert final['workerLogSHA256']==sha(root/'worker.log') and final['attemptsSHA256']==sha(root/'attempts.jsonl') and final['resourcesSHA256']==sha(root/'resources.jsonl')
log=(root/'worker.log').read_text();assert re.search(r"Test Case '-\[OSwindCoreTests.NativeTargetedCaptureSoakTests testOwnedPersistentTargetedCapture\]' passed",log) and 'Executed 1 test, with 0 failures' in log and 'skipped' not in log
bundle=Path(manifest['bundle']);proof=manifest['workerProvenance'];assert proof['files']==manifest['bundleFiles'] and all(sha(bundle/p)==h for p,h in proof['files'].items());frozen=bundle.parent
assert all(sha(frozen/p)==h for p,h in proof['resourceFiles'].items())
assert status['pid']==handle['workerLauncherPID'] and status['pid']>0
connection=sqlite3.connect('file:'+str(root/'memory.sqlite')+'?mode=ro&immutable=1',uri=True);connection.row_factory=sqlite3.Row;assert connection.execute('pragma integrity_check').fetchone()[0]=='ok'
sources=[{'id':r['id'],'kind':r['kind'],'payload':json.loads(r['payload']),'embeddingBytes':r['embeddingBytes']} for r in connection.execute('select id,kind,payload,length(embedding) as embeddingBytes from memories order by timestamp,id')]
def validate(rows,terminal,memories):
 assert rows and len(rows)==terminal['attempts'] and [r['attempt'] for r in rows]==list(range(1,len(rows)+1))
 assert terminal['state']=='completed' and terminal['coverageQualified'] is True and terminal['producersJoinedAndStoreClosed'] is True and terminal['errors']==0 and terminal['oversizeGaps']==0
 assert terminal['elapsedWall']>=configuration['seconds']-1 and terminal['elapsedUptime']>0 and terminal['expectedMinimumAttempts']==max(1,math.floor(configuration['seconds']/configuration['interval']*.8)) and len(rows)>=terminal['expectedMinimumAttempts']
 previousSaved=0;previousDeferrals=0
 for i,row in enumerate(rows):
  assert all(type(row[k]) in [int,float] and math.isfinite(row[k]) for k in ['wall','uptime','wallGap','uptimeGap','latencyMS']) and row['latencyMS']>=0 and row['errors']==0 and not row['oversizeGap']
  assert row['admittedThisAttempt'] in [0,1] and row['sourceCount']==row['saved']==previousSaved+row['admittedThisAttempt'] and row['deferrals']==previousDeferrals+(row['admittedThisAttempt']==0)
  if i:
   assert row['wall']>rows[i-1]['wall'] and row['uptime']>rows[i-1]['uptime'] and abs(row['wallGap']-(row['wall']-rows[i-1]['wall']))<.001 and abs(row['uptimeGap']-(row['uptime']-rows[i-1]['uptime']))<.001
   assert row['wallGap']<=configuration['interval']*2+5 and row['uptimeGap']<=configuration['interval']*2+5 and abs(row['wallGap']-row['uptimeGap'])<=5
  previousSaved=row['saved'];previousDeferrals=row['deferrals']
 assert terminal['sourceCount']==terminal['saved']==previousSaved==len(memories)>0 and terminal['captureDeferrals']==previousDeferrals
 assert terminal['minimumAdmissionRate']==.9 and abs(terminal['admissionRate']-len(memories)/len(rows))<1e-12 and terminal['admissionRate']>=.9 and terminal['uninterruptedCapture']==(previousDeferrals==0)
 assert terminal['tailWallGap']<=configuration['interval']*2+5 and terminal['tailUptimeGap']<=configuration['interval']*2+5 and abs(terminal['tailWallGap']-terminal['tailUptimeGap'])<=5
 assert len({m['id'] for m in memories})==len(memories)
 for m in memories:
  value=m['payload'];assert m['id']==value['id'] and m['kind']==value['kind']=='screen' and value['bundleID']==configuration['bundle'] and value['title']==ready['title'] and value['display']=='window-'+str(ready['windowID']) and re.search(r'\bSOAKFRAME\d+\b',value['text'])
  assert value.get('embeddingModel')=='apple-nl-sentence-en-v1' and m['embeddingBytes']>0 and len(value.get('regions',[]))>=3
  assert value['imagePath']=='images/'+m['id']+'.jpg';path=root/value['imagePath'];assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(root)
validate(attempts,status,sources)
faults={}
for name in ['dropped-attempt','duplicate-attempt','hidden-deferral','wrong-terminal-source-count','unjoined-producers','wrong-source-bundle','missing-vector']:
 rows=copy.deepcopy(attempts);terminal=copy.deepcopy(status);memories=copy.deepcopy(sources)
 if name=='dropped-attempt':rows.pop()
 if name=='duplicate-attempt':rows.append(copy.deepcopy(rows[-1]))
 if name=='hidden-deferral':terminal['captureDeferrals']+=1
 if name=='wrong-terminal-source-count':terminal['sourceCount']+=1
 if name=='unjoined-producers':terminal['producersJoinedAndStoreClosed']=False
 if name=='wrong-source-bundle':memories[0]['payload']['bundleID']='org.oswind.other-source'
 if name=='missing-vector':memories[0]['embeddingBytes']=0
 try:validate(rows,terminal,memories)
 except AssertionError:faults[name]='rejected'
 else:raise AssertionError('Accepted altered evidence '+name)
assert len(faults)==7
result={'format':'OSwind native targeted pilot review v1','runRoot':str(root),'workerProductionRuntime':proof['productionRuntimeCommit'],'workerDevelopmentBase':proof['developmentBase'],'workerProvenanceSHA256':manifest['workerProvenanceSHA256'],'sourceCount':len(sources),'attempts':len(attempts),'admissionRate':status['admissionRate'],'captureDeferrals':status['captureDeferrals'],'uninterruptedCapture':status['uninterruptedCapture'],'elapsedWall':status['elapsedWall'],'elapsedUptime':status['elapsedUptime'],'allSourcesExactGeneratedWindow':True,'allSourceVectorsImagesAndOCRPresent':True,'allFrozenWorkerAndResourceBytesUnchanged':True,'fixtureReaped':True,'producerJoinAndStoreClose':True,'rejectedAlteredReceiptControls':faults,'imageFiles':{m['payload']['imagePath']:sha(root/m['payload']['imagePath']) for m in sources},'rawFiles':{p.name:sha(p) for p in root.iterdir() if p.is_file() and p.suffix in ['.json','.jsonl','.log']},'reviewerSHA256':sha(Path(__file__)),'scope':'One bounded real native pilot over persistent controller/store and explicit generated window. Actual terminal exit0, source integrity and all attempt/admission/gap counters checked. Manual requests bypass automatic dedupe/idle/thermal scheduling. No24h, automatic full GUI, physical power/battery, complete sync, distribution or competitor ranking acceptance.'}
assert not a.output.exists();a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceCount','attempts','admissionRate','captureDeferrals','elapsedWall','rejectedAlteredReceiptControls']}))
