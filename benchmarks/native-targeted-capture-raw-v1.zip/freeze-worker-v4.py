from pathlib import Path
import hashlib,json,shutil,subprocess,re
root=Path.cwd();base=root/'.artifacts/native-targeted-soak-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=base/'gated-build-v5.log';text=log.read_text();assert 'Executed 3 tests, with 1 test skipped and 0 failures' in text and not re.search(r'(^.*:\d+:\d+: error:|^error:)',text,re.M)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='ce32d9b6c27b9aa2b249c3341efdec055f53280c'
paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],text=True).splitlines();pins={p:sha(root/p) for p in sorted(set(paths)) if (p.startswith(('Sources/','Tests/','Vendor/','vendor/')) or p in ['Package.swift','Package.resolved']) and (root/p).is_file()};assert len(pins)==692
prior=json.loads((root/'benchmarks/capture-start-readiness-inputs-v1.json').read_text());assert len(prior['inputFiles'])==690 and all(pins[p]==h for p,h in prior['inputFiles'].items())
changes=['Tests/Fixtures/ChangingCaptureFixture.swift','Tests/OSwindCoreTests/NativeTargetedCaptureSoakTests.swift','scripts/native-targeted-capture-soak.py']
assert set(pins)-set(prior['inputFiles'])==set(changes[:2])
source=root/'.build/release/OSwindPackageTests.xctest';frozen=base/'frozen-worker-v3';frozen.mkdir(mode=0o700,exist_ok=False);bundle=frozen/source.name;shutil.copytree(source,bundle,symlinks=True)
# Keep unused test/dependency resources beside the new frozen bundle too.
resources={}
for p in (root/'.build/release').glob('*.bundle'):
 dst=frozen/p.name;shutil.copytree(p,dst,symlinks=True)
 for f in dst.rglob('*'):
  if f.is_file():resources[str(f.relative_to(frozen))]=sha(f)
files={str(p.relative_to(bundle)):sha(p) for p in bundle.rglob('*') if p.is_file()};assert 'Contents/MacOS/OSwindPackageTests' in files
fixture=base/'ChangingCaptureFixture-v3';assert fixture.is_file()
linkage=subprocess.check_output(['otool','-L',str(bundle/'Contents/MacOS/OSwindPackageTests')],text=True);(frozen/'linkage.txt').write_text(linkage)
manifest={'format':'OSwind frozen targeted capture worker v3','productionRuntimeCommit':prior['runtimeCommit'],'developmentBase':head,'workingChanges':{p:sha(root/p) for p in changes},'inputFiles':pins,'inputCount':len(pins),'all690PriorProductionTestInputsUnchanged':True,'bundle':str(bundle),'files':files,'resourceFiles':resources,'fixtureBinary':str(fixture),'fixtureBinarySHA256':sha(fixture),'fixtureSourceSHA256':pins[changes[0]],'gatedBuildLogSHA256':sha(log),'gatedControl':{'defined':3,'passed':2,'skipped':1,'failed':0,'meaning':'Actual typed terminal encoding and bounded startup-deferral controls pass; native method skips without configuration. No capture attempted.'},'toolchain':subprocess.check_output(['swift','--version'],text=True).strip(),'linkageSHA256':sha(frozen/'linkage.txt'),'scope':'New immutable optimized XCTest worker over unchanged production runtime87ddff0 plus one opt-in test/fixture/runner. No real capture,24h,energy,GUI,full suite or ranking acceptance follows from compile/skip. Native path uses production controller and OS frameworks; fixture is generated. External platform/toolchain dependencies remain external; no code is rebuilt/resigned after freezing.'}
(frozen/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'bundle':str(bundle),'provenance':str(frozen/'provenance.json'),'bundleFiles':len(files),'resourceFiles':len(resources),'inputCount':len(pins),'gatedControl':'two actual encoding/startup control passes, one explicit native skip, zero capture'}))
