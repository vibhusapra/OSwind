from pathlib import Path
import os,json,hashlib,subprocess,time,re,shutil
out=Path(__file__).resolve().parent;b=out.parent;r=b.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=b/'calendar-parent-refresh-fixed-v1';assert json.loads((prior/'result.json').read_text())['exitCode']==0
package=json.loads((b/'normal-calendar-completion-package-v1/result.json').read_text());assert package['exitCode']==0
assert package['source']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
old=json.loads((prior/'inputs.json').read_text())
for row in old['inputs']:assert sha(r/row['path'])==row['sha256'],row['path']
protected=old['protectedFrozen'][:]
for row in json.loads((b/'frozen-calendar-parent-refresh-fixed-v1.json').read_text()):protected.append({'path':str(b/row['path']),'sha256':row['sha256']})
for name,row in package['executables'].items():protected.append({'path':str(Path(package['app'])/'Contents/MacOS'/name),'sha256':row['packagedSHA256']})
for row in [package['developmentArchive'],package['durableDelivery']]:protected.append({'path':row.get('path') or row['archive'],'sha256':row['sha256']})
for row in protected:assert sha(Path(row['path']))==row['sha256'],row['path']
files=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=r,text=True).splitlines()))
inputs=[{'path':p,'sha256':sha(r/p)} for p in files if (r/p).is_file()]
pins={'baseSource':package['source'],'inputs':inputs,'protectedFrozen':protected}
with (out/'inputs.json').open('x') as f:json.dump(pins,f,indent=2);f.write('\n')
for row in inputs:
 p=out/'source'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/row['path'],p)
print(json.dumps({'inputs':len(inputs),'protected':len(protected),'runtime':pins['baseSource']}),flush=True)

def check():
 for x in pins['inputs']:assert sha(r/x['path'])==x['sha256'],x['path']
 for x in pins['protectedFrozen']:assert sha(Path(x['path']))==x['sha256'],x['path']
check()
selection='RecordingCalendar|RecordingDetailsTests|RecordingNamesModelTests|RecordingNameRenderTests|MeetingsModelTests|MeetingContextTests|MeetingRequestTests|VaultSessionTests.testNativeRecordingName|VaultSessionTests.testNativeRecordingCalendar'
for mode in ['optimized','thread-sanitizer']:
 d=out/mode;d.mkdir();env=os.environ.copy();env.update({'OSWIND_TEST_NATIVE_VAULT':'1','OSWIND_TEST_NATIVE_SYNC_KEYCHAIN':'1','OSWIND_RECORDING_NAMES_UI_QA_DIR':str(d/'name-components'),'OSWIND_RECORDING_SCOPE_UI_DIR':str(d/'scope-components'),'OSWIND_RECORDED_MEETING_UI_QA_DIR':str(d/'recording-components'),'OSWIND_RECORDING_CALENDAR_UI_QA_DIR':str(d/'calendar-components'),'OSWIND_RECORDING_PRIOR_WRITER_CLI':str(r/'.artifacts/recording-view-performance-v1/frozen-normal-release-v1/oswindctl'),'OSWIND_RECORDING_WRITER_QA_DIR':str(d/'older-cli'),'OSWIND_TEST_VAULT_TRACE_DIR':str(d/'native-traces')})
 args=['-c','release'] if mode=='optimized' else ['--sanitize','thread','--scratch-path',str(b/'calendar-integration-v1/tsan-build')]
 if mode=='optimized':env['OSWIND_SESSION_NAME_BENCH_DIR']=str(d/'lookup-benchmark')
 command=['swift','test',*args,'--jobs','4','--filter',selection];start=time.monotonic()
 with (d/'test.log').open('xb') as log:p=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 check();text=(d/'test.log').read_text();methods=re.findall(r"Test Case '-\[([^\]]+)\]' (passed|skipped|failed) \(([0-9.]+) seconds\)",text)
 result={'source':pins['baseSource'],'command':command,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start,'inputsAndPriorActualEnginesUnchanged':True,'logSHA256':sha(d/'test.log'),'defined':len(methods),'counts':{s:sum(status==s for _,status,_ in methods) for s in ['passed','skipped','failed']},'skips':[x for x in text.splitlines() if 'Test skipped -' in x],'issues':[x for x in text.splitlines() if ' error: ' in x or 'WARNING: ThreadSanitizer' in x],'actualEngineFrozen':False}
 if 'Build complete!' in text and methods:
  products=r/'.build/arm64-apple-macosx/release' if mode=='optimized' else out/'tsan-build/arm64-apple-macosx/debug'
  frozen=d/'actual-engine';frozen.mkdir();shutil.copy2(products/'oswindctl',frozen/'oswindctl');shutil.copytree(products/'OSwindPackageTests.xctest',frozen/'OSwindPackageTests.xctest')
  manifest=[{'path':str(p.relative_to(out)),'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)} for p in sorted(frozen.rglob('*')) if p.is_file()]
  (d/'actual-engine.json').write_text(json.dumps(manifest,indent=2)+'\n');result['actualEngineFrozen']=True
  for x in manifest:pins['protectedFrozen'].append({'path':str(out/x['path']),'sha256':x['sha256']})
 (d/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['command','issues','skips']}),flush=True)
 if p.returncode:print(text[-2500:],flush=True);raise SystemExit(p.returncode)
check()
