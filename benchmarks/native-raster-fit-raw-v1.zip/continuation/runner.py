from pathlib import Path
import hashlib,json,os,subprocess,time,shutil
root=Path.cwd();base=root/'.artifacts/snapshot-source-fit-v1';run=base/'qualification-v1';out=base/'continuation-v1';out.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());prior=json.loads((run/'results.json').read_text())
assert [s['exit'] for s in prior['stages']]==[0,0,0,0,1]
assert "module 'OSwindCore' was not compiled for testing" in (run/'release-build-tests.log').read_text()
result={'format':'OSwind raster fit release continuation v1','inputManifestSHA256':sha(run/'inputs.json'),'retainedPriorResultsSHA256':sha(run/'results.json'),'runnerSHA256':sha(Path(__file__)),'reason':'swift build -c release --build-tests does not enable @testable imports. Optimized tests already passed; build production products normally. No successful test/build/package is repeated.','stages':[]}
env={k:v for k,v in os.environ.items() if not k.startswith('OSWIND_TEST_')}
for name,cmd,extra in [('release-build',['swift','build','-c','release'],{}),('package',['bash','scripts/build-app.sh','release'],{'OSWIND_APP_OUTPUT':str(out/'OSwind.app')})]:
    assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items());print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
    with log.open('xb') as f:rc=subprocess.run(cmd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT).returncode
    result['stages'].append({'name':name,'command':cmd,'environment':extra,'exit':rc,'wallSeconds':time.monotonic()-start,'log':str(log.relative_to(root)),'sha256':sha(log)});(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('FINISH',name,rc,flush=True)
    assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
    if rc:raise SystemExit(rc)
    if name=='release-build':
        candidate=run/'candidate-release';candidate.mkdir(mode=0o700,exist_ok=False);shutil.copy2(root/'.build/release/oswindctl',candidate/'oswindctl')
        (candidate/'provenance.json').write_text(json.dumps({'baseSource':inputs['baseSource'],'inputManifestSHA256':sha(run/'inputs.json'),'workingChanges':inputs['workingChanges'],'binarySHA256':sha(candidate/'oswindctl'),'sourceBuildStage':'continuation-v1/release-build','scope':'Same694 pinned inputs. Production release build; original optimized test stage passed, subsequent --build-tests module-testability failure retained.'},indent=2)+'\n')
print('CONTINUATION_COMPLETE',flush=True)
