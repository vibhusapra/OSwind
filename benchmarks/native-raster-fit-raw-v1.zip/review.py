from pathlib import Path
import hashlib,json,re,subprocess,struct

root=Path.cwd();base=root/'.artifacts/snapshot-source-fit-v1';run=base/'qualification-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());results=json.loads((run/'results.json').read_text())
assert inputs['baseSource']==results['baseSource']=='fffebfb440ccde66f3f242076e625274a56e5576'
assert len(inputs['inputFiles'])==694 and len(inputs['workingChanges'])==6
assert all(sha(root/p)==h for p,h in inputs['inputFiles'].items())
assert results['inputManifestSHA256']==sha(run/'inputs.json') and results['runnerSHA256']==sha(base/'qualify-v1.py')
prior=json.loads((root/'benchmarks/native-targeted-capture-inputs-v1.json').read_text())['inputFiles']
assert len(prior)==692
assert set(inputs['inputFiles'])-set(prior)=={'Sources/OSwindCore/NativeCaptureConfiguration.swift','Tests/OSwindCoreTests/NativeCaptureConfigurationTests.swift'}
changed={p for p in prior if prior[p]!=inputs['inputFiles'][p]}
assert changed=={'Sources/OSwindCore/ReplayScreenSource.swift','Sources/OSwindCore/SnapshotCaptureSource.swift','Sources/OSwindCore/SnapshotRegions.swift','Tests/OSwindCoreTests/SnapshotRegionTests.swift'}
pattern=re.compile(r"^Test Case '-\[([^ ]+) ([^\]]+)\]' (passed|failed|skipped)(?: |\.)",re.M)
def rows(t):
    found=[(a+'.'+b,c) for a,b,c in pattern.findall(t)]
    assert len(found)==len(set(a for a,b in found))
    return dict(found)
new={'OSwindCoreTests.NativeCaptureConfigurationTests.'+m for m in re.findall(r'func (test\w+)\(', (root/'Tests/OSwindCoreTests/NativeCaptureConfigurationTests.swift').read_text())}
assert len(new)==6
def inspect(t,count,passed,skipped):
    r=rows(t)
    assert len(r)==count and list(r.values()).count('passed')==passed and list(r.values()).count('skipped')==skipped
    assert all(r[x]=='passed' for x in new)
    assert f'Executed {count} tests, with {skipped} tests skipped and 0 failures' in t
    assert not any(s in t for s in ['WARNING: ThreadSanitizer','ThreadSanitizer: data race','unexpected signal','error: -['])
    return r
names=['debug-build-tests','full-debug','affected-tsan','affected-optimized','release-build-tests']
assert [s['name'] for s in results['stages']]==names
selector='NativeCaptureConfigurationTests|Snapshot|Replay|CaptureStartReadiness|AccessibilityTextCapture|TextObservationCapture|WorkspaceWakeLifecycle'
commands=[['swift','build','--build-tests'],['swift','test','--skip-build'],['swift','test','--sanitize=thread','--filter',selector],['swift','test','-c','release','--filter',selector],['swift','build','-c','release','--build-tests']]
reports=[];selections={}
for s,cmd in zip(results['stages'],commands):
    assert s['exit']==(1 if s['name']=='release-build-tests' else 0) and s['command']==cmd and sha(root/s['log'])==s['sha256']
    assert s['environment']=={}
    if s['name'] in ['full-debug','affected-tsan','affected-optimized']:
        count,passed,skipped=(2706,2550,156) if s['name']=='full-debug' else (187,181,6)
        r=inspect((root/s['log']).read_text(),count,passed,skipped);selections[s['name']]=r
        reports.append({'mode':s['name'],'defined':count,'passed':passed,'failed':0,'skipped':sorted(k for k,v in r.items() if v=='skipped'),'logSHA256':s['sha256'],'wallSeconds':s['wallSeconds']})
assert selections['affected-tsan']==selections['affected-optimized']
assert all(selections['full-debug'][k]==v for k,v in selections['affected-tsan'].items())
failure=results['stages'][-1]
assert "module 'OSwindCore' was not compiled for testing" in (root/failure['log']).read_text()
continuation=base/'continuation-v1';tail=json.loads((continuation/'results.json').read_text())
assert tail['inputManifestSHA256']==sha(run/'inputs.json') and tail['retainedPriorResultsSHA256']==sha(run/'results.json') and tail['runnerSHA256']==sha(base/'continue-v1.py')
assert [s['name'] for s in tail['stages']]==['release-build','package']
for s,cmd in zip(tail['stages'],[['swift','build','-c','release'],['bash','scripts/build-app.sh','release']]):
    assert s['exit']==0 and s['command']==cmd and sha(root/s['log'])==s['sha256']
    assert s['environment']==({'OSWIND_APP_OUTPUT':str(continuation/'OSwind.app')} if s['name']=='package' else {})
text=(run/'affected-tsan.log').read_text();method=next(iter(new)).rsplit('.',1)[1]
line=next(l for l in text.splitlines() if method in l and "' passed" in l)
faults={}
for name,bad in {'drop-case':text.replace(line,'',1),'duplicate-case':text+'\n'+line,'failed-case':text.replace(line,line.replace("' passed","' failed"),1),'rename-new-case':text.replace(method,'testUnrelatedIdentity'),'missing-terminal-summary':text.replace('Executed 187 tests, with 6 tests skipped and 0 failures','missing summary'),'race-diagnostic':text+'\nWARNING: ThreadSanitizer: data race'}.items():
    try:inspect(bad,187,181,6)
    except (AssertionError,KeyError):faults[name]='rejected'
    else:raise AssertionError('Accepted altered log '+name)
candidateReports={}
for mode in ['debug','release']:
    folder=run/('candidate-'+mode);p=json.loads((folder/'provenance.json').read_text())
    assert p['baseSource']==inputs['baseSource'] and p['inputManifestSHA256']==sha(run/'inputs.json') and p['workingChanges']==inputs['workingChanges'] and p['binarySHA256']==sha(folder/'oswindctl')
    candidateReports[mode]={'binarySHA256':p['binarySHA256'],'provenanceSHA256':sha(folder/'provenance.json')}
package=continuation/'OSwind.app';files={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file()}
def executable_payload(path):
    b=path.read_bytes();header=struct.unpack_from('<8I',b);assert header[0]==0xfeedfacf
    offset=32;signature=None;mutable=bytearray(b)
    for _ in range(header[4]):
        command,length=struct.unpack_from('<II',b,offset);assert length>=8 and offset+length<=32+header[5]
        if command==0x1d:
            assert signature is None and length==16
            start,size=struct.unpack_from('<II',b,offset+8);assert start+size==len(b)
            signature=start;mutable[offset+12:offset+16]=bytes(4)
        if command==0x19 and b[offset+8:offset+24].rstrip(b'\0')==b'__LINKEDIT':
            # Signing changes only this segment's rounded VM/file sizes and the
            # code-signature data size. Every other pre-signature byte matches.
            mutable[offset+32:offset+40]=bytes(8);mutable[offset+48:offset+56]=bytes(8)
        offset+=length
    assert signature is not None and offset==32+header[5] and signature>offset
    return signature,hashlib.sha256(mutable[:signature]).hexdigest()
releasePayload=executable_payload(run/'candidate-release/oswindctl')
packagedPayload=executable_payload(package/'Contents/MacOS/oswindctl')
assert releasePayload==packagedPayload

assert {'Contents/MacOS/OSwind','Contents/MacOS/oswind-preparation-guardian','Contents/Info.plist'}.issubset(files)
codesign=subprocess.run(['codesign','--verify','--deep','--strict',str(package)],capture_output=True,text=True)
assert codesign.returncode==0
padding=json.loads((base/'pilot-padding-inspection-v1.json').read_text())
defaults=json.loads((base/'configuration-defaults-v1.json').read_text())
assert defaults['scalesToFit'] is False and defaults['preservesAspectRatio'] is True
result={'format':'OSwind native raster fit review v2','baseSource':inputs['baseSource'],'inputCount':694,'unchangedPriorInputs':688,'workingChanges':inputs['workingChanges'],'inputManifestSHA256':sha(run/'inputs.json'),'runnerSHA256':results['runnerSHA256'],'reviewerSHA256':sha(Path(__file__)),'stages':reports,'retainedBuildFailure':failure,'releaseContinuation':tail,'newMethodsPassed':sorted(new),'rejectedAlteredLogControls':faults,'candidates':candidateReports,'newPackage':{'path':str(package),'files':files,'strictCodeSignatureVerificationExit':codesign.returncode,'releasePayloadEquality':{'signatureOffset':releasePayload[0],'normalizedPreSignatureSHA256':releasePayload[1],'rule':'Thin64 Mach-O; normalize only code-signature datasize and __LINKEDIT vmsize/filesize. Every other pre-signature byte equals copied release candidate.'}},'retainedPaddingObservation':{'file':str((base/'pilot-padding-inspection-v1.json').relative_to(root)),'sha256':sha(base/'pilot-padding-inspection-v1.json'),'observation':padding},'actualSDKDefaults':defaults,'scope':'Software/native-configuration qualification only. Old pilot image padding observed. Full/left/right actual native pixel oracle remains pending existing unlocked session; no crop-safety, new-runtime 24-hour, energy, complete sync, production signing/notarization or competitor-rank claim.'}
out=run/'reviewed-v2.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'inputCount':694,'stages':[{k:r[k] for k in ['mode','defined','passed','failed']} for r in reports],'alteredControls':len(faults),'reviewSHA256':sha(out)}))
