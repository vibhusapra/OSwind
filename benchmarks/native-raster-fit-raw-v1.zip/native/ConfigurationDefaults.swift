import Foundation
import ScreenCaptureKit
let configuration=SCStreamConfiguration()
let value:[String:Any]=["scalesToFit":configuration.scalesToFit,"preservesAspectRatio":configuration.preservesAspectRatio,"width":configuration.width,"height":configuration.height,"captureResolutionRawValue":configuration.captureResolution.rawValue,"permissionRequestsMade":false]
print(String(decoding:try JSONSerialization.data(withJSONObject:value,options:[.sortedKeys,.prettyPrinted]),as:UTF8.self))
