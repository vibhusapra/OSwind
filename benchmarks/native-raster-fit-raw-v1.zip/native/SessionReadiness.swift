import Foundation
import ApplicationServices
import CoreGraphics
let session=(CGSessionCopyCurrentDictionary() as? [String:Any]) ?? [:]
let locked=session.isEmpty || session["CGSSessionScreenIsLocked"] as? Bool == true || session[kCGSessionOnConsoleKey as String] as? Bool == false
let state:[String:Any]=["screenLocked":locked,"screenRecording":CGPreflightScreenCaptureAccess(),"accessibility":AXIsProcessTrusted(),"permissionRequestsMade":false,"wall":Date().timeIntervalSince1970]
print(String(decoding:try JSONSerialization.data(withJSONObject:state,options:[.sortedKeys]),as:UTF8.self))
