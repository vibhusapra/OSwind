import Foundation
import CoreGraphics
import ImageIO
import CryptoKit
let path=CommandLine.arguments[1],url=URL(fileURLWithPath:path),data=try Data(contentsOf:url)
guard let source=CGImageSourceCreateWithData(data as CFData,nil),let image=CGImageSourceCreateImageAtIndex(source,0,nil) else {fatalError("Invalid owned image")}
let width=image.width,height=image.height
guard width>0,height>0,width<=8192,height<=8192,width*height<=16_777_216 else {fatalError("Image exceeds bounded inspection size")}
var pixels=[UInt8](repeating:0,count:width*height*4)
let rendered=pixels.withUnsafeMutableBytes {bytes->Bool in
    guard let space=CGColorSpace(name:CGColorSpace.sRGB),let context=CGContext(data:bytes.baseAddress,width:width,height:height,bitsPerComponent:8,bytesPerRow:width*4,space:space,bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue|CGBitmapInfo.byteOrder32Big.rawValue) else {return false}
    context.interpolationQuality = .none;context.draw(image,in:CGRect(x:0,y:0,width:width,height:height));return true
}
guard rendered else {fatalError("Cannot inspect owned raster")}
var magenta=0,green=0,white=0,total=0,lastDark = -1
for y in height/4..<height*3/4 {for x in 0..<width {
    let i=(y*width+x)*4,r=Int(pixels[i]),g=Int(pixels[i+1]),b=Int(pixels[i+2]);total+=1
    if r>g+60 && b>g+60 {magenta+=1};if g>r+60 && g>b+60 {green+=1};if min(r,g,b)>245 {white+=1}
}}
for x in 0..<width {let i=((height/2)*width+x)*4,v=[Int(pixels[i]),Int(pixels[i+1]),Int(pixels[i+2])];if v.max()!<180 && v.max()!-v.min()!<30 {lastDark=x}}
let result:[String:Any]=["path":url.path,"sha256":SHA256.hash(data:data).map {String(format:"%02x",$0)}.joined(),"width":width,"height":height,"centralInspectedPixels":total,"strongMagentaPixels":magenta,"strongGreenPixels":green,"whitePixels":white,"lastDarkNeutralPixelInMidRow":lastDark,"rightPixelsAfterDarkSpan":lastDark<0 ? -1:width-lastDark-1,"magentaFraction":Double(magenta)/Double(total),"greenFraction":Double(green)/Double(total),"whiteFraction":Double(white)/Double(total)]
print(String(decoding:try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]),as:UTF8.self))
