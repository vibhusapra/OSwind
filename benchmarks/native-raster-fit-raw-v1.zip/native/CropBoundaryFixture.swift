import AppKit
import Foundation
import ScreenCaptureKit
let app=NSApplication.shared;app.setActivationPolicy(.regular)
guard CommandLine.arguments.count==2 else {fatalError("Owned readiness path required")}
let ready=URL(fileURLWithPath:CommandLine.arguments[1]),window=NSWindow(contentRect:NSRect(x:200,y:180,width:960,height:600),styleMask:[.titled,.closable],backing:.buffered,defer:false)
window.title="OSwind crop boundary fixture"
let view=NSView(frame:NSRect(x:0,y:0,width:960,height:600));view.wantsLayer=true
for (x,color,text) in [(CGFloat(0),NSColor(srgbRed:0.05,green:0.9,blue:0.05,alpha:1),"INSIDE_LEFT_7429"),(CGFloat(480),NSColor(srgbRed:0.9,green:0.05,blue:0.9,alpha:1),"OUTSIDE_RIGHT_7429")] {
    let half=NSView(frame:NSRect(x:x,y:0,width:480,height:600));half.wantsLayer=true;half.layer?.backgroundColor=color.cgColor
    let label=NSTextField(labelWithString:text);label.frame=NSRect(x:20,y:250,width:440,height:70);label.font = .systemFont(ofSize:30);label.textColor = .black;half.addSubview(label);view.addSubview(half)
}
window.contentView=view
let menu=NSMenu(),item=NSMenuItem(),submenu=NSMenu();submenu.addItem(withTitle:"Quit",action:#selector(NSApplication.terminate(_:)),keyEquivalent:"q");item.submenu=submenu;menu.addItem(item);app.mainMenu=menu
window.makeKeyAndOrderFront(nil);app.activate(ignoringOtherApps:true)
let readiness=Task { @MainActor in
    var previous:String?,stable=0
    while !Task.isCancelled {
        do {
            let content=try await SCShareableContent.excludingDesktopWindows(true,onScreenWindowsOnly:true)
            let own=content.windows.filter {$0.owningApplication?.processID==ProcessInfo.processInfo.processIdentifier && $0.windowID==CGWindowID(window.windowNumber) && $0.windowLayer==0 && $0.title==window.title}
            if window.isVisible,own.count==1,let source=own.first {
                let signature="\(source.windowID)|\(source.title ?? "")|\(source.frame)";stable=signature==previous ? stable+1:1;previous=signature
                if stable>=3 {
                    let filter=SCContentFilter(desktopIndependentWindow:source)
                    let state:[String:Any]=["pid":ProcessInfo.processInfo.processIdentifier,"bundle":Bundle.main.bundleIdentifier ?? "","executable":Bundle.main.executablePath ?? "","windowID":source.windowID,"title":source.title ?? "","frame":NSStringFromRect(source.frame),"filterContentRect":NSStringFromRect(filter.contentRect),"pointPixelScale":Double(filter.pointPixelScale),"backingScale":window.backingScaleFactor,"stableSCObservations":stable,"leftColor":"green","rightColor":"magenta","expectedLeftCropMagentaPixels":0]
                    try JSONSerialization.data(withJSONObject:state,options:[.sortedKeys,.prettyPrinted]).write(to:ready,options:.atomic);return
                }
            } else {stable=0;previous=nil}
        } catch {stable=0;previous=nil}
        try? await Task.sleep(for:.milliseconds(200))
    }
}
app.run()
