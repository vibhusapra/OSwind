from pathlib import Path
import hashlib,json,os,plistlib,shutil,sqlite3,subprocess,time,uuid
base=Path('.artifacts/snapshot-source-fit-v1').resolve();run=base/'candidate-native-v1';run.mkdir(mode=0o700,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cli=base/'qualification-v1/candidate-debug/oswindctl';proof=json.loads((base/'qualification-v1/candidate-debug/provenance.json').read_text());assert sha(cli)==proof['binarySHA256'];binarySHA=sha(cli)
bundle='com.oswind.fixture.crop.'+uuid.uuid4().hex;app=run/'Fixture.app';macos=app/'Contents/MacOS';macos.mkdir(parents=True);fixture=macos/'CropBoundaryFixture';shutil.copy2(base/'CropBoundaryFixture',fixture);(app/'Contents/Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':bundle,'CFBundleName':'OSwind Crop Boundary Fixture','CFBundleExecutable':'CropBoundaryFixture','CFBundlePackageType':'APPL','NSHighResolutionCapable':True}));subprocess.run(['codesign','--force','--deep','--sign','-',str(app)],check=True,capture_output=True)
report={'format':'OSwind generated native crop baseline v1','candidateBase':proof['baseSource'],'candidateWorkingChanges':proof['workingChanges'],'candidateInputManifestSHA256':proof['inputManifestSHA256'],'cliSHA256':binarySHA,'fixtureSourceSHA256':sha(base/'CropBoundaryFixture.swift'),'fixtureBinarySHA256':sha(fixture),'driverSHA256':sha(Path(__file__)),'bundle':bundle,'cases':[],'scope':'Actual explicitly targeted generated green-left/magenta-right native window. Left-half crop must not include strong magenta pixels. No user source/window pixels requested.'}
def save():(run/'report.json').write_text(json.dumps(report,indent=2)+'\n')
log=(run/'fixture.log').open('xb');process=subprocess.Popen([str(fixture),str(run/'ready.json')],stdout=log,stderr=subprocess.STDOUT)
try:
 deadline=time.monotonic()+25
 while not (run/'ready.json').exists() and process.poll() is None and time.monotonic()<deadline:time.sleep(.05)
 assert (run/'ready.json').exists(),'Own stable fixture unavailable';ready=json.loads((run/'ready.json').read_text());assert ready['bundle']==bundle and ready['pid']==process.pid and ready['stableSCObservations']>=3;report['ready']=ready;save();print('OWN_FIXTURE_READY',flush=True)
 for case,crop in [('full',None),('left',{'x':0,'y':0,'width':.5,'height':1}),('right',{'x':.5,'y':0,'width':.5,'height':1})]:
  data=run/(case+'-library');data.mkdir(mode=0o700);settings={'profile':'light','captureOnLaunch':False,'allDisplays':False,'visualCaptureMode':'snapshots','automaticMaintenance':False,'apiEnabled':False,'audioEnabled':False,'systemAudioEnabled':False}
  if crop:settings['snapshotRegions']={'focusedWindowCrop':crop}
  (data/'settings.json').write_text(json.dumps(settings)+'\n');observations=[];source=None
  for index in range(3):
   r=subprocess.run([str(cli),'--data',str(data),'capture','--app-bundle',bundle],capture_output=True,text=True,timeout=60);row={'attempt':index+1,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};observations.append(row);report['activeCase']={'name':case,'attempts':observations};save()
   assert r.returncode==0,(case,r.stderr)
   db=sqlite3.connect('file:'+str(data/'memory.sqlite')+'?mode=ro',uri=True);values=[json.loads(x[0]) for x in db.execute('select payload from memories')];db.close();assert len(values)<=1
   if values:source=values[0];break
   assert 'Locked' not in r.stdout and 'permission' not in r.stdout.lower(),r.stdout
   time.sleep(.2)
  assert source is not None,(case,observations);assert source['bundleID']==bundle and source['kind']=='screen' and source['imagePath']=='images/'+source['id']+'.jpg'
  raster=data/source['imagePath'];out=subprocess.run([str(base/'image-geometry-probe-v1'),str(raster)],capture_output=True,text=True,timeout=30);assert out.returncode==0,out.stderr;pixels=json.loads(out.stdout)
  report['cases'].append({'name':case,'crop':crop,'attempts':observations,'source':source,'pixels':pixels});report.pop('activeCase',None);save();print('CAPTURED',case,pixels['width'],pixels['height'],'magenta',pixels['magentaFraction'],'green',pixels['greenFraction'],flush=True)
 left=next(c for c in report['cases'] if c['name']=='left');full=next(c for c in report['cases'] if c['name']=='full');assert full['pixels']['strongMagentaPixels']>0 and full['pixels']['strongGreenPixels']>0
 right=next(c for c in report['cases'] if c['name']=='right');assert left['pixels']['strongMagentaPixels']==0 and right['pixels']['strongGreenPixels']==0;assert full['pixels']['whitePixels']==left['pixels']['whitePixels']==right['pixels']['whitePixels']==0;report.update(state='candidate-verified',leftCropUnexpectedStrongMagentaPixels=left['pixels']['strongMagentaPixels'],allSourcesExactOwnedBundle=True,cliUnchanged=sha(cli)==binarySHA);save();print(json.dumps({k:report[k] for k in ['state','leftCropUnexpectedStrongMagentaPixels','allSourcesExactOwnedBundle','cliUnchanged']}),flush=True)
except BaseException as error:report.update(state='failed',error=str(error));save();raise
finally:
 if process.poll() is None:
  process.terminate()
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:process.kill();process.wait()
 log.close();(run/'fixture-exit.json').write_text(json.dumps({'pid':process.pid,'exit':process.returncode,'ownedSourceReaped':True})+'\n')
