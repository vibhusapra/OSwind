from pathlib import Path
import hashlib,json,os,subprocess,zipfile

root=Path.cwd();base=root/'.artifacts/snapshot-source-fit-v1';run=base/'qualification-v1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((run/'inputs.json').read_text());review=json.loads((run/'reviewed-v2.json').read_text())
assert review['reviewerSHA256']==sha(base/'review-v2.py') and review['inputManifestSHA256']==sha(run/'inputs.json')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip()==inputs['baseSource']
assert set(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','HEAD'],text=True).splitlines())==set(inputs['workingChanges'])
tree={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',source]).split(b'\0'):
    if entry:
        h,p=entry.split(b'\t',1);tree[p.decode()]=h.decode().split()[2]
for p,h in inputs['inputFiles'].items():
    path=root/p;b=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
    assert hashlib.sha256(b).hexdigest()==h and tree[p]==hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
protected={}
for entry in subprocess.check_output(['git','ls-tree','-r','-z',inputs['baseSource'],'--','benchmarks','docs/features.json','docs/landscape.html']).split(b'\0'):
    if entry:
        h,p=entry.split(b'\t',1);b=(root/p.decode()).read_bytes()
        assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==h.decode().split()[2]
        protected[p.decode()]=hashlib.sha256(b).hexdigest()
files={'review.json':run/'reviewed-v2.json','inputs.json':run/'inputs.json','results.json':run/'results.json','qualify.py':base/'qualify-v1.py','review.py':base/'review-v2.py','publish.py':Path(__file__),'native/default-configuration.json':base/'configuration-defaults-v1.json','native/pilot-padding-observation.json':base/'pilot-padding-inspection-v1.json','native/ConfigurationDefaults.swift':base/'ConfigurationDefaults.swift','native/ImageGeometryProbe.swift':base/'ImageGeometryProbe.swift','native/SessionReadiness.swift':base/'SessionReadiness.swift','native/CropBoundaryFixture.swift':base/'CropBoundaryFixture.swift','native/pending-baseline.py':base/'reproduce-v2.py','native/pending-candidate.py':base/'verify-candidate-v1.py'}
for s in json.loads((run/'results.json').read_text())['stages']:files['logs/'+s['name']+'.log']=root/s['log']
files['retained-review-failure/review-v1.py']=base/'review-v1.py'
files['retained-review-failure/controller.log']=base/'review-controller-v1.log'
files['continuation/results.json']=base/'continuation-v1/results.json'
files['continuation/runner.py']=base/'continue-v1.py'
for s in json.loads((base/'continuation-v1/results.json').read_text())['stages']:files['continuation/'+s['name']+'.log']=root/s['log']
for p in inputs['workingChanges']:files['source/'+p]=root/p
for mode in ['debug','release']:files['candidates/'+mode+'-provenance.json']=run/('candidate-'+mode)/'provenance.json'
payload={n:p.read_bytes() for n,p in files.items()}
payload['README.txt']=(f'OSwind native raster configuration source {source}.694 committed inputs,688 preceding inputs unchanged; six changed files. Full Debug2550pass156skip, focused TSan/optimized181pass6skip each. Six new native-configuration/geometry methods pass each, six altered-log controls reject. Release app strict ad-hoc code signature verified; not Developer ID/notarized distribution. Prior generated native pilot image1280x842 has320blank pixels after actual dark-window edge. Current independent-window configuration caps resolution at actual filter.pointPixelScale, explicitly fills raster, disables shadow/cursor; replay output remains even. Display crop points unchanged. Actual new-runtime full/left/right pixel oracle is pending an unlocked session. SDK-only own-window probe refused while locked; this is not a pixel pass. No native crop-safety/24h/energy/fullsync/top-three claim. Exact earlier publications/features/landscape protected. This explicit archive contains source/logs/receipts only; no executable, library, DB, keys or credential account inventory.\n').encode()
archive=root/'benchmarks/native-raster-fit-raw-v1.zip';manifest=root/'benchmarks/native-raster-fit-inputs-v1.json';receipt=root/'benchmarks/native-raster-fit-v1.json'
assert all(not p.exists() for p in [archive,manifest,receipt])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(payload.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:assert len(z.namelist())==len(set(z.namelist()))==len(payload) and all(z.read(n)==b for n,b in payload.items())
with manifest.open('x') as f:json.dump({**inputs,'sourceCommit':source},f,indent=2);f.write('\n')
result={**review,'sourceCommit':source,'allCommittedInputBlobsMatch':True,'inputManifest':manifest.name,'inputManifestSHA256':sha(manifest),'reviewSHA256':sha(run/'reviewed-v2.json'),'publisherSHA256':sha(Path(__file__)),'rawEvidence':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(payload),'allArchivedBytesComparedToInputs':True,'files':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())}},'protectedPublications':{'files':len(protected),'allBaseBytesUnchanged':True}}
with receipt.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'sourceCommit':source,'rawSHA256':sha(archive),'rawBytes':archive.stat().st_size,'rawMembers':len(payload),'protectedBaseFiles':len(protected)}))
